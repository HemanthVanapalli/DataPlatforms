#paysafe-upf-files-delta-orchestration
This application is intended for pushing delta data files to vertica

## Release Notes

## Version 5.0.6
*[GDEP-996] Added crons for dnb jobs

## Version 5.0.5
*[GDEP-846] Added SparkSubmitJobsInvokerStateMachine

## Version 5.0.4
[GDEP-841] Added paymentRegister schedular in DBT-workflows

## Version 5.0.3
[GDEP-944] PII column addition to MerchantDemographicsDaily in blue zone

## Version 5.0.2
[GDEP-944] PII column addition to MerchantDemographicsMonthly in blue zone

## Version 5.0.1
[GDEP-841] Added paymentRegister in DBT-workflows 

## Version 5.0.0
[GDEP-848] Ec2 instance creation for the DBT setup
[GDEP-915] Added scripts to run dbt jobs on the Ec2 instance
[GDEP-917] Added DBT project to generate the reports

## Version 4.8.3
*[GDEP-845] Updated North Merchant Demographics BillingProgram value Daily.

## Version 4.8.2
*[GDEP-801] Updated North Merchant Demographics BillingProgram value.

## Version 4.8.1
*[GDEP-782] Updated Transactions Fiserv_Omaha sql for CardNumber in grey and blue zone .

## version 4.8.0
*[GDEP-633] Updated new ConfigId in DATASINK_INVOKER_PPBI.

## Version 4.7.9
*[GDEP-637] Updated VolumeCardMonthly config with Distinct in grey and blue zone .

## Version 4.7.8
*[GDEP-637] MM-Input_prod spark config change for CDM and Data Transformation job.

## Version 4.7.7
*[GDEP-650] Onboarded configs in EventDriven (Phase-1) in grey zone.

## Version 4.7.6
*[GDEP-513] Onboarded BI_RealTime Transactions table in grey zone.

## Version 4.7.5
*[GDEP-502] EventDriven LastRuntime metadata bug fix.

## Version 4.7.4
*[GDEP-461] Added Distinct filter in blue zone transaction sql for non duplicate data.

## Version 4.7.3
*[GDEP-507] Casted the bin column to decimal in BIN_prod file.

## Version 4.7.2
*[GDEP-462] Added usecase attributes to receive MM pipeline failure alerts.

## Version 4.7.1
*[GDEP-330] Updated the connection properties in DBConnection.

## Version 4.7.0
* [GDEP-389] BISME Event jobs retry functionality.

## Version 4.6.1
* [GDEP-342] Removed EmailPlain columns from blue zone sql files 

## Version 4.6.0
* [DCA-1233] Onboard MM523

## Version 4.5.4
* [DCA-1194] Swapped tables info of MerchantFee and partner fee tables info (Bug fix)

## Version 4.5.3
* [DCA-1312] Kafka Topic Change for Merchant Linkages Delta.

## Version 4.5.2
* [DCA-1044] Updated Kafka properties in Historical Linkages Config.

## Version 4.5.1
* [DCA-1097] Added Tsys invoice Data in ppbi data sink invoker configs.

## Version 4.5.0
* [DCA-1106] Introduced new changes of RS2 Version 28

## Version 4.4.0
* [DCA-1043] Merchant Linkages Delta enabled.

## Version 4.3.1
* [DCA-1031] Data Access Alert lambda updated to run multiple queries.

## Version 4.3.0
* [DCA-1022] Onboarded ACH Total file.

## Version 4.2.3
* [DCA-762] Updated RS2-Setup config with v27 new Attributes.

## Version 4.2.2
* [DCA-835] Reverted Irvine config changes, Modified MerchantDemoGraphics Monthly partition path.

## Version 4.2.1
* [DCA-952] PII Data Access Alert payload changes.

## Version 4.2.0
* [DCA-904] Configs for Merchant Linkages Historical Data Load 

##Version 4.1.5
 * [DCA-754] Updated RS2 Choice file with V27 changes

## Version 4.1.4
* [DCA-858] Onboarding TSYS Invoice data through cron

## Version 4.1.3
* [DCA-858] Added two RDR indicator columns in Chargebacks table.

## Version 4.1.2
* [DP-10892] Added CardIssuing Marquetta PROGRAMSTATUSER config for Vertica data load.

## Version 4.1.1
* [DCA-828] MerchantDemographics Config change to fix data discrepancy.

## Version 4.1.0
* [DP-10894] Added Marqueta settlements configs.

## Version 4.0.0
* [DP-10854] Added CardIssuing Marquetta CARDPROGRAMSTATS config for Vertica data load.

## Version 3.35.1
* [DCA-651] Added Refinitive Tic data load config.

## Version 3.35.0
* [DCA-706] Added new file BM406.

## Version 3.34.0
* [DCA-760] Added new flow for PII PLAIN columns PPBI configs.

## Version 3.33.4
* [DCA-601] Fixed Clover and Added missing column v26 for RS2

## Version 3.33.3
* [DCA-705] Added new job SD880A in DataSinkInvoker.

## Version 3.33.2
* [DCA-581] Irvine config update for DATECREATED column logic.

## Version 3.33.1
* [DCA-569] Updated Omaha Transaction Interchange Query

## Version 3.33.0
* [DCA-456] Added PII Data Access Alert Lambda to send email notification.

## Version 3.32.7
* [DCA-560] Added Email field in merchantDemographics queries in blue zone

## Version 3.32.6
* [DCA-560] Updated template path for EventDriven loading for delta orchestration to Vertica

## Version 3.32.5
 * [DCA-466] Increased driver memory for faster performance for the job

## Version 3.32.4
* [DCA-131] Merchant Funding ETL config changes.

## Version 3.32.3
* [DCA-493] Appended new columns for Risk profiles and Hirerachy in MCRM tables in Athena.

## Version 3.32.2
* [DCA-376] Merchant Demographics spark config changes. And separated config for mcrm.

## Version 3.32.1
* [DCA-385] PPBI authorizations data missing in prod due usecase conflict in config.

## Version 3.32.0
* [DCA-53] Cloud watch event configs modified to consume zone level job configs.

## Version 3.31.1
* [DCA-352] Updated message attributes to receive failure alerts for step functions.

## Version 3.31.0
* [DP-9330] Accommodated version 1.5 and 1.6 Sql changes for handling missing transactions.

## Version 3.30.6
* [DP-8748] Updated MM SummaryTables logic to capture data only for 4 tenants.

## Version 3.30.5
* [DP-9741] Accommodated Merchant Funding v2.5 sql changes.

## Version 3.30.4
* [DP-9511] Updated Message attributes and added SNS topic filters to send customized email alerts


## Version 3.30.3
* [DP-9637] Update North Close Date query in Merchant Demographics Monthly

## Version 3.30.2
* [DP-9469] Repartitioning s3 files to 3 from 200 default. 

## Version 3.30.1
* [DP-9471] BI Transaction CardSchemeCodes correction.

## Version 3.30.0
* [DP-8748] Clover Application Data Sync to vertica.

## Version 3.29.1
* [DP-8301] MM Summary tables Config and cron

## Version 3.29.0
* [DP-9035] Merchant demographics daily job should refer monthly output changes

## Version 3.28.1
* [DP-9131] Irvine Data ingestion to ApplicationAccounts Dim.

## Version 3.28.0 
* [DP-9022] MerchantDemographics data missing in blue zone

## Version 3.27.0
* [DP-8907] Irvine Merchant Data ingestion to MM CDM changes.

## Version 3.26.0
* [DP-8727] Transactions conformed Blue zone changes.

## Version 3.25.1
* [DP-9016] Updated the EMR name in blue and grey zones

## Version 3.25.0
* [DP-8509] RS2: V26 changes for Merchant, Transaction, Setup and Choice

## Version 3.24.0
* [DP-8293] MerchantDemographics distinct change and other cron changes.

## Version 3.23.1
* [DP-7988] Removed Delay step in MM Step function

## Version 3.23.0
* [DP-7553] Authorizations conformed table configs.

## Version 3.22.4
* [DP-8299] Changed configId to camelCase in step function definition.

## Version 3.22.3
* [DP-8299] Chargebacks and MerchantFunding blue sql fix to populate filename.

## Version 3.22.2
* [DP-7943] delta orch step function config id parameter.

## Version 3.22.1
* [DP-8404] added configid in event from delta step function.

## Version 3.22.0
* [DP-8271] Checking if a job is in running state before triggering job.

## Version 3.21.2
* [DP-8279] MIF :: Configuration changes

## Version 3.21.1
* [DP-8223] RS2 Alert and Reporting Channels Cron updated

## Version 3.21.0
* [DP-8091] EventBridge integration  in generic spark submit orch state machine

## Version 3.20.0
* [DP-7943] EventBridge integration in delta orch state machine.

## Version 3.19.0
* [DP-8167] RS2: Accomodated RS2 Version 24 changes for transaction and merchant extracts.

## Version 3.18.1
* [DP-7988] change to Lambda role to access USPP bucket

## Version 3.18.0
* [DP-7979] MIF: Added Hive support to load the latest 5 days Merchant data.

## Version 3.17.0
* [DP-7566] Changes in blue conformed configs to handle empty spaces

## Version 3.16.2
* [DP-7421] Format Alert Lambda fix

## Version 3.16.1
* [DP-7719] CDM: memory configuration and MIF: spark sql changes. 

## Version 3.16.0
* [DP-7574] FileDelete SNS, Lambda CFT changes

## Version 3.15.1
* [DP-7222] Event Driven - filenotfound and rs2,ppbi vertica sink detail type changes.

## Version 3.15.0
* [DP-7581] MIF: Added Hive support to MIF ApplicationRecord data. 

## Version 3.14.4
* [DP-7796] updated fp metadata config path

## Version 3.14.3
* [DP-7578] Added metadata table in RS2 choice

## Version 3.14.2
* [DP-7361] Updated configuration in MM input

## Version 3.14.1
* [DP-7566] Reverting hive changes in ppbi configs

## Version 3.14.0
* [DP-7222] Error handling in event driven.

## Version 3.13.0
* [DP-6954] Event Driven vertica sink for CI and RS2.

## Version 3.12.4
* [DP-7361] Moved jobName outside of livyCommand

## Version 3.12.3
* [DP-7567] Cross account access for uspp bucket

## Version 3.12.2
* [DP-7251] update merchantDemographics daily query to fix closeDates issue.

## Version 3.12.1
* [DP-7361] Moved jobName outside of livyCommand

## Version 3.12.0
* [DP-7296] RS2: ingesting forex columns in transaction extract

## Version 3.12.0
* [DP-7217] Changed emr to merchant-load for blue conformed jobs

## Version 3.11.0
* [DP-7217] Conformed configs to support blue and grey pipeline and athena support

## Version 3.10.0
* [DP-7194] hive enabled param cascading. 

## Version 3.9.0
* [DP-6913] Added changes in pipeline deployment step for grey zone for DEV and QA env.

## Version 3.8.0
* [DP-7821] ignoring s3 deletion in spark etl framework to support happy flow.

## Version 3.7.2
* [DP-7217] Added cron for conformed tables in ppbi

## Version 3.7.1
*[DP-7224] Updated Vertica Host

## Version 3.7.0
* [DP-6913] Added deployment step for grey zone for DEV and QA env.

## Version 3.6.0
* [DP-7214] Created separate buckets for ppbi and Rs2 and enabled SRR for vertica external tables bucket

## Version 3.5.3
* [DP-7167] Vertica load pipeline job status logs to Splunk formatting

## Version 3.5.2
* [DP-6675] Lambda to format SNS notification alerts 

## Version 3.5.1
* [DP-7115] MerchantDemographics missing openDates issue for iPaymentMerchants

## Version 3.5.0
* [DP-7106] Added lambda for daily processed files alert

## Version 3.4.9
* [DP-7031] lambda to read input from S3 and invoke step function

## Version 3.4.8
* [DP-6733] Conformed : Added Transactions configs

## Version 3.4.7
* [DP-7107] Adding clientLevel and billingLevel in Rs2 merchant extract for row type 004,005,006

## Version 3.4.6
* [DP-6913] Added CDM Load step in ThreeStepSparkSubmitOrchestration.

## Version 3.4.5
* [DP-6738] MerchantDemographics conformed tables fix duplicate data issue.

## Version 3.4.4
* [DP-6953] RS2 Choice configs update.

## Version 3.4.3
* [DP-6733] Cron change for mm etl 

## Version 3.4.2
* [DP-6707] Modified Rs2 Transactions query

## Version 3.4.1
* [DP-6737] Added cron for DDDE load(vendor result and rule result)

## Version 3.4.0
* [DP-6738] MerchantDemographics conformed enable Cron in prod and spark SQL queries

## Version 3.3.2
* [DP-6603] Added join logic with ReportingChannels for MerchantFunding and changed cardScheme to
 4 digit for chargebacks

## Version 3.3.1
* [DP-6733] Adding Zone in metadata

## Version 3.3.0
* [DP-6622] PPBI: Email alerts for PPBI files which not loaded to vertica.

## Version 3.2.0
* [DP-6625] Handling heartbeatseconds and counter dynamically for all step functions

## Version 3.1.4
* [DP-6707] Accomodated RS2 Version 23 changes

## Version 3.1.3
* Updated MM pipeline cron timings.

## Version 3.1.2
* [DP-6559] Added crons for MD027Detail and MD027Summary

## Version 3.1.1
* [DP-6707] Handling Zone property for all cases(upper, lower and camel cases)

## Version 3.1.0
* [DP-6449] Usecase specific yaml for AWS resources

## Version 3.0.0
* [DP-6449] PPBI: Migrated orchestration to the blue zone.

## Version 2.20.3
* [DP-4900] Configured to deploy on Dev with new configs and qa resource cft.

## Version 2.20.2
* [DP-6558] Handled Cluster Exception in Blue Zone.

## Version 2.20.1
* [DP-6474] Configure MetaData table for dataSinkInvoker job fix parsing issues  in Input .

## Version 2.20.0
* [DP-6474] Configure MetaData table for dataSinkInvoker job.

## Version 2.19.0
* [DP-6448] PPBI pipeline setup in Blue Zone.

## Version 2.18.0
* [DP-6325] pipeline setup in Merchant test environment

### Version 2.17.3
* [DP-6231] Added ISCONFORMED ENTRY in metadata.

### Version 2.17.2
* [DP-6240] PP BI: Volume Card & Volume bank card conformed table enhancements

### Version 2.17.1
* [DP-6177] Added spark cross join configuration for mm etl cloudWatch event

### Version 2.17.0
* [DP-6069] Conformed: Added RevenueMerchantMonthlyStatement and VolumeBankCardMonthly configs.

### Version 2.16.2
* [DP-6150] Added loggers for capturing exception

### Version 2.16.1
* [DP-6139] Adding cron for MD033 and oracle ip change.

### Version 2.16.0
* [DP-6150] Conformed : Added TransactionsSummaryCardDaily configs

### Version 2.15.3
* [DP-6074] Update MM ETL load spark configuration and disable Cron in lower environments

### Version 2.15.2
* [DP-5703] bug fix for Step function prod deployment

### Version 2.15.1
* [DP-6060] Rs2 version 22 changes. (Added Sequence number in merchant 007 rowtype)

### Version 2.15.0
* [DP-5703] bug fix for Step function QA deployment

### Version 2.14.5
* [DP-5703] Generic Step function QA deployment

### Version 2.14.5
* [DP-5907] Email alert for Aperia identified duplicates

### Version 2.14.4
* [DP-5703] Generic Step function for submitting 3 spark job and orchestration.

### Version 2.14.3
* [DP-5898] Conformed: Added ChargeBacks configs 

### Version 2.14.2
* [DP-5808] Corrected MerchantFunding query to avoid null values

### Version 2.14.1
* [DP-5900] Rs2 Version 19 and 21 changes. 

### Version 2.14.1
* [DP-5895] Changes to trigger mm step function from api

### Version 2.14.0
* [DP-5881] Houston MIF metadata table sync to vertica

### Version 2.13.25
* [DP-5703] Step function for master merchant orchestration

### Version 2.13.24
* [DP-5811] Corrected Value date udf in rs2 transaction

### Version 2.13.23
* [DP-5669] Corrected table ddl syntax for AperiaLogtable sync job

### Version 2.13.22
* [DP-5785] Added cron for MIF hierarchy.

### Version 2.13.21
* [DP-5712] Added cron for residual basic, DDF and AMEX Settlement.

### Version 2.13.20
*  Corrected tag values for BudgetedIn.

### Version 2.13.19
* [DP-5666] Removing duplicate path.

### Version 2.13.18
* [DP-5611] Adding cron for PPBI config.


### Version 2.13.17
* [DP-5625] Corrected outputs structs in Rs2 Merchant config for loading data into vertica.

### Version 2.13.16
* [DP-5551] Handled Change for files to INACTIVE status after deleting from vertica.

### Version 2.13.15
* [DP-5554] Added cron for mif files.

### Version 2.13.14
* [DP-5595] Added filenames existing check from metadata before deleting data in s3 staging.

### Version 2.13.13
* [DP-5594] Count is not matching for ACH deposits files among conformed table, s3 and vertica tables.

### Version 2.13.12
* [DP-5496] re-tagging the resources.

### Version 2.13.11
* [DP-5586] Delete is not working as expected for conformed table flow.

### Version 2.13.10
* [DP-5521] Correcting input for conformed tables 

### Version 2.13.9
* [DP-5522] Changed Scheduler expression for the cron, Deployment fix.

### Version 2.13.8
* [DP-5465] Added Table check exists for delete handler

### Version 2.13.7
* [DP-5465] Replaced Vertica Jar with SparkEtl Jar and removed dbSchema from Rs2configs.

### Version 2.13.6
 * [DP-5279] Notification Email fix

### Version 2.13.5
* [DP-5424] Conformed tables:TracingId column is coming as null in BI.Deposits table

### Version 2.13.4
 * [DP-5145] Added cron for conformed tables

### Version 2.13.3
 * [DP-5341] Removed O_fields for RS2 files

### Version 2.13.2
 * [DP-5240] removed extensions in cloudwatch events for mass flat files

### Version 2.13.1
 * [DP-5325] Volopa balances sink config changes.

### Version 2.13.0
 * [DP-5145] Delta files fetch for conformed tables using data_sink_job table.

### Version 2.12.0
 * [DP-5144] Support multiple input paths in spark ETL configs.

### Version 2.11.5
 * [DP-5212] spark etl config for paymentProcessing_ukAcquiring_RS2_CHOICE. 

### Version 2.11.4
 * [DP-5147] Added step in stages to populate entries in metadata table for Rs2 files

### Version 2.11.3
 * [DP-5324] Added Crons for Mass Flat Files.
 
### Version 2.11.2
 * [DP-5323] fix to avoid inserts in DATA_SINK_JOB table if no archived and rollback files are present


### Version 2.11.1
 * [DP-4794] configs for percentage and Forex files to sync data from S3 to Vertica

### Version 2.11.0
 * [DP-4982] Generic SES Notification and SES Notification for Duplicate Records in Files.
 
### Version 2.10.6
 * [DP-4933] RS2 Setup,Merchant , and TXN etl configs schema path change .

### Version 2.10.5
 * [DP-4982] Fix corrected files notification and buildspec
 
### Version 2.10.4
 * [DP-4975] fix to Build successful. 
 
### Version 2.10.3
 * [DP-4975] Changed the Filedate datatype and tables names for merchant rowtypes.

### Version 2.10.2
 * [DP-4814] Adding RS2 configs for setup files
 
### Version 2.10.1
  * [DP-4940] Run unit test on code build

### Version 2.10.0
  * [DP-4796] Added new exception for Files not found

### Version 2.9.1
 * [DP-4748] Added Rs2 Merchant DataModelling Configs.

### Version 2.9.0
* Changes in sparketlPipeline flow to accodmate Rs2 schema changes

### Version 2.8.0
 * [DP-4745] Configured SES Notification for Corrected Files and InvalidRecordCount Files.

### Version 2.7.2
 * [DP-4761] Spark ETL framework config for RS2 Transaction files data to create Record Type wise tables .

### Version 2.7.1
 * Corrected input json for cardIssuing and FP metadata sync

### Version 2.7.0
 * [DP-4726] PPBI increase cron timings frequency 

### Version 2.6.0
 * [DP-4522] Aperia log table changes using Local Temp tables

### Version 2.5.1
* [DP-4441] Changes to Disable cron for non-prod environment

### Version 2.5.0
* [DP-4441] Changes to delta-files-orchestration CFT based on the generic spark submit Step function

### Version 2.4.0
* [DP-4439] Generic Step function for submitting spark job and orchestration.

### Version 2.3.0
* [DP-4432] Generic spark execution changes.

### Version 2.2.1
* [DP-4236] Added tags for SNS, StateMachine resources

### Version 2.2.0
* [DP-4130] Added Lambda to update job status and clean up the configs.

### Version 2.1.0
* [DP-4237] Replacing variables in DataPipeline flow.

### Version 2.0.0
* [DP-4136] DataSinkInvoker Lambda changes.
* [DP-4138] CI/CD and builspec changes.

### Version 1.4.0
* [DP-4127] Integrated emr termination in orchestration.

### Version 1.3.0
* [DP-4126] Renamed Packages

### Version 1.2.0
* [DP-4127] Added step function callback handler.

### Version 1.1.0
* [DP-4127] Updated CFT config files.

### Version 1.0.0

** This project has been cloned from pasafe-gdp-ppbi

* [DP-4070] (https://jira.neterra.paysafe.com/browse/DP-4070)Data loading of 3 setup files to Vertica & views creation per rowType.

* [DP-4029] Changing DL and more logging in Automation DDL.

* [DP-4029] Automation DDL validation.

* [DP-3994](https://jira.neterra.paysafe.com/browse/DP-3994) Notifications have to be configured for lambda failures.

* [DP-3889] Reload Implementation refer correct Index .

* [DP-3898](https://jira.neterra.paysafe.com/browse/DP-3898) Added creating PPBI config from excel utility.

* [DP-3889] Lambda refactoring dev issues fixes .

* [DP-3891](https://jira.neterra.paysafe.com/browse/DP-3891) Aperia log table to Vertica Dev testing and Unit tests.

* [DP-3889] (https://jira.neterra.paysafe.com/browse/DP-3889) Lambda refactoring to extend for multiple Inputs.

* [DP-3637](https://jira.neterra.paysafe.com/browse/DP-3637) Sync Aperia Log table to vertica.

* [DP-3626](https://jira.neterra.paysafe.com/browse/DP-3626) Cleanup livy payload after completion of job.

* [DP-3632](https://jira.neterra.paysafe.com/browse/DP-3632) PPBI parallel job implementation 

* [DP-3699](https://jira.neterra.paysafe.com/browse/DP-3699) ConfigId wise Spark input creation Lambda code changes.

* [DP-3758](https://jira.neterra.paysafe.com/browse/DP-3758) PPBI orchestration CFT changes.

* [DP-3106](https://jira.neterra.paysafe.com/browse/DP-3106) Create DDL in Vertica for Aperia files.

* [DP-3608](https://jira.neterra.paysafe.com/browse/DP-3608) Infrastructure Util changes in Lambda.

* [DP-3607](https://jira.neterra.paysafe.com/browse/DP-3607) delete from metadata table and add entry.

* [DP-3607](https://jira.neterra.paysafe.com/browse/DP-3607) Store fp updated on at  vertica end to pick processed files

* [DP-3570](https://jira.neterra.paysafe.com/browse/DP-3570) Daily sync integration testing SRC bucket and dynamo changes.

* [DP-3570](https://jira.neterra.paysafe.com/browse/DP-3570) Daily sync integration testing

* [DP-3504](https://jira.neterra.paysafe.com/browse/DP-3504) PPBI Lambda changes to read processed files from MetaData Table 

* [DP-3305](https://jira.neterra.paysafe.com/browse/DP-3305) ppbi initial changes.
