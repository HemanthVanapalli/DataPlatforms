{{ config(materialized='table') }}

select
MERCHANTACCOUNTID,
mlename,
mleid,
pmlename,
pmleid,
business_relationship
from {{ source('mm', 'ProcessingAccount_Dim') }}
where iscurrent = TRUE