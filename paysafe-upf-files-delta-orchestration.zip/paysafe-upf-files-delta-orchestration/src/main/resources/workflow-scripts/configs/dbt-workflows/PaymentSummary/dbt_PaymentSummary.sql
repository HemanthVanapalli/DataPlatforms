{{ config(materialized='table') }}

with merch_details as
 (
select * from {{ ref('dbt_base_PaymentSummary_merch_details') }}
)
,bank_details_lat as (
select * from {{ ref('dbt_base_PaymentSummary_bank_details_lat') }}
)
, merch_links_lat as (
select * from {{ ref('dbt_base_PaymentSummary_merch_links_lat') }}
)
, acc_types as (
select * from {{ ref('dbt_base_PaymentSummary_acc_types') }}
)
, balance_group as (
select * from {{ ref('dbt_base_PaymentSummary_balance_group') }}
)
, pay2 as (
select * from {{ ref('dbt_base_PaymentSummary_pay2') }}
)
,rev_by_fee as (
select * from {{ ref('dbt_base_PaymentSummary_rev_by_fee') }}
)
, volume_buckets as (
select * from {{ ref('dbt_base_PaymentSummary_volume_buckets') }}
) ,
revenue_buckets as (
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    record_date recorddate ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    drcrindicator ,
    reversal ,
    accountcurrency settlementcurrency ,
    0 pmt_total_chargeback ,
    0 pmt_total_credit ,
    0 pmt_total_settlement ,
    case
        when transaction_type = 'Discount Fee' then fee_amount_account
        else 0
    end pmt_discount_fee ,
    case
        when transaction_type in ('Declined Authorization Fee',
        'Gateway Per Click Fee',
        'Authorisation fee- approved') then fee_amount_account
        else 0
    end pmt_transaction_fee ,
    case
        when fee_type in ('Interchange Fees',
        'Scheme Fees') then fee_amount_account
        else 0
    end interchange_scheme_fee ,
    case
        when transaction_type = 'CBK Fee' then fee_amount_account
        else 0
    end pmt_chargeback_fee ,
    case
        when transaction_type in ('Monthly Service Fee',
        'Monthly Minimum Fee') then fee_amount_account
        else 0
    end pmt_monthly_fee ,
    case
        when transaction_type in ('SEPA Payment Fee',
        'Faster Payment Fee',
        'WIRE Payment Fee') then fee_amount_account
        else 0
    end pmt_payment_fee ,
    fee_amount_account PMT_TOTAL_FEES
from
rev_by_fee ) ,
vol_and_rev as (
select
    *
from
    revenue_buckets
union all
select
    *
from
    volume_buckets )
, volrev2 as (
select
    institutionnumber ,
    clientnumber ,
    FILENUMBER ,
    recorddate ,
    settlementcurrency ,
    transactionstatus ,
    sum(pmt_total_chargeback * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_total_chargeback ,
    sum(pmt_total_credit * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_total_credit ,
    sum(pmt_total_settlement * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_total_settlement ,
    sum(pmt_discount_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_discount_fee ,
    sum(pmt_transaction_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_transaction_fee ,
    sum(interchange_scheme_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_interchange_scheme_fee ,
    sum(pmt_chargeback_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_chargeback_fee ,
    sum(pmt_monthly_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_monthly_fee ,
    sum(pmt_payment_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_payment_fee ,
    sum(PMT_TOTAL_FEES * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) PMT_TOTAL_FEES
from vol_and_rev
where transactionstatus in (2,9)
group by
    institutionnumber ,
    clientnumber ,
    FILENUMBER ,
    recorddate ,
    settlementcurrency ,
    transactionstatus )
, volrev3 as (
select
    pp_all.rec_dt ,
    pp_all.rec_dt_lag ,
    pp_all.recorddate date2 ,
    pp_all.valuedate date2_value ,
    pp_all.transactionslipnumber tx_slip_pay ,
    pp_all.ps_proc_amt payment_amount ,
    vr.*
from
    volrev2 vr
left join pay2 pp_all on
    vr.institutionnumber = pp_all.institutionnumber
    and vr.clientnumber = pp_all.clientnumber
    and vr.filenumber > pp_all.filenumber_lag
    and vr.filenumber <= pp_all.filenumber
)
, volrev4 as (
select
    institutionnumber ,
    clientnumber ,
    settlementcurrency ,
    transactionstatus ,
    min(rec_dt_lag) date_start ,
    max(rec_dt) date_end ,
    sum(pmt_total_chargeback) pmt_total_chargeback ,
    sum(pmt_total_credit) pmt_total_credit ,
    sum(pmt_total_settlement) pmt_total_settlement ,
    sum(pmt_discount_fee) pmt_discount_fee ,
    sum(pmt_transaction_fee) pmt_transaction_fee ,
    sum(pmt_interchange_scheme_fee) pmt_interchange_scheme_fee ,
    sum(pmt_chargeback_fee) pmt_chargeback_fee ,
    sum(pmt_monthly_fee) pmt_monthly_fee ,
    sum(pmt_payment_fee) pmt_payment_fee ,
    sum(PMT_TOTAL_FEES) PMT_TOTAL_FEES
from
    volrev3
    where 1=1
    and rec_dt >= date(TO_TIMESTAMP(1664928000000 / 1000)) and rec_dt < date(TO_TIMESTAMP(1665014400000/ 1000))
    group by institutionnumber,
    clientnumber,
    settlementcurrency,
    transactionstatus )
, output1 as (
select
    mdl.FMA ,
    mdl.legalname LEGALNAME,
    mdl.INSTITUTIONNUMBER INSTITUTION_NO ,
    case
        when mdl.institutionnumber = 10 then 'Paysafe Payment Solutions Limited'
        when mdl.institutionnumber = 12 then 'Paysafe Financial Services Limited'
        else null
    end LEGAL_ENTITY ,
    mdl.clientnumber TID ,
    mdl.clientnumber MID ,
    case
        when instr(mll.settlement_method,
        'SAX') > 0 then 'SAXO'
        when instr(mll.settlement_method,
        'LHV') > 0 then 'LHV'
        when instr(mll.settlement_method,
        'BMO') > 0 then 'BMO'
    end PAYMENT_BANK_CODE ,
    bdl.counterbankaccount BANK_ACT_NBR ,
    bl2.filedate START_BALANCE_DATE ,
    bl2.total_balance START_BALANCE ,
    bl2.total_balance BALANCE_CURRENT ,
    pp1.valuedate LATEST_PAYMENT_DATE ,
    pp1.transactionamount_processing LATEST_PAYMENT_AMOUNT ,
    pp1.p_slip LATEST_PAYMENT_SLIP ,
    pp2.valuedate LAST_PAYMENT_DATE ,
    pp2.transactionamount_processing LAST_PAYMENT_AMOUNT ,
    pp2.p_slip LAST_PAYMENT_SLIP ,
    bl1.filedate END_BALANCE_DATE ,
    bl1.total_balance END_BALANCE ,
    rcc.DESCRIPTION_1 SETTLEMENTCURRENCY ,
    rcts.DESCRIPTION_1 TRANSACTIONSTATUS ,
    vr.PMT_TOTAL_CHARGEBACK ,
    vr.PMT_TOTAL_CREDIT ,
    vr.PMT_TOTAL_SETTLEMENT ,
    vr.PMT_DISCOUNT_FEE ,
    vr.PMT_TRANSACTION_FEE ,
    vr.PMT_CHARGEBACK_FEE ,
    vr.PMT_MONTHLY_FEE ,
    vr.PMT_PAYMENT_FEE ,
    vr.PMT_TOTAL_FEES,
    mdl.PMLE_ID,
    mdl.PMLE_NAME,
    mdl.MLE_ID,
    mdl.MLE_NAME,
    mdl.tradename TRADENAME,
    case
        when mdl.institutionnumber = 10 then '89'
        when mdl.institutionnumber = 12 then '79'
        else null
    end LEGAL_ENTITY_CODE,
    mll.groupnumber GROUP_ID
from merch_details mdl
left join merch_links_lat mll on mdl.clientnumber = mll.clientnumber
left join bank_details_lat bdl on mdl.clientnumber = bdl.clientnumber
left join volrev4 vr on mdl.institutionnumber = vr.institutionnumber and mdl.clientnumber = vr.clientnumber
left join ukAcquiringRS2.RS2_CHOICE_CURRENCY rcc on vr.settlementcurrency = rcc.INDEX_FIELD and vr.institutionnumber = rcc.INSTITUTION_NUMBER
left join pay2 pp1 on pp1.CLIENTNUMBER = mdl.CLIENTNUMBER and pp1.rec_dt = vr.date_end
left join pay2 pp2 on pp2.CLIENTNUMBER = mdl.CLIENTNUMBER and pp2.rec_dt = vr.date_start
left join balance_group bl1 on mdl.clientnumber = bl1.clientnumber and bl1.filedate = date(TO_TIMESTAMP(1665014400000/ 1000)) - interval '1' day
left join balance_group bl2 on mdl.clientnumber = bl2.clientnumber and bl2.filedate = date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '1' day
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_STATUS') }} rcts on rcts.INSTITUTION_NUMBER = mdl.institutionnumber and rcts.INDEX_FIELD = vr.transactionstatus
)
select * from output1