{{ config(materialized='view') }}

with fcn_txn as
(
select * from {{ ref('dbt_base_AccountSummery_fcn_txn') }}
)
, rev_by_fee_and_vol_01 as
(
select * from {{ ref('dbt_base_AccountSummery_rev_by_fee_and_vol_01') }}
)
 , first_join AS (
    SELECT
        r.*,
        cf.MerchantRefNum AS cf_MerchantRefNum,
        cf.guid AS cf_guid,
        cf.description AS cf_description,
        cf.cardbin AS cf_cardbin,
        cf.recordseq AS cf_recordseq
    FROM rev_by_fee_and_vol_01 r
    LEFT JOIN fcn_txn cf ON r.ORIGINALREFERENCENUMBER = cf.recordseq
)
select * from first_join
