{{ config(materialized='table') }}

with txn_fees as (
select * from {{ ref('dbt_base_AccountSummery_txn_fees') }}
)
, merchant_fees as
(
select * from {{ ref('dbt_base_AccountSummery_merchant_fees') }}
)
, payment_fees as
(
select * from {{ ref('dbt_base_AccountSummery_payment_fees') }}
)
, interchange_fees as
(
select * from {{ ref('dbt_base_AccountSummery_interchange_fees') }}
)
, scheme_fees as
(
select * from {{ ref('dbt_base_AccountSummery_scheme_fees') }}
)
, misc_fees as (
select * from {{ ref('dbt_base_AccountSummery_misc_fees') }}
)
, settles as
(
select * from {{ ref('dbt_base_AccountSummery_settles') }}
)
, chargebacks as
(
select * from {{ ref('dbt_base_AccountSummery_chargebacks') }}
)
, payments_summary as (
select * from {{ ref('dbt_base_AccountSummery_payments_summary') }}
)
, payments as (
select * from {{ ref('dbt_base_AccountSummery_payments') }}
)
, service_fees as (
select * from {{ ref('dbt_base_AccountSummery_service_fees') }}
)
, rev_by_fee_and_vol_01 as
(
select * from txn_fees
union all
select * from scheme_fees
union all
select * from interchange_fees
union all
select * from payment_fees
union all
select * from merchant_fees
union all
select * from misc_fees
union all
select * from settles
union all
select * from chargebacks
union all
select * from payments_summary where recorddate >= current_date-31
union all
select * from payments where recorddate >= current_date-31
union all
select * from service_fees
)
select * from rev_by_fee_and_vol_01