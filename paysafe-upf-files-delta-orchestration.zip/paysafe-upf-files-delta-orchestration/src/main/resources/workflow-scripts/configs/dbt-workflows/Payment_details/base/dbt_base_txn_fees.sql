{{ config(materialized='table') }}

with txn_fees_1 as
(
select
    tmt.*,
    tt.TRANSACTIONSLIPNUMBER txn_applied_to,
    tt.MSCAMOUNT_PROCESSING,
    tt.MSCAMOUNT_SETTLEMENT
from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} tmt
join {{ ref('dbt_base_pay2') }} pp_all on tmt.institutionnumber = pp_all.institutionnumber and tmt.clientnumber = pp_all.clientnumber and tmt.filenumber > pp_all.filenumber_lag and tmt.filenumber <= pp_all.filenumber and (pp_all.AccountTypeID = 7 or pp_all.settlement_method = 'G')
left join {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} tt on tmt.NUMBERORIGINALSLIP = tt.SOURCESETTLEMENT
where tmt.TRANSACTIONCATEGORY = 21 and tmt.accountnumber > 13000
limit 1 over (partition by tt.TRANSACTIONSLIPNUMBER order by tmt.filedate desc )
)

select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    txn_applied_to::varchar ,
    filenumber ,
    transactionstatus ,
    TransactionType ,
    'Discount Fee' Transaction_Type,
    DRCRINDICATOR ,
    0 reversal ,
    'Discount Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency ,
    sum(MSCAMOUNT_PROCESSING) fee_amount_proccessing ,
    sum(MSCAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(MSCAMOUNT_SETTLEMENT) fee_amount_account ,
    count(*) txns
from
    txn_fees_1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) ,
    TRANSACTIONSLIPNUMBER ,
    txn_applied_to ,
    filenumber ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency