{{ config(materialized='table') }}

with fcn_txn as
(
select * from {{ ref('dbt_base_AccountSummery_fcn_txn') }}
)
, rev_by_fee_and_vol_01 as
(
select * from {{ ref('dbt_base_AccountSummery_rev_by_fee_and_vol_01') }}
)
, rev_by_fee_and_vol as
(
select
    r.* ,
    nvl(cf.MerchantRefNum,
    cf2.MerchantRefNum) MerchantRefNum ,
    nvl(cf.guid,
    cf2.guid) guid ,
    nvl(cf.description,
    cf2.description) description ,
    nvl(cf.cardbin,
    cf2.cardbin) cardbin ,
    nvl(cf.recordseq,
    cf2.recordseq) recordseq
from rev_by_fee_and_vol_01 r
left join fcn_txn cf on r.ORIGINALREFERENCENUMBER = cf.recordseq
left join fcn_txn cf2 on r.AQUIRERREFERENCE::varchar = cf2.arn::varchar
)
select * from rev_by_fee_and_vol