{{ config(materialized='table') }}

select
    m.InstitutionNumber ,
    m.clientnumber ,
    m.accountnumber ,
    m.TRANSACTION_TYPE ,
    m.transactionstatus ,
    m.reversal ,
    m.DRCRINDICATOR ,
    m.recorddate ,
    m.transactionslipnumber ,
    m.numberoriginalslip::varchar txn_applied_to ,
    m.filenumber ,
    txn.ORIGINALREFERENCENUMBER ,
    nvl(cf.MerchantRefNum,
    cf2.MerchantRefNum) MerchantRefNum ,
    nvl(cf.guid,
    cf2.guid) guid ,
    cf.txnid ,
    cf.cardtype ,
    m.transactioncurrency ,
    m.accountcurrency settlementcurrency ,
    CASE
        WHEN m.TRANSACTION_TYPE = 'Adjustment' THEN 'Adjustment'
        WHEN m.TRANSACTION_TYPE = 'Rejects (Financial)' THEN 'Volumes'
        ELSE 'Chargebacks'
    END as fee_type ,
    count(*) tx_cnt ,
    sum(m.transactionamount_processing) proc_amount ,
    sum(m.transactionamount_account) settle_amount,
    '' TRANSACTIONDESTINATION
from {{ ref('dbt_base_misc') }} m
left join (select * from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }}  limit 1 OVER (PARTITION BY TRANSACTIONSLIPNUMBER ORDER BY FILEDATE DESC)) txn on m.AQUIRERREFERENCE = txn.AQUIRERREFERENCE
left join {{ ref('dbt_base_fcn_txn') }} cf on txn.ORIGINALREFERENCENUMBER = cf.recordseq
left join {{ ref('dbt_base_fcn_txn') }} cf2 on m.AQUIRERREFERENCE::varchar = cf2.arn::varchar
group by
    m.InstitutionNumber ,
    m.clientnumber ,
    m.accountnumber ,
    m.TRANSACTION_TYPE ,
    m.transactionstatus ,
    m.reversal ,
    m.DRCRINDICATOR ,
    m.recorddate ,
    m.transactionslipnumber ,
    m.numberoriginalslip ,
    m.filenumber ,
    txn.ORIGINALREFERENCENUMBER ,
    nvl(cf.MerchantRefNum,
    cf2.MerchantRefNum) ,
    nvl(cf.guid,
    cf2.guid) ,
    cf.txnid ,
    cf.cardtype ,
    m.transactioncurrency ,
    m.accountcurrency