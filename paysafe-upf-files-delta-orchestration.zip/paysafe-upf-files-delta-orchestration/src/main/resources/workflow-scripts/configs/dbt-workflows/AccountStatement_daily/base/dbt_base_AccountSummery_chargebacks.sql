{{ config(materialized='table') }}

with misc as
(
select
    vtmt.*,
    tc.description_1 TRANSACTION_TYPE ,
    substr(vtmt.transactioncurrency, 1, 3) tx_currency
from (select * from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) vtmt
left join (select * from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} limit 1 OVER (PARTITION BY TRANSACTIONSLIPNUMBER ORDER BY FILEDATE DESC)) tt on vtmt.NUMBERORIGINALSLIP = tt.TRANSACTIONSLIPNUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_CATEGORY') }} tc on vtmt.INSTITUTIONNUMBER = tc.Institution_Number and vtmt.TRANSACTIONCATEGORY = tc.Index_Field
where vtmt.transactioncategory in (2,50) and vtmt.RECORDDATE = {{ var("RUNDATE") }} and vtmt.accountnumber > 13000
)
, chargebacks as
(
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    recorddate ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    transactiontype ,
    CARDFLAG ,
    -1 CARDBRAND ,
    numberoriginalslip::varchar txn_applied_to ,
    ORIGINALREFERENCENUMBER * 1 ORIGINALREFERENCENUMBER ,
    AQUIRERREFERENCE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    case
        when transaction_type = 'Adjustment' then 'Adjustments'
        else 'Chargebacks'
    end as fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(transactionamount_processing) fee_amount_processing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    count(*) txns
from misc
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    recorddate ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    transactiontype ,
    CARDFLAG ,
    txn_applied_to ,
    ORIGINALREFERENCENUMBER ,
    AQUIRERREFERENCE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency,
    transactioncategory
)
select * from chargebacks