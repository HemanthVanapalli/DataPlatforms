{{ config(materialized='table') }}

with pay2 as (
select
    min(filenumber) over (partition by institutionnumber,
    clientnumber) min_fn,
    LAG(transactionamount_processing) over (partition by clientnumber order by rec_dt asc) PRE_PAYMENT,
    transactionamount_processing NET_DEPOSIT,
    concat(concat(to_char(nvl(RECORDDATE, filedate), 'dd/Mon/yyyy'), ' to '), to_char(VALUEDATE, 'dd/Mon/yyyy')) DATE_RANGE,
    *
from
    {{ ref('dbt_base_PaymentSummary_payment') }}
where 1=1
and recorddate >= current_date -2  and recorddate < current_date
)
select * from pay2