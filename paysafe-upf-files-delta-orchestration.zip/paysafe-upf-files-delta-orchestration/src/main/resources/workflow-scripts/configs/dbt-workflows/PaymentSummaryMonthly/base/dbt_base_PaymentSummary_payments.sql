{{ config(materialized='table') }}

with payments as (
SELECT
    case
        when tp.valuedate > current_date then 1
        else 0
    end future_pmt ,
    tp.CLIENTNUMBER client_No ,
    tp.TRANSACTIONSLIPNUMBER p_slip ,
    vtps.NUMBERORIGINALSLIP ps_os ,
    vtps.TRANSACTIONSLIPNUMBER ps_slip ,
    vtps.TRANSACTIONAMOUNT_PROCESSING ps_proc_amt ,
    tp.TRANSACTIONAMOUNT_PROCESSING p_proc_amt ,
    tp.RECORDDATE rec_dt ,
    nvl(LAG(tp.RECORDDATE) over (partition by tp.INSTITUTIONNUMBER, tp.clientnumber order by tp.RECORDDATE asc), '2021-01-01') rec_dt_lag ,
    tp.VALUEDATE value_date ,
    tp.FILENUMBER fn ,
    nvl(LAG(tp.FILENUMBER) over (partition by tp.INSTITUTIONNUMBER, tp.clientnumber order by rec_dt asc), 0) filenumber_lag ,
    tp.*
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by transactionslipnumber order by recorddate desc)) vtps
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }}  limit 1 over (partition by transactionslipnumber order by recorddate desc)) tp on vtps.NUMBERORIGINALSLIP = tp.TRANSACTIONSLIPNUMBER
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on tp.clientnumber = md.clientnumber and tp.institutionnumber = md.institutionnumber
where vtps.TRANSACTIONTYPE IN (250, 252, 251)
)
select * from payments