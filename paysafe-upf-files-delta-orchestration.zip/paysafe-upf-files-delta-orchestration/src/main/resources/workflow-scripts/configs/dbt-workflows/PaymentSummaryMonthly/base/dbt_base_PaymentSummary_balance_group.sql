{{ config(materialized='table') }}

with balance_group as (
select
    filedate ,
    institutionnumber ,
    clientnumber ,
    sum(merch_payment_balance) merch_payment_balance ,
    sum(merch_fee_balance) merch_fee_balance ,
    sum(merch_cost_balance) merch_cost_balance ,
    sum(merch_hold_balance) merch_hold_balance ,
    sum(merch_reserve_balance) merch_reserve_balance ,
    sum(total_balance) total_balance
from {{ ref('dbt_base_PaymentSummary_balances') }}
group by
    filedate ,
    institutionnumber ,
    clientnumber
)
select * from balance_group