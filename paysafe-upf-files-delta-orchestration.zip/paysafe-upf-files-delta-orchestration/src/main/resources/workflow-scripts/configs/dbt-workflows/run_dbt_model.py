import argparse
import boto3
import botocore
import logging
import awscli
import base64
import json
import boto3
import time
import subprocess
import os
import datetime;
import sys

def log_group_exists(log_group_name):
    paginator = cloudwatch_client.get_paginator('describe_log_groups')
    for page in paginator.paginate():
        for group in page['logGroups']:
            if group['logGroupName'].lower() == log_group_name.lower():
                return True
    return False

argParser = argparse.ArgumentParser()
argParser.add_argument("--dirpath", help="dbt model folder location")
argParser.add_argument("--dbtcommand", help="dbt command")
argParser.add_argument("--snstopic", help="sns topic name")
argParser.add_argument("--env",help="environment name")
argParser.add_argument("--event",help="event")

args = argParser.parse_args()

dirpath = args.dirpath
dbt_run_command = args.dbtcommand
snstopic = args.snstopic
modelname = dirpath.split('/')[-3]
env = args.env
event_struct =json.loads(args.event)
event_struct["EventBusName"]="default"


try:
    os.chdir(dirpath)
    print("inside dbt model")
    print(dirpath)

    cloudwatch_client = boto3.client('logs', region_name='ca-central-1')
    sns_client = boto3.client('sns',region_name='ca-central-1')
    eventbridge_client = boto3.client('events', region_name='ca-central-1')


    process = subprocess.Popen(
            dbt_run_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

    print("before shell")
    stdout, stderr = process.communicate()
    print("after shell")

    log_group_name = 'EC2_DBT_Logs'
    retention_period_in_days = 30

    current_time = datetime.datetime.now()
    current_time_str = current_time.strftime('%Y-%m-%d-%H-%M-%S-%f')

    log_stream_name = modelname+'/'+ current_time_str

    std_out_logs = stdout.decode("utf-8")

    if process.returncode != 0:
        error_message = stderr.decode("utf-8")
        sns_client.publish(TargetArn=snstopic,
                        Message = 'log_group_name: '+log_group_name+'\n'+'log_stream_name: '+log_stream_name+'\n'+error_message,
                        Subject = f'{modelname} DBT Run Failure Grey {env}')

    last_line_log = str(std_out_logs.splitlines()[-1])
    print('last line'+last_line_log)
    if('ERROR=0' not in last_line_log):
        sns_client.publish(TargetArn=snstopic,
                        Message = 'log_group_name: '+log_group_name+'\n'+'log_stream_name: '+log_stream_name+'\n'+'\n'.join(std_out_logs.splitlines()[-50:]),
                        Subject = f'{modelname} DBT Run Failure Grey {env}')
        event_struct["detail"]["jobStatus"]="FAILED"
        response = eventbridge_client.put_events(
                  Entries=[
                        {'Source': event_struct['source'],
                        'DetailType': event_struct['detail-type'],
                        'Detail': json.dumps(event_struct['detail']),
                        'EventBusName': event_struct['EventBusName']
                        }
                  ])
    else:
        sns_client.publish(TargetArn=snstopic,
                        Message = 'log_group_name: '+log_group_name+'\n'+'log_stream_name: '+log_stream_name+'\n'+'DBT RUN SUCCESS',
                        Subject = f'{modelname} DBT Run Success Grey {env}')
        event_struct["detail"]["jobStatus"]="SUCCESS"
        response = eventbridge_client.put_events(
                  Entries=[
                        {'Source': event_struct['source'],
                        'DetailType': event_struct['detail-type'],
                        'Detail': json.dumps(event_struct['detail']),
                        'EventBusName': event_struct['EventBusName']
                        }
                  ])

    # Check if the log group exists
    if(log_group_exists(log_group_name)==False):
        response = cloudwatch_client.create_log_group(
            logGroupName=log_group_name,
            tags={
                'Type': 'Back end',
                'RetentionPeriod': str(retention_period_in_days)
            }
        )
        response = cloudwatch_client.put_retention_policy(
            logGroupName=log_group_name,
            retentionInDays=retention_period_in_days)


    response = cloudwatch_client.create_log_stream(
        logGroupName=log_group_name,
        logStreamName=log_stream_name
    )
    response = cloudwatch_client.put_log_events(
    logGroupName=log_group_name,
    logStreamName=log_stream_name,
    logEvents=[
        {
            "timestamp": int(time.time() * 1000),
            "message": "stdout: "+stdout.decode("utf-8")
        },
        {
            "timestamp": int(time.time() * 1000),
            "message": "stderr: "+stderr.decode("utf-8")
        }
    ])

except Exception as e:
    message = {'log_group_name':log_group_name,
               'log_stream_name':log_stream_name,
                'error_message': str(e)}
    message_body ={
        'default': json.dumps(message)}
    sns_client.publish(TargetArn=snstopic,
                        Message = json.dumps(message_body),
                        Subject = f'{modelname} DBT Run Failure Grey {env}',
                        MessageStructure ='json')
    event_struct["detail"]["jobStatus"]="FAILED"
    response = eventbridge_client.put_events(
                Entries=[
                    {'Source': event_struct['source'],
                    'DetailType': event_struct['detail-type'],
                    'Detail': json.dumps(event_struct['detail']),
                    'EventBusName': event_struct['EventBusName']
                    }
                ])
    raise Exception("DBT RUN FAILURE")

