{{ config(materialized='table') }}

with volume_buckets as
(
select * from {{ ref('dbt_base_volume_buckets') }}
)
, revenue_buckets as
(
select * from {{ ref('dbt_base_revenue_buckets') }}
)
, vol_and_rev as
(
select * from revenue_buckets
union all
select * from volume_buckets
)

select * from vol_and_rev