{{ config(materialized='table') }}

select
    distinct InstitutionNumber ,
    AccountNumber ,
    AccountTypeID
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ACCOUNT_Institution_topK') }}