{{ config(materialized='table') }}

with settlement_currency as
(
select
    INSTITUTIONNUMBER ,
    CLIENTNUMBER ,
    accountnumber ,
    c.DESCRIPTION_1 settlement_currency ,
    count(*) over (partition by CLIENTNUMBER ) cnt
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ACCOUNT_Institution_topK') }}  vmca
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }}  c on vmca.ACCOUNTCURRENCY = c.INDEX_FIELD and vmca.INSTITUTIONNUMBER = c.Institution_Number
group by
    INSTITUTIONNUMBER ,
    CLIENTNUMBER ,
    accountnumber ,
    c.DESCRIPTION_1
)
select * from settlement_currency