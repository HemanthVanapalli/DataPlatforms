{{ config(materialized='table') }}

with vol_and_rev as
(
select * from {{  ref('dbt_base_vol_and_rev')  }}
)
, volrev3 as
(
select
    pp_all.rec_dt ,
    pp_all.recorddate date2 ,
    pp_all.valuedate date2_value ,
    pp_all.transactionslipnumber tx_slip_pay ,
    pp_all.ps_proc_amt payment_amount ,
    pp_all.filenumber ,
    pp_all.filenumber_lag ,
    pp_all.ps_slip ,
    vr.institutionnumber ,
    vr.clientnumber ,
    vr.accountnumber ,
    vr.recorddate ,
    vr.transactionslipnumber ,
    vr.txn_applied_to ,
    vr.ORIGINALREFERENCENUMBER ,
    vr.join_condition ,
    vr.MerchantRefNum ,
    vr.guid ,
    vr.txnid ,
    vr.cardtype ,
    vr.TRANSACTION_TYPE ,
    vr.transactionstatus ,
    vr.drcrindicator ,
    vr.reversal ,
    vr.settlementcurrency ,
    vr.transactioncurrency ,
    vr.tx_cnt ,
    vr.settle_amount ,
    vr.proc_amount ,
    vr.fee_type ,
    vr.TRANSACTIONDESTINATION
from vol_and_rev vr
left join {{ ref('dbt_base_acc_types') }} act on act.institutionnumber = vr.institutionnumber and act.accountnumber = vr.accountnumber
left join {{ ref('dbt_base_pay2') }} pp_all on vr.institutionnumber = pp_all.institutionnumber and vr.clientnumber = pp_all.clientnumber and vr.filenumber > pp_all.filenumber_lag and vr.filenumber <= pp_all.filenumber and (act.AccountTypeID = pp_all.AccountTypeID or pp_all.settlement_method = 'G')
)

select * from volrev3