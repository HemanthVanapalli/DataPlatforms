{{ config(materialized='table') }}

with ix_fee as
(
select
    vtif.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtif.transactionslipnumber, vtif.originalclearingslip, vtif.recorddate order by vtif.filedate ) rn
from {{ source('ukAcquiringRS2', 'TXN_INTERCHANGE_FEE') }} vtif
join {{ ref('dbt_base_pay2') }} pp_all on vtif.institutionnumber = pp_all.institutionnumber and vtif.clientnumber = pp_all.clientnumber and vtif.filenumber > pp_all.filenumber_lag and vtif.filenumber <= pp_all.filenumber and (pp_all.AccountTypeID = 7 or pp_all.settlement_method = 'G')
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtif.INSTITUTIONNUMBER = tt.Institution_Number and vtif.TRANSACTIONTYPE = tt.Index_Field
where vtif.accountnumber > 13000
)
select * from ix_fee