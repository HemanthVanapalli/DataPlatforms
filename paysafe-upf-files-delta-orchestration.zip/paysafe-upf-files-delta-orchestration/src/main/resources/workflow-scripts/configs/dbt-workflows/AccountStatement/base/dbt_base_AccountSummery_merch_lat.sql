{{ config(materialized='table') }}

with cte as(
select
MD.clientnumber ,
MD.institutionnumber ,
MD.legalname ,
MD.tradename,
MD.ClientStatus,
fmm.MERCHANTACCOUNTID FMA,
fmm.mlename MLE_NAME,
fmm.mleid MLE_ID,
fmm.pmlename PMLE_NAME,
fmm.pmleid PMLE_ID,
c.DESCRIPTION_1 country_desc,
fmm.business_relationship
from {{ ref('dbt_base_AccountSummery_merch_details_01') }} md
join {{ ref('dbt_base_AccountSummery_fma_mid_map') }} fmm on MD.CLIENTNUMBER::varchar = LTRIM(FMM.ACID, '0')::varchar
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_COUNTRY') }} c on md.institutionnumber = c.INSTITUTION_NUMBER and md.country = c.INDEX_FIELD
)
select * from cte
order by clientnumber