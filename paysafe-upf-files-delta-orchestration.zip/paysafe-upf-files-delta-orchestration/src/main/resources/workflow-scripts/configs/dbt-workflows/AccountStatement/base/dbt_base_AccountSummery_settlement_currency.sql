{{ config(materialized='table') }}

with cte as (
select
    vmca.INSTITUTIONNUMBER ,
    vmca.CLIENTNUMBER ,
    accountnumber ,
    accounttypeid ,
    at.DESCRIPTION_1 account_type ,
    vmca.AccountCurrency ,
    c.DESCRIPTION_1 swift_code
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ACCOUNT_Institution_topK') }} vmca
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }} c on vmca.ACCOUNTCURRENCY = c.INDEX_FIELD and vmca.INSTITUTIONNUMBER = c.Institution_Number
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_ACCOUNT_TYPE') }}  at on vmca.accounttypeid = at.INDEX_FIELD and vmca.InstitutionNumber = at.INSTITUTION_NUMBER
where accounttypeid = 12 and accountnumber > 13000
group by
    vmca.INSTITUTIONNUMBER ,
    vmca.CLIENTNUMBER ,
    accountnumber ,
    accounttypeid ,
    at.DESCRIPTION_1 ,
    vmca.AccountCurrency ,
    c.DESCRIPTION_1
order by accountnumber
)
select * from cte