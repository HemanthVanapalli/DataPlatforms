import argparse
import boto3
import botocore
import logging
import awscli
import base64
import json
import boto3
import time
from datetime import datetime
import subprocess
import yaml
import os
import shutil
import ruamel.yaml
import sys



def find_bucket_key(s3_path):
    s3_components = s3_path.split('/')
    bucket = s3_components[0]
    s3_key = ""
    if len(s3_components) > 1:
        s3_key = '/'.join(s3_components[1:])
    return bucket, s3_key


def split_s3_bucket_key(s3_path):
    if s3_path.startswith('s3://'):
        s3_path = s3_path[5:]
    return find_bucket_key(s3_path)

def get_dbt_details(property_file_path):
    s3_client = boto3.client("s3",region_name='ca-central-1')
    bucket_name, key_name = split_s3_bucket_key(property_file_path)
    obj = s3_client.get_object(Bucket=bucket_name, Key=key_name)
    s3_object_body = obj.get('Body')
    content_str = s3_object_body.read().decode()

    Lines = content_str.split('\n')

    properties={}

    for line in Lines:
        line = line.strip("\n ' '")
        if len(line)>0:
            key=line.split('=',1)[0].strip()
            value=line.split('=',1)[1].strip()
            properties[key]=value


    dbt_username_temp = properties['DBT_USERNAME_PREP']
    base64_bytes_username = dbt_username_temp.encode("ascii")
    string_bytes_user = base64.b64decode(base64_bytes_username)
    dbt_username_prep = string_bytes_user.decode("ascii")

    dbt_username_temp = properties['DBT_USERNAME_PROD']
    base64_bytes_username = dbt_username_temp.encode("ascii")
    string_bytes_user = base64.b64decode(base64_bytes_username)
    dbt_username_prod = string_bytes_user.decode("ascii")

    dbt_password_temp= properties['DBT_PASSWORD_PREP']
    base64_bytes_password = dbt_password_temp.encode("ascii")
    string_bytes_password = base64.b64decode(base64_bytes_password)
    dbt_password_prep = string_bytes_password.decode("ascii")

    dbt_password_temp= properties['DBT_PASSWORD_PROD']
    base64_bytes_password = dbt_password_temp.encode("ascii")
    string_bytes_password = base64.b64decode(base64_bytes_password)
    dbt_password_prod = string_bytes_password.decode("ascii")

    dbtsourcelocation = properties['DBTSOURCELOCATION']

    return dbt_username_prep,dbt_password_prep,dbt_username_prod,dbt_password_prod,dbtsourcelocation

def update_dbt_profile():
    with open(dbt_ec2_location+"profiles.yml", "r") as profile_file:
        data = yaml.safe_load(profile_file)
        data["dbt_workflows"]["outputs"]["prep"]["username"] = dbt_username_prep
        data["dbt_workflows"]["outputs"]["prep"]["password"] = dbt_password_prep
        data["dbt_workflows"]["outputs"]["prod"]["username"] = dbt_username_prod
        data["dbt_workflows"]["outputs"]["prod"]["password"] = dbt_password_prod
        data["dbt_workflows"]["target"] = env

    with open(dbt_ec2_location+"profiles.yml", "w") as update_profile_file:
        yaml.dump(data, update_profile_file)


def update_dbt_model_path(modelname):
    yaml = ruamel.yaml.YAML()
    yaml.indent(mapping=2, sequence=4, offset=2)

    with open(model_dir+"dbt_project.yml", 'r') as f:
        lines = f.readlines()
    with open(model_dir+"dbt_project.yml", 'w') as f:
        for line in lines:
            if line.strip().startswith('model-paths:'):
                f.write(f'model-paths: ["{modelname}"]\n')
            else:
                f.write(line)

def generate_dbt_run_command(model_info):
    dbt_variables = model_info["DBT_VARIABLES"]
    dbt_var_str =json.dumps(json.dumps(dbt_variables))

    dbt_run_command = "sudo dbt run"
    if dbt_variables:
        dbt_run_command += f" --vars {dbt_var_str}"

    return dbt_run_command



#main function

argParser = argparse.ArgumentParser()
argParser.add_argument("--properties", help="s3 file location of dbt properties file")
argParser.add_argument("--env",help="environment name")
argParser.add_argument("--snstopic",help="sns topic name")
argParser.add_argument("--bucketname",help="bucketname")
args = argParser.parse_args()

property_file_path = args.properties
env = args.env
snstopic = args.snstopic
bucketname = args.bucketname

dbt_username_prep,dbt_password_prep,dbt_username_prod,dbt_password_prod,dbtsourcelocation = get_dbt_details(property_file_path)

dbtsourcelocation=dbtsourcelocation.replace('${MgrBucketName}',bucketname)
dbt_ec2_location = '/usr/bin/dbt/home/dbt_workflows/'

try:
    subprocess.call(f'mkdir -p {dbt_ec2_location}', shell=True)
    subprocess.run(['aws', 's3', 'cp',dbtsourcelocation,dbt_ec2_location,'--recursive'])

    s3_client = boto3.client("s3",region_name='ca-central-1')
    sns_client = boto3.client('sns',region_name='ca-central-1')



    with open('/usr/bin/dbt/home/dbt_workflows/run_dbt_models.json','r') as model_file_data:
        model_details = json.load(model_file_data)
        data = [model for model in model_details if model['DBT_PROFILE'] == env]

    update_dbt_profile()

    cron_job = 'sudo crontab<<EOF'
    cron_job+= f'\n0 */1 * * * sh /usr/bin/dbt/home/dbt_workflows/dbt_job_init.sh s3://{bucketname}/pipeline-unity/configs/dbt-workflows/run_dbt_workflows.py s3://{bucketname}/pipeline-unity/configs/dbt-workflows/run_dbt_workflows.properties {env} {snstopic} {bucketname}'

    for model_info in data:
        dbt_run_command = generate_dbt_run_command(model_info)
        modelname = model_info["DBT_MODEL_NAME"]
        model_dir = '/usr/bin/dbt/home/dbt_models/'+ modelname + '/dbt_workflows/'
        if os.path.exists(model_dir):
            shutil.rmtree(model_dir)
        shutil.copytree(dbt_ec2_location, model_dir)
        update_dbt_model_path(modelname)
        print(os.getcwd())
        cront_line = model_info["DBT_MODEL_CRON"]
        load_type = model_info["DBT_LOAD_TYPE"]
        event_struct= model_info["DBT_PUBLISH_EVENT"]
        event = json.dumps(event_struct)

        if(load_type.lower()=='reload'):
            print("reload")
            os.system(f"python3 {model_dir}run_dbt_model.py --dirpath '{model_dir}' --dbtcommand '{dbt_run_command}' --snstopic '{snstopic}' --env '{env}' --event '{event}'")
        if(load_type.lower()=='load'):
            print("load")
            cron_job += f"\n{cront_line} python3 {model_dir}run_dbt_model.py --dirpath '{model_dir}' --dbtcommand '{dbt_run_command}' --snstopic '{snstopic}' --env '{env}' --event '{event}'"

    cron_job += '\nEOF'
    os.system(cron_job)


    response = s3_client.put_object(
        Bucket=bucketname,
        Key='pipeline-unity/configs/dbt-workflows/cronjob_timings.txt',
        Body=cron_job
    )

except Exception as e:
    message = {"error_message": str(e)}
    sns_client.publish(TargetArn=snstopic,
                        Message = json.dumps({'default': json.dumps(message)}),
                        Subject = f"DBT Workflow failure Grey {env}",
                        MessageStructure ='json')
    raise Exception("DBT Workflow failure")
