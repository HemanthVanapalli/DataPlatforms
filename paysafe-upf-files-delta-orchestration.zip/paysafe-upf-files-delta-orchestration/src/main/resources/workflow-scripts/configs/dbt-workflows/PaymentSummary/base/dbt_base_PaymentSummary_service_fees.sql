{{ config(materialized='table') }}

with service_fees as (
select
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tsf.recorddate,
    tsf.filedate) record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Service Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(FEEAMOUNT_PROCESSING) fee_amount_processing ,
    sum(FEEAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    sum(NUMBEROFSLIPS) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_SERVICE_FEE') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tsf
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tsf.TRANSACTIONTYPE = tt.Index_Field and tsf.INSTITUTIONNUMBER = tt.Institution_Number
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on tsf.clientnumber = md.clientnumber and tsf.institutionnumber = md.institutionnumber
where tsf.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and tsf.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
group by
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tsf.recorddate,
    tsf.filedate) ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency )
select * from service_fees