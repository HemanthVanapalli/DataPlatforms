{{ config(materialized='table') }}

with txn_fees as (
select * from {{ ref('dbt_base_PaymentSummary_txn_fees') }}
)
, merchant_fees as (
select * from {{ ref('dbt_base_PaymentSummary_merchant_fees') }}
)
, payment_fees as (
select * from {{ ref('dbt_base_PaymentSummary_payment_fees') }}
)
,
interchange_fees as (
select * from {{ ref('dbt_base_PaymentSummary_interchange_fees') }}
)
, scheme_fees as (
select * from {{ ref('dbt_base_PaymentSummary_scheme_fees') }}
) ,
misc_fees as (
select * from {{ ref('dbt_base_PaymentSummary_misc_fees') }}
 ) ,
service_fees as (
 select * from {{ ref('dbt_base_PaymentSummary_service_fees') }}
 ) ,
rev_by_fee as (
select
    *
from
    txn_fees
union all
select
    *
from
    scheme_fees
union all
select
    *
from
    interchange_fees
union all
select
    *
from
    payment_fees
union all
select
    *
from
    merchant_fees
union all
select
    *
from
    misc_fees
union all
select
    *
from
    service_fees
)
select * from rev_by_fee