{{ config(materialized='table') }}

with scheme_fee as (
SELECT
    vtsf.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtsf.transactionslipnumber, vtsf.numberoriginalslip, vtsf.recorddate order by vtsf.filedate) rn
from {{ source('ukAcquiringRS2', 'TXN_SCHEME_FEE') }} vtsf
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtsf.TRANSACTIONTYPE = tt.Index_Field and vtsf.INSTITUTIONNUMBER = tt.Institution_Number
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CHARGE_TYPE') }} ct on vtsf.CHARGETYPE = ct.Index_Field and vtsf.INSTITUTIONNUMBER = ct.Institution_Number
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vtsf.clientnumber = md.clientnumber and vtsf.institutionnumber = md.institutionnumber
where VTSF.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and VTSF.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
)
, scheme_fees as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Scheme Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from
    scheme_fee
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency )
select * from scheme_fees