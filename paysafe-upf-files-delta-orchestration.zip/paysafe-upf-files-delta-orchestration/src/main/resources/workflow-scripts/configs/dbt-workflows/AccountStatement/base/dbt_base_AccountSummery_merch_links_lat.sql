{{ config(materialized='table') }}

select
mcl.clientnumber,
mcl.groupnumber,
mcl.institutionnumber
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_LINKS') }} mcl
limit 1 OVER (partition by mcl.CLIENTNUMBER order by mcl.DATEOFEXTRACTION desc)