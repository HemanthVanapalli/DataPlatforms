{{ config(materialized='table') }}

with pay_fee as (
select
    vtpf.TRANSACTIONSLIPNUMBER ,
    vtpf.NUMBERORIGINALSLIP ,
    tps.TRANSACTIONSLIPNUMBER ,
    tps.NUMBERORIGINALSLIP ,
    tp.TRANSACTIONSLIPNUMBER ,
    tp.VALUEDATE actual_date ,
    vtpf.* ,
    tt.description_1 transaction_type
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_FEE') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) vtpf
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tps on  vtpf.NUMBERORIGINALSLIP = tps.TRANSACTIONSLIPNUMBER
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tp on tp.TRANSACTIONSLIPNUMBER = tps.NUMBERORIGINALSLIP
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtpf.INSTITUTIONNUMBER = tt.Institution_Number and vtpf.TRANSACTIONTYPE = tt.Index_Field
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vtpf.clientnumber = md.clientnumber and vtpf.institutionnumber = md.institutionnumber
where VTPF.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and VTPF.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
)
, payment_fees as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER + 1 FILENUMBER ,
    actual_date record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Payment Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(transactionamount_processing) fee_amount_processing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    count(*) txns
from
    pay_fee
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER + 1 ,
    actual_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    Transaction_Type ,
    drcrindicator ,
    settlementcurrency ,
    accountcurrency )

select * from payment_fees