{{ config(materialized='table') }}

with payments as (
SELECT
    case
        when tp.valuedate > current_date then 1
        else 0
    end future_pmt ,
    tp.CLIENTNUMBER client_No ,
    tp.TRANSACTIONSLIPNUMBER p_slip ,
    vtps.NUMBERORIGINALSLIP ps_os ,
    vtps.TRANSACTIONSLIPNUMBER ps_slip ,
    vtps.TRANSACTIONAMOUNT_PROCESSING ps_proc_amt ,
    tp.TRANSACTIONAMOUNT_PROCESSING p_proc_amt ,
    tp.RECORDDATE rec_dt ,
    nvl(LAG(tp.RECORDDATE) over (partition by tp.INSTITUTIONNUMBER, tp.clientnumber order by tp.RECORDDATE asc), '2021-01-01') rec_dt_lag ,
    tp.VALUEDATE value_date ,
    tp.FILENUMBER fn ,
    nvl(LAG(tp.FILENUMBER) over (partition by tp.INSTITUTIONNUMBER, tp.clientnumber order by rec_dt asc), 0) filenumber_lag ,
    tp.*
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by transactionslipnumber order by recorddate desc)) vtps
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc)) tp on vtps.NUMBERORIGINALSLIP = tp.TRANSACTIONSLIPNUMBER
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on tp.clientnumber = md.clientnumber and tp.institutionnumber = md.institutionnumber
where vtps.TRANSACTIONTYPE IN (250, 252, 251)
)
, pay2 as (
select
    min(filenumber) over (partition by institutionnumber,
    clientnumber) min_fn,
    LAG(transactionamount_processing) over (partition by clientnumber order by rec_dt asc) PRE_PAYMENT,
    transactionamount_processing NET_DEPOSIT,
    concat(concat(to_char(nvl(RECORDDATE, filedate), 'dd/Mon/yyyy'), ' to '), to_char(VALUEDATE, 'dd/Mon/yyyy')) DATE_RANGE,
    *
from
    payments
where 1=1
and recorddate >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and recorddate < date(TO_TIMESTAMP(1665014400000/ 1000))
)
select * from pay2