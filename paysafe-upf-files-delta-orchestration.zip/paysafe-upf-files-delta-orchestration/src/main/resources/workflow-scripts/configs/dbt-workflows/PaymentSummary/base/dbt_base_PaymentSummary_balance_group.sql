{{ config(materialized='table') }}

with balances as (
select
    decode(accounttypeid, 12, accountbalance_settlement) merch_payment_balance ,
    decode(accounttypeid, 7,  accountbalance_settlement) merch_fee_balance ,
    decode(accounttypeid, 15, accountbalance_settlement) merch_cost_balance ,
    decode(accounttypeid, 13, accountbalance_settlement) merch_hold_balance ,
    decode(accounttypeid, 14, accountbalance_settlement) merch_reserve_balance ,
    accountbalance_settlement total_balance ,
    mcbb.* ,
    sc.accounttypeid
from {{ source('ukAcquiringRS2', 'MERCHANT_CYCLE_BOOK_BALANCE') }} mcbb
left join {{ ref('dbt_base_PaymentSummary_acc_types') }}  sc on mcbb.AccountNumber = sc.accountnumber and mcbb.INSTITUTIONNUMBER = sc.INSTITUTIONNUMBER
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on mcbb.clientnumber = md.clientnumber and mcbb.institutionnumber = md.institutionnumber
where accounttypeid <> 15
limit 1 OVER (partition by mcbb.CLIENTNUMBER, mcbb.accountnumber, mcbb.filedate order by mcbb.DATEOFEXTRACTION desc)
)
, balance_group as (
select
    filedate ,
    institutionnumber ,
    clientnumber ,
    sum(merch_payment_balance) merch_payment_balance ,
    sum(merch_fee_balance) merch_fee_balance ,
    sum(merch_cost_balance) merch_cost_balance ,
    sum(merch_hold_balance) merch_hold_balance ,
    sum(merch_reserve_balance) merch_reserve_balance ,
    sum(total_balance) total_balance
from balances
group by
    filedate ,
    institutionnumber ,
    clientnumber
)
select * from balance_group