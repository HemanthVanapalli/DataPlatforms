{{ config(materialized='table') }}

with settles as
(
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    valuedate record_date ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    0 transactiontype ,
    CARDFLAG ,
    CARDBRAND ,
    txn_applied_to ,
    ORIGINALREFERENCENUMBER * 1 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    'Volume' fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(proc_amt) fee_amount_processing ,
    sum(settle_amt) fee_amount_settlement ,
    sum(settle_amt) fee_amount_account ,
    count(*) txns
from {{ ref('dbt_base_AccountSummery_tx_dd') }}
group by
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    valuedate ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    CARDFLAG ,
    CARDBRAND ,
    txn_applied_to ,
    ORIGINALREFERENCENUMBER ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency
)
select * from settles