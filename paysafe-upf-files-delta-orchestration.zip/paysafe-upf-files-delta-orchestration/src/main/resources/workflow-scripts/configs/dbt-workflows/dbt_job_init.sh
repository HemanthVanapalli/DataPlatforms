#!bin/bash

dbt_script_path=$1
properties_file_path=$2
env=$3
snstopic=$4
bucketname=$5


sudo aws s3 cp "$dbt_script_path" /usr/bin/dbt/home/dbt_workflows/run_dbt_workflows.py

sudo python3 /usr/bin/dbt/home/dbt_workflows/run_dbt_workflows.py --properties "$properties_file_path" --env "$env" --snstopic "$snstopic" --bucketname "$bucketname"

