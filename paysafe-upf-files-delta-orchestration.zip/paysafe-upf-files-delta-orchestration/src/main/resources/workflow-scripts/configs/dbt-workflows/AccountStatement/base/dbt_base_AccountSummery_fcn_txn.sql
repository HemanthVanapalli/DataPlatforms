{{ config(materialized='table') }}

with fcn_lookup as (
select
    recordSeq ,
    MerchantRefNum ,
    description ,
    guid ,
    arn ,
    Cardtype ,
    CardBin ,
    CardCategory ,
    ROW_NUMBER () over (partition by recordseq order by description,arn) rn
from {{ source('cards', 'cardFact') }} cf
JOIN {{ ref('dbt_base_AccountSummery_merch_lat') }} FMM ON CF.ACCOUNTID = FMM.FMA
where batchid > to_Char(add_months(Current_Date, -13), 'YYYYMMDD')::int
)
,fcn_txn as
(
select *
from fcn_lookup
where rn = 1
)
select * from fcn_txn