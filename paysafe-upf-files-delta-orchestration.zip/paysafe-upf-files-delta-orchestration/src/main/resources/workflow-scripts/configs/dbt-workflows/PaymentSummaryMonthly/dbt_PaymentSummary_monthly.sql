with merch_details as
 (
select * from {{ ref('dbt_base_PaymentSummary_merch_details') }}
)
,bank_details_lat as (
select * from {{ ref('dbt_base_PaymentSummary_bank_details_lat') }}
)
, merch_links_lat as (
select * from {{ ref('dbt_base_PaymentSummary_merch_links_lat') }}
)
, acc_types as (
select * from {{ ref('dbt_base_PaymentSummary_acc_types') }}
)
, balances as (
select * from {{ ref('dbt_base_PaymentSummary_balances') }}
)
, balance_group as (
select * from {{ ref('dbt_base_PaymentSummary_balance_group') }}
)
, payments as (
select * from {{ ref('dbt_base_PaymentSummary_payment') }}
)
, pay2 as (
select * from {{ ref('dbt_base_PaymentSummary_pay2') }}
)
, txn_fees as (
select * from {{ ref('dbt_base_PaymentSummary_txn_fees') }}
)
, merch_fee as (
select * from {{ ref('dbt_base_PaymentSummary_merch_fee') }}
)
, merchant_fees as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) record_date ,
    transactionstatus ,
    TransactionType ,
    nvl(Transaction_Type,
    CONCAT('tx type: ', TransactionType)) Transaction_Type ,
    DRCRINDICATOR ,
    0 reversal ,
    case
        when transaction_type like 'Visa%' then 'Scheme Fees'
        when transaction_type like 'Mastercard%' then 'Scheme Fees'
        else 'Merchant Fees'
    end fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(transactionamount_processing) fee_amount_proccessing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    sum(numberofslips) txns
from
    merch_fee
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency )
, pay_fee as (
select
    vtpf.TRANSACTIONSLIPNUMBER ,
    vtpf.NUMBERORIGINALSLIP ,
    tps.TRANSACTIONSLIPNUMBER ,
    tps.NUMBERORIGINALSLIP ,
    tp.TRANSACTIONSLIPNUMBER ,
    tp.VALUEDATE actual_date ,
    vtpf.* ,
    tt.description_1 transaction_type
from (select * from ukAcquiringRS2.TXN_PAYMENTS_FEE limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) vtpf
left join (select * from ukAcquiringRS2.TXN_PAYMENTS_SUMMARY limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tps on  vtpf.NUMBERORIGINALSLIP = tps.TRANSACTIONSLIPNUMBER
left join (select * from ukAcquiringRS2.TXN_PAYMENTS limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tp on tp.TRANSACTIONSLIPNUMBER = tps.NUMBERORIGINALSLIP
left join ukAcquiringRS2.rs2_choice_TRANSACTION_TYPE tt on vtpf.INSTITUTIONNUMBER = tt.Institution_Number and vtpf.TRANSACTIONTYPE = tt.Index_Field
join merch_details md on vtpf.clientnumber = md.clientnumber and vtpf.institutionnumber = md.institutionnumber
where VTPF.RECORDDATE = current_date-1
)
, payment_fees as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER + 1 FILENUMBER ,
    actual_date record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Payment Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(transactionamount_processing) fee_amount_processing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    count(*) txns
from
    pay_fee
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER + 1 ,
    actual_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    Transaction_Type ,
    drcrindicator ,
    settlementcurrency ,
    accountcurrency )
, ix_fee as (
select
    vtif.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtif.transactionslipnumber, vtif.originalclearingslip, vtif.recorddate order by vtif.filedate ) rn
from ukAcquiringRS2.TXN_INTERCHANGE_FEE vtif
left join ukAcquiringRS2.rs2_choice_TRANSACTION_TYPE tt on vtif.INSTITUTIONNUMBER = tt.Institution_Number and vtif.TRANSACTIONTYPE = tt.Index_Field
join merch_details md on vtif.clientnumber = md.clientnumber and vtif.institutionnumber = md.institutionnumber
where VTIF.RECORDDATE = current_date-1
) ,
interchange_fees as (
SELECT
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) record_date ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Interchange Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from
    ix_fee
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ) ,
scheme_fee as (
SELECT
    vtsf.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtsf.transactionslipnumber, vtsf.numberoriginalslip, vtsf.recorddate order by vtsf.filedate) rn
from ukAcquiringRS2.TXN_SCHEME_FEE vtsf
left join ukAcquiringRS2.RS2_CHOICE_TRANSACTION_TYPE tt on vtsf.TRANSACTIONTYPE = tt.Index_Field and vtsf.INSTITUTIONNUMBER = tt.Institution_Number
left join ukAcquiringRS2.RS2_CHOICE_CHARGE_TYPE ct on vtsf.CHARGETYPE = ct.Index_Field and vtsf.INSTITUTIONNUMBER = ct.Institution_Number
join merch_details md on vtsf.clientnumber = md.clientnumber and vtsf.institutionnumber = md.institutionnumber
where VTSF.RECORDDATE = current_date-1
)
, scheme_fees as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Scheme Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from
    scheme_fee
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ) ,
misc_fees as (
select
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tmt.recorddate,
    tmt.filedate) record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    reversal ,
    'Misc Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(TRANSACTIONAMOUNT_PROCESSING) fee_amount_processing ,
    sum(TRANSACTIONAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    count(*) txns
from (select * from ukAcquiringRS2.TXN_MISCELLANEOUS_TRANSACTIONS limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tmt
left join ukAcquiringRS2.RS2_CHOICE_TRANSACTION_TYPE tt on tmt.TRANSACTIONTYPE = tt.Index_Field and tmt.INSTITUTIONNUMBER = tt.Institution_Number
join merch_details md on tmt.clientnumber = md.clientnumber and tmt.institutionnumber = md.institutionnumber
where transactioncategory = 7
and tmt.RECORDDATE = current_date-1
group by
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tmt.recorddate,
    tmt.filedate) ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    settlementcurrency ,
    accountcurrency ) ,
service_fees as (
select
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tsf.recorddate,
    tsf.filedate) record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Service Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(FEEAMOUNT_PROCESSING) fee_amount_processing ,
    sum(FEEAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    sum(NUMBEROFSLIPS) txns
from (select * from ukAcquiringRS2.TXN_SERVICE_FEE limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tsf
left join ukAcquiringRS2.RS2_CHOICE_TRANSACTION_TYPE tt on tsf.TRANSACTIONTYPE = tt.Index_Field and tsf.INSTITUTIONNUMBER = tt.Institution_Number
join merch_details md on tsf.clientnumber = md.clientnumber and tsf.institutionnumber = md.institutionnumber
where tsf.RECORDDATE = current_date-1
group by
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tsf.recorddate,
    tsf.filedate) ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ) ,
rev_by_fee as
(
select * from txn_fees
union all
select * from scheme_fees
union all
select * from interchange_fees
union all
select * from payment_fees
union all
select * from merchant_fees
union all
select * from misc_fees
union all
select * from service_fees
)
, tx as (
select
    vts.CLIENTNUMBER ,
    vts.INSTITUTIONNUMBER,
    vts.ACCOUNTNUMBER ,
    vtt.FILENUMBER ,
    vtt.DATEOFEXTRACTION ,
    vtt.recorddate VALUEDATE ,
    vtt.TRANSACTIONSLIPNUMBER slip,
    ORIGINALREFERENCENUMBER,
    vtt.INWARDFEENUMBER ,
    rcs.DESCRIPTION_1 brand,
    vtt.REVERSAL ,
    vtt.TRANSACTIONAMOUNT_PROCESSING proc_amt ,
    vtt.TRANSACTIONAMOUNT_SETTLEMENT settle_amt,
    vtt.TRANSACTIONCATEGORY txcat ,
    tt.DESCRIPTION_1 Transaction_Type ,
    vtt.TRANSACTIONSTATUS ,
    vts.TRANSACTIONCURRENCY ,
    vts.SETTLEMENTCURRENCY ,
    vtt.DRCRINDICATOR ,
    sum(vtt.TRANSACTIONAMOUNT_PROCESSING) over (partition by vtt.VALUEDATE,
    vtt.TRANSACTIONTYPE ) proc_day ,
    vts.TRANSACTIONAMOUNT_PROCESSING total_proc ,
    ROW_NUMBER() over (PARTITION by originalreferencenumber) rn
from (select * from ukAcquiringRS2.TXN_TRANSACTIONS limit 1 over (partition by transactionslipnumber order by filedate desc)) vtt
left join (select * from ukAcquiringRS2.TXN_SUMMARY limit 1 over (partition by transactionslipnumber order by filedate desc)) vts on vtt.SOURCESETTLEMENT = vts.SOURCESETTLEMENT
left join ukAcquiringRS2.RS2_CHOICE_TRANSACTION_TYPE tt on vtt.INSTITUTIONNUMBER = tt.Institution_Number  and vtt.TRANSACTIONTYPE = tt.Index_Field
left join (select * from ukAcquiringRS2.SETUP_TRANSACTION limit 1 over (partition by recordidnumber order by filedate desc)) st on vtt.INWARDFEENUMBER = st.RECORDIDNUMBER and vtt.INSTITUTIONNUMBER = st.INSTITUTIONNUMBER
left join ukAcquiringRS2.RS2_CHOICE_SERVICES rcs on rcs.INDEX_FIELD = st.SERVICEID and rcs.INSTITUTION_NUMBER = st.INSTITUTIONNUMBER
join merch_details md on vts.clientnumber = md.clientnumber and vts.institutionnumber = md.institutionnumber
where  vtt.RECORDDATE = current_date-1
) ,
tx_dd as
(
select * from tx where rn = 1
) ,
settles as (
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    TRANSACTIONSTATUS ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    valuedate ,
    transactioncurrency ,
    settlementcurrency ,
    count(*) tx_cnt ,
    sum(proc_Amt) proc_amount ,
    sum(settle_amt) settle_amount
from
    tx_dd
group by
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    TRANSACTIONSTATUS ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    valuedate ,
    transactioncurrency ,
    settlementcurrency ) ,
misc as (
select
    vtmt.*,
    'Chargeback' TRANSACTION_TYPE,
    rcs.DESCRIPTION_1 brand ,
    substr(vtmt.transactioncurrency,
    1,
    3) tx_currency
from (select * from ukAcquiringRS2.TXN_MISCELLANEOUS_TRANSACTIONS limit 1 over (partition by transactionslipnumber order by recorddate desc) ) vtmt
left join (select * from ukAcquiringRS2.TXN_TRANSACTIONS limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tt on vtmt.NUMBERORIGINALSLIP = tt.TRANSACTIONSLIPNUMBER
left join (select * from ukAcquiringRS2.SETUP_TRANSACTION limit 1 over (partition by recordidnumber order by filedate desc)) st on tt.INWARDFEENUMBER = st.RECORDIDNUMBER and tt.INSTITUTIONNUMBER = st.INSTITUTIONNUMBER
left join ukAcquiringRS2.RS2_CHOICE_TRANSACTION_CATEGORY Tc on vtmt.INSTITUTIONNUMBER = tc.Institution_Number and vtmt.TRANSACTIONCATEGORY = tc.Index_Field
left join ukAcquiringRS2.RS2_CHOICE_SERVICES rcs on rcs.INDEX_FIELD = st.SERVICEID and rcs.INSTITUTION_NUMBER = st.INSTITUTIONNUMBER
join merch_details md on tt.clientnumber = md.clientnumber and tt.institutionnumber = md.institutionnumber
where vtmt.transactioncategory in ( 2,50)
and vtmt.RECORDDATE = current_date-1
) ,
chargebacks as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    recorddate ,
    transactioncurrency ,
    accountcurrency settlementcurrency ,
    count(*) tx_cnt ,
    sum(transactionamount_processing) proc_amount ,
    sum(transactionamount_account) settle_amount
from
    misc
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    recorddate ,
    transactioncurrency ,
    accountcurrency ) ,
volumes as
(
select * from chargebacks
union all
select * from settles
)
, volume_buckets as (
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    recorddate ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    drcrindicator ,
    reversal ,
    settlementcurrency ,
    case
        when TRANSACTION_TYPE = 'Chargeback' then settle_amount
        else 0
    end pmt_total_chargeback ,
    case
        when TRANSACTION_TYPE = 'Refund (Credit)' then settle_amount
        else 0
    end pmt_total_credit ,
    case
        when TRANSACTION_TYPE in ('Cardholder Funds Transfer',
        'Unique transaction',
        'Purchase',
        'Interchange Payment') then settle_amount
        else 0
    end pmt_total_settlement ,
    0 pmt_discount_fee ,
    0 pmt_transaction_fee ,
    0 interchange_scheme_fee ,
    0 pmt_chargeback_fee ,
    0 pmt_monthly_fee ,
    0 pmt_payment_fee ,
    0 PMT_TOTAL_FEES
from
volumes
) ,
revenue_buckets as (
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    record_date recorddate ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    drcrindicator ,
    reversal ,
    accountcurrency settlementcurrency ,
    0 pmt_total_chargeback ,
    0 pmt_total_credit ,
    0 pmt_total_settlement ,
    case
        when transaction_type = 'Discount Fee' then fee_amount_account
        else 0
    end pmt_discount_fee ,
    case
        when transaction_type in ('Declined Authorization Fee',
        'Gateway Per Click Fee',
        'Authorisation fee- approved') then fee_amount_account
        else 0
    end pmt_transaction_fee ,
    case
        when fee_type in ('Interchange Fees',
        'Scheme Fees') then fee_amount_account
        else 0
    end interchange_scheme_fee ,
    case
        when transaction_type = 'CBK Fee' then fee_amount_account
        else 0
    end pmt_chargeback_fee ,
    case
        when transaction_type in ('Monthly Service Fee',
        'Monthly Minimum Fee') then fee_amount_account
        else 0
    end pmt_monthly_fee ,
    case
        when transaction_type in ('SEPA Payment Fee',
        'Faster Payment Fee',
        'WIRE Payment Fee') then fee_amount_account
        else 0
    end pmt_payment_fee ,
    fee_amount_account PMT_TOTAL_FEES
from
rev_by_fee
)
,vol_and_rev as
(
select * from revenue_buckets
union all
select * from volume_buckets
)
, volrev2 as (
select
    institutionnumber ,
    clientnumber ,
    FILENUMBER ,
    recorddate ,
    settlementcurrency ,
    transactionstatus ,
    sum(pmt_total_chargeback * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_total_chargeback ,
    sum(pmt_total_credit * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_total_credit ,
    sum(pmt_total_settlement * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_total_settlement ,
    sum(pmt_discount_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_discount_fee ,
    sum(pmt_transaction_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_transaction_fee ,
    sum(interchange_scheme_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_interchange_scheme_fee ,
    sum(pmt_chargeback_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_chargeback_fee ,
    sum(pmt_monthly_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_monthly_fee ,
    sum(pmt_payment_fee * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) pmt_payment_fee ,
    sum(PMT_TOTAL_FEES * decode(reversal, 0, 1, 1,-1, 1) * decode(drcrindicator, '002', 1, '001',-1, 1)) PMT_TOTAL_FEES
from vol_and_rev
where transactionstatus in (2,9)
group by
    institutionnumber ,
    clientnumber ,
    FILENUMBER ,
    recorddate ,
    settlementcurrency ,
    transactionstatus
)
, volrev3 as
(
select
    pp_all.rec_dt ,
    pp_all.rec_dt_lag ,
    pp_all.recorddate date2 ,
    pp_all.valuedate date2_value ,
    pp_all.transactionslipnumber tx_slip_pay ,
    pp_all.ps_proc_amt payment_amount ,
    vr.*
from
    volrev2 vr
left join pay2 pp_all on
    vr.institutionnumber = pp_all.institutionnumber
    and vr.clientnumber = pp_all.clientnumber
    and vr.filenumber > pp_all.filenumber_lag
    and vr.filenumber <= pp_all.filenumber
)
, volrev4 as (
select
    institutionnumber ,
    clientnumber ,
	recorddate,
    settlementcurrency ,
    transactionstatus ,
    max(rec_dt_lag) rec_dt_lag  ,
    max(rec_dt) rec_dt ,
    sum(pmt_total_chargeback) pmt_total_chargeback ,
    sum(pmt_total_credit) pmt_total_credit ,
    sum(pmt_total_settlement) pmt_total_settlement ,
    sum(pmt_discount_fee) pmt_discount_fee ,
    sum(pmt_transaction_fee) pmt_transaction_fee ,
    sum(pmt_interchange_scheme_fee) pmt_interchange_scheme_fee ,
    sum(pmt_chargeback_fee) pmt_chargeback_fee ,
    sum(pmt_monthly_fee) pmt_monthly_fee ,
    sum(pmt_payment_fee) pmt_payment_fee ,
    sum(PMT_TOTAL_FEES) PMT_TOTAL_FEES
from
    volrev3
    where 1=1
    and rec_dt = current_date -1
    group by institutionnumber,
    clientnumber,
	recorddate,
    settlementcurrency,
    transactionstatus
)
,output1 as (
select
    mdl.FMA ,
    mdl.legalname LEGALNAME,
    mdl.INSTITUTIONNUMBER INSTITUTION_NO ,
	vr.recorddate,
    case
        when mdl.institutionnumber = 10 then 'Paysafe Payment Solutions Limited'
        when mdl.institutionnumber = 12 then 'Paysafe Financial Services Limited'
        else null
    end LEGAL_ENTITY ,
    mdl.clientnumber TID ,
    mdl.clientnumber MID ,
    case
        when instr(mll.settlement_method,
        'SAX') > 0 then 'SAXO'
        when instr(mll.settlement_method,
        'LHV') > 0 then 'LHV'
        when instr(mll.settlement_method,
        'BMO') > 0 then 'BMO'
    end PAYMENT_BANK_CODE ,
    bdl.counterbankaccount BANK_ACT_NBR ,
    bl2.filedate START_BALANCE_DATE ,
    bl2.total_balance START_BALANCE ,
    bl2.total_balance BALANCE_CURRENT ,
    pp1.valuedate LATEST_PAYMENT_DATE ,
    pp1.transactionamount_processing LATEST_PAYMENT_AMOUNT ,
    pp1.p_slip LATEST_PAYMENT_SLIP ,
    pp2.valuedate LAST_PAYMENT_DATE ,
    pp2.transactionamount_processing LAST_PAYMENT_AMOUNT ,
    pp2.p_slip LAST_PAYMENT_SLIP ,
    bl1.filedate END_BALANCE_DATE ,
    bl1.total_balance END_BALANCE ,
    rcc.DESCRIPTION_1 SETTLEMENTCURRENCY ,
    rcts.DESCRIPTION_1 TRANSACTIONSTATUS ,
    vr.PMT_TOTAL_CHARGEBACK ,
    vr.PMT_TOTAL_CREDIT ,
    vr.PMT_TOTAL_SETTLEMENT ,
    vr.PMT_DISCOUNT_FEE ,
    vr.PMT_TRANSACTION_FEE ,
    vr.PMT_CHARGEBACK_FEE ,
    vr.PMT_MONTHLY_FEE ,
    vr.PMT_PAYMENT_FEE ,
    vr.PMT_TOTAL_FEES,
    mdl.PMLE_ID,
    mdl.PMLE_NAME,
    mdl.MLE_ID,
    mdl.MLE_NAME,
    mdl.tradename TRADENAME,
    case
        when mdl.institutionnumber = 10 then '89'
        when mdl.institutionnumber = 12 then '79'
        else null
    end LEGAL_ENTITY_CODE,
    mll.groupnumber GROUP_ID
from merch_details mdl
left join merch_links_lat mll on mdl.clientnumber = mll.clientnumber
left join bank_details_lat bdl on mdl.clientnumber = bdl.clientnumber
left join volrev4 vr on mdl.institutionnumber = vr.institutionnumber and mdl.clientnumber = vr.clientnumber
left join ukAcquiringRS2.RS2_CHOICE_CURRENCY rcc on vr.settlementcurrency = rcc.INDEX_FIELD and vr.institutionnumber = rcc.INSTITUTION_NUMBER
left join pay2 pp1 on pp1.CLIENTNUMBER = mdl.CLIENTNUMBER and pp1.rec_dt = vr.rec_dt
left join pay2 pp2 on pp2.CLIENTNUMBER = mdl.CLIENTNUMBER and pp2.rec_dt = vr.rec_dt_lag
left join balance_group bl1 on mdl.clientnumber = bl1.clientnumber and bl1.filedate = current_Date - 1
left join balance_group bl2 on mdl.clientnumber = bl2.clientnumber and bl2.filedate = current_Date - 2
left join ukAcquiringRS2.RS2_CHOICE_TRANSACTION_STATUS rcts on rcts.INSTITUTION_NUMBER = mdl.institutionnumber and rcts.INDEX_FIELD = vr.transactionstatus
)
select * from output1