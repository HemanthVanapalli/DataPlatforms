{{ config(materialized='table') }}

select
    recordSeq ,
    txnid ,
    paymentid ,
    settlementid ,
    arn ,
    MerchantRefNum ,
    guid ,
    Cardtype ,
    description
from {{ source('cards', 'cardFact') }}  cf
JOIN {{ ref('dbt_base_merch_details') }} FMM ON CF.ACCOUNTID = FMM.FMA
where batchid >= to_Char(add_months(current_date, -13), 'YYYYMMDD')::int
limit 1 over (partition by recordseq order by description,arn)