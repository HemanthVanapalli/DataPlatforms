{{ config(materialized='table') }}

with merch_details as
(
select * from {{ ref('dbt_base_merch_details') }}
)
, cte as (
select
tf.gatewayReconciliationId,
tf2.merchantdescriptor_dynamicdescriptor
from
{{ ref('dbt_base_transactions_query1') }} tf
join merch_details fmm on tf.event_origin_accountid::!int = fmm.FMA
left join
{{ ref('dbt_base_transactions_query2') }} tf2 on cast(tf2.id as varchar)= cast(tf.paymentid as varchar)
)
select * from cte