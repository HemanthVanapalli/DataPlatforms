{{ config(materialized='incremental') }}


with output1 as
(
select
    mdl.FMA,
    mdl.legalname LEGALNAME,
    rcas.DESCRIPTION_1 ACCOUNT_STATUS ,
    CASE
        WHEN UPPER(VR.TRANSACTION_TYPE) LIKE '%FEE%' THEN VR.TRANSACTION_TYPE
        WHEN VR.TRANSACTION_TYPE IN ('Unique transaction',
        'Purchase',
        'Refund (Credit)',
        'Chargebacks',
        'Adjustment',
        'Acct Funding Transaction DR',
        'Rejects (Financial)') THEN VR.TRANSACTION_TYPE
        ELSE CONCAT(VR.TRANSACTION_TYPE, ' Fee')
    END AS "TXN_TYPE" ,
    rcts.DESCRIPTION_1 TRANSACTION_STATUS ,
    vr.transactionslipnumber TXN_ID ,
    vr.TXN_APPLIED_TO ,
    vr.recorddate TXN_DATE ,
    CASE
        WHEN vr.transaction_type in ('Adjustment','Fee Collection', 'Refund Markup fee') then
        case
            when VR.DRCRINDICATOR = 1 then VR.proc_amount
            else -vr.proc_amount
        end
        WHEN VR.TRANSACTION_TYPE IN ('Unique transaction',
        'Purchase',
        'Misc. CR transaction',
        'Acct Funding Transaction DR',
        'Rejects (Financial)') THEN VR.proc_amount
        WHEN VR.TRANSACTION_TYPE like ('%CR') THEN VR.proc_amount
        ELSE -VR.proc_amount
    END AS PROCESSING_AMOUNT ,
    CASE
        WHEN vr.transaction_type in ('Adjustment','Fee Collection', 'Refund Markup fee') then
        case
            when VR.DRCRINDICATOR = 1 then VR.SETTLE_AMOUNT
            else -vr.SETTLE_AMOUNT
        end
        WHEN VR.TRANSACTION_TYPE IN ('Unique transaction',
        'Purchase',
        'Adjustment',
        'Misc. CR transaction',
        'Acct Funding Transaction DR',
        'Rejects (Financial)') THEN VR.SETTLE_AMOUNT
        WHEN VR.TRANSACTION_TYPE like ('%CR') THEN VR.SETTLE_AMOUNT
        ELSE -VR.SETTLE_AMOUNT
    END AS SETTLE_AMOUNT ,
    vr.TX_CNT ,
    vr.MerchantRefNum MERCHANT_TXN_ID ,
    vr.ORIGINALREFERENCENUMBER CONF_NBR ,
    vr.cardtype CARD_BRAND ,
    rcc.DESCRIPTION_1 PROCESSING_CURRENCY ,
    rcc1.DESCRIPTION_1 SETTLEMENT_CURRENCY ,
    vr.date2 POST_DATE ,
    vr.date2_value PAYMENT_DATE ,
    vr.tx_slip_pay PAYMENT_TXN_ID ,
    vr.PAYMENT_AMOUNT ,
    '' SETTLEMENT_BANK_ACCOUNT ,
    mdl.clientnumber MID ,
    vr.ACCOUNTNUMBER ,
    act.account_type_desc ,
    vr.txnid NETBANX_REF_ID ,
    vr.ORIGINALREFERENCENUMBER NETBANX_TRANSACTION_ID ,
    vr.GUID ,
    fcn.DESCRIPTION ,
    mdl.INSTITUTIONNUMBER INSTITUTION_NO,
    '' ACCOUNT_PROCESSING_AMOUNT,
    '' ACCOUNT_PROCESSING_CURRENCY,
    tfp.merchantDescriptor_dynamicDescriptor,
    vr.FEE_TYPE,
	vr.ps_slip PAYMENT_SUMMARY_TXN_ID,
	vr.TRANSACTIONDESTINATION,
    mdl.PMLE_ID,
    mdl.PMLE_NAME,
    mdl.MLE_ID,
    mdl.MLE_NAME,
    mdl.TRADENAME,
    case
        when mdl.institutionnumber=10 then '89'
        when mdl.institutionnumber=12 then '79'
        else null
    end LEGAL_ENTITY_CODE,
    mll.groupnumber GROUP_ID,
    mdl.business_relationship,
    {{ var("RUNDATE") }} as run_date
from {{ ref('dbt_base_merch_details') }} mdl
left join {{ ref('dbt_base_merch_links_lat') }} mll on mdl.clientnumber = mll.clientnumber
join {{ ref('dbt_base_volrev3') }} vr on mdl.institutionnumber = vr.institutionnumber and mdl.clientnumber = vr.clientnumber
left join {{ ref('dbt_base_fcn_txn') }} fcn on fcn.recordseq = vr.ORIGINALREFERENCENUMBER
left join {{ ref('dbt_base_acc_types') }} act on act.institutionnumber = mdl.institutionnumber and act.accountnumber = vr.accountnumber
left join {{ref('dbt_base_output1_innerquery')}} rcc on vr.transactioncurrency = rcc.index_field
left join {{ref('dbt_base_output1_innerquery')}} rcc1 on vr.settlementcurrency = rcc1.index_field
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_ACCOUNT_STATUS') }} rcas on rcas.INSTITUTION_NUMBER = vr.institutionnumber and rcas.INDEX_FIELD = mdl.ClientStatus
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_STATUS') }} rcts on rcts.INSTITUTION_NUMBER = vr.institutionnumber and rcts.INDEX_FIELD = vr.transactionstatus
left join {{ ref('dbt_base_transactions_fact_payments') }} tfp on cast(vr.join_condition as varchar) = cast(tfp.gatewayReconciliationId as varchar)
)
select * from output1
where POST_DATE >= {{ var("RUNDATE") }}-31