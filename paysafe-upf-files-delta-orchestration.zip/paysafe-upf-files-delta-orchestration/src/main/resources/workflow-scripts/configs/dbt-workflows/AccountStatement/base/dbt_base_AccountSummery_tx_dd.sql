{{ config(materialized='table') }}

with tx as (
select
    vts.CLIENTNUMBER ,
    vts.INSTITUTIONNUMBER,
    vts.ACCOUNTNUMBER ,
    vtt.DATEOFEXTRACTION ,
    vtt.recorddate VALUEDATE ,
    VTT.TRANSACTIONSLIPNUMBER ,
    vtt.TRANSACTIONSLIPNUMBER slip,
    vtt.INWARDFEENUMBER ,
    rcs.DESCRIPTION_1 brand,
    vtt.REVERSAL ,
    vtt.TRANSACTIONAMOUNT_PROCESSING proc_amt ,
    vtt.TRANSACTIONAMOUNT_SETTLEMENT settle_amt,
    vtt.TRANSACTIONCATEGORY txcat ,
    tt.DESCRIPTION_1 Transaction_Type ,
    vtt.TRANSACTIONSLIPNUMBER::varchar txn_applied_to ,
    vtt.CARDFLAG ,
    vtt.CARDBRAND ,
    vtt.TRANSACTIONSTATUS ,
    vts.ACCOUNTCURRENCY ,
    vts.TRANSACTIONCURRENCY ,
    vts.SETTLEMENTCURRENCY ,
    vtt.DRCRINDICATOR ,
    vtt.ORIGINALREFERENCENUMBER ,
    sum(vtt.TRANSACTIONAMOUNT_PROCESSING) over (partition by vtt.VALUEDATE,vtt.TRANSACTIONTYPE ) proc_day ,
    vts.TRANSACTIONAMOUNT_PROCESSING total_proc ,
    ROW_NUMBER() over (PARTITION by vtt.transactionslipnumber,vtt.transactionstatus order by vtt.recorddate desc) rn
from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} vtt
left join {{ source('ukAcquiringRS2', 'TXN_SUMMARY') }} vts on vtt.SOURCESETTLEMENT = vts.SOURCESETTLEMENT
join {{ ref('dbt_base_AccountSummery_merch_lat') }} mli on mli.clientnumber = vts.clientnumber and mli.institutionnumber = vts.institutionnumber
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtt.INSTITUTIONNUMBER = tt.Institution_Number and vtt.TRANSACTIONTYPE = tt.Index_Field
left join {{ source('ukAcquiringRS2', 'SETUP_TRANSACTION') }} st on vtt.INWARDFEENUMBER = st.RECORDIDNUMBER and vtt.INSTITUTIONNUMBER = st.INSTITUTIONNUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_SERVICES') }} rcs on rcs.INDEX_FIELD = st.SERVICEID and rcs.INSTITUTION_NUMBER = st.INSTITUTIONNUMBER
where vts.RECORDDATE >= {{ var("RUNDATE") }} -31 and vts.accountnumber > 13000
)
, tx_dd as
(
select *
from tx
where rn = 1
)
select * from tx_dd