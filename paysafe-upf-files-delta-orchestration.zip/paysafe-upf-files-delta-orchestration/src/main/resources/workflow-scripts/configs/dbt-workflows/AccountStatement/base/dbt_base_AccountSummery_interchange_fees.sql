{{ config(materialized='table') }}

with ix_fee as
(
select
    vtif.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtif.transactionslipnumber, vtif.originalclearingslip, vtif.recorddate order by vtif.filedate ) rn
from {{ source('ukAcquiringRS2', 'TXN_INTERCHANGE_FEE') }} vtif
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtif.INSTITUTIONNUMBER = tt.Institution_Number and vtif.TRANSACTIONTYPE = tt.Index_Field
where RECORDDATE >= current_date-31 and vtif.accountnumber > 13000
)
, interchange_fees as
(
SELECT
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TransactionType ,
    -1 CARDFLAG ,
    -1 CARDBRAND ,
    originalclearingslip::varchar txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Interchange Fees' fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from ix_fee
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,filedate) ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TransactionType ,
    originalclearingslip ,
    Transaction_Type ,
    DRCRINDICATOR ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency
)
select * from interchange_fees