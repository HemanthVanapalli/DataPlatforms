{{ config(materialized='table') }}

with volume_buckets as
(
select * from {{ ref('dbt_base_volume_buckets') }}
)
, rev_by_fee as
(
select * from {{ ref('dbt_base_rev_by_fee') }}
)
, revenue_buckets as
(
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    record_date recorddate ,
    rbf.transactionslipnumber ,
    txn_applied_to ,
    filenumber ,
    '' ORIGINALREFERENCENUMBER ,
    vb.join_condition ,
    '' merchantrefnum ,
    '' guid ,
    '' txnid ,
    '' cardtype ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    drcrindicator ,
    reversal ,
    accountcurrency settlementcurrency ,
    transactioncurrency ,
    txns tx_cnt ,
    fee_amount_account settle_amount ,
    fee_amount_proccessing proc_amount ,
    fee_type ,
    '' TRANSACTIONDESTINATION ,
    1 rn
from rev_by_fee rbf
left join (select transactionslipnumber, join_condition from volume_buckets where join_condition is not null
limit 1 over (partition by transactionslipnumber order by recorddate asc)) vb on cast(vb.transactionslipnumber as varchar) = cast(rbf.txn_applied_to as varchar)
)

select * from revenue_buckets