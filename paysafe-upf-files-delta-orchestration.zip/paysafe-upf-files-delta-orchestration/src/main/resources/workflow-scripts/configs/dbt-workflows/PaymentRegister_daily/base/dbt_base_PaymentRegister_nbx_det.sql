{{ config(materialized='table') }}

with nbx_det as
(
select
pad2.MERCHANTACCOUNTID,
pad2.mlename,
pad2.mleid,
pad2.pmlename,
pad2.pmleid,
pad2.isactive,
pad2.iscurrent,
fmm.acid
from {{ ref('dbt_base_PaymentRegister_fma_mid_map') }} fmm
left join {{ source('mm', 'ProcessingAccount_Dim') }} pad2  on pad2.merchantaccountid = fmm.fmaid
where pad2.iscurrent = TRUE and pad2.isactive = 1
)
select * from nbx_det