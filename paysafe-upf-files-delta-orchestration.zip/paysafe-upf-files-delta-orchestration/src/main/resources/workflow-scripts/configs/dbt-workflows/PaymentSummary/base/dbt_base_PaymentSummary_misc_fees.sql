{{ config(materialized='table') }}

with misc_fees as (
select
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tmt.recorddate,
    tmt.filedate) record_date ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    reversal ,
    'Misc Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(TRANSACTIONAMOUNT_PROCESSING) fee_amount_processing ,
    sum(TRANSACTIONAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    count(*) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tmt
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tmt.TRANSACTIONTYPE = tt.Index_Field and tmt.INSTITUTIONNUMBER = tt.Institution_Number
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on tmt.clientnumber = md.clientnumber and tmt.institutionnumber = md.institutionnumber
where transactioncategory = 7
and tmt.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and tmt.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
group by
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(tmt.recorddate,
    tmt.filedate) ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    settlementcurrency ,
    accountcurrency )
select * from misc_fees