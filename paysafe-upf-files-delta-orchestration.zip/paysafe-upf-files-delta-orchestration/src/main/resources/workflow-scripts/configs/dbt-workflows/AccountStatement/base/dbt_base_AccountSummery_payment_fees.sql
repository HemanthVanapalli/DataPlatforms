{{ config(materialized='table') }}

with pay_fee as (
select
    vtpf.NUMBERORIGINALSLIP ,
    tps.NUMBERORIGINALSLIP ,
    tp.TRANSACTIONSLIPNUMBER tp_slip ,
    tp.VALUEDATE actual_date ,
    vtpf.* ,
    tt.description_1 transaction_type
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_FEE') }}  limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) vtpf
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tps on vtpf.NUMBERORIGINALSLIP = tps.TRANSACTIONSLIPNUMBER
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }}  limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tp on tp.TRANSACTIONSLIPNUMBER = tps.NUMBERORIGINALSLIP
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtpf.INSTITUTIONNUMBER = tt.Institution_Number and vtpf.TRANSACTIONTYPE = tt.Index_Field
where tps.accountnumber > 13000
)
, payment_fees as
(
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    actual_date record_date ,
    TP_SLIP TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    -1 CARDFLAG ,
    -1 CARDBRAND ,
    tp_slip::varchar txn_applied_to ,
    tp_slip ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Payment Fees' fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(transactionamount_processing) fee_amount_processing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    count(*) txns
from
    pay_fee
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    actual_date ,
    TP_SLIP ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tp_slip ,
    Transaction_Type ,
    drcrindicator ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency
)
select * from payment_fees