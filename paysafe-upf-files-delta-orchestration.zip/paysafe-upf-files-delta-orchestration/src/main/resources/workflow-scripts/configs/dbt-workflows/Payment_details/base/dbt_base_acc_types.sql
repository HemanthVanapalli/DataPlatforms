{{ config(materialized='table') }}

select
    ac.* ,
    rcat.DESCRIPTION_1 account_type_desc
from
    (
    select
        DISTINCT InstitutionNumber,
        ClientNumber ,
        AccountNumber,
        AccountTypeID
    from
        {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ACCOUNT') }} mca) ac
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_ACCOUNT_TYPE') }} rcat on ac.institutionnumber = rcat.INSTITUTION_NUMBER and ac.accounttypeid = rcat.INDEX_FIELD
limit 1 over (PARTITION by InstitutionNumber, ClientNumber , AccountNumber, AccountTypeID order by 1)