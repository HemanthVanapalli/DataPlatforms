{{ config(materialized='table') }}

with tx as (
select
    vts.CLIENTNUMBER ,
    vts.INSTITUTIONNUMBER,
    vts.ACCOUNTNUMBER ,
    vtt.FILENUMBER ,
    vtt.DATEOFEXTRACTION ,
    vtt.recorddate VALUEDATE ,
    vtt.TRANSACTIONSLIPNUMBER slip,
    ORIGINALREFERENCENUMBER,
    vtt.INWARDFEENUMBER ,
    rcs.DESCRIPTION_1 brand,
    vtt.REVERSAL ,
    vtt.TRANSACTIONAMOUNT_PROCESSING proc_amt ,
    vtt.TRANSACTIONAMOUNT_SETTLEMENT settle_amt,
    vtt.TRANSACTIONCATEGORY txcat ,
    tt.DESCRIPTION_1 Transaction_Type ,
    vtt.TRANSACTIONSTATUS ,
    vts.TRANSACTIONCURRENCY ,
    vts.SETTLEMENTCURRENCY ,
    vtt.DRCRINDICATOR ,
    sum(vtt.TRANSACTIONAMOUNT_PROCESSING) over (partition by vtt.VALUEDATE,
    vtt.TRANSACTIONTYPE ) proc_day ,
    vts.TRANSACTIONAMOUNT_PROCESSING total_proc ,
    ROW_NUMBER() over (PARTITION by originalreferencenumber) rn
from (select * from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by filedate desc)) vtt
left join (select * from {{ source('ukAcquiringRS2', 'TXN_SUMMARY') }} limit 1 over (partition by transactionslipnumber order by filedate desc)) vts on vtt.SOURCESETTLEMENT = vts.SOURCESETTLEMENT
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtt.INSTITUTIONNUMBER = tt.Institution_Number  and vtt.TRANSACTIONTYPE = tt.Index_Field
left join (select * from {{ source('ukAcquiringRS2', 'SETUP_TRANSACTION') }} limit 1 over (partition by recordidnumber order by filedate desc)) st on vtt.INWARDFEENUMBER = st.RECORDIDNUMBER and vtt.INSTITUTIONNUMBER = st.INSTITUTIONNUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_SERVICES') }} rcs on rcs.INDEX_FIELD = st.SERVICEID and rcs.INSTITUTION_NUMBER = st.INSTITUTIONNUMBER
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vts.clientnumber = md.clientnumber and vts.institutionnumber = md.institutionnumber
where  vtt.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and vtt.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
) ,
tx_dd as (
select
    *
from
    tx
where
    rn = 1 ) ,
settles as (
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    TRANSACTIONSTATUS ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    valuedate ,
    transactioncurrency ,
    settlementcurrency ,
    count(*) tx_cnt ,
    sum(proc_Amt) proc_amount ,
    sum(settle_amt) settle_amount
from
    tx_dd
group by
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    TRANSACTIONSTATUS ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    valuedate ,
    transactioncurrency ,
    settlementcurrency )
select * from settles