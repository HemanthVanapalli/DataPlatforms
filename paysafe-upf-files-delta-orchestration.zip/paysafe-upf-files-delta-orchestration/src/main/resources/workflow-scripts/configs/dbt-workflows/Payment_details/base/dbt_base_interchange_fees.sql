{{ config(materialized='table') }}

with ix_fee as
(
select * from {{ ref('dbt_base_ix_fee') }}
)

SELECT
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    originalclearingslip::varchar txn_applied_to ,
    filenumber ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Interchange Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from
    ix_fee
    where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) ,
    TRANSACTIONSLIPNUMBER ,
    originalclearingslip ,
    filenumber ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency