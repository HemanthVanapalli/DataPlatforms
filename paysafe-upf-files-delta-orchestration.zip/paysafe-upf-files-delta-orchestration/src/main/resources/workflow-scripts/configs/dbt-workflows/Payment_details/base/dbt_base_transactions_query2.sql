{{ config(materialized='table') }}

with merch_details as
(
select * from {{ ref('dbt_base_merch_details') }}
)
, cte as (
select id, merchantDescriptor_dynamicDescriptor from {{ source('transactions', 'transactions_fact') }}
    join merch_details on event_origin_accountid::!int = FMA
	where merchantDescriptor_dynamicDescriptor is not null and event_type = 'PAYMENT' and event_origin_service ='CARD'
	and txntime > add_months({{ var("RUNDATE") }}, -12)
	limit 1 over (partition by id order by txntime asc)
)
select * from cte