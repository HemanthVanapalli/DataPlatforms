{{ config(materialized='table') }}

select gatewayReconciliationId,event_origin_accountid, paymentid from {{ source('transactions', 'transactions_fact') }}
	where txntime > add_months({{ var("RUNDATE") }}, -12) and gatewayReconciliationId is not null
	limit 1 over (partition by gatewayReconciliationId order by txntime asc)