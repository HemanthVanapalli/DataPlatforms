{{ config(materialized='table') }}

with service_fees as (
select
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    -1 cardflag ,
    -1 cardbrand ,
    '0' txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Service Fees' fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(FEEAMOUNT_PROCESSING) fee_amount_processing ,
    sum(FEEAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    sum(NUMBEROFSLIPS) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_SERVICE_FEE') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tsf
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tsf.TRANSACTIONTYPE = tt.Index_Field and tsf.INSTITUTIONNUMBER = tt.Institution_Number
where RECORDDATE >= {{ var("RUNDATE") }}-31 and tsf.accountnumber > 13000
group by
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency
)
select * from service_fees