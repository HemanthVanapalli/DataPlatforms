{{ config(materialized='view') }}

with fcn_txn as
(
select * from {{ ref('dbt_base_AccountSummery_fcn_txn') }}
)
, rev_by_fee_and_vol_01 as
(
select * from {{ ref('dbt_base_AccountSummery_rev_by_fee_and_vol_01') }}
)
, second_join AS (
     SELECT
         r.*,
         cf2.MerchantRefNum AS cf2_MerchantRefNum,
         cf2.guid AS cf2_guid,
         cf2.description AS cf2_description,
         cf2.cardbin AS cf2_cardbin,
         cf2.recordseq AS cf2_recordseq
     FROM rev_by_fee_and_vol_01 r
     LEFT JOIN fcn_txn cf2 ON r.AQUIRERREFERENCE::varchar = cf2.arn::varchar
 )
 select * from second_join