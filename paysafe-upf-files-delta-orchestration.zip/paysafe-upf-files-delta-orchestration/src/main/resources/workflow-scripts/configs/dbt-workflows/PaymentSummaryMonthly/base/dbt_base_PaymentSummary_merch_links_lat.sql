{{ config(materialized='table') }}

with merch_links_lat as (
select
    sm.DESCRIPTION_1 settlement_method,
    mcl.clientnumber,
    mcl.GroupNumber
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_LINKS') }} mcl
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_SETTLEMENT_METHOD') }} sm on mcl.SettlementMethod = sm.INDEX_FIELD and mcl.InstitutionNumber = sm.INSTITUTION_NUMBER
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on mcl.clientnumber = md.clientnumber and mcl.institutionnumber = md.institutionnumber
limit 1 OVER (partition by mcl.CLIENTNUMBER order by mcl.DATEOFEXTRACTION desc)
)
select * from merch_links_lat