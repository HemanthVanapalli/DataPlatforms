{{ config(materialized='table') }}

with txn_fees_1 as (
select
    tmt.* ,
    tt.description_1 transaction_type
from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} tmt
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tmt.TRANSACTIONTYPE = tt.Index_Field and tmt.INSTITUTIONNUMBER = tt.Institution_Number
where tmt.RECORDDATE = {{ var("RUNDATE") }} and tmt.TRANSACTIONCATEGORY = 21 and tmt.accountnumber > 13000
limit 1 over (partition by tmt.TRANSACTIONSLIPNUMBER order by tmt.filedate desc )
)
, txn_fees as (
select
    INSTITUTIONNUMBER ,
    CLIENTNUMBER ,
    ACCOUNTNUMBER ,
    recorddate record_date ,
    TRANSACTIONSLIPNUMBER ,
    TRANSACTIONSTATUS ,
    TRANSACTIONTYPE ,
    CARDFLAG ,
    CARDBRAND ,
    '' txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    'Discount Fee' transaction_type ,
    DRCRINDICATOR ,
    REVERSAL ,
    'Discount Fees' fee_type ,
    TRANSACTIONCURRENCY ,
    SETTLEMENTCURRENCY ,
    ACCOUNTCURRENCY ,
    sum(TRANSACTIONAMOUNT_PROCESSING) fee_amount_processing ,
    sum(TRANSACTIONAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_SETTLEMENT) fee_amount_account ,
    count(*) txns
from txn_fees_1
group by
    INSTITUTIONNUMBER ,
    CLIENTNUMBER ,
    ACCOUNTNUMBER ,
    record_date ,
    TRANSACTIONSLIPNUMBER ,
    TRANSACTIONSTATUS ,
    TRANSACTIONTYPE ,
    CARDFLAG ,
    CARDBRAND ,
    txn_applied_to ,
    DRCRINDICATOR ,
    REVERSAL ,
    TRANSACTIONCURRENCY ,
    SETTLEMENTCURRENCY ,
    ACCOUNTCURRENCY
)

select * from txn_fees