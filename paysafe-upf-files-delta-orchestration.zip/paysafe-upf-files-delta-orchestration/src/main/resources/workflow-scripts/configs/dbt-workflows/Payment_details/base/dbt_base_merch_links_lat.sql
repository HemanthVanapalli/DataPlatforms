{{ config(materialized='table') }}

select
    mcl.InstitutionNumber,
    mcl.clientnumber,
    mcl.groupnumber,
    sm.DESCRIPTION_1 settlement_method
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_LINKS') }} mcl
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_SETTLEMENT_METHOD') }} sm on mcl.SettlementMethod = sm.INDEX_FIELD and mcl.InstitutionNumber = sm.INSTITUTION_NUMBER
limit 1 OVER (partition by mcl.CLIENTNUMBER order by mcl.DATEOFEXTRACTION desc)