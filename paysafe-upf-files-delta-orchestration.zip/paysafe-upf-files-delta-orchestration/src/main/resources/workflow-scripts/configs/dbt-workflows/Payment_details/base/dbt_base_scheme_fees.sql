{{ config(materialized='table') }}

with scheme_fee as (
select * from {{ ref('dbt_base_scheme_fee') }}
)

select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    numberoriginalslip::varchar txn_applied_to ,
    filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Scheme Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from scheme_fee
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,
    filedate) ,
    TRANSACTIONSLIPNUMBER ,
    numberoriginalslip ,
    filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency