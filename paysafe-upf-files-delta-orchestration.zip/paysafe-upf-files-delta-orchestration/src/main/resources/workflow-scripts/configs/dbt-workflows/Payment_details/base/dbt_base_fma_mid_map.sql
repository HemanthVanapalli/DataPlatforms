{{ config(materialized='table') }}

select
nd.*,
acid
from {{ source('mm', 'cardtypecode_dim') }} fmm
join {{ ref('dbt_base_nbx_det') }} nd on nd.merchantaccountid = fmm.fmaid
where iscurrent = 'true' and processorcode = 'OPN'
LIMIT 1 over (partition by acid order by iscurrent desc)