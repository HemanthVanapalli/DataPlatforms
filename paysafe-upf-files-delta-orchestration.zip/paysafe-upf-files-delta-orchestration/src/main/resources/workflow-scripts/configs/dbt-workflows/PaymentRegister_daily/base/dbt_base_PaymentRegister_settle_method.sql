{{ config(materialized='table') }}

with settle_method as (
SELECT
    vmd.DATEOFEXTRACTION ,
    vmd.INSTITUTIONNUMBER ,
    vmd.CLIENTNUMBER ,
    vmcl.groupnumber,
    vmcl.SettlementMethod ,
    sm.DESCRIPTION_1 Settlement_Method ,
    case
        when instr(sm.DESCRIPTION_1,'SAX') > 0 then 'SAXO'
        when instr(sm.DESCRIPTION_1,'LHV') > 0 then 'LHV'
        when instr(sm.DESCRIPTION_1,'BMO') > 0 then 'BMO'
        when instr(sm.DESCRIPTION_1,'JPM') > 0 then 'JPM'
        when instr(sm.DESCRIPTION_1,'FID') > 0 then 'FID'
        when instr(sm.DESCRIPTION_1,'CIC') > 0 then 'CIC'
    end bank
from {{ source('ukAcquiringRS2', 'MERCHANT_DETAILS') }}  vmd
left join {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_LINKS') }} vmcl on vmd.CLIENTNUMBER = vmcl.CLIENTNUMBER and vmd.INSTITUTIONNUMBER = vmcl.INSTITUTIONNUMBER and vmd.DateofExtraction = vmcl.DateofExtraction
left join {{ source('ukAcquiringRS2', 'rs2_choice_SETTLEMENT_METHOD') }} sm on vmcl.SETTLEMENTMETHOD = sm.Index_Field and vmd.INSTITUTIONNUMBER = sm.Institution_Number
LIMIT 1 over (PARTITION by vmd.clientnumber, vmd.institutionnumber order by vmd.DateofExtraction desc, vmcl.EffectiveDate desc)
)
select * from settle_method