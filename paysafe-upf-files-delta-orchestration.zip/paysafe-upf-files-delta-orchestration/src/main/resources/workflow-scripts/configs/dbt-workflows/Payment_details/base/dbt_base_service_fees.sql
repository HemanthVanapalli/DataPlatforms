{{ config(materialized='table') }}

select
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    nvl(tsf.recorddate,
    tsf.filedate) record_date ,
    tsf.TRANSACTIONSLIPNUMBER ,
    '' txn_applied_to ,
    tsf.filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Account Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency ,
    sum(FEEAMOUNT_PROCESSING) fee_amount_processing ,
    sum(FEEAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    sum(NUMBEROFSLIPS) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_SERVICE_FEE') }}  limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tsf
join {{ ref('dbt_base_pay2') }} pp_all on tsf.institutionnumber = pp_all.institutionnumber and tsf.clientnumber = pp_all.clientnumber and tsf.filenumber > pp_all.filenumber_lag and tsf.filenumber <= pp_all.filenumber and (pp_all.AccountTypeID = 7 or pp_all.settlement_method = 'G')
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tsf.TRANSACTIONTYPE = tt.Index_Field and tsf.INSTITUTIONNUMBER = tt.Institution_Number
where accountnumber > 13000
group by
    tsf.InstitutionNumber ,
    tsf.clientnumber ,
    accountnumber ,
    nvl(tsf.recorddate,
    tsf.filedate) ,
    tsf.TRANSACTIONSLIPNUMBER ,
    tsf.filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency