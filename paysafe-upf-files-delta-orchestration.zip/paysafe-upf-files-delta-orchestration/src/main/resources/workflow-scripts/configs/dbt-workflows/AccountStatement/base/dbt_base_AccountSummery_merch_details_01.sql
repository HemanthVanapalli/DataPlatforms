{{ config(materialized='table') }}

select
MD.clientnumber ,
MD.institutionnumber ,
MD.legalname ,
MD.tradename,
MD.ClientStatus,
md.country
from {{ source('ukAcquiringRS2', 'merchant_details') }} md
limit 1  over (partition by md.ClientNumber order by FILEDATE desc)