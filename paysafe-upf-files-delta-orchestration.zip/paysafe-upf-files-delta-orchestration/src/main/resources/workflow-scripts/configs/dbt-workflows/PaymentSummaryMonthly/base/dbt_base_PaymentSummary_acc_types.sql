{{ config(materialized='table') }}

with acc_types as (
select
    distinct InstitutionNumber ,
    AccountNumber ,
    AccountTypeID
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ACCOUNT_Institution_topK') }}
)
select * from acc_types