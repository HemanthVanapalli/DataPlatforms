{{ config(materialized='table') }}

with cte as
(select distinct INDEX_FIELD,DESCRIPTION_1 from {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }} )
select * from cte