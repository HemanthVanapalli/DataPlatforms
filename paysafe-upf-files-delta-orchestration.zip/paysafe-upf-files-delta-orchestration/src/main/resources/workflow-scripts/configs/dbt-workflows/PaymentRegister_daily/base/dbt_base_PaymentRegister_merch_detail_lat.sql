{{ config(materialized='table') }}

with merch_detail_lat as
(
select
    count(*) over (partition by clientnumber) cnt,
    vmd.*,
    ct.aplha_2_code country_name,
    case when INSTITUTIONNUMBER = 10 then '89' else '79' end le_code
from
{{ source('ukAcquiringRS2', 'MERCHANT_DETAILS') }} vmd
left join {{ source('ukAcquiringRS2', 'RS2_COUNTRY_CODE') }} ct on vmd.country = ct.countrycode
LIMIT 1 OVER (partition by vmd.CLIENTNUMBER, institutionnumber order by vmd.DATEOFEXTRACTION desc)
)
select * from merch_detail_lat