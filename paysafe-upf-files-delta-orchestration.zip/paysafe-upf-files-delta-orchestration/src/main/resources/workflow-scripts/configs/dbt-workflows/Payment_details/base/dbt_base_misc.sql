{{ config(materialized='table') }}

select
    vtmt.*,
    tc.description_1 TRANSACTION_TYPE
from (select * from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) vtmt
join {{ ref('dbt_base_pay2') }} pp_all on vtmt.institutionnumber = pp_all.institutionnumber and vtmt.clientnumber = pp_all.clientnumber and vtmt.filenumber > pp_all.filenumber_lag and vtmt.filenumber <= pp_all.filenumber and pp_all.AccountTypeID = 12
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_CATEGORY') }} tc on vtmt.INSTITUTIONNUMBER = tc.Institution_Number and vtmt.TRANSACTIONCATEGORY = tc.Index_Field
left join {{ ref('dbt_base_acc_types') }} act on act.institutionnumber = vtmt.institutionnumber and act.accountnumber = vtmt.accountnumber
where vtmt.transactioncategory in (2,7,22,24,50) and act.AccountTypeID <> 7 and vtmt.accountnumber > 13000