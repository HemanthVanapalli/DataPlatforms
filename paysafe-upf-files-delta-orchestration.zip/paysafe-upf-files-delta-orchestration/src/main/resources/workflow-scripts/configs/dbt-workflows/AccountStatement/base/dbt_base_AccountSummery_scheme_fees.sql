{{ config(materialized='table') }}

with scheme_fees as
(
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    -1 CARDFLAG ,
    -1 CARDBRAND ,
    NUMBERORIGINALSLIP::varchar txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    TRANSACTION_TYPE ,
    drcrindicator ,
    0 reversal ,
    'Scheme Fees' fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(ORIGINALAMOUNT_PROCESSING) fee_amount_processing ,
    sum(ORIGINALAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(ORIGINALAMOUNT_SETTLEMENT) fee_amount_account ,
    count(*) txns
from {{ ref('dbt_base_AccountSummery_scheme_fee') }}
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    nvl(recorddate,filedate) ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    NUMBERORIGINALSLIP ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency
)
select * from scheme_fees