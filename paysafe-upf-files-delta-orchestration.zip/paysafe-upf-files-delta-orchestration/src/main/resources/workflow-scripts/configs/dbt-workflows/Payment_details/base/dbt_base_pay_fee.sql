{{ config(materialized='table') }}

with pay_fee as
(
select
    vtpf.TRANSACTIONSLIPNUMBER tpf_slip ,
    tps.TRANSACTIONSLIPNUMBER tps_slip ,
    tp.TRANSACTIONSLIPNUMBER tp_slip ,
    tp.VALUEDATE actual_date ,
    vtpf.* ,
    tt.description_1 transaction_type
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_FEE') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) vtpf
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tps on vtpf.NUMBERORIGINALSLIP = tps.TRANSACTIONSLIPNUMBER
join {{ ref('dbt_base_pay2') }} pp_all on vtpf.institutionnumber = pp_all.institutionnumber and vtpf.clientnumber = pp_all.clientnumber and vtpf.filenumber > pp_all.filenumber_lag and vtpf.filenumber <= pp_all.filenumber and (pp_all.AccountTypeID = 7 or pp_all.settlement_method = 'G')
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tp on tp.TRANSACTIONSLIPNUMBER = tps.NUMBERORIGINALSLIP
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }}  tt on vtpf.INSTITUTIONNUMBER = tt.Institution_Number and vtpf.TRANSACTIONTYPE = tt.Index_Field
where  tps.accountnumber > 13000
)
select * from pay_fee