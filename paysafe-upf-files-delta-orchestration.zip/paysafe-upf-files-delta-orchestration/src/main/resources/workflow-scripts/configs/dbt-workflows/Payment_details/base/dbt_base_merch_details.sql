{{ config(materialized='table') }}

select
MD.clientnumber ,
MD.institutionnumber ,
MD.legalname ,
MD.tradename,
MD.ClientStatus,
fmm.MERCHANTACCOUNTID FMA,
fmm.mlename MLE_NAME,
fmm.mleid MLE_ID,
fmm.pmlename PMLE_NAME,
fmm.pmleid PMLE_ID,
fmm.business_relationship
from {{ source('ukAcquiringRS2', 'merchant_details') }} md
join {{ ref('dbt_base_fma_mid_map') }} fmm on MD.CLIENTNUMBER::varchar = LTRIM(FMM.ACID, '0')::varchar
limit 1  over (partition by md.ClientNumber order by FILEDATE desc)