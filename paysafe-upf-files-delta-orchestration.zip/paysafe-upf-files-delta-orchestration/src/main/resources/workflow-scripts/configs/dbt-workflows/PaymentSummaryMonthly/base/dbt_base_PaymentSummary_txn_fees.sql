{{ config(materialized='table') }}

with txn_fees as (
select
    vts.INSTITUTIONNUMBER ,
    vts.CLIENTNUMBER ,
    vts.ACCOUNTNUMBER ,
    vtt.FILENUMBER ,
    nvl(vts.RECORDDATE,
    vts.FILEDATE) record_date ,
    vts.TRANSACTIONSTATUS ,
    vts.TRANSACTIONTYPE ,
    'Discount Fee' transaction_type ,
    vtt.DRCRINDICATOR ,
    vtt.REVERSAL ,
    'Transaction Fees' fee_type ,
    vts.SETTLEMENTCURRENCY ,
    vts.ACCOUNTCURRENCY ,
    sum(vtt.MSCAMOUNT_PROCESSING) fee_amount_proccessing ,
    sum(vtt.MSCAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(vtt.MSCAMOUNT_SETTLEMENT) fee_amount_account ,
    count(*) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc)) vtt
left join (select * from {{ source('ukAcquiringRS2', 'TXN_SUMMARY') }} limit 1 over (partition by transactionslipnumber order by recorddate desc)) vts on vtt.SOURCESETTLEMENT = vts.SOURCESETTLEMENT
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vts.clientnumber = md.clientnumber and vts.institutionnumber = md.institutionnumber
where vtt.RECORDDATE = current_date-1
group by
    vts.INSTITUTIONNUMBER ,
    vts.CLIENTNUMBER ,
    vts.ACCOUNTNUMBER ,
    vtt.FILENUMBER ,
    nvl(vts.RECORDDATE,
    vts.FILEDATE) ,
    vts.TRANSACTIONSTATUS ,
    vts.TRANSACTIONTYPE ,
    vtt.DRCRINDICATOR ,
    vtt.REVERSAL ,
    vts.SETTLEMENTCURRENCY ,
    vts.ACCOUNTCURRENCY
)
select * from txn_fees