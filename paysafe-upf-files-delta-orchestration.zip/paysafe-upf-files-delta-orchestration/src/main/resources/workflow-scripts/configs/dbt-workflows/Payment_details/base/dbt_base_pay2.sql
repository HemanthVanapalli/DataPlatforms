{{ config(materialized='table') }}

select
    p.*, fns.numberoriginalslip, fns.filenumber, fns.filenumber_lag, act.AccountTypeID
from {{ ref('dbt_base_payments') }} p
left join {{ ref('dbt_base_filenumbers') }} fns
on p.institutionnumber = fns.institutionnumber and p.clientnumber = fns.clientnumber and p.recorddate=fns.recorddate
left join {{ ref('dbt_base_acc_types') }} act on act.institutionnumber = p.institutionnumber and act.accountnumber = fns.numberoriginalslip
where p.recorddate = {{ var("RUNDATE") }}

