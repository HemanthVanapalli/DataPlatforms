with merch_fee as (
select
    vtmf.* ,
    tt.description_1 transaction_type
from {{ source('ukAcquiringRS2', 'TXN_MERCHANT_FEE') }} vtmf
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtmf.TRANSACTIONTYPE = tt.Index_Field and vtmf.INSTITUTIONNUMBER = tt.Institution_Number
join merch_details md on vtmf.clientnumber = md.clientnumber and vtmf.institutionnumber = md.institutionnumber
where  VTMF.RECORDDATE = current_date-1
limit 1 over (partition by vtmf.transactionslipnumber order by vtmf.filedate desc)
)
select * from merch_fee