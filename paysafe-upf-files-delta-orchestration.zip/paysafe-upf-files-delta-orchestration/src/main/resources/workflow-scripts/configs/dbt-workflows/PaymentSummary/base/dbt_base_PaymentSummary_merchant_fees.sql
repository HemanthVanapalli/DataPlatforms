{{ config(materialized='table') }}

with merch_fee as (
select
    vtmf.* ,
    tt.description_1 transaction_type
from {{ source('ukAcquiringRS2', 'TXN_MERCHANT_FEE') }} vtmf
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtmf.TRANSACTIONTYPE = tt.Index_Field and vtmf.INSTITUTIONNUMBER = tt.Institution_Number
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vtmf.clientnumber = md.clientnumber and vtmf.institutionnumber = md.institutionnumber
where  VTMF.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and VTMF.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
limit 1 over (partition by vtmf.transactionslipnumber order by vtmf.filedate desc)
)
, merchant_fees as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) record_date ,
    transactionstatus ,
    TransactionType ,
    nvl(Transaction_Type,
    CONCAT('tx type: ', TransactionType)) Transaction_Type ,
    DRCRINDICATOR ,
    0 reversal ,
    case
        when transaction_type like 'Visa%' then 'Scheme Fees'
        when transaction_type like 'Mastercard%' then 'Scheme Fees'
        else 'Merchant Fees'
    end fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(transactionamount_processing) fee_amount_proccessing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    sum(numberofslips) txns
from
    merch_fee
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency )
select * from merchant_fees