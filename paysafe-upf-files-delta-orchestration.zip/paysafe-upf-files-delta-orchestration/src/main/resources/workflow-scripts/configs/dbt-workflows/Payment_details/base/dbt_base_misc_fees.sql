{{ config(materialized='table') }}

select
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    tmt.accountnumber ,
    nvl(tmt.recorddate,
    tmt.filedate) record_date ,
    tmt.TRANSACTIONSLIPNUMBER ,
    '' txn_applied_to ,
    tmt.filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    reversal ,
    case
        when transaction_type in (
            'Ad Hoc Scheme Fee',
            'MA pVol Dom',
            'MA pVol Inter',
            'MA pVol Intra',
            'Mastercard Auth Dom',
            'Mastercard Auth Inter',
            'Mastercard Auth Intra',
            'Mastercard Clearing',
            'MC Assessment',
            'MC CNP Dom',
            'MC CNP Inter',
            'MC CNP Intra',
            'MC mVol Inter',
            'MC mVol Intra',
            'MC pTrns Dom',
            'MC SC',
            'MC XB non-SEPA',
            'MC XB SEPA',
            'Visa Assessment',
            'Visa Auth Dom',
            'Visa Auth Inter',
            'Visa Auth Intra',
            'Visa CS Dom',
            'Visa CS Inter',
            'Visa CS Intra',
            'Visa Inter CNP',
            'Visa Serv Inter',
            'Visa Vol Credit',
            'Visa Vol Debit')
        then 'Scheme Fees'
        when transaction_type in (
            'Authorisation fee- approved',
            'Behavioural Auth Fee',
            'CBK Fee',
            'CBK Fee RDR',
            'Declined Authorization Fee',
            'Non-Secure Fee')
        then 'Transaction Fees'
        when transaction_type in ('High risk registration fee', 'PCI non compliance Fee') then 'Account Fees'
        when transaction_type in ('Interchange fee', 'Interchange Fee CR') then 'Interchange Fees'
        when transaction_type in ('Misc. CR transaction', 'Misc. DR transaction') then 'Manual'
        else 'Misc Fees'
    end as fee_type ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency ,
    sum(TRANSACTIONAMOUNT_PROCESSING) fee_amount_processing ,
    sum(TRANSACTIONAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    count(*) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tmt
join {{ ref('dbt_base_pay2') }} pp_all on tmt.institutionnumber = pp_all.institutionnumber and tmt.clientnumber = pp_all.clientnumber and tmt.filenumber > pp_all.filenumber_lag and tmt.filenumber <= pp_all.filenumber and (pp_all.AccountTypeID = 7 or pp_all.settlement_method = 'G')
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }}  tt on tmt.TRANSACTIONTYPE = tt.Index_Field and tmt.INSTITUTIONNUMBER = tt.Institution_Number
left join {{ ref('dbt_base_acc_types') }} act on act.institutionnumber = tmt.institutionnumber and act.accountnumber = tmt.accountnumber
where
    transactioncategory in (7,22,50) and act.AccountTypeID = 7 and tmt.accountnumber > 13000
group by
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    tmt.accountnumber ,
    nvl(tmt.recorddate,
    tmt.filedate) ,
    tmt.TRANSACTIONSLIPNUMBER ,
    tmt.filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency