{{ config(
  materialized='incremental',
  pre_hook="DELETE FROM REPORTING_DATAMART.RS2_PAYMENT_REGISTER WHERE run_date = {{ var('RUNDATE') }}"
) }}

with payments as
(
select
    nd.pmleid PMLE_ID,
    nd.pmlename PMLE_NAME,
    nd.mleid MLE_ID,
    nd.mlename MLE_NAME,
    fmm.fmaid FMA,
    fmm.fmaid account_id,
    mdl.tradename TRADENAME,
    mdl.legalname LEGALNAME,
    case
        when vtps.institutionnumber = 10 then '89'
        when vtps.institutionnumber = 12 then '79'
        else null
    end LEGAL_ENTITY_CODE,
    vtps.institutionnumber INSTITUTION_NO,
    sm.groupnumber GROUP_ID,
    vtps.CLIENTNUMBER ,
    sm.bank ,
    cc.DESCRIPTION_1 settlement_currency ,
    case
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) = 'SP' then 'SEPA'
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) = 'WP' then 'WIRE'
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) = 'FP' then 'BACS'
    end vehicle ,
    case
        when vtps.institutionnumber = 10 then 'Paysafe Payment Solutions Limited'
        when vtps.institutionnumber = 12 then 'Paysafe Financial Services Limited'
        else null
    end legal_entity ,
    rsb.source_bank "Source Bank Account No." ,
    vtps.TRANSACTIONAMOUNT_PROCESSING * decode(vtps.reversal, 0, 1, 0) payment_amount ,
    vtps.TRANSACTIONAMOUNT_PROCESSING * decode(vtps.reversal, 1, 0, 0) debit_amount ,
    tp.VALUEDATE payment_date ,
    123456 "Source Bank Routing No." ,
    vtps.TRANSACTIONSLIPNUMBER ref_no ,
    mdl.tradename account_name ,
    case
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) = 'FP' then bdl.CORRESPONDINGBANKACCOUNT
        else ''
    end "Dest bank routing No." ,
    case
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) = 'FP' then bdl.CounterBankAccount
        else ''
    end "Dest bank account No." ,
    mdl.legalname "Beneficiary Name" ,
    case
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) <> 'FP' and LENGTH(bdl.CounterBankAccount)=8 then bdl.CounterBankAccount
        else ''
    end "Beneficiary Account Number" ,
    bdl.SETTLEMENTBANKNAME "Beneficiary Bank Name" ,
    case
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) <> 'FP' and LENGTH(bdl.CounterBankAccount)>8 then bdl.CounterBankAccount
        else ''
    end "Beneficiary Bank IBAN" ,
    case
        when SUBSTRING(sm.Settlement_Method, LENGTH(sm.settlement_method)-1, 2) <> 'FP' then bdl.BankClearingNumber
        else ''
    end "Beneficiary Bank Swift" ,
    mdl.country_name "Beneficiary Country" ,
    al.addressline1 "Beneficiary Address1" ,
    al.addressline2 "Beneficiary Address2" ,
    vtps.ACCOUNTNUMBER ,
    settlement_method ,
    BDL.FUNDINGCLIENT ,
    bdl.CORRESPONDINGBANKACCOUNT ,
    bdl.CounterBankAccount ,
    bdl.BankClearingNumber ,
    vtps.filedate filedate ,
    vtps.REVERSAL ,
    ts.description_1 transaction_status ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE
from
(select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} where TRANSACTIONTYPE IN (250,252,251) limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc)) vtps
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc)) tp on vtps.NUMBERORIGINALSLIP = tp.TRANSACTIONSLIPNUMBER
left join {{ ref('dbt_base_PaymentRegister_merch_detail_lat') }} mdl on mdl.institutionnumber = vtps.INSTITUTIONNUMBER and mdl.clientnumber = vtps.CLIENTNUMBER
left join {{ ref('dbt_base_PaymentRegister_bank_details_lat') }} bdl on vtps.CLIENTNUMBER = bdl.CLIENTNUMBER and vtps.INSTITUTIONNUMBER = bdl.INSTITUTIONNUMBER
left join {{ ref('dbt_base_PaymentRegister_address_lat') }} al on vtps.INSTITUTIONNUMBER = al.institutionnumber and vtps.CLIENTNUMBER = al.clientnumber
left join {{ ref('dbt_base_PaymentRegister_settle_method') }} sm on vtps.INSTITUTIONNUMBER = sm.InstitutionNumber and vtps.CLIENTNUMBER = sm.clientnumber
left join {{ ref('dbt_base_PaymentRegister_settlement_currency') }} sc on vtps.INSTITUTIONNUMBER = sc.institutionnumber and vtps.ACCOUNTNUMBER = sc.accountnumber
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }} cc on tp.TRANSACTIONCURRENCY = cc.INDEX_FIELD and vtps.INSTITUTIONNUMBER = cc.INSTITUTION_NUMBER
left join {{ source('ukAcquiringRS2', 'RS2_SOURCE_BANK') }} rsb on rsb.le_code = mdl.le_code and rsb.bank = sm.bank and rsb.currency = cc.DESCRIPTION_1
left join {{ source('ukAcquiringRS2', 'rs2_choice_TRANSACTION_STATUS') }} ts on vtps.INSTITUTIONNUMBER = ts.Institution_Number and vtps.TRANSACTIONSTATUS = ts.Index_Field
left join {{ source('ukAcquiringRS2', 'rs2_choice_TRANSACTION_TYPE') }} tt on vtps.INSTITUTIONNUMBER = tt.Institution_Number and vtps.TRANSACTIONTYPE = tt.Index_Field
left join {{ ref('dbt_base_PaymentRegister_fma_mid_map') }} fmm on mdl.CLIENTNUMBER::varchar = LTRIM(FMM.ACID, '0')::varchar
left join {{ ref('dbt_base_PaymentRegister_nbx_det') }} nd on mdl.clientnumber::varchar = LTRIM(nd.ACID, '0')::varchar
)
, output1 as
(
select
    *
from
payments
where payment_Date = {{ var("RUNDATE") }}
order by
    payment_Date desc,
    account_id
)
select
	FMA,
    LEGALNAME,
    CLIENTNUMBER,
    BANK,
    SETTLEMENT_CURRENCY,
    VEHICLE,
	LEGAL_ENTITY_CODE,
    LEGAL_ENTITY,
    "SOURCE BANK ACCOUNT NO." SOURCE_BANK_ACCOUNT_NO,
    PAYMENT_AMOUNT,
    DEBIT_AMOUNT,
    PAYMENT_DATE,
    "SOURCE BANK ROUTING NO." SOURCE_BANK_ROUTING_NO,
    REF_NO,
    TRADENAME,
    "DEST BANK ROUTING NO." DEST_BANK_ROUTING_NO,
    "DEST BANK ACCOUNT NO." DEST_BANK_ACCOUNT_NO,
    "BENEFICIARY NAME" BENEFICIARY_NAME,
    "BENEFICIARY ACCOUNT NUMBER" BENEFICIARY_ACCOUNT_NUMBER,
    "BENEFICIARY BANK NAME" BENEFICIARY_BANK_NAME,
    "BENEFICIARY BANK IBAN" BENEFICIARY_BANK_IBAN,
    "BENEFICIARY BANK SWIFT" BENEFICIARY_BANK_SWIFT,
    "BENEFICIARY COUNTRY" BENEFICIARY_COUNTRY,
    "BENEFICIARY ADDRESS1" BENEFICIARY_ADDRESS1,
    "BENEFICIARY ADDRESS2" BENEFICIARY_ADDRESS2,
    ACCOUNTNUMBER,
    SETTLEMENT_METHOD,
    FUNDINGCLIENT,
    CORRESPONDINGBANKACCOUNT,
    COUNTERBANKACCOUNT,
    BANKCLEARINGNUMBER,
    FILEDATE,
    REVERSAL,
    TRANSACTION_STATUS,
    TRANSACTION_TYPE,
    PMLE_ID,
	PMLE_NAME,
	MLE_ID,
	MLE_NAME,
    INSTITUTION_NO,
	GROUP_ID,
	{{ var("RUNDATE") }} as run_date
from output1