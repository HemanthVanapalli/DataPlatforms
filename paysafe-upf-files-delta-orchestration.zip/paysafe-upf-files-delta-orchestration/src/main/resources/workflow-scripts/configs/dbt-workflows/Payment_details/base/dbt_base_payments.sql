{{ config(materialized='table') }}

SELECT
    tp.CLIENTNUMBER client_No ,
    tp.TRANSACTIONSLIPNUMBER p_slip ,
    vtps.NUMBERORIGINALSLIP ps_os ,
    vtps.TRANSACTIONSLIPNUMBER ps_slip ,
    vtps.TRANSACTIONAMOUNT_PROCESSING ps_proc_amt ,
    tp.TRANSACTIONAMOUNT_PROCESSING p_proc_amt ,
    tp.RECORDDATE rec_dt ,
    tp.VALUEDATE value_date ,
    tp.INSTITUTIONNUMBER ,
    tp.clientnumber ,
    tp.RECORDDATE ,
    tp.valuedate ,
    tp.TRANSACTIONSLIPNUMBER,
    LEFT(mll.settlement_method, 1) settlement_method
from
    (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) vtps
left join (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tp on vtps.NUMBERORIGINALSLIP = tp.TRANSACTIONSLIPNUMBER
join {{ ref('dbt_base_merch_links_lat') }} mll on tp.clientnumber = mll.clientnumber and tp.institutionnumber = mll.institutionnumber
where vtps.TRANSACTIONTYPE IN (250, 252,251)
and vtps.accountnumber > 13000