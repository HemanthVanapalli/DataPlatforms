{{ config(materialized='table') }}

select
    vmca.INSTITUTIONNUMBER ,
    ACCOUNTNUMBER ,
    ACCOUNTTYPEID ,
    ak.DESCRIPTION_1 Account_Type
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ACCOUNT_Institution_topK') }}  vmca
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_ACCOUNT_TYPE') }} ak on vmca.ACCOUNTTYPEID = ak.Index_Field and vmca.INSTITUTIONNUMBER = ak.Institution_Number
group by
    vmca.InstitutionNumber ,
    ACCOUNTNUMBER ,
    ACCOUNTTYPEID ,
    Account_Type