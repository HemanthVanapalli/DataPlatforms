{{ config(materialized='table') }}

with pay_fee as
(
select * from {{ ref('dbt_base_pay_fee') }}
)

select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    recorddate record_date ,
    tpf_slip TRANSACTIONSLIPNUMBER ,
    tp_slip::varchar txn_applied_to ,
    filenumber + 1 filenumber ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Payment Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency ,
    sum(transactionamount_processing) fee_amount_processing ,
    sum(transactionamount_settlement) fee_amount_settlement ,
    sum(transactionamount_account) fee_amount_account ,
    count(*) txns
from
    pay_fee
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    recorddate ,
    tpf_slip ,
    tp_slip ,
    filenumber + 1 ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    Transaction_Type ,
    drcrindicator ,
    settlementcurrency ,
    accountcurrency ,
    transactioncurrency