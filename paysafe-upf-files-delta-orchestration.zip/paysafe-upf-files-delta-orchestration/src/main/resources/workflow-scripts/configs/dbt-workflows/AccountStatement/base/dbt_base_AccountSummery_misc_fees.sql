{{ config(materialized='table') }}

with misc_fees as (
select
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    accountnumber ,
    nvl(recorddate,filedate) record_date ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    -1 CARDFLAG ,
    -1 CARDBRAND ,
    '0' txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    tt.DESCRIPTION_1 TRANSACTION_TYPE ,
    drcrindicator ,
    reversal ,
    case
        when transaction_type in (
            'Ad Hoc Scheme Fee',
            'MA pVol Dom',
            'MA pVol Inter',
            'MA pVol Intra',
            'Mastercard Auth Dom',
            'Mastercard Auth Inter',
            'Mastercard Auth Intra',
            'Mastercard Clearing',
            'MC Assessment',
            'MC CNP Dom',
            'MC CNP Inter',
            'MC CNP Intra',
            'MC mVol Inter',
            'MC mVol Intra',
            'MC pTrns Dom',
            'MC SC',
            'MC XB non-SEPA',
            'MC XB SEPA',
            'Visa Assessment',
            'Visa Auth Dom',
            'Visa Auth Inter',
            'Visa Auth Intra',
            'Visa CS Dom',
            'Visa CS Inter',
            'Visa CS Intra',
            'Visa Inter CNP',
            'Visa Serv Inter',
            'Visa Vol Credit',
            'Visa Vol Debit')
        then 'Scheme Fees'
        when transaction_type in (
            'Authorisation fee- approved',
            'Behavioural Auth Fee',
            'CBK Fee',
            'CBK Fee RDR',
            'Declined Authorization Fee',
            'Non-Secure Fee')
        then 'Transaction Fees'
        when transaction_type in ('High risk registration fee', 'PCI non compliance Fee') then 'Account Fees'
        when transaction_type in ('Interchange fee', 'Interchange Fee CR') then 'Interchange Fees'
        when transaction_type in ('Misc. CR transaction', 'Misc. DR transaction') then 'Manual'
        else 'Misc Fees'
    end as fee_type ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency ,
    sum(TRANSACTIONAMOUNT_PROCESSING) fee_amount_processing ,
    sum(TRANSACTIONAMOUNT_SETTLEMENT) fee_amount_settlement ,
    sum(TRANSACTIONAMOUNT_ACCOUNT) fee_amount_account ,
    count(*) txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tmt
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tmt.TRANSACTIONTYPE = tt.Index_Field and tmt.INSTITUTIONNUMBER = tt.Institution_Number
where transactioncategory = 7 and RECORDDATE >=  {{ var("RUNDATE") }}-31 and accountnumber > 13000
group by
    tmt.InstitutionNumber ,
    tmt.clientnumber ,
    accountnumber ,
    nvl(recorddate,filedate) ,
    TRANSACTIONSLIPNUMBER ,
    transactionstatus ,
    TRANSACTIONTYPE ,
    TRANSACTION_TYPE ,
    DRCRINDICATOR ,
    reversal ,
    TRANSACTIONCURRENCY ,
    settlementcurrency ,
    accountcurrency
)
select * from misc_fees