{{ config(materialized='table') }}

with settles as
(
select * from {{ ref('dbt_base_settles') }}
)
, chargebacks as
(
select * from {{ ref('dbt_base_chargebacks') }}
)
, volumes as
(
select * from chargebacks
union all
select * from settles
)
, volume_buckets01 as
(
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    recorddate ,
    transactionslipnumber ,
    txn_applied_to ,
    filenumber ,
    ORIGINALREFERENCENUMBER ,
    ORIGINALREFERENCENUMBER join_condition ,
    MerchantRefNum ,
    guid ,
    txnid ,
    cardtype ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    drcrindicator ,
    reversal ,
    settlementcurrency ,
    transactioncurrency ,
    tx_cnt ,
    settle_amount ,
    proc_amount ,
    fee_type ,
    TRANSACTIONDESTINATION
from
    volumes v
)
, volume_buckets02 as
(
select
    * ,
    ROW_NUMBER () over (partition by transactionslipnumber order by 1) rn
from volume_buckets01
)
, volume_buckets as
(
select
    *
from volume_buckets02
where rn = 1
)

select * from volume_buckets