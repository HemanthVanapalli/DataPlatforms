{{ config(materialized='table') }}

with ix_fee as (
select
    vtif.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtif.transactionslipnumber, vtif.originalclearingslip, vtif.recorddate order by vtif.filedate ) rn
from {{ source('ukAcquiringRS2', 'TXN_INTERCHANGE_FEE') }} vtif
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtif.INSTITUTIONNUMBER = tt.Institution_Number and vtif.TRANSACTIONTYPE = tt.Index_Field
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vtif.clientnumber = md.clientnumber and vtif.institutionnumber = md.institutionnumber
where VTIF.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and VTIF.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
),
interchange_fees as (
SELECT
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) record_date ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    drcrindicator ,
    0 reversal ,
    'Interchange Fees' fee_type ,
    settlementcurrency ,
    accountcurrency ,
    sum(originalamount_processing) fee_amount_processing ,
    sum(originalamount_settlement) fee_amount_settlement ,
    sum(originalamount_settlement) fee_amount_account ,
    count(*) txns
from
    ix_fee
where rn = 1
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    nvl(recorddate,
    filedate) ,
    transactionstatus ,
    TransactionType ,
    Transaction_Type ,
    DRCRINDICATOR ,
    settlementcurrency ,
    accountcurrency
)
select * from interchange_fees

