{{ config(materialized='table') }}

with fma_mid_map as
(
select
    acid,
    fmaid,
    iscurrent
from
{{ source('mm', 'cardtypecode_dim') }} fmm
WHERE iscurrent = 'true' and processorcode = 'OPN'
LIMIT 1 over (partition by acid order by iscurrent desc)
)
select * from fma_mid_map