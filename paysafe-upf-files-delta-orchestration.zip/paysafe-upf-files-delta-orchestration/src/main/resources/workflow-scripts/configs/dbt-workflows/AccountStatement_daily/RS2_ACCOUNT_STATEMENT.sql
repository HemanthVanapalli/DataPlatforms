{{ config(
  materialized='incremental',
  pre_hook="DELETE FROM REPORTING_DATAMART.RS2_ACCOUNT_STATEMENT WHERE run_date = {{ var('RUNDATE') }}"
) }}

with merch_lat as
(
select * from {{ ref('dbt_base_AccountSummery_merch_lat') }}
)
,accs as
(
select * from {{ ref('dbt_base_AccountSummery_accs') }}
)
, merch_links_lat as (
select * from {{ ref('dbt_base_AccountSummery_merch_links_lat') }}
)
, rev_by_fee_and_vol as
(
select * from {{ ref('dbt_base_AccountSummery_rev_by_fee_and_vol') }}
)
, balances as (
select * from {{ ref('dbt_base_AccountSummery_balances') }}
)
, revenue_by_fee_type as (
select
    r.TRANSACTIONSLIPNUMBER ,
    m.FMA,
    m.TRADENAME ,
    m.LEGALNAME ,
    r.INSTITUTIONNUMBER INSTITUTION_NO,
    r.CLIENTNUMBER ,
    r.ACCOUNTNUMBER ,
    a.Account_Type ACCOUNT_TYPE ,
    r.TRANSACTION_TYPE ,
    rcct.DESCRIPTION_1 TRANSACTION_STATUS ,
    r.FEE_TYPE ,
    r.RECORD_DATE ,
    CASE
        WHEN r.TRANSACTION_TYPE in ('Adjustment','Fee Collection', 'Intra Account Fee Collection') then
        case
            when r.DRCRINDICATOR = 1 then r.fee_amount_processing
            else -r.fee_amount_processing
        end
        WHEN r.TRANSACTION_TYPE IN ('Unique transaction',
        'Purchase',
        'Adjustment',
        'Misc. CR transaction',
        'Acct Funding Transaction DR',
        'Rejects (Financial)') THEN r.fee_amount_processing
        WHEN r.TRANSACTION_TYPE like ('%CR') THEN r.fee_amount_processing
        ELSE -r.fee_amount_processing
    END AS PROCESSING_AMOUNT ,
    CASE
        WHEN r.TRANSACTION_TYPE in ('Adjustment','Fee Collection', 'Intra Account Fee Collection') then
        case
            when r.DRCRINDICATOR = 1 then r.fee_amount_account
            else -r.fee_amount_account
        end
        WHEN r.TRANSACTION_TYPE IN ('Unique transaction',
        'Purchase',
        'Adjustment',
        'Misc. CR transaction',
        'Acct Funding Transaction DR',
        'Rejects (Financial)') THEN r.fee_amount_account
        WHEN r.TRANSACTION_TYPE like ('%CR') THEN r.fee_amount_account
        ELSE -r.fee_amount_account
    END AS SETTLEMENT_AMOUNT ,
    r.TXNS ,
    r.recordseq CONF_NO ,
    r.TXN_APPLIED_TO ,
    b.accountbalance_settlement TOTAL_BALANCE ,
    r.DRCRINDICATOR ,
    r.REVERSAL ,
    decode(r.CARDFLAG,1,'DEBIT',2,'CREDIT') CARD_FLAG ,
    rccb.DESCRIPTION_1 CARD_BRAND ,
    r.CARDBIN ,
    ct3.DESCRIPTION_1 PROCESSING_CURRENCY ,
    ct2.DESCRIPTION_1 ACCOUNT_CURRENCY ,
    r.MERCHANTREFNUM ,
    r.GUID ,
    r.DESCRIPTION,
    m.PMLE_ID,
    m.PMLE_NAME,
    m.MLE_ID,
    m.MLE_NAME,
    case
        when r.institutionnumber=10 then '89'
        when r.institutionnumber=12 then '79'
        else null
    end LEGAL_ENTITY_CODE ,
    mll.groupnumber GROUP_ID,
    m.business_relationship,
    {{ var("RUNDATE") }} as run_date
from rev_by_fee_and_vol r
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_STATUS') }} tt on r.institutionnumber = tt.Institution_Number and r.transactionstatus = tt.Index_Field
left join merch_lat m on r.institutionnumber = m.institutionnumber and r.clientnumber = m.clientnumber
left join balances b on r.clientnumber = b.clientnumber and r.accountnumber = b.accountnumber and r.institutionnumber = b.institutionnumber and r.record_date = b.filedate
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }} ct on r.settlementcurrency = ct.INDEX_FIELD and r.institutionnumber = ct.INSTITUTION_NUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }} ct2 on r.accountcurrency = ct2.INDEX_FIELD and r.institutionnumber = ct2.INSTITUTION_NUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CURRENCY') }} ct3 on r.transactioncurrency = ct3.INDEX_FIELD and r.institutionnumber = ct3.INSTITUTION_NUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CARD_BRAND') }} rccb on r.cardbrand = rccb.INDEX_FIELD and r.institutionnumber = rccb.INSTITUTION_NUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_STATUS') }} rcct on r.transactionstatus = rcct.INDEX_FIELD and r.institutionnumber = rcct.INSTITUTION_NUMBER
left join merch_links_lat mll on mll.clientnumber = r.clientnumber and mll.institutionnumber = r.institutionnumber
left join accs a on r.accountnumber = a.accountnumber and r.institutionnumber = a.institutionnumber
where 1 = 1
and r.accountnumber > 13000
)
select *
from revenue_by_fee_type
where record_date = {{ var("RUNDATE") }}