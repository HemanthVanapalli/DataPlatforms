{{ config(materialized='table') }}

with misc as (
select
    vtmt.*,
    'Chargeback' TRANSACTION_TYPE,
    rcs.DESCRIPTION_1 brand ,
    substr(vtmt.transactioncurrency,
    1,
    3) tx_currency
from (select * from {{ source('ukAcquiringRS2', 'TXN_MISCELLANEOUS_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) vtmt
left join (select * from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} limit 1 over (partition by transactionslipnumber order by recorddate desc) ) tt on vtmt.NUMBERORIGINALSLIP = tt.TRANSACTIONSLIPNUMBER
left join (select * from {{ source('ukAcquiringRS2', 'SETUP_TRANSACTION') }}  limit 1 over (partition by recordidnumber order by filedate desc)) st on tt.INWARDFEENUMBER = st.RECORDIDNUMBER and tt.INSTITUTIONNUMBER = st.INSTITUTIONNUMBER
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_CATEGORY') }} Tc on vtmt.INSTITUTIONNUMBER = tc.Institution_Number and vtmt.TRANSACTIONCATEGORY = tc.Index_Field
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_SERVICES') }} rcs on rcs.INDEX_FIELD = st.SERVICEID and rcs.INSTITUTION_NUMBER = st.INSTITUTIONNUMBER
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on tt.clientnumber = md.clientnumber and tt.institutionnumber = md.institutionnumber
where vtmt.transactioncategory in ( 2,50)
and vtmt.RECORDDATE >= date(TO_TIMESTAMP(1664928000000 / 1000)) - interval '30' day and vtmt.RECORDDATE < date(TO_TIMESTAMP(1665014400000/ 1000))
) ,
chargebacks as (
select
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    recorddate ,
    transactioncurrency ,
    accountcurrency settlementcurrency ,
    count(*) tx_cnt ,
    sum(transactionamount_processing) proc_amount ,
    sum(transactionamount_account) settle_amount
from
    misc
group by
    InstitutionNumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    brand ,
    reversal ,
    DRCRINDICATOR ,
    recorddate ,
    transactioncurrency ,
    accountcurrency )
select * from chargebacks