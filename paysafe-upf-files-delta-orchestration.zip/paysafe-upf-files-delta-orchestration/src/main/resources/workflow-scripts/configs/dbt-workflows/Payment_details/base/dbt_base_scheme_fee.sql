{{ config(materialized='table') }}

with scheme_fee as (
SELECT
    vtsf.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtsf.transactionslipnumber, vtsf.numberoriginalslip, vtsf.recorddate order by vtsf.filedate) rn
from {{ source('ukAcquiringRS2', 'TXN_SCHEME_FEE') }} vtsf
join {{ ref('dbt_base_pay2') }} pp_all on vtsf.institutionnumber = pp_all.institutionnumber and vtsf.clientnumber = pp_all.clientnumber and vtsf.filenumber > pp_all.filenumber_lag and vtsf.filenumber <= pp_all.filenumber and (pp_all.AccountTypeID = 7 or pp_all.settlement_method = 'G')
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtsf.TRANSACTIONTYPE = tt.Index_Field and vtsf.INSTITUTIONNUMBER = tt.Institution_Number
where vtsf.accountnumber > 13000
)

select * from scheme_fee