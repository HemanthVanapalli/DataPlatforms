{{ config(materialized='table') }}

with settles as (
 select * from {{ ref('dbt_base_PaymentSummary_settles') }}
) ,
chargebacks as (
select * from {{ ref('dbt_base_PaymentSummary_chargebacks') }}
) ,
volumes as (
select
    *
from
    chargebacks
union all
select
    *
from
    settles )
, volume_buckets as (
select
    institutionnumber ,
    clientnumber ,
    accountnumber ,
    FILENUMBER ,
    recorddate ,
    TRANSACTION_TYPE ,
    transactionstatus ,
    drcrindicator ,
    reversal ,
    settlementcurrency ,
    case
        when TRANSACTION_TYPE = 'Chargeback' then settle_amount
        else 0
    end pmt_total_chargeback ,
    case
        when TRANSACTION_TYPE = 'Refund (Credit)' then settle_amount
        else 0
    end pmt_total_credit ,
    case
        when TRANSACTION_TYPE in ('Cardholder Funds Transfer',
        'Unique transaction',
        'Purchase',
        'Interchange Payment') then settle_amount
        else 0
    end pmt_total_settlement ,
    0 pmt_discount_fee ,
    0 pmt_transaction_fee ,
    0 interchange_scheme_fee ,
    0 pmt_chargeback_fee ,
    0 pmt_monthly_fee ,
    0 pmt_payment_fee ,
    0 PMT_TOTAL_FEES
from
volumes )
select * from volume_buckets
