{{ config(materialized='table') }}

with merch_details as
 (
select
    MD.clientnumber ,
    MD.institutionnumber ,
    MD.legalname,
    MD.tradename,
    fmm.FMA,
    pad2.MERCHANTACCOUNTID,
	pad2.MLE_NAME,
	pad2.MLE_ID,
	pad2.PMLE_NAME,
	pad2.PMLE_ID
from {{ source('ukAcquiringRS2', 'merchant_details') }} MD
left join (select acid, fmaid FMA, iscurrent, cardtypekey, cardcategorykey from {{ source('mm', 'cardtypecode_dim') }} where iscurrent = 'true' and processorcode = 'OPN' LIMIT 1 over (partition by acid order by iscurrent desc)) fmm on MD.CLIENTNUMBER::varchar = LTRIM(FMM.ACID, '0')::varchar
left join (select mleid MLE_ID, mlename MLE_NAME, pmleid PMLE_ID, pmlename PMLE_NAME, merchantaccountid from {{ source('mm', 'ProcessingAccount_Dim') }} where iscurrent = true) pad2 on pad2.merchantaccountid = fmm.FMA
--where legalname in ('Neteller (UK) Ltd','PFSL Neteller', 'PPSL Neteller', 'PPSL Skrill', 'Skrill Limited', 'Skrill Ltd')
limit 1 over (partition by ClientNumber order by FILEDATE desc)
)
select * from merch_details