{{ config(materialized='table') }}

with payments_summary as (
select
    vtps.INSTITUTIONNUMBER ,
    vtps.CLIENTNUMBER ,
    vtps.ACCOUNTNUMBER ,
    nvl(vtps.RECORDDATE ,
    vtps.VALUEDATE ) recorddate ,
    vtps.TRANSACTIONSLIPNUMBER ,
    vtps.TRANSACTIONSTATUS ,
    vtps.TRANSACTIONTYPE ,
    -1 CARDFLAG ,
    -1 CARDBRAND ,
    vtps.numberoriginalslip::varchar txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    tt.DESCRIPTION_1 transaction_type ,
    decode(vtps.DRCRINDICATOR,1,'001',2,'002') drcrindicator ,
    vtps.REVERSAL ,
    CASE
        WHEN tt.DESCRIPTION_1 IN ('Partner Faster Payment', 'Merch Faster Payment', 'Merch SEPA Payment', 'Partner Wire Payment', 'Merch Wire Payment', 'Partner SEPA Payment') THEN 'Payments'
        WHEN tt.DESCRIPTION_1 IN ('Intra Account Fee Collection') THEN 'Transfer'
        WHEN tt.DESCRIPTION_1 IN ('Rolling Reserve Out', 'Rolling Reserve Inw') THEN 'Reserve'
        WHEN tt.DESCRIPTION_1 IN ('Merch BACS Collection') THEN 'Deposit'
    ELSE 'Transfer'
    END AS fee_type ,
    vtps.TRANSACTIONCURRENCY ,
    vtps.TRANSACTIONCURRENCY settlementcurrency,
    vtps.TRANSACTIONCURRENCY accountcurrency ,
    0 fee_amount_processing ,
    vtps.TRANSACTIONAMOUNT_PROCESSING fee_amount_settlement ,
    vtps.TRANSACTIONAMOUNT_PROCESSING fee_amount_account ,
    1 txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS_SUMMARY') }} limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) )  vtps
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtps.INSTITUTIONNUMBER = tt.INSTITUTION_NUMBER and vtps.TRANSACTIONTYPE = tt.INDEX_FIELD
where vtps.accountnumber > 13000
)
select * from payments_summary