{{ config(materialized='table') }}

with cte as (
select
    mcbb.*
from {{ source('ukAcquiringRS2', 'MERCHANT_CYCLE_BOOK_BALANCE') }} mcbb
where mcbb.accountnumber > 13000
limit 1 over (partition by mcbb.CLIENTNUMBER, mcbb.accountnumber, mcbb.filedate order by mcbb.DATEOFEXTRACTION desc)
)
select * from cte