{{ config(materialized='table') }}

with payments as (
select
    tp.INSTITUTIONNUMBER ,
    tp.CLIENTNUMBER ,
    tp.ACCOUNTNUMBER ,
    nvl(tp.RECORDDATE ,
    tp.VALUEDATE ) recorddate ,
    TP.TRANSACTIONSLIPNUMBER ,
    tp.TRANSACTIONSTATUS ,
    tp.TRANSACTIONTYPE ,
    -1 CARDFLAG ,
    -1 CARDBRAND ,
    '' txn_applied_to ,
    0 ORIGINALREFERENCENUMBER ,
    0 AQUIRERREFERENCE ,
    tt.DESCRIPTION_1 transaction_type ,
    decode(tp.DRCRINDICATOR,1,'001',2,'002') drcrindicator ,
    tp.REVERSAL ,
    CASE
        WHEN tt.DESCRIPTION_1 IN ('Partner Faster Payment', 'Merch Faster Payment', 'Merch SEPA Payment', 'Partner Wire Payment', 'Merch Wire Payment', 'Partner SEPA Payment') THEN 'Payments'
        WHEN tt.DESCRIPTION_1 IN ('Intra Account Fee Collection') THEN 'Transfer'
        WHEN tt.DESCRIPTION_1 IN ('Rolling Reserve Out', 'Rolling Reserve Inw') THEN 'Reserve'
        WHEN tt.DESCRIPTION_1 IN ('Merch BACS Collection') THEN 'Deposit'
        WHEN tt.DESCRIPTION_1 IN ('Misc. CR transaction') THEN 'Adjustment'
    ELSE 'Transfer'
    END AS fee_type ,
    tp.TRANSACTIONCURRENCY ,
    tp.TRANSACTIONCURRENCY settlementcurrency,
    tp.TRANSACTIONCURRENCY accountcurrency ,
    tp.TRANSACTIONAMOUNT_PROCESSING fee_amount_processing ,
    tp.TRANSACTIONAMOUNT_PROCESSING fee_amount_settlement ,
    tp.TRANSACTIONAMOUNT_PROCESSING fee_amount_account ,
    1 txns
from (select * from {{ source('ukAcquiringRS2', 'TXN_PAYMENTS') }}  limit 1 over (partition by TRANSACTIONSLIPNUMBER order by RECORDDATE desc) ) tp
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on tp.INSTITUTIONNUMBER = tt.INSTITUTION_NUMBER and tp.TRANSACTIONTYPE = tt.INDEX_FIELD
where tp.accountnumber > 13000
)
select * from payments