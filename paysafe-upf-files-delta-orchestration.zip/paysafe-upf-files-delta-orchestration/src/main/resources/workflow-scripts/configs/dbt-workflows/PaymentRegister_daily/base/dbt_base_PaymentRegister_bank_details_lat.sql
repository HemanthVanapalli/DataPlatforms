{{ config(materialized='table') }}

with bank_details_lat as
(
select
    count(*) over (PARTITION by CLIENTNUMBER, DATEOFEXTRACTION) cnt,
    max(bankcountry) over (partition by InstitutionNumber , clientnumber ) bank2,
    *
from
{{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_SETTLEMENT') }} vmcs
limit 1 over (partition by INSTITUTIONNUMBER , CLIENTNUMBER order by DATEOFEXTRACTION desc,SettlementNumber)
)
select * from bank_details_lat