{{ config(materialized='table') }}

with address_lat as
(
select
    count(*) over (PARTITION by clientnumber) mid_cnt ,
    *
from
{{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_ADDRESSES') }}  vmca
limit 1 over (PARTITION by CLIENTNUMBER, institutionnumber order by DATEOFEXTRACTION desc)
)
select * from address_lat