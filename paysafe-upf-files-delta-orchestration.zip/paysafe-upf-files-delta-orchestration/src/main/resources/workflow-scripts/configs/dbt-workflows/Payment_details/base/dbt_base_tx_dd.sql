{{ config(materialized='table') }}

with tx as
(
select
    vts.CLIENTNUMBER ,
    vts.INSTITUTIONNUMBER,
    vts.ACCOUNTNUMBER ,
    vtt.DATEOFEXTRACTION ,
    vtt.recorddate VALUEDATE ,
    vtt.TRANSACTIONSLIPNUMBER slip,
    ORIGINALREFERENCENUMBER,
    vtt.INWARDFEENUMBER ,
    vtt.REVERSAL ,
    vtt.TRANSACTIONAMOUNT_PROCESSING proc_amt ,
    vtt.TRANSACTIONAMOUNT_SETTLEMENT settle_amt,
    vtt.TRANSACTIONCATEGORY txcat ,
    tt.DESCRIPTION_1 Transaction_Type ,
    vtt.TRANSACTIONSTATUS ,
    vts.TRANSACTIONCURRENCY ,
    vtt.FILENUMBER ,
    vts.SETTLEMENTCURRENCY ,
    vtt.DRCRINDICATOR ,
    sum(vtt.TRANSACTIONAMOUNT_PROCESSING) over (partition by vtt.VALUEDATE,
    vtt.TRANSACTIONTYPE ) proc_day ,
    vts.TRANSACTIONAMOUNT_PROCESSING total_proc ,
    rccc.DESCRIPTION_1 TRANSACTIONDESTINATION ,
    ROW_NUMBER() over (PARTITION by vtt.transactionslipnumber,vtt.transactionstatus order by vtt.recorddate desc) rn
from {{ source('ukAcquiringRS2', 'TXN_TRANSACTIONS') }} vtt
left join {{ source('ukAcquiringRS2', 'TXN_SUMMARY') }} vts on vtt.SOURCESETTLEMENT = vts.SOURCESETTLEMENT
join {{ ref('dbt_base_pay2') }} pp_all on vts.institutionnumber = pp_all.institutionnumber and vts.clientnumber = pp_all.clientnumber and vtt.filenumber > pp_all.filenumber_lag and vtt.filenumber <= pp_all.filenumber and pp_all.AccountTypeID = 12
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }}  tt on vtt.INSTITUTIONNUMBER = tt.Institution_Number and vtt.TRANSACTIONTYPE = tt.Index_Field
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CLEARING_CHANNEL') }} rccc on rccc.INSTITUTION_NUMBER = vtt.INSTITUTIONNUMBER and rccc.INDEX_FIELD = vtt.TRANSACTIONDESTINATION
where vts.accountnumber > 13000
)

select * from tx where rn = 1
