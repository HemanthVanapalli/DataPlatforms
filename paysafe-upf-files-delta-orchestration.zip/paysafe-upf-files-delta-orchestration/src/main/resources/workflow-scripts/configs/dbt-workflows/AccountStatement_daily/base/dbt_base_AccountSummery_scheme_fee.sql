{{ config(materialized='table') }}

with scheme_fee as
(
SELECT
    vtsf.*,
    tt.DESCRIPTION_1 transaction_type,
    ROW_NUMBER() over (partition by vtsf.transactionslipnumber, vtsf.numberoriginalslip, vtsf.recorddate order by vtsf.filedate) rn
from {{ source('ukAcquiringRS2', 'TXN_SCHEME_FEE') }} vtsf
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_TRANSACTION_TYPE') }} tt on vtsf.TRANSACTIONTYPE = tt.Index_Field and vtsf.INSTITUTIONNUMBER = tt.Institution_Number
left join {{ source('ukAcquiringRS2', 'RS2_CHOICE_CHARGE_TYPE') }} ct on vtsf.CHARGETYPE = ct.Index_Field and vtsf.INSTITUTIONNUMBER = ct.Institution_Number
where RECORDDATE = {{ var("RUNDATE") }}  and vtsf.accountnumber > 13000
)
select * from scheme_fee