{{ config(materialized='table') }}

with bank_details_lat as (
select
    vmcs.clientnumber,
    vmcs.CounterBankAccount
from {{ source('ukAcquiringRS2', 'MERCHANT_CLIENT_SETTLEMENT') }} vmcs
join {{ ref('dbt_base_PaymentSummary_merch_details') }} md on vmcs.clientnumber = md.clientnumber and vmcs.institutionnumber = md.institutionnumber
limit 1 over (partition by vmcs.INSTITUTIONNUMBER , vmcs.CLIENTNUMBER order by vmcs.DATEOFEXTRACTION desc, vmcs.FundingClient )
)
select * from bank_details_lat