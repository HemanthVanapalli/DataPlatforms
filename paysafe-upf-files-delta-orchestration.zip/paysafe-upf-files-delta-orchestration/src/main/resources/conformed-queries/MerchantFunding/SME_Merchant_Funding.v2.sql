DROP TABLE Settlement
GO
CREATE LOCAL TEMPORARY TABLE Settlement
(
    DateTransmit DATE NOT NULL, --DateEffectiveEntry?
    MerchantNumber INTEGER NOT NULL, --VARCHAR(16)? --INT, INTEGER, INT8, SMALLINT, TINYINT, and BIGINT are all synonyms for the same signed 64-bit integer data type. Automatic compression techniques are used to conserve disk space in cases where the full 64 bits are not required.
    WithdrawalAmt MONEY NOT NULL, --withdrawl from merchant's bank account
    DepositAmt MONEY NOT NULL, --deposit to merchant's bank account
    AmtDirection VARCHAR(2) NOT NULL, -- debit = withdrawl from merchant's bank account.  credit = deposit to merchant's bank account
    TraceNumber CHAR(15) NOT NULL, --It's always 15 digits long.  
    MerchantRouteNbr CHAR(9), --It's always 9 digits long.  Can start with a zero..
    MerchantAccountNbr VARCHAR(5),  --According to NACHA rules, this can technically be alphanumeric 17.  International ACH (IAT) items can be alpha 35!
    MerchantAccountNbrHash VARCHAR(134), 
    TransactionCode  VARCHAR(3), --INT, INTEGER, INT8, SMALLINT, TINYINT, and BIGINT are all synonyms for the same signed 64-bit integer data type. Automatic compression techniques are used to conserve disk space in cases where the full 64 bits are not required.
    FileIdModifier VARCHAR(1),
    DateFileCreation DATE,
    Processor VARCHAR(3)
    
) ON COMMIT PRESERVE ROWS NO PROJECTION 
GO
ALTER TABLE Settlement ADD CONSTRAINT PK PRIMARY KEY (DateTransmit,MerchantNumber,TraceNumber,WithdrawalAmt,DepositAmt,AmtDirection) ENABLED
GO
---== 1 of 3 | Omaha platform ==---
INSERT INTO Settlement
(
    DateTransmit,
    MerchantNumber,
    WithdrawalAmt,
    DepositAmt,
    AmtDirection,
    TraceNumber,
    MerchantRouteNbr,
    MerchantAccountNbr,
    MerchantAccountNbrHash, 
    TransactionCode,
    FileIdModifier,
    DateFileCreation,
    Processor
)    
SELECT
    TRANSMISSION_DATE                   "DateTransmit", 
    CAST(ACCOUNT_NUMBER AS INTEGER)     "MerchantNumber",
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN CAST(0 AS MONEY)  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN CAST(AMOUNT AS MONEY)
        ELSE NULL
    END                                 "WithdrawalAmt", 
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN CAST(AMOUNT AS MONEY)  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN CAST(0 AS MONEY)
        ELSE NULL
    END                                 "DepositAmt", 
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN 'C'  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN 'D'
        ELSE CAST(TRN_CDE AS VARCHAR(5))
    END                                 "AmtDirection",         
    TRACE_NUMBER                        "TraceNumber",
    TR_NUMBER                           "MerchantRouteNbr",
    '00000'                             "MerchantAccountNbr",
    DDA_GL_SAVINGS                      "MerchantAccountNbrHash",
    TRN_CDE::INTEGER                    "TransactionCode",
    ID                                  "FileIdModifier",
    CAST(sd77.FC_DATE AS DATE)          "DateFileCreation",
    'OMA'                               "Processor"
FROM 
    BISME.SD077_Omaha   sd77
WHERE
    ACCOUNT_NUMBER IS NOT NULL
    AND CAST(TRANSMISSION_DATE AS DATE)>='01-MAY-2020'
    --AND TRANSMISSION_DATE='15-MAY-2020'
    --LIMIT 5
    --AND TRANSMISSION_DATE='23-MAR-2020'
    --AND ACCOUNT_NUMBER='5428141601013947'
    --AND TR_NUMBER='113008460014986'   
GO
--SELECT * FROM BISME.SD077_Omaha   sd77 WHERE TRANSMISSION_DATE='2020-04-12' AND ACCOUNT_NUMBER='5180894501113640' AND TRACE_NUMBER='091000010019070'
---== 2 of 3 | North platform ==---     
INSERT INTO Settlement
(
    DateTransmit,
    MerchantNumber,
    WithdrawalAmt,
    DepositAmt,
    AmtDirection,
    TraceNumber,
    MerchantRouteNbr,
    MerchantAccountNbr,
    MerchantAccountNbrHash, 
    TransactionCode,
    FileIdModifier,
    DateFileCreation,
    Processor
)  
SELECT
    FUNDED_DATE                 "DateTransmit",
    CAST(LOCATION_ID AS INT)    "MerchantNumber",
    CASE 
        WHEN DEPOSIT_AMOUNT_SIGN='+' THEN 0                         --'DP'
        WHEN DEPOSIT_AMOUNT_SIGN='-' THEN ABS(DEPOSITAMOUNTSIGNED)  --'WD'
        ELSE NULL
    END                         "WithdrawalAmt",
    CASE 
        WHEN DEPOSIT_AMOUNT_SIGN='+' THEN ABS(DEPOSITAMOUNTSIGNED)  --'DP'
        WHEN DEPOSIT_AMOUNT_SIGN='-' THEN 0                         --'WD'
        ELSE NULL
    END                         "DepositAmt",        
    CASE 
        WHEN DEPOSIT_AMOUNT_SIGN='+' THEN 'C'       --'DP'
        WHEN DEPOSIT_AMOUNT_SIGN='-' THEN 'D'       --'WD'
        ELSE DEPOSIT_AMOUNT_SIGN
    END                         "AmtDirection",
    LOCATION_ID                 "TraceNumber",
    ABA_NUMBER                  "MerchantRouteNbr",
    RIGHT(DDANUMBERLAST25PCT,5) "MerchantAccountNbr",
    DDA_NUMBER                  "MerchantAccountNbrHash",
    NULL                        "TransactionCode",
    NULL                        "FileIdModifier",
    FUNDED_DATE                 "DateFileCreation",
    'NOR'                       "Processor"    
FROM    
    BISME.DFM_LocationBankDepositsSummary013_North 
WHERE
    LOCATION_ID IS NOT NULL
    AND DEPOSITAMOUNTSIGNED IS NOT NULL
    AND CAST(FUNDED_DATE AS DATE)>='01-MAY-2020'
GO
---== 3 of 3 | TSYS platform ==--- 
INSERT INTO Settlement
(
    DateTransmit,
    MerchantNumber,
    WithdrawalAmt,
    DepositAmt,
    AmtDirection,
    TraceNumber,
    MerchantRouteNbr,
    MerchantAccountNbr,
    MerchantAccountNbrHash, 
    TransactionCode,
    FileIdModifier,
    DateFileCreation,
    Processor
)  
SELECT 
    EFFECTIVE_DATE                      "DateTransmit",
    CAST(ACCOUNT_NUMBER AS INT)         "MerchantNumber",
    --Are we summing the right things?  We want to match the line items (plural) showing daily in the merchant's bank account.
    SUM(
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 0                   --'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN ABS(AMOUNT)         --'DP'
        ELSE NULL
    END)                               "WithdrawalAmt",
    SUM(
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN ABS(AMOUNT)         --'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 0                   --'DP'
        ELSE NULL
    END)                                "DepositAmt",
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'C'                 --'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'D'                 --'DP'
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END                                 "AmtDirection",        
    CASE 
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) > 0 THEN RIGHT(REFERENCE_NUMBER,15)
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) = 0 THEN RECORD_SEQUENCE_NUMBER
        ELSE 'ERROR'
    END                                 "TraceNumber",
    ROUTING_NUMBER                      "MerchantRouteNbr",
    RIGHT(DDANUMBERLAST25PCT,5)         "MerchantAccountNbr",
    DDA_NUMBER                          "MerchantAccountNbrHash",
    LEFT(TRANSACTION_TYPES,3)           "TransactionCode",
    NULL                                "FileIdModifier",
    MAX(PROCESSING_DATE)                "DateFileCreation", --It's unfortunate to MAX() this so we don't get the detail.  Need to figure out what's going on here.
    'TSS'                               "Processor"   
FROM 
    BISME.ACHDetailFile_TSYS 
WHERE
    ROUTING_NUMBER IS NOT NULL
    AND EFFECTIVE_DATE IS NOT NULL
    AND CAST(EFFECTIVE_DATE AS DATE)>='01-MAY-2020' 
    --REFERENCE_NUMBER='0000090001919777'
    --AND ACCOUNT_NUMBER='221191306'
    --AND EFFECTIVE_DATE='4/16/2020'
    --EFFECTIVE_DATE>PROCESSING_DATE
GROUP BY
    EFFECTIVE_DATE                      ,
    ACCOUNT_NUMBER                      ,
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'C'                     --'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'D'                     --'DP'
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END,
    CASE 
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) > 0 THEN RIGHT(REFERENCE_NUMBER,15)
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) = 0 THEN RECORD_SEQUENCE_NUMBER
        ELSE 'ERROR'
    END                                 ,
    ROUTING_NUMBER                      ,
    RIGHT(DDANUMBERLAST25PCT,5)         ,
    DDA_NUMBER                          ,
    LEFT(TRANSACTION_TYPES,3)           ,
    NULL   
GO
SELECT 
    Processor,
    DateTransmit,
    DateFileCreation,
    SUM(WithdrawalAmt)  WithdrawalAmt, 
    SUM(DepositAmt)     DepositAmt
FROM 
    Settlement 
WHERE 
    DateTransmit='5/25/2020' 
GROUP BY 
    Processor,
    DateTransmit,
    DateFileCreation
    
---== STOP, delete everything below here - for snadboxing QA only below here ==---    
SELECT * FROM Settlement WHERE Processor='NOR' AND DateTransmit='5/25/2020' GROUP BY AmtDirection
;

SELECT 
    EFFECTIVE_DATE                      "DateTransmit",
    ACCOUNT_NUMBER                      "MerchantNumber",
    ABS(AMOUNT)                         "Amount",
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'DP'
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END                                 "AmountDirection",
    RIGHT(REFERENCE_NUMBER,15)          "TraceNumber",
    ROUTING_NUMBER                      "MerchantRouteNbr",
    RIGHT(DDANUMBERLAST25PCT,5)         "MerchantAccountNbr",
    DDA_NUMBER                          "MerchantAccountNbrHash",
    LEFT(TRANSACTION_TYPES,3)           "TransactionCode",
    NULL                                "FileIdModifier",
    PROCESSING_DATE                     "DateFileCreation",
    *
FROM 
    BISME.ACHDetailFile_TSYS 
WHERE
    --ERROR: Duplicate key values: 'DateTransmit=2020-04-27,MerchantNumber=3286000000244202,TraceNumber=000000000000000,Amount=0.1000,AmountDirection=WD'
    --DateTransmit=2020-04-27,MerchantNumber=3286000000570804,TraceNumber=000090001010001,Amount=0.0100,AmountDirection=WD
    EFFECTIVE_DATE='2020-04-27'
    AND ACCOUNT_NUMBER=3286000000570804
    and RIGHT(REFERENCE_NUMBER,15)='000090001010001'
    AND Amount=0.0100
    AND     CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'DP'
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END='WD'
LIMIT
    500
;
SELECT * FROM BISME.ACHDetailFile_TSYS WHERE ACCOUNT_NUMBER IN ('220673668','3286000000027144') LIMIT 500
;
SELECT 
    *
FROM
    BISME.DFM_LocationBankDepositsSummary013_North
WHERE
    FUNDED_DATE='2019-12-22'
    AND LOCATION_ID='444248376881'
;
---== Run on vertica.edl2.prod.paysafe.cloud ==---
-- Hash is sometimes 133 and other times, 134.  Is that expected?
SELECT LENGTH(DDA_NUMBER), DDA_NUMBER, * FROM BISME.DFM_LocationBankDepositsSummary013_North LIMIT 5
;
-- Hash is 50.  Why doesn't it match the length of the DDA_NUMBER above?
SELECT LENGTH(DDA_GL_SAVINGS),DDA_GL_SAVINGS,* FROM BISME.SD077_Omaha LIMIT 5
;

--'DateACH=2020-03-23,MerchantNumber=5428141601013947,TraceNumber=113008460014986' -- violates constraint 'v_temp_schema.Settlement.PK'
---== DUPLICATES! Run on vertica.edl2.prod.paysafe.cloud ==---
SELECT 
    *
FROM 
    BISME.SD077_Omaha
WHERE    
    TRANSMISSION_DATE='23-MAR-2020'
    --AND ACCOUNT_NUMBER='5428141601013947'
    AND TRACE_NUMBER='113008460014986'
;    

;    
SELECT
    AMOUNT_TYPE_CODE,
    CASE 
        WHEN AMOUNT_TYPE_CODE='D' THEN 'Diverted funds'
        WHEN AMOUNT_TYPE_CODE='F' THEN 'Remitted to AdvanceMe, Inc. (AMI) for merchant alternative funding'
        WHEN AMOUNT_TYPE_CODE='R' THEN 'Merchant reserve'
        WHEN AMOUNT_TYPE_CODE='T' THEN 'Trust fund'
        WHEN AMOUNT_TYPE_CODE='W' THEN 'Backup withholding'
        WHEN AMOUNT_TYPE_CODE='O' THEN 'Funds advance' --This is when a merchant is contracted with a third party cash advance provider that is taking their split of the funds. This generally effects merchant ACH reconciliation as far as settlement is concerned.
        WHEN AMOUNT_TYPE_CODE='P' THEN 'Funds diverted to collections' --This is when a merchant is contracted with a third party cash advance provider that is taking their split of the funds. This generally effects merchant ACH reconciliation as far as settlement is concerned.
  
        WHEN AMOUNT_TYPE_CODE IS NULL THEN ''
        ELSE 'Unknown'
    END AMOUNT_TYPE_DESC,
    TRN_CDE,
    CASE
        WHEN TRN_CDE='22' THEN 'Automatic deposit crediting the checking account'
        WHEN TRN_CDE='23' THEN 'Automatic deposit prenote'
        WHEN TRN_CDE='27' THEN 'Automatic payment debiting the checking account'
        WHEN TRN_CDE='28' THEN 'Automatic payment prenote'
        WHEN TRN_CDE='32' THEN 'Automatic deposit crediting the savings account'
        WHEN TRN_CDE='33' THEN 'Automatic savings deposit prenote'
        WHEN TRN_CDE='37' THEN 'Automatic payment debiting the savings account'
        WHEN TRN_CDE='38' THEN 'Automatic savings payment prenotet'
        WHEN TRN_CDE='42' THEN 'Automatic deposit crediting the general ledger account'
        WHEN TRN_CDE='47' THEN 'Automatic payment debiting the general ledger account'
        ELSE 'Unknown'
    END TRN_CDE_DESC,
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN 'DEPOSIT TO MERCHANT'  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN 'WITHDRAWAL FROM MERCHANT'
        ELSE 'Unknown'
    END FEE_DIRECTION,
    SUM(CAST(AMOUNT AS MONEY)) AMOUNT
FROM 
    BISME.SD077_Omaha
WHERE
    OFFSET_DLY_ADV_SYSTEMID IS NULL 
    --AND AMOUNT_TYPE_CODE='R' --P, O, W, (null), R
GROUP BY
    AMOUNT_TYPE_CODE,
    CASE 
        WHEN AMOUNT_TYPE_CODE='D' THEN 'Diverted funds'
        WHEN AMOUNT_TYPE_CODE='F' THEN 'Remitted to AdvanceMe, Inc. (AMI) for merchant alternative funding'
        WHEN AMOUNT_TYPE_CODE='R' THEN 'Merchant reserve'
        WHEN AMOUNT_TYPE_CODE='T' THEN 'Trust fund'
        WHEN AMOUNT_TYPE_CODE='W' THEN 'Backup withholding'
        WHEN AMOUNT_TYPE_CODE IS NULL THEN ''
        ELSE 'Unknown'
    END ,
    TRN_CDE,
    CASE
        WHEN TRN_CDE='22' THEN 'Automatic deposit crediting the checking account'
        WHEN TRN_CDE='23' THEN 'Automatic deposit prenote'
        WHEN TRN_CDE='27' THEN 'Automatic payment debiting the checking account'
        WHEN TRN_CDE='28' THEN 'Automatic payment prenote'
        WHEN TRN_CDE='32' THEN 'Automatic deposit crediting the savings account'
        WHEN TRN_CDE='33' THEN 'Automatic savings deposit prenote'
        WHEN TRN_CDE='37' THEN 'Automatic payment debiting the savings account'
        WHEN TRN_CDE='38' THEN 'Automatic savings payment prenotet'
        WHEN TRN_CDE='42' THEN 'Automatic deposit crediting the general ledger account'
        WHEN TRN_CDE='47' THEN 'Automatic payment debiting the general ledger account'
        ELSE 'Unknown'
    END ,
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN 'DEPOSIT TO MERCHANT'  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN 'WITHDRAWAL FROM MERCHANT'
        ELSE 'Unknown'
    END 
/*
Valid codes for merchant ACH items:
22 - Automatic deposit crediting the checking account
23 - Automatic deposit prenote
27 - Automatic payment debiting the checking account
28 - Automatic payment prenote
32 - Automatic deposit crediting the savings account
33 - Automatic savings deposit prenote
37 - Automatic payment debiting the savings account
38 - Automatic savings payment prenote
42 - Automatic deposit crediting the general ledger account
47 - Automatic payment debiting the general ledger account
*/
;
SELECT 
    ACCOUNT_NUMBER,
    COUNT(DISTINCT TR_NUMBER)

FROM 
    BISME.SD077_Omaha
WHERE
    OFFSET_DLY_ADV_SYSTEMID IS NULL 
    --AND TRN_CDE='42'
    --AND AMOUNT_TYPE_CODE='P' --P
    AND ENVELOPEBUSINESSLOCATION = 'Westlake' --('Dallas/Houston/Irvine','Westlake')
    --AND ACCOUNT_NUMBER='4765795103039360'
    --AND TRACE_NUMBER='121000240000050'
    --AND AMOUNT='25.00'
    AND SYSTEM_NUMBER || PRIN_NUMBER != '53784900'

GROUP BY
    ACCOUNT_NUMBER
ORDER BY
    COUNT(DISTINCT TR_NUMBER) DESC
;
SELECT
    TRANSMISSION_DATE-FC_DATE , 
    FC_DATE,
    TRANSMISSION_DATE,
    ID,
    AMOUNT_TYPE_CODE,
    * 
FROM 
    BISME.SD077_Omaha 
WHERE 
    --FC_DATE<TRANSMISSION_DATE 
    --ID NOT IN ('G','H','B') --ID is always G or H or B
    --AMOUNT_TYPE_CODE NOT IN ('R','O','W','P','D')
    --OFFSET_DLY_ADV_AMOUNT>0
    --TRN_CDE IS NOT NULL
    --AND AMOUNT <> 0
    LEFT(TR_NUMBER,1)='0'
ORDER BY  
    FC_DATE-TRANSMISSION_DATE 
LIMIT 
    500
;
SELECT
    TRN_CDE,
    count(*),
    sum(AMOUNT)
FROM 
    BISME.SD077_Omaha 
GROUP BY
    TRN_CDE
;
SELECT
    *
FROM 
    BISME.SD077_Omaha 
WHERE
    --OFFSET_DLY_ADV_TRACE_NUMBER='113008460011804' ---22.91
    FC_DATE = '21-FEB-2020'
    AND AMOUNT=22.91
    --TRACE_NUMBER='113008460011804'
LIMIT
    2
;
SELECT
    *
FROM 
    BISME.SD077_Omaha 
WHERE
    OFFSET_DLY_ADV_TRACE_NUMBER='113008460011804'
LIMIT
    2
;    

    