/*
Version 2.4 Changelog
+ Joined each of the 3 tables to the BI.ReportingChannels to insure only merchants in the MIF are being added to the BI.MerchantFunding table.
*/
CREATE LOCAL TEMPORARY TABLE FileDetails
(
    FileID IDENTITY(1,1),
    UNITYFILENAME VARCHAR(100),
    UNITYFILEDATE TIMESTAMP,
    OtherThings VARCHAR(100)
) ON COMMIT PRESERVE ROWS NO PROJECTION     
ALTER TABLE FileDetails ADD CONSTRAINT PK UNIQUE (UNITYFILENAME,UNITYFILEDATE) ENABLED  QUIETLY IGNORE CONFLICTING INSERTS 
INSERT INTO FileDetails (UNITYFILENAME, UNITYFILEDATE, OtherThings) 
SELECT 
    UNITYFILENAME,	
    UNITYFILEDATE 
FROM 
    BISME.SD077_Omaha   
;

---== Start settlement conformed table ==---
DROP TABLE IF EXISTS Settlement
;
CREATE LOCAL TEMPORARY TABLE Settlement
(
    ACH_Date                DATE NOT NULL,          --
    MerchantNumber          VARCHAR(16) NOT NULL,   --Although INTEGER is way more efficient (speed and storeage size), the VARCHAR(16) is more user friendly and will create less problems (e.g. will not drop leading zeros, etc).
    WithdrawalAmt           MONEY NOT NULL,         --withdrawl from merchant's bank account
    DepositAmt              MONEY NOT NULL,         --deposit to merchant's bank account
    AmtDirection            VARCHAR(2) NOT NULL,    --debit = withdrawl from merchant's bank account.  credit = deposit to merchant's bank account.  This field is cosmentic but some people are used to seeing it so throwing it in.
    TraceNumber             CHAR(15) NOT NULL,      --It's always 15 digits long per NACHA requirements  
    MerchantRouteNbr        CHAR(9),                --It's always 9 digits long.  Can start with a zero..
    MerchantAccountNbr      VARCHAR(5),             --According to NACHA rules, this can technically be alphanumeric 17. So 25% of 17 = 5 thus VARCHAR(5). Beware: International ACH (IAT) items can be alpha 35!
    MerchantAccountNbrHash  VARCHAR(134), 
    TransactionCode         VARCHAR(3),             --INT, INTEGER, INT8, SMALLINT, TINYINT, and BIGINT are all synonyms for the same signed 64-bit integer data type. Automatic compression techniques are used to conserve disk space in cases where the full 64 bits are not required.
    FileIdModifier          VARCHAR(1),             --This is a sincle character field and it's in the NACHA spec - it helps guarentee the uniquness of the 15-digit NACHA trace number. 
    DateFileCreation        DATE,
    Processor               VARCHAR(3)
    
) ON COMMIT PRESERVE ROWS NO PROJECTION 
;
ALTER TABLE Settlement ADD CONSTRAINT PK PRIMARY KEY (ACH_Date,MerchantNumber,TraceNumber,WithdrawalAmt,DepositAmt,AmtDirection) ENABLED
;
---== 1 of 3 | Omaha platform ==---
INSERT INTO BI.MerchantFunding
(
    ACH_Date,
    MerchantNumber,
    WithdrawalAmt,
    DepositAmt,
    AmtDirection,
    TraceNumber,
    MerchantRouteNbr,
    MerchantAccountNbr,
    MerchantAccountNbrHash, 
    TransactionCode,
    FileIdModifier,
    DateFileCreation,
    Processor
)    
SELECT
    TRANSMISSION_DATE                   "ACH_Date", 
    ACCOUNT_NUMBER                      "MerchantNumber",
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN CAST(0 AS MONEY)  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN CAST(AMOUNT AS MONEY)
        ELSE NULL
    END                                 "WithdrawalAmt", 
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN CAST(AMOUNT AS MONEY)  
        WHEN TRN_CDE IN ('27','37') THEN CAST(0 AS MONEY)
        ELSE NULL
    END                                 "DepositAmt", 
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN 'C'  
        WHEN TRN_CDE IN ('27','37') THEN 'D'
        ELSE CAST(TRN_CDE AS VARCHAR(5))
    END                                 "AmtDirection",         
    TRACE_NUMBER                        "TraceNumber",
    TR_NUMBER                           "MerchantRouteNbr",
    '00000'                             "MerchantAccountNbr",
    DDA_GL_SAVINGS                      "MerchantAccountNbrHash",
    TRN_CDE::INTEGER                    "TransactionCode",
    ID                                  "FileIdModifier",
    CAST(sd77.FC_DATE AS DATE)          "DateFileCreation",
    'OMA'                               "Processor"
FROM 
    BISME.SD077_Omaha      sd77
    INNER JOIN FileDetails fd   ON (sd77.) 
    INNER JOIN BI.ReportingChannels rc ON (LEFT(sd77.ACCOUNT_NUMBER,15)=LEFT(rc.MerchantNumber,15)) --This LEFT(MID,15) is only needed on the Omaha platform.
WHERE
    ACCOUNT_NUMBER IS NOT NULL
    AND CAST(TRANSMISSION_DATE AS DATE)>='01-MAY-2020'
;
--SELECT * FROM BISME.SD077_Omaha   sd77 WHERE TRANSMISSION_DATE='2020-04-12' AND ACCOUNT_NUMBER='5180894501113640' AND TRACE_NUMBER='091000010019070'
---== 2 of 3 | North platform ==---     
INSERT INTO Settlement
(
    ACH_Date,
    MerchantNumber,
    WithdrawalAmt,
    DepositAmt,
    AmtDirection,
    TraceNumber,
    MerchantRouteNbr,
    MerchantAccountNbr,
    MerchantAccountNbrHash, 
    TransactionCode,
    FileIdModifier,
    DateFileCreation,
    Processor
)  
SELECT
    FUNDED_DATE                 "ACH_Date",
    LOCATION_ID                 "MerchantNumber",
    CASE 
        WHEN DEPOSIT_AMOUNT_SIGN='+' THEN 0                         
        WHEN DEPOSIT_AMOUNT_SIGN='-' THEN ABS(DEPOSITAMOUNTSIGNED) 
        ELSE NULL
    END                         "WithdrawalAmt",
    CASE 
        WHEN DEPOSIT_AMOUNT_SIGN='+' THEN ABS(DEPOSITAMOUNTSIGNED)  
        WHEN DEPOSIT_AMOUNT_SIGN='-' THEN 0                         
        ELSE NULL
    END                         "DepositAmt",        
    CASE 
        WHEN DEPOSIT_AMOUNT_SIGN='+' THEN 'C'       
        WHEN DEPOSIT_AMOUNT_SIGN='-' THEN 'D'      
        ELSE DEPOSIT_AMOUNT_SIGN
    END                         "AmtDirection",
    LOCATION_ID                 "TraceNumber",
    ABA_NUMBER                  "MerchantRouteNbr",
    RIGHT(DDANUMBERLAST25PCT,5) "MerchantAccountNbr",
    DDA_NUMBER                  "MerchantAccountNbrHash",
    NULL                        "TransactionCode",
    NULL                        "FileIdModifier",
    ENVELOPEFILEDATE            "DateFileCreation",
    'NOR'                       "Processor"    
FROM    
    BISME.DFM_LocationBankDepositsSummary013_North  nn
    INNER JOIN BI.ReportingChannels                 rc ON (nn.LOCATION_ID=rc.MerchantNumber)
WHERE
    LOCATION_ID IS NOT NULL
    AND DEPOSITAMOUNTSIGNED IS NOT NULL
    AND CAST(FUNDED_DATE AS DATE)>='01-MAY-2020'
;
---== 3 of 3 | TSYS platform ==--- 
INSERT INTO Settlement
(
    ACH_Date,
    MerchantNumber,
    WithdrawalAmt,
    DepositAmt,
    AmtDirection,
    TraceNumber,
    MerchantRouteNbr,
    MerchantAccountNbr,
    MerchantAccountNbrHash, 
    TransactionCode,
    FileIdModifier,
    DateFileCreation,
    Processor
)  
SELECT 
    EFFECTIVE_DATE                      "ACH_Date",
    ACCOUNT_NUMBER                      "MerchantNumber",
    --Are we summing the right things?  We want to match the line items (plural) showing daily in the merchant's bank account.
    SUM(
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 0
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN ABS(AMOUNT)
        ELSE NULL
    END)                               "WithdrawalAmt",
    SUM(
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN ABS(AMOUNT) 
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 0                  
        ELSE NULL
    END)                                "DepositAmt",
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'C'                 
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'D'                 
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END                                 "AmtDirection",        
    CASE 
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) > 0 THEN RIGHT(REFERENCE_NUMBER,15)
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) = 0 THEN RECORD_SEQUENCE_NUMBER
        ELSE 'ERROR'
    END                                 "TraceNumber",
    ROUTING_NUMBER                      "MerchantRouteNbr",
    RIGHT(DDANUMBERLAST25PCT,5)         "MerchantAccountNbr",
    DDA_NUMBER                          "MerchantAccountNbrHash",
    LEFT(TRANSACTION_TYPES,3)           "TransactionCode",
    NULL                                "FileIdModifier",
    NULL                                "FileCreationDate", --Both ENVELOPEFILEDATE and PROCESSING_DATE seem valable in ways that don't make sense.  Need to dig into this. Best to set to NULL for now.
    'TSS'                               "Processor"   
FROM 
    BISME.ACHDetailFile_TSYS        adf
    INNER JOIN BI.ReportingChannels rc  ON (adf.ACCOUNT_NUMBER=rc.MerchantNumber)
WHERE
    ROUTING_NUMBER IS NOT NULL
    AND EFFECTIVE_DATE IS NOT NULL
    AND CAST(EFFECTIVE_DATE AS DATE)>='01-MAY-2020' 
GROUP BY
    EFFECTIVE_DATE                      ,
    ACCOUNT_NUMBER                      ,
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'C'                 
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'D'                   
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END,
    CASE 
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) > 0 THEN RIGHT(REFERENCE_NUMBER,15)
        WHEN CAST(RIGHT(REFERENCE_NUMBER,15) AS INT) = 0 THEN RECORD_SEQUENCE_NUMBER
        ELSE 'ERROR'
    END                                 ,
    ROUTING_NUMBER                      ,
    RIGHT(DDANUMBERLAST25PCT,5)         ,
    DDA_NUMBER                          ,
    LEFT(TRANSACTION_TYPES,3)           
;
---== END ==---
;
---== STOP, delete everything below here - for sandboxing, analysis & QA only below here ==---   
---== Analysis and QA only below this line ==----
--==Thsi produces enough summary level that Accounting can balence to it. ==---
SELECT 
    Processor,
    CASE
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('5630','9416','8960')   THEN 'MRK'
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('3286','7630')          THEN 'WNB'
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('9264','2870')          THEN 'BVA'
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('9109')                 THEN 'BMO'
        
        WHEN Processor='NOR' AND LEFT(CAST(MerchantNumber AS VARCHAR),3) IN ('887')                  THEN 'WLF' --Dallas
        WHEN Processor='NOR' AND LEFT(CAST(MerchantNumber AS VARCHAR),3) IN ('497','291')            THEN 'WLF' --iPayment
        WHEN Processor='NOR' AND LEFT(CAST(MerchantNumber AS VARCHAR),3) IN ('296','434','444')      THEN 'WNB' 
        
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),6) IN ('230422','420009','422369','422899','429151','431227','446057','517817') THEN 'BVA'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),8) IN ('44682500','44682501','44682502','44682503','47657915','47657951',
        '51015939','51015940','51015941','51015964','51015965','51015968','51015969','51015980','51015981','51016516',
        '51016533','51792404','51792410','51792411','51792412','51792413','51792414','51792423','51792443','51792467',
        '51808930','51808931','51808945','51808965','51808968','51808987','51808988','51808989','51808991','51808992',
        '51808993','51856403','51856404','51856425','51898701','51898702','51898703','51898704','51898705','53470133',
        '53470134','53470135','53470136','53470137','54156304','54156310','54156350','54313814','54313815','54313816',
        '54313817','54313818','54313830','54313831','54313832','54313839','54313840','54313854','54313855','54313857',
        '54313858','54313859')                                                          THEN 'WLF'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),6) IN ('536387','542814','548298') THEN 'WNB'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),8) IN ('40566801','40566806')      THEN 'MRK'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),6) IN ('443163')                   THEN 'MRK'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),8) IN ('54309310','54309311','54309312','54309313','54309314',
        '54309315','54309316','54309317','54309318','54309319')                         THEN 'DTB'
        ELSE LEFT(CAST(MerchantNumber AS VARCHAR),6) 
    END "Sponsor",
    DateTransmit,
    DateFileCreation,
    SUM(WithdrawalAmt)  WithdrawalAmt, 
    SUM(DepositAmt)     DepositAmt
FROM 
    Settlement 
WHERE 
    DateTransmit IN ('5/26/2020','5/27/2020','5/28/2020') 
GROUP BY 
    Processor,
    CASE
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('5630','9416','8960')   THEN 'MRK'
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('3286','7630')          THEN 'WNB'
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('9264','2870')          THEN 'BVA'
        WHEN Processor='TSS' AND LEFT(CAST(MerchantNumber AS VARCHAR),4) IN ('9109')                 THEN 'BMO'
        
        WHEN Processor='NOR' AND LEFT(CAST(MerchantNumber AS VARCHAR),3) IN ('887')                  THEN 'WLF' --Dallas
        WHEN Processor='NOR' AND LEFT(CAST(MerchantNumber AS VARCHAR),3) IN ('497','291')            THEN 'WLF' --iPayment
        WHEN Processor='NOR' AND LEFT(CAST(MerchantNumber AS VARCHAR),3) IN ('296','434','444')      THEN 'WNB' 
        
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),6) IN ('230422','420009','422369','422899','429151','431227','446057','517817') THEN 'BVA'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),8) IN ('44682500','44682501','44682502','44682503','47657915','47657951',
        '51015939','51015940','51015941','51015964','51015965','51015968','51015969','51015980','51015981','51016516',
        '51016533','51792404','51792410','51792411','51792412','51792413','51792414','51792423','51792443','51792467',
        '51808930','51808931','51808945','51808965','51808968','51808987','51808988','51808989','51808991','51808992',
        '51808993','51856403','51856404','51856425','51898701','51898702','51898703','51898704','51898705','53470133',
        '53470134','53470135','53470136','53470137','54156304','54156310','54156350','54313814','54313815','54313816',
        '54313817','54313818','54313830','54313831','54313832','54313839','54313840','54313854','54313855','54313857',
        '54313858','54313859')                                                          THEN 'WLF'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),6) IN ('536387','542814','548298') THEN 'WNB'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),8) IN ('40566801','40566806')      THEN 'MRK'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),6) IN ('443163')                   THEN 'MRK'
        WHEN Processor='OMA' AND LEFT(CAST(MerchantNumber AS VARCHAR),8) IN ('54309310','54309311','54309312','54309313','54309314',
        '54309315','54309316','54309317','54309318','54309319')                         THEN 'DTB'
        ELSE LEFT(CAST(MerchantNumber AS VARCHAR),6) 
    END, 
    DateTransmit,
    DateFileCreation
;

---=== TSTS detail ==---
SELECT
    'TSS' "Processor",
    CASE
        WHEN BANK_NUMBER IN ('5630','9416','8960')   THEN 'MRK'
        WHEN BANK_NUMBER IN ('3286','7630')          THEN 'WNB'
        WHEN BANK_NUMBER IN ('9264','2870')          THEN 'BVA'
        WHEN BANK_NUMBER IN ('9109')                 THEN 'BMO'
        ELSE '???'
    END "SponsorBank",   
    BANK_NUMBER,
    EFFECTIVE_DATE                      "DateTransmit",
    ENVELOPEFILEDATE                    "DateFileCreation",
    CASE
        WHEN ach.ENVELOPEJOBNAME='B2870BI1' THEN '11:00AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B20' THEN '07:30PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B21' THEN '04:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B22' THEN '01:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B23' THEN '12:01AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B24' THEN '10:00AM Eastern (Sunday)'
        WHEN ach.ENVELOPEJOBNAME='B7630B18' THEN '05:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B7630B19' THEN '12:01AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B8960BI1' THEN '08:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B8960BI2' THEN '01:00AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9109BI1' THEN '10:00AM Eastern (Sunday)'
        WHEN ach.ENVELOPEJOBNAME='B9109BI2' THEN '07:30PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9109BI3' THEN '10:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9264B19' THEN '07:00PM Eastern (Sunday)'
        WHEN ach.ENVELOPEJOBNAME='B9264B20' THEN '06:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9264B21' THEN '08:00PM Eastern'                                                
        WHEN ach.ENVELOPEJOBNAME='B9264B22' THEN '12:01PM Eastern'
    END "TimingWindow",
    SUM(
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 0
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN ABS(AMOUNT)
        ELSE NULL
    END)                               "WithdrawalAmt",
    SUM(
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN ABS(AMOUNT) 
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 0                  
        ELSE NULL
    END)                                "DepositAmt"
FROM 
    BISME.ACHDetailFile_TSYS ach 
WHERE
    ROUTING_NUMBER IS NOT NULL
    AND EFFECTIVE_DATE IS NOT NULL
    AND CAST(EFFECTIVE_DATE AS DATE) IN ('5/26/2020','5/27/2020','5/28/2020') 
GROUP BY  
    CASE
        WHEN BANK_NUMBER IN ('5630','9416','8960')   THEN 'MRK'
        WHEN BANK_NUMBER IN ('3286','7630')          THEN 'WNB'
        WHEN BANK_NUMBER IN ('9264','2870')          THEN 'BVA'
        WHEN BANK_NUMBER IN ('9109')                 THEN 'BMO'
        ELSE '???'
    END,   
    BANK_NUMBER,
    EFFECTIVE_DATE,
    ENVELOPEFILEDATE,
    CASE
        WHEN ach.ENVELOPEJOBNAME='B2870BI1' THEN '11:00AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B20' THEN '07:30PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B21' THEN '04:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B22' THEN '01:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B23' THEN '12:01AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B3286B24' THEN '10:00AM Eastern (Sunday)'
        WHEN ach.ENVELOPEJOBNAME='B7630B18' THEN '05:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B7630B19' THEN '12:01AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B8960BI1' THEN '08:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B8960BI2' THEN '01:00AM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9109BI1' THEN '10:00AM Eastern (Sunday)'
        WHEN ach.ENVELOPEJOBNAME='B9109BI2' THEN '07:30PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9109BI3' THEN '10:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9264B19' THEN '07:00PM Eastern (Sunday)'
        WHEN ach.ENVELOPEJOBNAME='B9264B20' THEN '06:00PM Eastern'
        WHEN ach.ENVELOPEJOBNAME='B9264B21' THEN '08:00PM Eastern'                                                
        WHEN ach.ENVELOPEJOBNAME='B9264B22' THEN '12:01PM Eastern'
    END                              
;
--== Debugging TSYS dates ==---
SELECT 
    REFERENCE_NUMBER,
    EFFECTIVE_DATE,
    PROCESSING_DATE,
    ENVELOPEFILEDATE,
    * 
FROM 
    BISME.ACHDetailFile_TSYS 
WHERE 
    EFFECTIVE_DATE='2020-05-26' 
    AND ACCOUNT_NUMBER='3286000000549659' 
    AND RIGHT(REFERENCE_NUMBER,15) ='000090001430002' 
 
--== Don't remeber what's below here ==---    
SELECT 
    EFFECTIVE_DATE                      "DateTransmit",
    ACCOUNT_NUMBER                      "MerchantNumber",
    ABS(AMOUNT)                         "Amount",
    CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'DP'
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END                                 "AmountDirection",
    RIGHT(REFERENCE_NUMBER,15)          "TraceNumber",
    ROUTING_NUMBER                      "MerchantRouteNbr",
    RIGHT(DDANUMBERLAST25PCT,5)         "MerchantAccountNbr",
    DDA_NUMBER                          "MerchantAccountNbrHash",
    LEFT(TRANSACTION_TYPES,3)           "TransactionCode",
    NULL                                "FileIdModifier",
    PROCESSING_DATE                     "DateFileCreation",
    *
FROM 
    BISME.ACHDetailFile_TSYS 
WHERE
    --ERROR: Duplicate key values: 'DateTransmit=2020-04-27,MerchantNumber=3286000000244202,TraceNumber=000000000000000,Amount=0.1000,AmountDirection=WD'
    --DateTransmit=2020-04-27,MerchantNumber=3286000000570804,TraceNumber=000090001010001,Amount=0.0100,AmountDirection=WD
    EFFECTIVE_DATE='2020-04-27'
    AND ACCOUNT_NUMBER=3286000000570804
    and RIGHT(REFERENCE_NUMBER,15)='000090001010001'
    AND Amount=0.0100
    AND     CASE 
        WHEN DEBIT_OR_CREDIT_INDICATOR='C' THEN 'WD'
        WHEN DEBIT_OR_CREDIT_INDICATOR='D' THEN 'DP'
        ELSE LEFT(DEBIT_OR_CREDIT_INDICATOR,2)
    END='WD'
LIMIT
    500
;
SELECT * FROM BISME.ACHDetailFile_TSYS WHERE ACCOUNT_NUMBER IN ('220673668','3286000000027144') LIMIT 500
;
SELECT 
    *
FROM
    BISME.DFM_LocationBankDepositsSummary013_North
WHERE
    FUNDED_DATE='2019-12-22'
    AND LOCATION_ID='444248376881'
;
---== Run on vertica.edl2.prod.paysafe.cloud ==---
-- Hash is sometimes 133 and other times, 134.  Is that expected?
SELECT LENGTH(DDA_NUMBER), DDA_NUMBER, * FROM BISME.DFM_LocationBankDepositsSummary013_North LIMIT 5
;
-- Hash is 50.  Why doesn't it match the length of the DDA_NUMBER above?
SELECT LENGTH(DDA_GL_SAVINGS),DDA_GL_SAVINGS,* FROM BISME.SD077_Omaha LIMIT 5
;

--'DateACH=2020-03-23,MerchantNumber=5428141601013947,TraceNumber=113008460014986' -- violates constraint 'v_temp_schema.Settlement.PK'
---== DUPLICATES! Run on vertica.edl2.prod.paysafe.cloud ==---
SELECT 
    *
FROM 
    BISME.SD077_Omaha
WHERE    
    TRANSMISSION_DATE='23-MAR-2020'
    --AND ACCOUNT_NUMBER='5428141601013947'
    AND TRACE_NUMBER='113008460014986'
;    

;    
SELECT
    AMOUNT_TYPE_CODE,
    CASE 
        WHEN AMOUNT_TYPE_CODE='D' THEN 'Diverted funds'
        WHEN AMOUNT_TYPE_CODE='F' THEN 'Remitted to AdvanceMe, Inc. (AMI) for merchant alternative funding'
        WHEN AMOUNT_TYPE_CODE='R' THEN 'Merchant reserve'
        WHEN AMOUNT_TYPE_CODE='T' THEN 'Trust fund'
        WHEN AMOUNT_TYPE_CODE='W' THEN 'Backup withholding'
        WHEN AMOUNT_TYPE_CODE='O' THEN 'Funds advance' --This is when a merchant is contracted with a third party cash advance provider that is taking their split of the funds. This generally effects merchant ACH reconciliation as far as settlement is concerned.
        WHEN AMOUNT_TYPE_CODE='P' THEN 'Funds diverted to collections' --This is when a merchant is contracted with a third party cash advance provider that is taking their split of the funds. This generally effects merchant ACH reconciliation as far as settlement is concerned.
  
        WHEN AMOUNT_TYPE_CODE IS NULL THEN ''
        ELSE 'Unknown'
    END AMOUNT_TYPE_DESC,
    TRN_CDE,
    CASE
        WHEN TRN_CDE='22' THEN 'Automatic deposit crediting the checking account'
        WHEN TRN_CDE='23' THEN 'Automatic deposit prenote'
        WHEN TRN_CDE='27' THEN 'Automatic payment debiting the checking account'
        WHEN TRN_CDE='28' THEN 'Automatic payment prenote'
        WHEN TRN_CDE='32' THEN 'Automatic deposit crediting the savings account'
        WHEN TRN_CDE='33' THEN 'Automatic savings deposit prenote'
        WHEN TRN_CDE='37' THEN 'Automatic payment debiting the savings account'
        WHEN TRN_CDE='38' THEN 'Automatic savings payment prenotet'
        WHEN TRN_CDE='42' THEN 'Automatic deposit crediting the general ledger account'
        WHEN TRN_CDE='47' THEN 'Automatic payment debiting the general ledger account'
        ELSE 'Unknown'
    END TRN_CDE_DESC,
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN 'DEPOSIT TO MERCHANT'  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN 'WITHDRAWAL FROM MERCHANT'
        ELSE 'Unknown'
    END FEE_DIRECTION,
    SUM(CAST(AMOUNT AS MONEY)) AMOUNT
FROM 
    BISME.SD077_Omaha
WHERE
    OFFSET_DLY_ADV_SYSTEMID IS NULL 
    --AND AMOUNT_TYPE_CODE='R' --P, O, W, (null), R
GROUP BY
    AMOUNT_TYPE_CODE,
    CASE 
        WHEN AMOUNT_TYPE_CODE='D' THEN 'Diverted funds'
        WHEN AMOUNT_TYPE_CODE='F' THEN 'Remitted to AdvanceMe, Inc. (AMI) for merchant alternative funding'
        WHEN AMOUNT_TYPE_CODE='R' THEN 'Merchant reserve'
        WHEN AMOUNT_TYPE_CODE='T' THEN 'Trust fund'
        WHEN AMOUNT_TYPE_CODE='W' THEN 'Backup withholding'
        WHEN AMOUNT_TYPE_CODE IS NULL THEN ''
        ELSE 'Unknown'
    END ,
    TRN_CDE,
    CASE
        WHEN TRN_CDE='22' THEN 'Automatic deposit crediting the checking account'
        WHEN TRN_CDE='23' THEN 'Automatic deposit prenote'
        WHEN TRN_CDE='27' THEN 'Automatic payment debiting the checking account'
        WHEN TRN_CDE='28' THEN 'Automatic payment prenote'
        WHEN TRN_CDE='32' THEN 'Automatic deposit crediting the savings account'
        WHEN TRN_CDE='33' THEN 'Automatic savings deposit prenote'
        WHEN TRN_CDE='37' THEN 'Automatic payment debiting the savings account'
        WHEN TRN_CDE='38' THEN 'Automatic savings payment prenotet'
        WHEN TRN_CDE='42' THEN 'Automatic deposit crediting the general ledger account'
        WHEN TRN_CDE='47' THEN 'Automatic payment debiting the general ledger account'
        ELSE 'Unknown'
    END ,
    CASE 
        WHEN TRN_CDE IN ('22','32','42') THEN 'DEPOSIT TO MERCHANT'  --42 is likely cash advance merchant
        WHEN TRN_CDE IN ('27','37') THEN 'WITHDRAWAL FROM MERCHANT'
        ELSE 'Unknown'
    END 
/*
Valid codes for merchant ACH items:
22 - Automatic deposit crediting the checking account
23 - Automatic deposit prenote
27 - Automatic payment debiting the checking account
28 - Automatic payment prenote
32 - Automatic deposit crediting the savings account
33 - Automatic savings deposit prenote
37 - Automatic payment debiting the savings account
38 - Automatic savings payment prenote
42 - Automatic deposit crediting the general ledger account
47 - Automatic payment debiting the general ledger account
*/
;
SELECT 
    ACCOUNT_NUMBER,
    COUNT(DISTINCT TR_NUMBER)

FROM 
    BISME.SD077_Omaha
WHERE
    OFFSET_DLY_ADV_SYSTEMID IS NULL 
    --AND TRN_CDE='42'
    --AND AMOUNT_TYPE_CODE='P' --P
    AND ENVELOPEBUSINESSLOCATION = 'Westlake' --('Dallas/Houston/Irvine','Westlake')
    --AND ACCOUNT_NUMBER='4765795103039360'
    --AND TRACE_NUMBER='121000240000050'
    --AND AMOUNT='25.00'
    AND SYSTEM_NUMBER || PRIN_NUMBER != '53784900'

GROUP BY
    ACCOUNT_NUMBER
ORDER BY
    COUNT(DISTINCT TR_NUMBER) DESC
;
SELECT
    TRANSMISSION_DATE-FC_DATE , 
    FC_DATE,
    TRANSMISSION_DATE,
    ID,
    AMOUNT_TYPE_CODE,
    * 
FROM 
    BISME.SD077_Omaha 
WHERE 
    --FC_DATE<TRANSMISSION_DATE 
    --ID NOT IN ('G','H','B') --ID is always G or H or B
    --AMOUNT_TYPE_CODE NOT IN ('R','O','W','P','D')
    --OFFSET_DLY_ADV_AMOUNT>0
    --TRN_CDE IS NOT NULL
    --AND AMOUNT <> 0
    LEFT(TR_NUMBER,1)='0'
ORDER BY  
    FC_DATE-TRANSMISSION_DATE 
LIMIT 
    500
;
SELECT
    TRN_CDE,
    count(*),
    sum(AMOUNT)
FROM 
    BISME.SD077_Omaha 
GROUP BY
    TRN_CDE
;
SELECT
    *
FROM 
    BISME.SD077_Omaha 
WHERE
    --OFFSET_DLY_ADV_TRACE_NUMBER='113008460011804' ---22.91
    FC_DATE = '21-FEB-2020'
    AND AMOUNT=22.91
    --TRACE_NUMBER='113008460011804'
LIMIT
    2
;
SELECT
    *
FROM 
    BISME.SD077_Omaha 
WHERE
    OFFSET_DLY_ADV_TRACE_NUMBER='113008460011804'
LIMIT
    2
;    

    