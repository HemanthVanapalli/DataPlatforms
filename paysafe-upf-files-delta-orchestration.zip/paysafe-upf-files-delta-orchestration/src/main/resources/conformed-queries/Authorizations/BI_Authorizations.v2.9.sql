------------------------------------------------------------------------------------------------------------------------------------------------
-- This is the (6) Authorizations "Conformed" Tables - FDR (Fiserv) Omaha (4) and North (1) and TSYS (1) Tables...
-- Version 2.9  [2021-10-05]
--
-- (1) BISME.AW107_Omaha ( 7.7% [#] / 10.2% [$])  - Weekly Omaha back end, Nashville front end?
-- (2)*BISME.AW169_Omaha ( 1.1% [#] /  0.9% [$])  - Weekly Omaha back end, North front end?  *NO MANUAL AVAILABLE
-- (3) BISME.MD027_Omaha (23.6% [#] / 31.2% [$]) - Daily Omaha back end, Omaha front end (Still in DEV with Aperia) *** BIGEST ***
-- (4) BISME.MD572_Omaha ( 1.2% [#] /  1.0% [$]) - Daily Omaha back end, Buypass front end
-- (5) BISME.DFM_AuthorizationDetails021_North (47.8% [#] / 32.2% [$]) - Daily North back end
-- (6) BISME.AuthorizationDetailFile_TSYS[ADF] (18.5% [#] / 24.5% [$]) - Daily TSYS Back end
--
--
-- 99.7% of the Decline Reason Codes have been mapped to a ISO Standard Description
--
------------------------------------------------------------------------------------------------------------------------------------------------
----> Issues/Changes:
--Received the "starting" SQL code from Vishal Patel
--SAD_FLAG - What are "AUTH" and "SUMM"? --> Filter on 'AUTH'. Done!  Details in Recording... https://web.microsoftstream.com/video/8f97892c-f692-40c5-9684-119a982d58ae  ["ONLINE" - Starting at 11 minutes in, "SAD_FLAG" - Starting at 13 minutes in] [Ends at 15:40]
--PRINT_DATE - What is this?  --> Bye, Bye PRINT_DATE
--Changed CAST of - TimestampTz to Timestamp. --> Done!
--Search for '!*!' to find other "NOTES" and make those changes requested by Geoff --> Done!
--Fix the BN Ref# --> Done!
--Need access ACCESSONE website. Contact Chris Thill, per Geoff.  --> 
--isIncremental (add this column?) --> Done!
--isPartialAuth (add this column?) --> Done!
--isReversed (yes, add this column) --> Done!
--Fix Card Exp fields (MM/DD or DD/MM)???  After looking at the data, advise that we don't touch it!
--Add isKeyed? --> Done!
--Add isChipRead? --> Done!
--Removed VisaCurrencyCode
--Add new column - isApproved with values 'Yes', 'No'
--Add new column - for DESCRIPTION (MD-027) "ProcessorExtraMsg"
--Fixed MD-027 RUN_DATE & RUN_TIME issue with bad formats: MM/DD and HH:MM
--Fixed MD-027 "in" to a "LIKE" for Description when checking for Partial Approvals
--Fix the TSYS "JOIN" using a formula for TD01_ECONNECTIONS_MERCHANT_NUMBER to MerchantNumber translation
--Add filter on AuthDate to be >= "2021-03-01" (01-MAR-21)
--Added field AUTHZR_CODE / DebitNetworkID (CASE Statement) to the MD-572
--Added the remaining hard-coded TSYS Account#s to the CASE (JOIN) statement and reduced the other "special" logic to only values are are used
--Change column name 'TableX' to 'SourceReport'
--Updated the DFM-021 Auth (Decline) Response Codes after meeting with Fiserv (Jay)
--Added '09','81','83','85' POS ENTRY MODE to AW-169 isKeyed (Yes) list, using data from the isChipRead data
--Fix TransactionDateTime column on AW-169 - DATE to TIMESTAMP CASTing wasn't working correctly
--Add missing POS ENTRY MODE values for POSEntryMsg on MD-572 (10,79,80,82,83,85)
--Rename the column PaysafeTransactionID to PaysafeAuthID --> Done!
--Revised CASE logic for SalesAmountAuth on MD-572 section when 'Authorization'
--Modified the CardSchemeCode CASE statement for TSYS (adfTSYS). Simplified it after talking with Geoff
--Added new CASE statement to drive the DebitCreditCode by using the CD_TP (CardSchemeCode) value on AW-107
--Added new CASE statement to drive the DebitCreditCode by using the CARD_TYPE (CardSchemeCode) value on DFM-021
--Added new CASE statement to drive the DebitCreditCode by using the TD01_NETWORK_ID value on TSYS (adfTSYS)
--Change the SourceReport to UPPPERCASE and "-" dashes added?
--Added Geoff's MD-027 CardSchemeCode "solution" and will be testing...
--Added new column - StatementDate from the FC_DATE or equal
--Refined the DISC (JCB/Diners) / AMEX TID capture in MD-027 report
--Changed 'AD-021' to 'DFM-021' on this North report
--Moved all 'Processor...' columns to the "SME info" area
--After further Research/Comparing the TransactionDate vs. AuthorizationDate on all reports and consulting with Geoff, removing Transaction Date was decided
--Implemented the isIncremental column value on DFM-021 per Geoff
--Removed - isIncremental, isPartialAuth, CVVResultCode, per Geoff (using spreadsheet)
--Removed - DebitCreditCode, per Geoff (using spreasheet). Not reliable data
--Add 2 new columns to support the DE39 Lookup tablex - AuthResponseCode and AuthResponseDescription		
--Rename: TransEntryAuthCode to TransEntryAuthAccessMode
--Fixed 1 entry of the POSEntryMsg field to be upper-case
--Fixed 3 columns that were varchar(1)
--Combined - AuthResponseMsg and ProcessorExtraMsg
--Add separate SQL: UPDATE for AUTH RESPONSE CODE (table of Description) Visa ISO 8583 standard
--Rename AuthResponseCode to ProcessorResponseCode and then have a NEW AuthResponseCode
--Breakout the MD-572 BUYPASS 2-character Declined Code and put into the ProcessorResponseCode
--Reduced the number of TSYS "missing" or NULL MerchantNumber from 2,356 to 2,068 by adding '14' to the '3286' logic and commented out the '5428' logic
--Only 2 reports (MD-572 and TSS-ADF) provide the MCC.  The others come from the BI.MerchantDemographics table
--Added '78' to the '3286' logic for TSYS, as I found more MIDs that weren't being constructed correctly.  Added 4 additional hard-coded MIDs also
--Added filter to AW-107 to skip records that - RESP=NULL
--Review: AuthorizationType --> Waiting on Geoff
--Modified the ProcessorExtraMsg to have the RAW (usually Declined) messages move here, rather than setting 'Approved' and 'Declined'
--Moved the ProcessorResponseCode column further out (down)
--Fixed REGEX issue "Integer" resolved by "VARCHAR" encasement
--Fixed the truncated '0' (zeroes) caused by the REGEX_REPLACE statement
--Move CardExpDate to after CardLast4
--Move isApproved to after AuthType
--Move 4 Dates (AuthDateTime,ProcessorRunDate,ProcessorRunDateTime,StatementDate) to just before the AuthPlatform
--Move AuthResponseCode and AuthResponseDescription to after the CardExpDate
--
--  ^ ^ ^                      ^ ^ ^
--  | | | ...PRE-PRODUCTION... | | |
--
--
--Version 2.9  [2021-10-05]
--  Added a CASE statement on RESPONSE_CODE in the AW-169 Report to default the 'DECL' and 'REF' to '05' and '01' respectfully, since the Processor does not send any Auth Response Codes
--  Extended the existing CASE statement on RESP in the AW-107 Report to default the 'EXPL', 'REF' and 'T.O.' to '054', '001' and '096' respectfully, since the Processor does not send any Auth Response Codes when these 3 values are retruned
--	Use table: ppbisandbox.jmoeller_AuthResponseDescriptions_2021_10_04 for the AuthResponseCode "lookup"
--



----> ToDo:


----> Questions:
--How far back can an Authorization record be supplied/loaded from a recent Processor file (e.g. Today's file is provided, but an Authorization is included that is dated many months ago)?
--



/*
DROP TABLE IF EXISTS ppbisandbox.jmoeller_A27_Staging
;
*/

/*
DROP TABLE IF EXISTS ppbisandbox.jmoeller_AuthorizationsBeta
;
ALTER TABLE ppbisandbox.jmoeller_A27_Staging RENAME TO jmoeller_AuthorizationsBeta
;
GRANT SELECT ON TABLE ppbisandbox.jmoeller_AuthorizationsBeta TO verticappbisandbox
;
GRANT UPDATE ON TABLE ppbisandbox.jmoeller_AuthorizationsBeta TO geoffreymillikan
;
*/


/*****************************************************************************************
 *   Fiserv Omaha AW107 Authorization Card Transactions (Authorization Conform Tables)   *
 *    All Cards                                                                          *
 *****************************************************************************************/
SELECT
	*
INTO
	ppbisandbox.jmoeller_A27_Staging
FROM
(
  (
	SELECT
		CAST(AUTH_DATE AS DATE)					AuthDate,					--Not MM/DD, as the manual says.  YYYY-MM-DD and earliest full date seems to start at: 2020-06-20
		rc.MerchantNumber          				MerchantNumber,
		md.DBA									DBA,
		CAST(
			CASE
				WHEN CD_TP IN ('VS')	THEN 'VISA'							--Visa
				WHEN CD_TP IN ('MC')	THEN 'MC'							--Mastercard
				WHEN CD_TP IN ('DR')	THEN 'DISC'							--Discover
				WHEN CD_TP IN ('DB')	THEN 'GPIN'							--Generic Debit (Debit Summary File) [Deluxe Debit Gateway] - PIN-Debit!
				WHEN CD_TP IN ('EB')	THEN 'EBT'							--EBT (Tape Only) [Electronic Benefits Transfer]
				WHEN CD_TP IN ('AO')	THEN 'ONE'							--American Express OnePoint
				WHEN CD_TP IN ('AX')	THEN 'AMEX'							--American Express Pass-through - AMEX
				WHEN CD_TP IN ('WE')	THEN 'WEX'							--WEX Wright Express [Non-Funded] (or 'WAM')???
				ELSE LEFT(CD_TP,4)
			END
		AS VARCHAR(4))							CardSchemeCode,
		CASE
			WHEN PR_CD IN ('SL') THEN 'Sale'								--Credit Card Sale (-Card, +Merch)
			WHEN PR_CD IN ('CR') THEN 'Return'								--Return of Goods (+Card, -Merch)
			WHEN PR_CD IN ('CA') THEN 'CashAdvance'							--Cash Advance from Card (-Card, +Merch)
			ELSE PR_CD
		END                       				AuthType,
		CASE
			WHEN RESP IN ('APPR')								THEN 'Yes'
			WHEN RESP LIKE 'D%' OR RESP IN ('EXP','REF','T.O.') THEN 'No'
			ELSE RESP														--There are NULLs, but I have filtered them out.  'APPR' - The transaction was approved. 'DECL' - The transaction was declined. 'ECOM' � Debit Communication Problem. 'EPIN'  - Invalid PIN Entry. 'EXP' CARD � The PAN is past the Expiration Date. 'REF' - The transaction was referred to the issuer for approval. 'RPIN' - Invalid PIN Retry. 'T.O.' - There was a disconnect (Time Out) between the Terminal and the Front End Switch
		END                       				isApproved,
		CASE WHEN PR_CD NOT IN ('CR')	THEN CAST(ZEROIFNULL(AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END SalesAmountAuth,	--'SL','CA' = Sales
		CASE WHEN PR_CD		IN ('CR')	THEN CAST(ZEROIFNULL(AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END ReturnsAmountAuth,	--'CR' = Returns
		--Authorizations - Sale goes in the SalesAmountAuth, includes all Declines, Expired, Referred, TimeOut. Must attempt to go out for Authorizations
		--Authorizations - Returns goes in the ReturnsAmountAuth, includes all Declines, Expired, Referred, TimeOut. Must attempt to go out for Authorizations
		AUTH_CODE			                  	AuthCode,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b'))<>6 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(6)), 6, '0') END
												CardFirst6,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDNUMBERLAST4, '[^0-9]', '', 1, 0, 'b'))<>4 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDNUMBERLAST4, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(4)), 4, '0') END
												CardLast4,
		EXP_DATE                   				CardExpDate,				--MM/YY
		CAST(NULL AS VARCHAR(3))				AuthResponseCode,			--ISO-8583 (DE39) Standard (Decline) Auth Response Code
		CAST(NULL AS VARCHAR(255))				AuthResponseDescription,	--ISO-8583 (DE39) Standard (Decline) Auth Response Description		
		CASE
			WHEN DT_SC IN ('1','2') THEN 'No'								--Track 1 & 2 was read (Swiped)
			WHEN DT_SC IN ('M') 	THEN 'Yes'								--Keyed-In (NON-Swipe)
			ELSE NULL
		END										isKeyed,
		NULL									isChipRead,
		CAST(NULL AS VARCHAR(3))				isReversed,					--Added now for the future usage - per Geoff
		ACI                        				ACI,						--Visa Authorization Characteristic Indicator
		NULL									ValidationCode,
		NULL									VisaTranID,
		NULL									MastercardRefNumber,
		NULL									AmexRefNumber,
		NULL									DiscoverNetworkRefID,
		NULL									AVSResponse,
		NULL									CVV2ResultCode,
		NULL									CAVVResultCode,
		NULL									UCAFSupportCode,
		NULL									CardProductID,				--Visa Card Product ID and MasterCard Product ID
		CAST(AUTHORIZATIONDATETIME AS TIMESTAMP) AuthDateTime,
		CAST(RUN_DATE AS DATE)                  ProcessorRunDate,
		CAST(RUNDATETIME AS TIMESTAMP)			ProcessorRunDateTime,
		CAST(FC_DATE AS DATE)					StatementDate,
        --START of lesser priority Columns - Mostly SME info ----------------------------------------------------------------------------------------------------------------
		CASE
			WHEN ENVELOPEPROCESSORPLATFORM = 'Omaha' THEN 'OMA'
			ELSE ENVELOPEPROCESSORPLATFORM
		END										AuthPlatform,				--Processor Platform Name: 'OMA' Fiserv (FDR) Omaha
		CAST(CD_TP AS VARCHAR(6))				ProcessorCardScheme,
		PR_CD									ProcessorAuthType,
		CAST(ZEROIFNULL(AMOUNT) AS MONEY)		ProcessorAmount,			--This is only 'AMOUNT'  <sigh...>
--		CASE
--			WHEN RESP IN ('APPR') 	THEN 'Approved'							-- *** PUT RAW RESP IN HERE! (per Geoff)
--			WHEN RESP LIKE 'D%' 	THEN 'Declined'
--			WHEN RESP IN ('EXP') 	THEN 'Expired'
--			WHEN RESP IN ('REF') 	THEN 'Referred'
--			WHEN RESP IN ('T.O.') 	THEN 'TimeOut'
--			ELSE RESP														--There are NULLs
--		END										ProcessorExtraMsg,
		CAST(RESP AS VARCHAR(255))				ProcessorExtraMsg,
		CASE
			WHEN RESP LIKE 'D%'		THEN SUBSTRING(RESP,2,3)
			WHEN RESP IN ('EXP')	THEN '054'								--Use default of '54' - Expired Card
			WHEN RESP IN ('REF')	THEN '001'								--Use default of '01' - Call Issuer
			WHEN RESP IN ('T.O.')	THEN '096'								--Use default of '96' - System Error
		END                       				ProcessorResponseCode,		--Declined Response Code seems to be the last 2 digits here, but there are mostly 3 digit numbers. Amex Declines are >= '100'.  The RESP values of 'EXP', 'REF' and 'T.O.' do not come with a Numeric Auth Response Code so we have to default them
		CASE
			WHEN DT_SC IN ('1') THEN 'MAG Stripe Read - T1'					--Track 1 was read (Swiped)
			WHEN DT_SC IN ('2') THEN 'MAG Stripe Read - T2'					--Track 2 was read (Swiped)
			WHEN DT_SC IN ('M') THEN 'Manual Key Entry'						--Keyed-In (NON-Swipe)
			ELSE DT_SC
		END										POSEntryMsg,
		DT_SC									POSEntryMode,
		NULL									EComInd,
		NULL									PreOrFinalAuth,
		NULL									ForeignFrontEndMID,
		md.MCC									MCC,						--The MCC is provided by the BI.MerchantDemographics table on this report AW-107
		NULL									TransTraceAuditNumber,
		NULL									TransEntryAuthAccessMode,
		NULL									HostInterfaceSystemCode,
		NULL									HostCPUIndCode,
		NULL									HowSentToFiserv,
		NULL									BatchSequence,
		NULL									BatchCutOff,
		NULL									BatchTypeETC,
--		CASE
--			WHEN TRANS_TYPE IN ('ADD')		THEN 'Offline'					--'ADD' Offline transaction
--			WHEN TRANS_TYPE IN ('DB ORIG')	THEN 'DB ORIG'					--'DB ORIG' Don't know!!!
--			WHEN TRANS_TYPE IN ('DB SUBS')	THEN 'DB SUBS'					--'DB SUBS' Don't know!!!
--			WHEN TRANS_TYPE IN ('DEL ADD')	THEN 'Deleted Offline'			--'DEL ADD' Deleted offline transaction
--			WHEN TRANS_TYPE IN ('DEL ONL')	THEN 'Deleted Online'			--'DEL ONL' Deleted online transaction
--			WHEN TRANS_TYPE IN ('ONLINE')	THEN 'Online'					--'ONLINE' Online transaction - (*Typically Authorizations)
--			WHEN TRANS_TYPE IN ('UNPOST')	THEN 'UNPOST'					--'UNPOST' Don't know!!!
--			WHEN TRANS_TYPE IN ('VOID')		THEN 'VOID'						--'VOID' Don't know!!! Other than the obvious
--			ELSE TRANS_TYPE
--		END										TransactionOriginationType,
		NULL									CreditVoucherCode,
		CAST(NULL AS MONEY)						SurchargeAmount,
		CAST(NULL AS MONEY)						CashbackAmount,
		NULL									StarSignatureDebit,
		NULL									DebitNetworkID,
		CAST(NULL AS MONEY)						DebitNetworkFee,
		NULL									PINEntryCapability,
		NULL									PINCaptureCapability,
		NULL									PINVerification,
--		CASE
--			WHEN CD_TP IN ('VS','MC','DR','AO','AX','WE')	THEN 'CreditCard'
--			WHEN CD_TP IN ('DB','EB')						THEN 'DebitCard'
--			ELSE NULL
--		END                       				DebitCreditCode,
		NULL									RetrievalRefNumber,
		NULL									MarketSpecificIndicatorCode,
		NULL									TransCommType,
		NULL									StoreNumber,
		NULL									POSModelInfo,
		NULL									POSDataCode,
		NULL									CardSourceType,
		NULL									TSYSBINBankStore,
		ENVOY_TID                  				TerminalID,
		NULL									ExternalID,
		NULL									OrderNumber,
		INVOICE_NUMBER             				InvoiceNumber,
		'USD'									CurrencyCode,
		NULL									CardServiceCode,			--'101','201' from the Cards
		NULL									TransEncryptionType,
		NULL									AuthSecurityLevel,
		CARD_NUMBER                				CardFingerprint,
		'AW-107'								SourceReport,
		UUID_GENERATE()							PaysafeAuthID				--Unique ID assigned to each record (row)
	FROM BISME.AW107_Omaha aw107
		INNER JOIN BI.ReportingChannels rc ON (LEFT(aw107.MERCHANT_NUMBER,15)=LEFT(rc.MerchantNumber,15))
		LEFT JOIN BI.MerchantDemographics md ON (LEFT(aw107.MERCHANT_NUMBER,15)=LEFT(md.MerchantNumber,15))
	WHERE
--		AUTH_DATE >= '2021-06-01' AND AUTH_DATE <= '2021-06-30' AND
		SAD_FLAG IN ('AUTH','SUMM')											--Possible values: 'AUTH' - Authorization-only, 'SUMM' - Summarized.
		AND TRANS_TYPE='ONLINE'												--Assumed that it must be "ONLINE" to be a real-time Authorization (AuthOnly or Sale/Return)
		AND RESP IS NOT NULL												--NULL value (or <blank>) per Blake is an offline transaction and not an Authorization that went "out the door"
		AND AUTH_DATE >= '2021-03-01'
--	LIMIT 100   

) UNION ALL (

/*****************************************************************************************
 *   Fiserv Omaha AW169 Authorization Card Transactions (Authorization Conform Tables)   *
 *    All Cards                                                                          *
 *****************************************************************************************/
	SELECT
		CAST(AUTHORIZATION_DATE AS DATE)		AuthDate,
		rc.MerchantNumber          				MerchantNumber,
		md.DBA									DBA,
		CAST(
			CASE
				WHEN CARD_TYPE IN ('VI')	THEN 'VISA'						--Visa
				WHEN CARD_TYPE IN ('MC')	THEN 'MC'						--Mastercard
				WHEN CARD_TYPE IN ('DS')	THEN 'DISC'						--Discover
				WHEN CARD_TYPE IN ('DB')	THEN 'GPIN'						--Generic Debit (Debit Summary File) 
				WHEN CARD_TYPE IN ('EB')	THEN 'EBT'						--EBT (Tape Only)
				WHEN CARD_TYPE IN ('AX')	THEN 'AMEX'						--American Express Pass-through
				ELSE LEFT(CARD_TYPE,4)
			END
		AS VARCHAR(4))							CardSchemeCode,
		CASE
			WHEN TRANSACTION_TYPE IN ('PURC') 	THEN 'Sale'					--Credit Card "Purchase"?
			WHEN TRANSACTION_TYPE IN ('DPUR') 	THEN 'Sale'					--*(DB) Debit Card "Purchase" --> *ONLY CARD_TYPE='DB' use this!
			WHEN TRANSACTION_TYPE IN ('DRFD') 	THEN 'Sale'					--*(DB) Deferred? --> *ONLY CARD_TYPE='DB' use this!
			WHEN TRANSACTION_TYPE IN ('DCSH') 	THEN 'CashAdvance'			--*(DB) Debit Card Cash Advance --> *ONLY CARD_TYPE='DB' use this!
			WHEN TRANSACTION_TYPE IN ('ECB') 	THEN 'Sale'					--*(EB) European Central Bank? --> ONLY CARD_TYPE='EB' use this!
			WHEN TRANSACTION_TYPE IN ('EFS') 	THEN 'Sale'					--*(EB) Electronic Filing and Service? --> ONLY CARD_TYPE='EB' use this!
			WHEN TRANSACTION_TYPE IN ('REV') 	THEN 'Reversal'				--"Reversal"? --> ALL CARD_TYPEs use this!
			ELSE TRANSACTION_TYPE
		END                       				AuthType,					--Credit Card Sale (-Card, +Merch)  --Return of Goods (+Card, -Merch)  --Cash Advance from Card (-Card, +Merch)
		CASE
			WHEN RESPONSE_CODE IN ('APPR')		 THEN 'Yes'
			WHEN RESPONSE_CODE IN ('DECL','REF') THEN 'No'
			ELSE RESPONSE_CODE
		END										isApproved,
		CASE WHEN TRANSACTION_TYPE NOT	IN ('REV')	THEN CAST(ZEROIFNULL(TRANSACTION_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END SalesAmountAuth,	--'' = Sales
		CASE WHEN TRANSACTION_TYPE 		IN ('REV')	THEN CAST(ZEROIFNULL(TRANSACTION_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END ReturnsAmountAuth,	--'' = Returns - No way to determined this, as there are no 'RETURNS', so just 'REV' Reversals for now
		APPROVAL_CODE							AuthCode,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b'))<>6 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(6)), 6, '0') END
												CardFirst6,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDNUMBERLAST4, '[^0-9]', '', 1, 0, 'b'))<>4 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDNUMBERLAST4, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(4)), 4, '0') END
												CardLast4,
		CARD_EXPIRATION_DATE       				CardExpDate,
		CAST(NULL AS VARCHAR(3))				AuthResponseCode,			--ISO-8583 (DE39) Standard (Decline) Auth Response Code
		CAST(NULL AS VARCHAR(255))				AuthResponseDescription,	--ISO-8583 (DE39) Standard (Decline) Auth Response Description		
		CASE
			WHEN ENTRY_MODE IN ('02','05','06','07','09','80','83','85','90','91','95')	THEN 'No'
			WHEN ENTRY_MODE IN ('00','01','10','79','81','96')							THEN 'Yes'
			ELSE NULL
		END										isKeyed,
		CASE
    		WHEN ENTRY_MODE IN ('05','07','09','83','85','95')	THEN 'Yes'
			ELSE 'No'
		END										isChipRead,
		CAST(NULL AS VARCHAR(3))				isReversed,					--Added now for the future usage - per Geoff
		ACI_VALUE_RETURNED         				ACI,						--Visa Authorization Characteristic Indicator
		NULL									ValidationCode,
		NULL									VisaTranID,
		NULL									MastercardRefNumber,
		NULL									AmexRefNumber,
		NULL									DiscoverNetworkRefID,
		NULL									AVSResponse,
		NULL									CVV2ResultCode,
		NULL									CAVVResultCode,
		NULL									UCAFSupportCode,
		NULL									CardProductID,				--Visa Card Product ID and MasterCard Product ID
		CAST(AUTHORIZATIONDATETIME AS TIMESTAMP) AuthDateTime,
		CAST(RUN_DATE AS DATE)                  ProcessorRunDate,
		CAST(RUNDATETIME AS Timestamp)			ProcessorRunDateTime,
		CAST(FC_DATE AS DATE)					StatementDate,
        --START of lesser priority Columns - Mostly SME info ----------------------------------------------------------------------------------------------------------------
		CASE
			WHEN ENVELOPEPROCESSORPLATFORM = 'Omaha' THEN 'OMA'
			ELSE ENVELOPEPROCESSORPLATFORM
		END										AuthPlatform,				--Processor Platform Name: 'OMA' Fiserv (FDR) Omaha
		CAST(CARD_TYPE AS VARCHAR(6))			ProcessorCardScheme,
		TRANSACTION_TYPE						ProcessorAuthType,
		CAST(ZEROIFNULL(TRANSACTION_AMOUNT) AS MONEY) ProcessorAmount,
--		CASE
--			WHEN RESPONSE_CODE IN ('APPR')	THEN 'Approved'
--			WHEN RESPONSE_CODE IN ('DECL') 	THEN 'Declined'
--			WHEN RESPONSE_CODE IN ('REF')	THEN 'Referred'					--Call Referral
--			ELSE RESPONSE_CODE
--		END										ProcessorExtraMsg,
		CAST(RESPONSE_CODE AS VARCHAR(255))		ProcessorExtraMsg,
		CASE
			WHEN RESPONSE_CODE NOT IN ('APPR')	THEN
				CASE
					WHEN RESPONSE_CODE IN ('DECL')	THEN '05'				--Use default of '05' - Do Not Honor
					WHEN RESPONSE_CODE IN ('REF')	THEN '01'				--Use default of '01' - Call Issuer
					ELSE RESPONSE_CODE
				END
		END										ProcessorResponseCode,		--Since the Processor doesn't send an Auth Response Code, we create a default
		CASE
			WHEN ENTRY_MODE IN ('00') THEN 'Unknown'
			WHEN ENTRY_MODE IN ('01') THEN 'Manual Key Entry'
			WHEN ENTRY_MODE IN ('02') THEN 'MAG Stripe Read'
			WHEN ENTRY_MODE IN ('05') THEN 'Chip Card Read'
			WHEN ENTRY_MODE IN ('07') THEN 'Contactless Payment'
			WHEN ENTRY_MODE IN ('81') THEN 'Manual Key Entry E-Commerce'
			WHEN ENTRY_MODE IN ('90') THEN 'MAG Stripe Read (Full Unaltered)'
			WHEN ENTRY_MODE IN ('91') THEN 'Contactless - MAG Stripe Rules'
			WHEN ENTRY_MODE IN ('95') THEN 'Chip Card Read - No CVV'
		END										POSEntryMsg,
		ENTRY_MODE								POSEntryMode,
		NULL									EComInd,
		NULL									PreOrFinalAuth,		
		NULL									ForeignFrontEndMID,
		md.MCC									MCC,						--The MCC is provided by the BI.MerchantDemographics table on this report AW-169
		NULL									TransTraceAuditNumber,
		NULL									TransEntryAuthAccessMode,
		NULL									HostInterfaceSystemCode,
		NULL									HostCPUIndCode,
		NULL									HowSentToFiserv,
		NULL									BatchSequence,
		NULL									BatchCutOff,
		NULL									BatchTypeETC,		
		NULL									CreditVoucherCode,		
		CAST(NULL AS MONEY)						SurchargeAmount,		
		CAST(NULL AS MONEY)						CashbackAmount,
		NULL									StarSignatureDebit,		
		NULL									DebitNetworkID,		
		CAST(NULL AS MONEY)						DebitNetworkFee,
		NULL									PINEntryCapability,
		NULL									PINCaptureCapability,
		NULL									PINVerification,
--		CASE
--			WHEN TRANSACTION_TYPE IN ('PURC')		 THEN 'CreditCard'
--			WHEN TRANSACTION_TYPE IN ('DCSH','DPUR') THEN 'DebitCard'
--			WHEN TRANSACTION_TYPE IN ('ECB') 		 THEN 'DebitCard'		--'ECB' or "DebitCard' ??? Need an answer to this!
--			WHEN TRANSACTION_TYPE IN ('EFS') 		 THEN 'DebitCard'		--'EFS' or "DebitCard' ??? Need an answer to this!
--			ELSE TRANSACTION_TYPE
--		END                       				DebitCreditCode,
		NULL									RetrievalRefNumber,		
		NULL									MarketSpecificIndicatorCode,
		NULL									TransCommType,
		NULL									StoreNumber,
		NULL									POSModelInfo,
		NULL									POSDataCode,
		NULL									CardSourceType,
		NULL			          				TSYSBINBankStore,		
		TERMINAL_ID                				TerminalID,
		NULL									ExternalID,
		NULL									OrderNumber,
		NULL									InvoiceNumber,
		'USD'									CurrencyCode,
		NULL									CardServiceCode,
		NULL									TransEncryptionType,
		NULL									AuthSecurityLevel,
		CARD_NUMBER                				CardFingerprint,
		'AW-169'								SourceReport,
		UUID_GENERATE()							PaysafeAuthID				--Unique ID assigned to each record (row)
	FROM BISME.AW169_Omaha aw169
        INNER JOIN BI.ReportingChannels rc ON (LEFT(aw169.MERCHANT_NUMBER,15)=LEFT(rc.MerchantNumber,15))
		LEFT JOIN BI.MerchantDemographics md ON (LEFT(aw169.MERCHANT_NUMBER,15)=LEFT(md.MerchantNumber,15))
	WHERE
--		AUTHORIZATION_DATE >= '2021-06-01' AND AUTHORIZATION_DATE <= '2021-06-30' AND
		TRANSACTION_TYPE IN ('DCSH','DPUR','DRFD','ECB','EFS','PURC')
		AND AUTHORIZATION_DATE >= '2021-03-01'
--	LIMIT 100   

) UNION ALL (

/*****************************************************************************************
 *   Fiserv Omaha MD027 Authorization Card Transactions (Authorization Conform Tables)   *
 *    All Cards                                                                          *
 *****************************************************************************************/
	SELECT
		CASE
			WHEN SUBSTRING(TDATE,1,2) || '-' || SUBSTRING(TDATE,4,2) <= SUBSTRING(CAST(TO_DATE(MONTH(GETDATE()) || '/' || DAY(GETDATE()) || '/' || YEAR(GETDATE()), 'MM-DD-YYYY') AS Varchar(50)),6,5) THEN
				CAST(TO_DATE(TDATE || '/' || YEAR(GETDATE()),   'MM/DD/YYYY') AS DATE)
			ELSE
				CAST(TO_DATE(TDATE || '/' || YEAR(GETDATE())-1, 'MM/DD/YYYY') AS DATE)
		END										AuthDate,					--Inbound "TDATE" is in 'MM/DD' Format. Need to correct the Year 'YYYY' using the Current Date to decide to use THIS Year or LAST Year
		rc.MerchantNumber         				MerchantNumber,
		NAME 									DBA,
		CAST(
			CASE
			    WHEN CARDHOLDER_NUMBER_PREFIX='E' AND LEFT(ALINE,3) IN ('ZDG') AND DRD IS NULL 		THEN 'EBT'
			    WHEN CARDHOLDER_NUMBER_PREFIX='D' AND LEFT(ALINE,3) IN ('ZDG') AND DRD IS NOT NULL	THEN
			        CASE
			            -- DRD = The identifier of the network to which the First Data� Dynamic Routing Decision system routed the debit transaction
			            WHEN DRD='01' THEN 'ACCL'
			            WHEN DRD='02' THEN 'ACCL'
			            WHEN DRD='04' THEN 'ACCL'
			            WHEN DRD='05' THEN 'AFFN'
			            WHEN DRD='06' THEN 'AFFN'
			            WHEN DRD='07' THEN 'AKOP'
			            WHEN DRD='08' THEN 'AKOP'
			            WHEN DRD='09' THEN 'AKOP'
			            WHEN DRD='24' THEN 'CU24'
			            WHEN DRD='16' THEN 'CULI'
			            WHEN DRD='17' THEN 'CULI'
			            WHEN DRD='03' THEN 'EBT'
			            WHEN DRD='14' THEN 'EBT'
			            WHEN DRD='19' THEN 'EBT'
			            WHEN DRD='22' THEN 'EBT'
			            WHEN DRD='46' THEN 'EBT'
			            WHEN DRD='29' THEN 'IACT'
			            WHEN DRD='20' THEN 'ITLK'
			            WHEN DRD='25' THEN 'ITLK'
			            WHEN DRD='26' THEN 'ITLK'
			            WHEN DRD='56' THEN 'ITLK'
			            WHEN DRD='57' THEN 'ITLK'
			            WHEN DRD='27' THEN 'JEAN'
			            WHEN DRD='28' THEN 'JEAN'
			            WHEN DRD='55' THEN 'JEAN'
			            WHEN DRD='30' THEN 'MAES'
			            WHEN DRD='31' THEN 'MAES'
			            WHEN DRD='32' THEN 'MAES'
			            WHEN DRD='34' THEN 'NYCE'
			            WHEN DRD='35' THEN 'NYCE'
			            WHEN DRD='50' THEN 'NYCE'
			            WHEN DRD='13' THEN 'PULS'
			            WHEN DRD='36' THEN 'PULS'
			            WHEN DRD='37' THEN 'PULS'
			            WHEN DRD='51' THEN 'PULS'
			            WHEN DRD='38' THEN 'SHZM'
			            WHEN DRD='39' THEN 'STAR'
			            WHEN DRD='40' THEN 'STAR'
			            WHEN DRD='41' THEN 'STAR'
			            WHEN DRD='42' THEN 'STAR'
			            WHEN DRD='43' THEN 'STAR'
			            WHEN DRD='44' THEN 'STAR'
			            WHEN DRD='52' THEN 'STAR'
			            WHEN DRD='53' THEN 'STAR'
			            WHEN DRD='54' THEN 'STAR'
			            WHEN DRD='64' THEN 'STAR'
			            WHEN DRD='65' THEN 'STAR'
			            ELSE 'GPIN'
			        END
				WHEN CARDHOLDER_NUMBER_PREFIX='D' AND LEFT(ALINE,3) IN ('ZDG') AND DRD IS NULL THEN 'GPIN'
			    WHEN CARDHOLDER_NUMBER_PREFIX IS NULL AND LEFT(ALINE,3) IN ('BAS') THEN 'VISA'
			    WHEN CARDHOLDER_NUMBER_PREFIX IS NULL AND LEFT(ALINE,3) IN ('INA') THEN 'MC'
			    WHEN CARDHOLDER_NUMBER_PREFIX IS NULL AND LEFT(ALINE,3) IN ('ZAM') THEN 'AMEX'
			    WHEN CARDHOLDER_NUMBER_PREFIX IS NULL AND LEFT(ALINE,3) IN ('ZSS') THEN 'DISC'
			    ELSE 'OTHR'
			END
		AS VARCHAR(4))							CardSchemeCode,
		CASE
			WHEN TRANCD IN ('SALE')		THEN 'Sale'							--'SALE' - Authorization and sale/cash advance
			WHEN TRANCD IN ('P SALE')	THEN 'P SALE'						--'P SALE' - Pre-sale
			WHEN TRANCD IN ('RTRN') 	THEN 'Return'						--'RTRN' - Return
			WHEN TRANCD IN ('AUTH') 	THEN 'Sale'							--'AUTH' - Authorization (Sale)
			WHEN TRANCD IN ('CASH') 	THEN 'CashAdvance'					--'CASH' - ???  Not listed - How do CASHADVANCE RETURNS get handled ???
			WHEN TRANCD IN ('TKTO') 	THEN 'TKTO'							--'TKTO' - Ticket-only sale/cash advance
			WHEN TRANCD IN ('SALV') 	THEN 'SALV'							--'SALV' - Void request on a sale or an authorization/sale for ETC types 7 and B
			WHEN TRANCD IN ('AVOID') 	THEN 'AVOID'						--'AVOID' - Voided authorization --> Do NOT include these in the Authorization table (future)
			WHEN TRANCD IN ('RVOID') 	THEN 'RVOID'						--'RVOID' - Accepted void return for all ETC types other than 7 or B. For ETC types 7 and B, this represents a void return that was not accepted. The reason for the nonacceptance is shown on the far right side of the line
			WHEN TRANCD IN ('SVOID') 	THEN 'SVOID'						--'SVOID' - Accepted void sale for all ETC types other than 7 or B. For ETC types 7 and B, this represents a void sale that was not accepted. The reason for the nonacceptance is shown on the far right side of the line
			WHEN TRANCD IN ('TVOID') 	THEN 'TVOID'						--'TVOID' - Accepted void ticket-only for all ETC types other than 7 and B. For ETC types 7 and B, this represents a void ticket-only that was not accepted. The reason for the nonacceptance is shown on the far right side of the line
			WHEN TRANCD IN ('FVOD') 	THEN 'FVOD'							--'FVOD' - Fraudulent void
			WHEN TRANCD IN ('BINQ') 	THEN 'BINQ'							--'BINQ' - Open batch inquiry
			WHEN TRANCD IN ('DINQ') 	THEN 'DINQ'							--'DINQ' - Merchant deposit inquiry
			WHEN TRANCD IN ('PINQ') 	THEN 'PINQ'							--'PINQ' - Point-of-Sale (POS) balance inquiry for Visa prepaid card or Electronic Benefits Transfer (EBT) transactions. A transaction with this code does not display an amount in the TRAN AMOUNT field
			WHEN TRANCD IN ('RTNV') 	THEN 'RTNV'							--'RTNV' - Accepted void return for ETC types 7 and B
			WHEN TRANCD IN ('TKTV') 	THEN 'TKTV'							--'TKTV- - Accepted void ticket-only for ETC types 7 and B
			WHEN TRANCD IN ('REV') 		THEN 'REV'							--'REV' - Reversal
			WHEN TRANCD IN ('TA') 		THEN 'TA'							--'TA' - TransArmor key update or a TransArmor system reject This code appears when the System has updated a key to the TransArmor-certified application installed on a POS device or the TransArmor system caused a reject response to be sent to the POS device
		END                      				AuthType,
		CASE
			WHEN DESCRIPTION IS NULL OR DESCRIPTION LIKE ('%APPROVAL%') THEN 'Yes'
			ELSE 'No'
		END										isApproved,
		CASE WHEN TRANCD IN ('SALE','AUTH','CASH')	THEN CAST(ABS(ZEROIFNULL(TRAN_AMOUNT)) AS MONEY) ELSE CAST(0.00 AS MONEY) END SalesAmountAuth,	--'SALE','AUTH','CASH' = Sales.  TRAN_AMOUNT < AUTH_AMOUNT on all PARTIAL APPROVALS and some others (Non-Partial), so use TRAN_AMOUNT.  For ALL ELSE --> 
		CASE WHEN TRANCD IN ('RTRN')				THEN CAST(ABS(ZEROIFNULL(TRAN_AMOUNT)) AS MONEY) ELSE CAST(0.00 AS MONEY) END ReturnsAmountAuth,--'RTRN' = Returns.  TRAN_AMOUNT = AUTH_AMOUNT Always!
		ATHCD		             				AuthCode,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDHOLDERNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b'))<>6 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDHOLDERNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(6)), 6, '0') END
												CardFirst6,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDHOLDERNUMBERLAST4, '[^0-9]', '', 1, 0, 'b'))<>4 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDHOLDERNUMBERLAST4, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(4)), 4, '0') END
												CardLast4,
		EXP										CardExpDate,				--Seems to be MM/YY format
		CAST(NULL AS VARCHAR(3))				AuthResponseCode,			--ISO-8583 (DE39) Standard (Decline) Auth Response Code
		CAST(NULL AS VARCHAR(255))				AuthResponseDescription,	--ISO-8583 (DE39) Standard (Decline) Auth Response Description		
		CASE
			WHEN OPCD IN ('I5','99','77','80','90','C2','88','09','85')	THEN 'No'
			WHEN OPCD IN ('T1','79','F0','11','VO','00')				THEN 'Yes'
			ELSE NULL
		END										isKeyed,
		CASE
    		WHEN OPCD IN ('I5')	THEN 'Yes'
			ELSE 'No'
		END										isChipRead,
		CAST(NULL AS VARCHAR(3))				isReversed,					--Added now for the future usage - per Geoff		
		CASE
            WHEN LEFT(CARDHOLDERNUMBERFIRST6,1) IN ('4') AND LENGTH(TID) NOT in (6,9) THEN DETAILS_OF_AN_AUTHORIZATION
        END										ACI,						--Visa Authorization Characteristic Indicator when Visa and 'R' (sometimes) when Mastercard???
		VALCD									ValidationCode,				--Visa 4-character Validation Code (CPS2000)
		CASE
            WHEN LEFT(CARDHOLDERNUMBERFIRST6,1) IN ('4') AND LENGTH(TID) NOT in (6,9) THEN TID
        END										VisaTranID,					--Visa 15-digit (actually 18?) CPS2000 Transaction ID
		CASE
			WHEN LEFT(CARDHOLDERNUMBERFIRST6,1) IN ('5') THEN
				CASE
    		        WHEN LENGTH(TID)=9  THEN TID || '-****'
            		WHEN LENGTH(TID)=6  THEN '***' || TID || '-****'
            	END
        END										MastercardRefNumber,		--Mastercard ISO 8583 DE63 Banknet Reference Number.  Mastercard MMDD NOT included
		CASE
			WHEN LEFT(CARDHOLDERNUMBERFIRST6,2) IN ('34','37') THEN TID		--American Express ID, if available
		END										AmexRefNumber,
		CASE
			WHEN LEFT(CARDHOLDERNUMBERFIRST6,1) IN ('6') THEN TID			--Discover Network Reference ID
			WHEN LEFT(CARDHOLDERNUMBERFIRST6,2) IN ('35','36') THEN TID		--'35' JCB, '36' Diners (Discover)
		END										DiscoverNetworkRefID,
		ADDRESS_VERIFICATION_RESPONSE			AVSResponse,
		SR										CVV2ResultCode,				--Code representing whether a CVV2/CVC2/CID value was included in the authorization request and the authorization response. The first position of this field displays the CVV2/CVC2/CID presence indicator. This code indicates whether the CVV2/CVC2/CID value was included in the authorization request --> '0' - The merchant did not provide the value. '1' - The value was present. '2' - The value on the card was illegible. '9' - The cardholder did not provide the value. 'blank' - A value was not included in the authorization request.  The second position of the field displays the response returned in the authorization response message. --> 'M' - The CVV2/CVC2/CID value matched the value on the account record, 'N' - The CVV2/CVC2/CID value did not match the value on the account record, 'P' - The CVV2/CVC2/CID value was not processed, 'S' - The CVV2 value was on the plastic, but not submitted with the authorization request. This code is only used for Visa transactions. 'U' - The issuer is either not certified by Visa or did not provide the CVV2 keys to Visa. This code is only used for Visa transactions. 'blank' - No CVV2/CVC2/CID data was in the authorization response 
		NULL									CAVVResultCode,
		UC										UCAFSupportCode,			--Mastercard-assigned code representing whether the merchant supports the Mastercard� Universal Cardholder Authentication Field (UCAF) and the presence of UCAF data.  --> '0' - Merchant does not support UCAF, and no UCAF data is present, '1' - Merchant supports UCAF, but no UCAF data is present, '2' - Merchant supports UCAF, and UCAF data is present, '3' - UCAF data collection is supported by the merchant and the UCAF (Mastercard Assigned Static Accountholder Authentication Value) data must be present, '4' - Reserved for future use, '5' - Issuer risk-based decisioning, '6' - Merchant risk-based decisioning, '7' - Partial shipment or recurring payment
		CASE
			WHEN LEFT(CARDHOLDERNUMBERFIRST6,1) IN ('4') THEN PRD_ID
			WHEN LEFT(CARDHOLDERNUMBERFIRST6,1) IN ('5') AND LENGTH(TID)=9 THEN LEFT(TID,3)
			ELSE NULL
		END										CardProductID,				--Visa Card Product ID and MasterCard Product ID
		CASE
			WHEN SUBSTRING(TDATE,1,2) || '-' || SUBSTRING(TDATE,4,2) <= SUBSTRING(CAST(TO_DATE(MONTH(GETDATE()) || '/' || DAY(GETDATE()) || '/' || YEAR(GETDATE()), 'MM-DD-YYYY') AS Varchar(50)),6,5) THEN
				CAST(TO_TIMESTAMP(TDATE || '/' || YEAR(GETDATE())   || ' ' || TTIME, 'MM/DD/YYYY HH:MI:SS') AS TIMESTAMP)
			ELSE
				CAST(TO_TIMESTAMP(TDATE || '/' || YEAR(GETDATE())-1 || ' ' || TTIME, 'MM/DD/YYYY HH:MI:SS') AS TIMESTAMP)
		END										AuthDateTime,				--THIS NEEDS TO BE A CONCATINATION OF THE "TDATE" AND "TTIME" columns to create a TIMESTAMP format!!!
		CASE 
			WHEN SUBSTRING(RUN_DATE,1,2) || '-' || SUBSTRING(RUN_DATE,4,2) <= SUBSTRING(CAST(TO_DATE(MONTH(GETDATE()) || '/' || DAY(GETDATE()) || '/' || YEAR(GETDATE()), 'MM-DD-YYYY') AS Varchar(50)),6,5) THEN
				CAST(TO_DATE(RUN_DATE || '/' || YEAR(GETDATE()),   'MM/DD/YYYY') AS DATE)
			ELSE
				CAST(TO_DATE(RUN_DATE || '/' || YEAR(GETDATE())-1, 'MM/DD/YYYY') AS DATE)
		END										ProcessorRunDate,			--MM/DD format with no YY!. Need to correct the Year 'YYYY' using the Current Date to decide to use THIS Year or LAST Year
		CASE
			WHEN SUBSTRING(RUN_DATE,1,2) || '-' || SUBSTRING(RUN_DATE,4,2) <= SUBSTRING(CAST(TO_DATE(MONTH(GETDATE()) || '/' || DAY(GETDATE()) || '/' || YEAR(GETDATE()), 'MM-DD-YYYY') AS Varchar(50)),6,5) THEN
				CAST(TO_TIMESTAMP(RUN_DATE || '/' || YEAR(GETDATE())   || ' ' || RUN_TIME, 'MM/DD/YYYY HH:MI:SS') AS TIMESTAMP)
			ELSE
				CAST(TO_TIMESTAMP(RUN_DATE || '/' || YEAR(GETDATE())-1 || ' ' || RUN_TIME, 'MM/DD/YYYY HH:MI:SS') AS TIMESTAMP)
		END										ProcessorRunDateTime,		--Combine the "RUN_TIME" with "RUN_DATE" to create this?  No YY though!  Create a TIMESTAMP format!!!
		CAST(FC_DATE AS DATE)					StatementDate,
        --START of lesser priority Columns - Mostly SME info ----------------------------------------------------------------------------------------------------------------
		CASE
			WHEN ENVELOPEPROCESSORPLATFORM = 'Omaha' THEN 'OMA'
			ELSE ENVELOPEPROCESSORPLATFORM
		END										AuthPlatform,				--Processor Platform Name: 'OMA' Fiserv (FDR) Omaha
		CAST(LEFT(CARDHOLDERNUMBERFIRST6,6)	AS VARCHAR(6))
												ProcessorCardScheme,
		TRANCD									ProcessorAuthType,
		CAST(ZEROIFNULL(AUTH_AMOUNT) AS MONEY)	ProcessorAmount,			--This AUTH_AMOUNT can be different than the TRAN_AMOUNT. Should we KEEP still?  If an amount appears in this field and the TRAN AMOUNT field, the amount in the TRAN AMOUNT field is a partial approval amount on a prepaid card. Partial approval amounts are less than the amounts in the AUTH AMOUNT field
--		CASE
--			WHEN DESCRIPTION IS NOT NULL THEN DESCRIPTION					--Document says if <blank> aka "NULL", then "Accepted", else NOT Accepted (Declined)
--			WHEN DESCRIPTION IS NULL OR DESCRIPTION LIKE ('%APPROVAL%') THEN 'Approved'	--Document says if <blank> aka "NULL", then "Accepted"
--			ELSE NULL
--		END										ProcessorExtraMsg,
		CAST(DESCRIPTION AS VARCHAR(255))		ProcessorExtraMsg,			--This column contains extra messages from the Processor when the transaction was NOT Accepted
		ZERO_ZERO								ProcessorResponseCode,		--Use "ZERO_ZERO" field? Seems like there isn't anything else to use
		CASE
			WHEN OPCD IN ('I5')	THEN 'Chip Card Read'						--'I5' - Contact chip entry
			WHEN OPCD IN ('T1')	THEN 'Manual Key Entry'						--'T1' - Key entry (if ticket was captured electronically)
			WHEN OPCD IN ('99')	THEN 'MAG Stripe Read (Full Unaltered)'		--'99' - Entire magnetic stripe read and transmitted
			WHEN OPCD IN ('77')	THEN 'Contactless - MAG Stripe Rules'		--'77' - Contactless magnetic stripe read using a mobile commerce device
			WHEN OPCD IN ('80')	THEN 'MC Swiped Fallback'					--'80' - Mastercard swiped fallback
			WHEN OPCD IN ('90')	THEN 'Visa Swiped Fallback'					--'90' - Visa swiped fallback
			WHEN OPCD IN ('C2')	THEN 'MAG Stripe Read'						--'C2' - Card swipe
			WHEN OPCD IN ('88')	THEN 'Contactless - MAG Stripe Rules'		--'88' - Contactless magnetic stripe
			WHEN OPCD IN ('09')	THEN 'AMEX Swiped Fallback'					--'09' - American Express swiped fallback
			WHEN OPCD IN ('79')	THEN 'MC Keyed Fallback'					--'79' - Key entry fallback for Mastercard transactions (Keyed entry for all other associations)
			WHEN OPCD IN ('85')	THEN 'DISC Swiped Fallback'					--'85' - Discover swiped fallback
			WHEN OPCD IN ('F0')	THEN 'F0'									--'F0' - ???
			WHEN OPCD IN ('11')	THEN 'Touchtone'							--'11' - Touchtone
			WHEN OPCD IN ('VO')	THEN 'Voice Auth'							--'VO' - 'VOI' Voice through First Data Voice Services
			WHEN OPCD IN ('00')	THEN 'Not Available'						--'00' - Not available
			ELSE OPCD
		END										POSEntryMsg,				--System-assigned code representing how the authorization request was entered. --> 'C2' - Card swipe, 'I5' - Contact chip entry, 'T1' - Key entry (if ticket was captured electronically), 'VOI' - Voice through First Data Voice Services, '00' - Not available, '09' - American Express swiped fallback, '11' - Touchtone, '77' - Contactless magnetic stripe read using a mobile commerce device, '79' - Key entry fallback for Mastercard transactions (Keyed entry for all other associations), '80' - Mastercard swiped fallback, '85' - Discover swiped fallback, '88' - Contactless magnetic stripe, '90' - Visa swiped fallback, '99' - Entire magnetic stripe read and transmitted
		OPCD									POSEntryMode,
		NULL									EComInd,
		FA										PreOrFinalAuth,				--Code representing whether an authorization is a preauthorization or a final authorization. --> '0' - Normal authorization/undefined finality, '1' - Final authorization, 'blank' - Not provided by the merchant
		NULL			          				ForeignFrontEndMID,
		md.MCC									MCC,						--The MCC is provided by the BI.MerchantDemographics table on this report MD-027
		NULL									TransTraceAuditNumber,
		S_P_D		               				TransEntryAuthAccessMode,	--S_P_D = S_P_D_MODE_OF_ACCESS + S_P_D_AUTHORIZATION_MODE. Codes representing the site, telephone service, and device. The first two positions identify the site receiving the authorization request. --> '00' - All site totals, '01' - Omaha, '02' - Digital Data Over Voice/Integrated Service Digital Network (DDOV/ISDN), '03' - San Mateo, '04' - Atlanta, '05' - Boston, '06' - Ram Mobile Data, '07' - Santa Ana, '08' - Minneapolis, '10' - Baltimore, '11' - Las Vegas, '22' - Vail, '40' - FDRNET (Telenet), '42' - POS authorizations, '46' - BellSouth wireless service, '47' - US Wireless service, '50' - Omaha Test, '55' - Omaha Test, '60' - Gateway, '99' - Series One Test.  The third and fourth positions identify the mode of access. '01' - Local, '02' - Intrastate WATS, '03' - POS authorizations, '04' - WATS zone 2, '05' - WATS zone 3, '06' - WATS zone 5 special, '07' - WATS zone 5, '08' - Leased line, '09' - Batch authorizations.  The fifth and sixth positions identify the authorization mode. '01' - Touchtone, '03' - POS device, '04' - CPU, '05' - ATM, '06' - Remote CRT, '07' - VRT, '09' - Voice or ARU Voice Integration (AVI).
		CASE
			WHEN LEFT(ALINE,3) IN ('BAS') THEN 'Visa-' || ALINE				--'BAS' - Visa
			WHEN LEFT(ALINE,3) IN ('INA') THEN 'Mastercard-' || ALINE		--'INA' - Mastercard
			WHEN LEFT(ALINE,3) IN ('ZAM') THEN 'Amex-' || ALINE				--'ZAM' - American Express
			WHEN LEFT(ALINE,3) IN ('ZDG') THEN 'Debit Gateway-' || ALINE	--'ZDG' - Debit Gateway
			WHEN LEFT(ALINE,3) IN ('ZSS') THEN 'Discover-' || ALINE			--'ZSS' - Discover
			WHEN LEFT(ALINE,3) IN ('FDR') THEN 'Fiserv-' || ALINE			--'FDR' - FDR processed the transaction (either Duplicate or Ticket Only)?
			ELSE ALINE
		END										HostInterfaceSystemCode,	--Code representing the processor sending the authorization. You can use this code to determine whether an association or First Data originated the authorization. Refer to the following table (ABOVE). For all other card types, First Data will identify the outgoing line for the authorization provider
		CASE
			WHEN CPU IN ('P') THEN 'Primary'								--'P' - Primary
			WHEN CPU IN ('B') THEN 'Backup'									--'B' - Backup
			WHEN CPU IN ('H') THEN 'Hold Queue'								--'H' - Temporary hold queue
			WHEN CPU IN ('T') THEN 'Test'									--'T' - Test (for First Data use only)
			ELSE CPU
		END										HostCPUIndCode,				--CPU indicator code
		CASE
			WHEN OFI IN ('1') THEN 'Offline'								--'1' - Transaction captured offline
			WHEN OFI IN ('2') THEN 'Offline Closed Batch'					--'2' - Transaction captured offline and sent as part of a closed batch transaction
			WHEN OFI IN ('3') THEN 'Revised Item'							--'3' - Revised item transaction
			WHEN OFI IN ('4') THEN 'Revised Item Closed Batch'				--'4' - Revised item transaction sent as part of a closed batch transaction
			WHEN OFI IN ('5') THEN 'Specific Poll Revised'					--'5' - Specific poll for a revised transaction
			WHEN OFI IN ('6') THEN 'Specific Poll Offline'					--'6' - Specific poll for an offline transaction
			ELSE OFI
		END										HowSentToFiserv,			--Code representing how the transaction was transmitted to First Data
		BSEQ									BatchSequence,				--Number assigned to each batch. The device generates this number for ETC �PLUS� merchants only.
		CUT_OFF									BatchCutOff,				--Code representing when the merchant�s use of the ETC System ends for one processing day and begins for the next processing day
		CASE
			WHEN ETC_TYPE IN ('B') THEN 'ETC Plus Merch Debit Close'		--'B' - ETC �PLUS� with merchant debit close
			WHEN ETC_TYPE IN ('0') THEN 'ETC Not Used'						--'0' - ETC not used
			WHEN ETC_TYPE IN ('1') THEN 'ETC Host-Balancing R/T Detail'		--'1' - ETC only with host-balancing/real-time detail lookup
			WHEN ETC_TYPE IN ('2') THEN 'ETC Only R/T LookUp'				--'2' - ETC only with real-time detail lookup
			WHEN ETC_TYPE IN ('3') THEN 'ETC Sys Batch Close'				--'3' - ETC only and the System closes the batch
			WHEN ETC_TYPE IN ('4') THEN 'ETC Voice B/U Sys Batch Close'		--'4' - ETC with voice backup and the System closes the batch
			WHEN ETC_TYPE IN ('5') THEN 'ETC Merch Batch Close'				--'5' - ETC only and the merchant closes the batch
			WHEN ETC_TYPE IN ('6') THEN 'ETC Voice B/U Merch Batch Close'	--'6' - ETC with voice backup and the merchant closes the batch
			WHEN ETC_TYPE IN ('7') THEN 'ETC Plus'							--'7' - ETC �PLUS�
			WHEN ETC_TYPE IN ('B') THEN 'Online Conv Checks'				--'8' - Online entry of convenience checks at your location
			ELSE ETC_TYPE
		END										BatchTypeETC,				--Code representing how the merchant is supported by the ETC System
		CASE
			WHEN CRVR IN ('QA') THEN 'Return Adj Approved'					--'QA' - Merchandise return adjustment
			WHEN CRVR IN ('QD') THEN 'Return Declined'						--'QD' - *Merchandise return declined (*Data shows only these 2)
			WHEN CRVR IN ('QR') THEN 'Return Approved'						--'QR' - *Merchandise return approved (*Data shows only these 2)
			WHEN CRVR IN ('QZ') THEN 'Return Adj Declined'					--'QZ' - Merchandise return adjustment declined
			WHEN CRVR IS NULL	THEN 'Unknown'								--'  ' - <blank> or NULL - Unknown
			ELSE CRVR
		END										CreditVoucherCode,			--Code representing the action taken on the credit voucher authorization transaction
		CAST(SURCHARGE AS MONEY)				SurchargeAmount,			--Amount of surcharge assessed by the merchant on POS transactions
		CAST(NULL AS MONEY)						CashbackAmount,
		SP										StarSignatureDebit,			--Code representing whether the transaction was a STAR Signature Debit transaction --> 'A' - STAR Signature Debit,  ' ' <blank> - All other
		DRD										DebitNetworkID,				--Identifier of the network to which the First Data Dynamic Routing Decision system routed the debit transaction
		CAST(NULL AS MONEY)						DebitNetworkFee,
		NULL									PINEntryCapability,
		NULL									PINCaptureCapability,
		CASE
			WHEN PIN IN ('D') THEN 'Declined PIN'							--'D' - Authorization was declined for PIN
			WHEN PIN IN ('I') THEN 'Interchange Verified'					--'I' - Interchange performed the verification
			WHEN PIN IN ('U') THEN 'Verified By Other'						--'U' - Verification was performed even though First Data was unable to verify the PIN
			WHEN PIN IN ('V') THEN 'Verified By FDR'						--'V' - First Data performed the verification
			WHEN PIN IN (' ') THEN 'Non PIN Mgmt'							--' ' - <blank> - The cardholder is not processing with a PIN Management System issuer
			ELSE PIN
		END										PINVerification,			--Code representing how the PIN was verified
--		CASE
--			WHEN CARDHOLDER_NUMBER_PREFIX IN ('D') THEN 'DebitCard'			--Should we use "PIN-Debit" or just "DebitCard"
--			WHEN CARDHOLDER_NUMBER_PREFIX IN ('P') THEN 'DebitCard'			--Should we use "Pre-Paid" or just "DebitCard"
--			WHEN CARDHOLDER_NUMBER_PREFIX IN ('E') THEN 'DebitCard'			--Should we use "EBT-Card" or just "DebitCard"
--			ELSE CARDHOLDER_NUMBER_PREFIX									--If there is ONLY values of 'D','P' and 'E' and nothing for 'CreditCard'...  Huh???
--		END										DebitCreditCode,			--D_C is NOT the Proper Name for this column --> CARDHOLDER_NUMBER_PREFIX seems to be.  --> An account identifier with a 'D' prefix indicates the customer used an online debit card for this transaction. Blake (Fiserv) confirmed that 'E' is for an EBT type transaction. An account identifier with a 'P' prefix indicates the customer used a Visa prepaid card for this transaction.  An '*' symbol (asterisk) preceding the identifier indicates the transaction is a STAR Signature Debit transaction
		NULL									RetrievalRefNumber,		
		NULL									MarketSpecificIndicatorCode,
		ILINE									TransCommType,				--System-assigned identifier of the communication line from the terminal at the merchant�s location
		NULL									StoreNumber,
		POS										POSModelInfo,				--Codes representing information about the transmission from the POS device. - The first two positions identify the POS device model. - The third position is the reversal reason code. '0' - Not a reversal, '1' - LRC error, '2' - Call-Center Reversal, '3' - Timeout, '4' - ACK/NAK not received, '5' - NAK retried to limit, '6' - Stop-bit error, '7' - Late response from host, '8' - Modern interface error, '9' - Other error - The fourth position identifies the extent of the transmission. '0' - Single transaction, '1' - Multiple transactions
		NULL									POSDataCode,
		DEVT									CardSourceType,				--Code representing the type of device used to initiate a transaction (Like a "Credit Card"...)
		NULL			          				TSYSBINBankStore,
		ID										TerminalID,
		NULL									ExternalID,
		CUST_CD									OrderNumber,				--User-defined code representing accounting data, customer-defined data, or driver/vehicle information
		INVNUM									InvoiceNumber,				--Invoice Number
		'USD'									CurrencyCode,
		SVC										CardServiceCode,			--Sequence of digits that, taken as a whole, defines various services. --> Position one represents whether plastics are eligible for national or international interchange. '1' - International card, '2' - International card - integrated circuit card, '5' - National use only, '6' - National use only - integrated circuit card, '7' - Private label or proprietary card.  Position two represents PIN requirements. '0' - Normal authorization '2' - Positive online authorization required.  Position three represents the card restrictions. '0' - PIN required, '1' - Normal cardholder verification; no restrictions, '2' - Normal cardholder verification, goods & services only at point of interaction (no cash back), '3' - ATM only, PIN required, '5' - PIN required, goods & services only at point of interaction (no cashback), '6' - Prompt for PIN if PIN pad present, '7' - Prompt for PIN if PIN pad present, goods & services only at point of interaction (no cash back)
		NULL									TransEncryptionType,
		CASE
			WHEN TASL IN ('01') THEN 'TA Tokn Encrypt'						--'01' - TransArmor solution tokenized and encrypted authorization request
			WHEN TASL IN ('03')	THEN 'TA Tokn Only'							--'03' - TransArmor solution tokenized-only authorization request
			WHEN TASL IS NULL	THEN 'No Tokn'								--'  ' - <blank> or NULL - Unsecured request originating at a POS device that does not run a TransArmor-certified application
			ELSE TASL
		END										AuthSecurityLevel,			--Code representing the security level of the authorization request		
		CARDHOLDER_NUMBER          				CardFingerprint,
		'MD-027'								SourceReport,
		UUID_GENERATE()							PaysafeAuthID				--Unique ID assigned to each record (row)
	FROM BISME.MD027_Detail_Omaha md027
        INNER JOIN BI.ReportingChannels rc ON (LEFT(md027.MERCHANT_NUMBER,15)=LEFT(rc.MerchantNumber,15))
		LEFT JOIN BI.MerchantDemographics md ON (LEFT(md027.MERCHANT_NUMBER,15)=LEFT(md.MerchantNumber,15))
	WHERE
		TRANCD IN ('SALE','AUTH','CASH','RTRN')
		AND LEFT(ALINE,3) NOT IN ('FDR')									--Proposed by Blake at Fiserv
		AND
		CASE
			WHEN SUBSTRING(TDATE,1,2) || '-' || SUBSTRING(TDATE,4,2) <= SUBSTRING(CAST(TO_DATE(MONTH(GETDATE()) || '/' || DAY(GETDATE()) || '/' || YEAR(GETDATE()), 'MM-DD-YYYY') AS Varchar(50)),6,5) THEN
				CAST(TO_DATE(TDATE || '/' || YEAR(GETDATE()),   'MM/DD/YYYY') AS DATE)
			ELSE
				CAST(TO_DATE(TDATE || '/' || YEAR(GETDATE())-1, 'MM/DD/YYYY') AS DATE)
		END >= '2021-03-01'
--		END >= '2021-06-01'
--	LIMIT 100   

) UNION ALL (

/*****************************************************************************************
 *   Fiserv Omaha MD572 Authorization Card Transactions (Authorization Conform Tables)   *
 *    All Cards                                                                          *
 *****************************************************************************************/
	SELECT
		CAST(COALESCE(AUTH_DATE, TRAN_DT) AS DATE) AuthDate,				--AUTH_DATE seems to always be NULL, so TRAN_DT is the one really used for AuthDate
		rc.MerchantNumber         				MerchantNumber,
		md.DBA									DBA,
/*		CAST(
			CASE
				WHEN DATA_IND IN ('VS') THEN 'VISA'							--Visa
				WHEN DATA_IND IN ('MC') THEN 'MC'							--Mastercard
				WHEN DATA_IND IN ('AE') THEN 'AMEX'							--American Express
				ELSE LEFT(DATA_IND,4)
			END
		AS VARCHAR(4))							CardSchemeCode, */
		CAST(
			CASE
				WHEN PYMNT_TYPE IN ('0004') THEN 'VISA'						--Visa
				WHEN PYMNT_TYPE IN ('0005') THEN 'MC'						--Mastercard
				WHEN PYMNT_TYPE IN ('0003') THEN 'AMEX'						--American Express
--				WHEN PYMNT_TYPE IN ('0006') THEN 'GPIN'						--Generic Debit (Debit Summary File) --> Debit Networks: 06,07,17,23,28,40,48,58,68,69,86,97 (Broken out below)
				WHEN PYMNT_TYPE IN ('0006') AND TRANSACTION_IND IN ('A') THEN
					CASE
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('40') THEN 'MAES'	--Maestro
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('69') THEN 'ACCL'	--Accel
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('06') THEN 'PULS'	--PULSE
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('17') THEN 'STAR'	--STAR Northeast
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('28') THEN 'NYCE'	--NYCE
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('07') THEN 'STAR'	--STAR Southeast
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('23') THEN 'STAR'	--STAR West
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('58') THEN 'SHZM'	--SHAZAM
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('48') THEN 'ITLK'	--Interlink
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('68') THEN 'CU24'	--Credit Union 24
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('86') THEN 'OTHR'	--Armed Forces Financial Network Direct
						WHEN SUBSTRING(AUTHZR_CODE,3,2) IN ('97') THEN 'JEAN'	--Jeanie Direct
						ELSE 'GPIN'
					END
				WHEN PYMNT_TYPE IN ('0048') THEN 'EBTF'						--EBT (Food Stamps)
				WHEN PYMNT_TYPE IN ('0015') THEN 'DISC'						--Discover Network
				WHEN PYMNT_TYPE IN ('0099') THEN 'OTHR'						--Specials (as 'OTHR')
				WHEN PYMNT_TYPE IN ('0022') THEN 'WEX'						--WEX Wright Express Fleet (or 'WAM')???
				WHEN PYMNT_TYPE IN ('0017') THEN 'VOYG'						--Voyager
				WHEN PYMNT_TYPE IN ('0065') THEN 'MC'						--Mastercard Fleet
				WHEN PYMNT_TYPE IN ('0050') THEN 'EBT'						--EBT WIC
				WHEN PYMNT_TYPE IN ('0049') THEN 'EBTC'						--EBT Cash
				WHEN PYMNT_TYPE IN ('0066') THEN 'GASC'						--Gas Card
				WHEN PYMNT_TYPE IN ('0088') THEN 'TELE'						--TeleCheck ECA (Although some transactions show in this file, we don't process/bill them - SKIP!)
				WHEN PYMNT_TYPE IN ('0062') THEN 'GC'						--Stored Value Card
				WHEN PYMNT_TYPE IN ('0000') THEN 'OTHR'						--Unknown (as 'OTHR')
				WHEN PYMNT_TYPE IN ('0046') THEN 'WEX'						--Universal Fleets - set as 'WEX' (WEX Inc.)
				ELSE LEFT(PYMNT_TYPE,4)
			END
		AS VARCHAR(4))							CardSchemeCode,
		CASE
			WHEN TRANSACTION_TYPE IN ('0000') THEN '0000'					--'DLL' - Nonfinancial Transaction
			WHEN TRANSACTION_TYPE IN ('0001') THEN '0001'					--'TOTALS' - Nonfinancial Transaction
			WHEN TRANSACTION_TYPE IN ('0003') THEN '0003'					--'MAIL BOX' - Nonfinancial Transaction
			WHEN TRANSACTION_TYPE IN ('0037') THEN '0037'					--*Bogus* - ERROR???
			WHEN TRANSACTION_TYPE IN ('0054') THEN 'Sale'					--'PURCHASE' - Debit (+) Transaction [#1 for Visa, MC, Amex]
			WHEN TRANSACTION_TYPE IN ('0056') THEN 'Sale'					--'MAILPHON' - Debit (+) Transaction [#4 for Visa, Amex]
			WHEN TRANSACTION_TYPE IN ('0057') THEN '0057'					--'REVERSAL' - Credit (-) Transaction [#5 for MC]
			WHEN TRANSACTION_TYPE IN ('0058') THEN 'Return'					--'RETURN' - Credit (-) Transaction [#6 for Visa, MC, #5 for Amex]
			WHEN TRANSACTION_TYPE IN ('0059') THEN 'Sale'					--'AUTHONLY' - Nonfinancial Transaction	[#2 for Visa, MC, Amex] 'Authorization' changed to 'Sale'
			WHEN TRANSACTION_TYPE IN ('0060') THEN '0060'					--'PRE AUTH' - Debit (+) Transaction [#3 for Visa, MC, Amex]
			WHEN TRANSACTION_TYPE IN ('0062') THEN 'Return'					--'RET ADJ' - Credit (-) Transaction
			WHEN TRANSACTION_TYPE IN ('0063') THEN '0063'					--'VOID RET' - Void of a return
			WHEN TRANSACTION_TYPE IN ('0075') THEN 'Sale'					--'CAP PUR' - Debit (+) Transaction
			WHEN TRANSACTION_TYPE IN ('0080') THEN '0080'					--'ACTIVATE' - Card Activation
			WHEN TRANSACTION_TYPE IN ('0083') THEN '0083'					--'RECHARGE' - Financial Transaction (Recharge)
			WHEN TRANSACTION_TYPE IN ('0084') THEN '0084'					--'CANCELL' - Nonfinancial Transaction (Preauthorization Cancellation) #5 for Visa, #4 for MC, #6 for Amex
			WHEN TRANSACTION_TYPE IN ('0088') THEN '0088'					--'ACCT VER' - Nonfinancial Transaction
			WHEN TRANSACTION_TYPE IN ('0092') THEN '0092'					--'MAILREV' - Debit (+) Transaction
			WHEN TRANSACTION_TYPE IN ('0096') THEN '0096'					--'INQUIRY' - Nonfinancial Transaction
		END                      				AuthType,					--Need access ACCESSONE website
		CASE
			WHEN TRANSACTION_IND IN ('A') THEN 'Yes'
			WHEN TRANSACTION_IND IN ('D') THEN 'No'
			ELSE NULL
		END										isApproved,
		CASE WHEN TRANSACTION_TYPE IN ('0054','0056','0075') THEN CAST(ZEROIFNULL(TRANSACTION_AMOUNT) AS MONEY) 												--'' = Sales
			 WHEN TRANSACTION_TYPE IN ('0059')				 THEN CAST(ZEROIFNULL(APPROVAL_AMOUNT)    AS MONEY) ELSE CAST(0.00 AS MONEY) END SalesAmountAuth,	--'' = Authorization (Sale)
		CASE WHEN TRANSACTION_TYPE IN ('0058','0062')		 THEN CAST(ZEROIFNULL(TRANSACTION_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END ReturnsAmountAuth,	--'' = Returns
		APPRV_DCLINE              				AuthCode,
		CASE WHEN LENGTH(REGEXP_REPLACE(ACCOUNTNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b'))<>6 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(ACCOUNTNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(6)), 6, '0') END
												CardFirst6,
		CASE WHEN LENGTH(REGEXP_REPLACE(ACCOUNTNUMBERLAST4, '[^0-9]', '', 1, 0, 'b'))<>4 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(ACCOUNTNUMBERLAST4, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(4)), 4, '0') END
												CardLast4,
		EXP_DATE                  				CardExpDate,				--Format is YYMM
		CAST(NULL AS VARCHAR(3))				AuthResponseCode,			--ISO-8583 (DE39) Standard (Decline) Auth Response Code
		CAST(NULL AS VARCHAR(255))				AuthResponseDescription,	--ISO-8583 (DE39) Standard (Decline) Auth Response Description		
		CASE
    		WHEN SUBSTRING(ENTRY_MODE_1,1,2)	IN ('00','01','06','10','79','81','82','S')					THEN 'Yes'  --AMEX (ESA) '0A', '0S', '1', '2' --We need to find out what these are!
    		WHEN SUBSTRING(ENTRY_MODE_1,1,2)	IN ('02','05','07','09','80','83','85','90','91','95','W')	THEN 'No'
			ELSE NULL
        END										isKeyed,         			--'Yes' Keyed, 'No" Not Keyed - Swiped or Chipped or Other
		CASE
    		WHEN SUBSTRING(ENTRY_MODE_1,1,2)	IN ('05','07','09','83','85','95')	THEN 'Yes'
			ELSE 'No'
   		END										isChipRead,					--'05','07'(Not Discover),'09','83','85','95'
		CAST(NULL AS VARCHAR(3))				isReversed,					--Added now for the future usage - per Geoff		
		PS_BKNT_IND								ACI,						--Visa Authorization Characteristic Indicator
		VISA_VALCD								ValidationCode,				--'0'-'9', 'A'-'Z'  ???
		CASE
			WHEN PYMNT_TYPE IN ('0004') THEN TID_BANKNET
		END										VisaTranID,					--Visa 15-digit CPS2000 Transaction ID (Not a Banknet Reference Number!)
		CASE
			WHEN PYMNT_TYPE IN ('0005','0065') THEN TID_BANKNET
		END										MastercardRefNumber,
		CASE
			WHEN PYMNT_TYPE IN ('0003') THEN TID_BANKNET
		END										AmexRefNumber,
		CASE
			WHEN PYMNT_TYPE IN ('0015') THEN TID_BANKNET
		END										DiscoverNetworkRefID,
		AVS										AVSResponse,
		CASE
			WHEN CVV2_RSLT IN ('N') THEN 'N'
			WHEN CVV2_RSLT IN ('Y') THEN 'Y'
			ELSE CVV2_RSLT
		END										CVV2ResultCode,				--'Y' Yes, the CVV2 matched or 'N' the CVV2 did not match
		CAVV_RSLT								CAVVResultCode,				--Seems to always be NULL on all transactions
		NULL									UCAFSupportCode,
		CASE
			WHEN DATA_IND IN ('VS') THEN CARD_LEVL
		END										CardProductID,				--Visa Card Product ID and MasterCard Product ID
		CAST(TRAN_DT AS TIMESTAMP)				AuthDateTime,				--Add "time" by Casting as TimeStamp, per Geoff
		CAST(RUN_DATE AS DATE)                  ProcessorRunDate,
		CAST(RUNDATETIME AS TIMESTAMP)			ProcessorRunDateTime,
		CAST(FC_DATE AS DATE)					StatementDate,
        --START of lesser priority Columns - Mostly SME info ----------------------------------------------------------------------------------------------------------------
		CASE
			WHEN ENVELOPEPROCESSORPLATFORM = 'Omaha' THEN 'OMA'
			ELSE ENVELOPEPROCESSORPLATFORM
		END										AuthPlatform,				--Processor Platform Name: 'OMA' Fiserv (FDR) Omaha
		CAST(PYMNT_TYPE AS VARCHAR(6))			ProcessorCardScheme,		--'0004','0005','0006' are most popular. Values: 0000,0003,0004,0005,0006,0015,0017,0022,0046,0048,0049,0050,0062,0065,0066,0088,0099
		TRANSACTION_TYPE						ProcessorAuthType,
		CAST(ZEROIFNULL(APPROVAL_AMOUNT) AS MONEY) ProcessorAmount,
		CAST(
			CASE
				WHEN TRANSACTION_IND IN ('D') THEN
					CASE
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$0' THEN 'INVALID REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%1' THEN 'NEEDS APPLICATION???'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%2' THEN 'IN COLLECTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2%' THEN 'NOT ABLE TO PROCESS - VCC2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%3' THEN 'CUSTOMER BLOCKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%4' THEN 'CARD REPORTED STOLEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4%' THEN 'MRCH MUST BE ROAD RANGER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%5' THEN 'CARD REPORTED LOST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5%' THEN 'UNKNOWN MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%6' THEN 'CARD EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%7' THEN 'CARD DEACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%8' THEN 'HARD NEGATIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2:' THEN 'HOLD CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%9' THEN 'CASHBACK NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9%' THEN 'CHECK VEL RFRL-OVER MRCH PRD COUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9:' THEN 'USE IMPRINTER - CENEX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$1' THEN 'TRANS TIMEOUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$2' THEN 'INVALID TIMESTAMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$3' THEN 'CARD ALREADY ISSUED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$4' THEN 'CARD NOT ISSUED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$5' THEN 'CARD ALREADY USED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$6' THEN 'MANUAL TRANS. NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$7' THEN 'MAGNETIC STRIPE NOT VALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$8' THEN 'TRANSACTION TYPE UNKNOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$9' THEN 'INVALID TENDER TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='10' THEN 'ACCEPT - PARTIAL APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='10' THEN 'PARTIAL APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='20' THEN 'Q OVERFLOW IN HOST INTERFACE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='21' THEN 'TIMED OUT IN HOST INTERFACE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='22' THEN 'MODEM ELIMINATOR LINE DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='23' THEN 'PIN ENCRYPTION ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='23' THEN 'PIN ENCRYPTION ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='23' THEN 'PIN ENCRYPTION ERROR-NETWORK PROB.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='24' THEN 'DUPLICATE COMPLETION RECEIVED.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='25' THEN 'REVERSAL OF COMPLETION NOT ALLOWED.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='26' THEN 'UNMATCHED REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='27' THEN 'GENERAL DECLINE - CONTACT BANK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='28' THEN 'LOST OR STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='29' THEN 'FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='33' THEN 'INVALID MDSE OR SERVICE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='36' THEN 'CARD TYPE DOES NOT MATCH RECORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='37' THEN 'DRIVER NO. NOT VALID FOR FLEET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='38' THEN 'VEHICLE NO. NOT VALID FOR FLEET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='40' THEN 'INVALID TRANSACTION PRE-DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='41' THEN 'SOHIO TRAN AMOUNT > $5000.00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='42' THEN 'USED DEBIT KEY ON REVERSAL OF CC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='43' THEN 'NON-NUMERIC PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='44' THEN 'REVERSAL AMOUNT INCORRECT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='45' THEN 'UNMATCHED REVERSAL APPROVAL NO.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='46' THEN 'UNMATCHED REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='47' THEN 'ZERO AMOUNT REQUESTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='48' THEN 'MDSE RETN NOT ALLOWED FOR CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='49' THEN 'SOHIO JOBBER MC/VISA $50 OR OVER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='50' THEN 'OVER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='51' THEN 'UNDER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='52' THEN 'BAD STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='52' THEN 'CARD DEACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='53' THEN 'UNKNOWN TRANSACTION OR SEQUENCE NM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='54' THEN 'INVALID TRAN FOR THIS MECHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='55' THEN 'ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='55' THEN 'INVALID TRAN FOR THIS CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='56' THEN 'NO GIFT GROUP IN STF - SETUP ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='58' THEN 'NO GIFT GROUP IN CARD REC -'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='59' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='90' THEN 'INSUFF INFO / BAD ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='91' THEN 'CHK SEC/ETC - LICENSE ON NEG FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='92' THEN 'CHK SECURITY - NEG FILE IS DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='93' THEN 'CHK SECURITY - NEG FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='94' THEN 'CHK SEC/ETC - INVALID STATE CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='95' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='96' THEN 'AMOUNT EXCEEDS $300'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='97' THEN 'CITGO REPAIRS > 150'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='98' THEN 'CITGO NEG FILE "DO NOT ACCEPT"'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='99' THEN 'CITGO NEG FILE "BAD CARD"'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!0' THEN 'FINDER WRITE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!1' THEN 'BAD TRACKII'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!2' THEN 'CARDHOLDER NOT KNOWN TO PROCESSOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!3' THEN 'INVALID PIN - PLEASE RETRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!4' THEN 'MESSAGE FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!5' THEN 'PIN TRIES EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!6' THEN 'INVALID TRANSACTION TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!7' THEN 'CARD NUMBER NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!8' THEN 'NO ACCOUNT ON FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!9' THEN 'LOST OR STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!A' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!a' THEN 'NOT A WIC ITEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!b' THEN 'CANNOT TRACE BACK TO ORIG TRX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!B' THEN 'TRANSACTION NOT VALID FOR CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!C' THEN 'RETURN EXCEEDS BENEFIT AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!D' THEN 'ENTER LESSER AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!E' THEN 'AUTHORIZOR NOT AVAILABLE (TIME OUT)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!F' THEN 'PROCESSOR NOT LOGGED ON'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!G' THEN 'STORE/SUBSCRIBER NOT DEFINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!H' THEN 'SUPERVISOR OVERRIDE REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!I' THEN 'DUPLICATE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!J' THEN 'INSUFFICIENT FUNDS (EBT BAL)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!K' THEN 'CLERK ID/PASSWORD IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!L' THEN 'EBT ACH TOTALS UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!M' THEN 'BENEFITS ON HOLD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!N' THEN 'AMT LESS THAN MINIMUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!O' THEN 'REVERSAL FORMATTING ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!P' THEN 'PIN NOT SELECTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!Q' THEN 'BAD FCS STATUS FOR MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!R' THEN 'UNACCEPTABLE TRANACTION FEE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!S' THEN 'CARD HAS INVALID ISO PREFIX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!T' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!U' THEN 'VOUCHER EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!V' THEN 'INVALID SECURITY CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!W' THEN 'INVALID VOUCHER/AUTH NBR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!X' THEN 'UNMATCHED TIMEOUT REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='!Y' THEN 'WIC PRESCRIPTION EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$!' THEN 'ACQUIRER ID NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$$' THEN 'APPROVED - PARTIAL $$'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$%' THEN 'PIN SUSPEND/DEACTIVATED/NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$&' THEN 'ERROR IN PROCESSING'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$(' THEN 'FROZEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$)' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$@' THEN 'PIN ALREADY ACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$^' THEN 'SECURITY ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$~' THEN 'INVALID SERVER ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$<' THEN 'INVALID CURRENCY CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$>' THEN 'MAX NUM OF REDEMPTIONS EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$A' THEN 'INACTIVE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$A' THEN 'INACTIVE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$B' THEN 'INVALID CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$C' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$D' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$E' THEN 'NO PREVIOUS AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$F' THEN 'INVALID MESSAGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$G' THEN 'NO CARD FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$H' THEN 'NSF OUTSTANDING PRE-AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$I' THEN 'DENIAL,NO PRE-AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$J' THEN 'NO AUTHORIZATION NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$K' THEN 'INVALID AUTHORIZATION NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$L' THEN 'MAX SINGLE RE-CHARGE AMT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$M' THEN 'MAX TOTAL RE-CHARGE AMT EXCEECED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$N' THEN 'AUTH SERVER IS SHUTDOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$O' THEN 'INVALID CARD STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$P' THEN 'UNKNOWN DEALER/STORE CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$Q' THEN 'MAX NUMBER OF RE-CHARGES EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$R' THEN 'INAVLID CARD VERIFICATION VALUE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$S' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$T' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$U' THEN 'INVALID FORMAT TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$V' THEN 'INVALID AMOUNT FOR RECHARGE VALUE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$W' THEN 'UNMATCHED LINK RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$X' THEN 'LINE IS DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$Y' THEN 'FASTWRITE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='$Z' THEN 'QUEUE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%I' THEN 'CALL ME'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%J' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%K' THEN 'UNKNOWN TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%L' THEN 'NETWORK UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%M' THEN 'EDIT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='%N' THEN 'EXCESS TIME BETWEEN TRANSACTIONS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&!' THEN 'FRAUD ALERT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&#' THEN 'INVALID ODOMETER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&$' THEN 'EOD TRAN NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&%' THEN 'DUPL EOD TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&&' THEN 'TIME OUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&*' THEN 'INVALID REVERSAL FORMAT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&@' THEN 'INVALID MERCHANT ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&^' THEN 'TRANSACTION NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&0' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&1' THEN 'REPAIR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&2' THEN 'ADDITIVE LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&3' THEN 'NON-NUMERIC AUTH#'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&4' THEN 'DUPLICATE TRANSACTIO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&5' THEN 'ATM NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&6' THEN 'ACCOUNT INACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&7' THEN 'ACCOUNT ON HOLD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&8' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&9' THEN 'INACTIVE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&A' THEN 'HAVE DRIVER CALL CO.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&a' THEN 'OIL NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&b' THEN 'DUPLICATE ENTRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&B' THEN 'HAVE DRIVER CALL CO.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&c' THEN 'INVALID PIN #'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&C' THEN 'OVER FUEL LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&D' THEN 'CASH ADVANCE LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&d' THEN 'DUPLICATE ENTRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&e' THEN 'NO CASH ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&E' THEN 'TOTALS INCORRECT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&f' THEN 'CAN NOT VOID CHECK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&F' THEN 'PRODUCT CODE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&g' THEN 'ODOMETER REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&G' THEN 'UNAPPROVED SITE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&h' THEN 'INVALID CHECK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&H' THEN 'MISCELLANEOUS LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&i' THEN '47'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&I' THEN 'AUTH OK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&j' THEN 'ADVANCE LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&J' THEN 'ENTRY ERROR-RETRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&k' THEN 'PURCHASE MAX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&K' THEN 'TRIP ERROR-RETRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&l' THEN 'CALL ERROR-50'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&L' THEN 'UNIT ERROR-RETRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&M' THEN 'ERROR IN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&m' THEN 'INVALID PIN #'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&n' THEN 'CALL ERROR-52'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&N' THEN 'TRANS CODE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&O' THEN 'AMOUNTS TOO HIGH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&o' THEN 'DUPLICATE INVOICE #'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&P' THEN 'ERROR-RETRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&p' THEN 'OLD CHECK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&q' THEN 'DUPLICATE AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&Q' THEN 'DUPLICATE ENTRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&R' THEN 'AUTH TEST-OK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&r' THEN 'PURCHASE ORDER REQ'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&S' THEN 'FUEL PRICE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&s' THEN 'SWIPE TABB DRVR CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&T' THEN 'CALL FOR AUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&t' THEN 'PRODUCT QTY ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&u' THEN 'PRODUCT TOT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&U' THEN 'Y OR N REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&v' THEN 'FUEL TYPE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&V' THEN 'NOT ON FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&W' THEN 'ERR-25 CALL TPS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&w' THEN 'PRODUCT NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&x' THEN 'LIMIT NOT DEFINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&X' THEN 'SELF SERVE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&y' THEN 'ACCOUNT IN USE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&Y' THEN 'MINI SERVE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&z' THEN 'AMOUNTS IN ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='&Z' THEN 'FULL SERVE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*B' THEN 'DELINQUENT ACCOUNT - TYPE 1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*C' THEN 'INACTIVE STORE OR CARD - TYPE 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*D' THEN 'ACCOUNT OVER LIMIT - TYPE 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*E' THEN 'UNAUTHORIZED USER - TYPE 1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*F' THEN 'CARD EXPIRED - TYPE 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*G' THEN 'SYSTEM NOT AVAILABLE - TYPE 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*H' THEN 'HVN ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*I' THEN 'AUTH CODE NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*J' THEN 'SALE DATE MISMATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*K' THEN 'DUPLICATE INVOICE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*L' THEN 'INVALID TRANSACTION FUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*M' THEN 'INVALID ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*N' THEN 'TRAN AMOUNT NOT NUMERIC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*O' THEN 'ACCOUNT NOT ON SYSTEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*P' THEN 'PRODUCT TRACKING ITEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*Q' THEN 'INVALID CHECK DIGIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*S' THEN 'INVALID TRANSACTION FOR MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*T' THEN 'ZERO AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='*U' THEN 'INTERNAL ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':A' THEN 'GENERAL TRANSACTION DENIAL RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':B' THEN 'FORMAT OF COMMUNICATIONS PACKET IS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':C' THEN 'CARD ACCOUNT NOT FOUND. RESPONSE FO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':D' THEN 'VEHICLE CARD ACCOUNT NOT FOUND. RES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':E' THEN 'EMPLOYEE CARD ACCOUNT NOT FOUND. RE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':F' THEN 'TERMINAL IDENTIFIER IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':G' THEN 'FUEL PRODUCT CODE IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':H' THEN 'PERSON IDENTIFIER NUMBER IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':I' THEN 'PRODUCT CODE NOT ALLOWED FOR LOCATI'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':J' THEN 'CARD ACCOUNT HAS EXCEEDED LIMIT FOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':K' THEN 'CARD ACCOUT HAS EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':L' THEN 'TRANSACTION DECLINED DUE TO MISC. R'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':M' THEN 'CARD(S) SHOULD BE CONFISCATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':N' THEN 'SYSTEM IS UNABLE TO RESPOND/PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':O' THEN 'INTERNAL CODE FOR UNACKNOWLEDGED BU'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':P' THEN 'RESTRICTED USER, EITHER BY SITE OR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':Q' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':R' THEN 'INVALID FORMAT TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':S' THEN 'UNMATCHED RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':T' THEN 'LINE DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':U' THEN 'FASTWRITE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':V' THEN 'ADD TO QUEUE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)=':W' THEN 'INVALID TIMESTAMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?1' THEN 'CLAIM # VALIDATION FAILED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?2' THEN 'DECISION MADE BY TRIAD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?3' THEN 'BATCH AUTH DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?4' THEN 'ACCT RETURN MAIL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?5' THEN 'OVERRIDE, CALL 800/388-4142'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?7' THEN 'CHECK ID, CALL 800/388-4142'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?8' THEN 'EOD - CANNOT UPDATE CMS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?9' THEN 'A/R SYSTEM UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?A' THEN 'OPEN TO BUY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?B' THEN 'ERROR - INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?C' THEN 'ERROR - CARD EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?D' THEN 'ACCT BLOCKED DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?E' THEN 'ACCT BLOCKED REFER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?F' THEN 'ACCT BLOCKED FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?G' THEN 'ACCT BLOCKED PICKUP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?H' THEN 'MANUAL DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?I' THEN 'ERROR - ACCOUNT STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?J' THEN 'INVALID STORE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?K' THEN 'DUPLICATE REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?L' THEN 'ORIG TRAN NOT FOUND FOR REV.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?M' THEN 'INVALID LOGO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?N' THEN 'INVALID CREDIT PLAN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?O' THEN 'INACTIVE CREDIT PLAN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?P' THEN 'COLLECTIONS - MANUAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?P' THEN 'CREDIT PLAN AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?P' THEN 'CREDIT PLAN LOGO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?P' THEN 'CREDIT PLAN SKU'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?P' THEN 'CREDIT PLAN STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?P' THEN 'CREDIT PLAN STORE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?Q' THEN 'COLLECTIONS - NON-MANUAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?R' THEN 'CREDIT BUREAU'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?R' THEN 'CREDIT PLAN DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?S' THEN 'INSUFF CLASS DOWN PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?T' THEN 'CHECK VERIFICATION BAD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?U' THEN 'WARNING CODE 1-8'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?V' THEN 'DELINQUENT LEVEL 1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?W' THEN 'CHARGE-OFF ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?W' THEN 'DELINQUENT LEVEL 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?X' THEN 'PAID P&L ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?Y' THEN 'RETURNED CHECKS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?Y' THEN 'SEVERE RETURNED CHECKS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='?Z' THEN 'DEFAULT ACTION CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@A' THEN 'GENERAL TRANSACTION DENIAL RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@B' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@H' THEN 'INVALID ABA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@I' THEN 'CALL ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@J' THEN 'TRY AGAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@K' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@L' THEN 'ISSUER INOPERATIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='@M' THEN 'SYSTEM MALFUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[A' THEN 'INVALID BIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[B' THEN 'INVALID CARD RANGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[C' THEN 'CARD NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[D' THEN 'INVALID ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[E' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[F' THEN 'OVER SALE LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[G' THEN 'OVER CARD VELOCITY COUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[H' THEN 'OVER CARD VELOCITY AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[I' THEN 'OVER ISSUER VELOCITY COUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[J' THEN 'OVER ISSUER VELOCITY AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[K' THEN 'HOST UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[L' THEN 'SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[M' THEN 'INVALID VALIDATION REASON CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[N' THEN 'NON PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[O' THEN 'REVOKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[P' THEN 'CARD SURRENDERED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[Q' THEN 'CARD STOLEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[R' THEN 'TEMPORARY HOLD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[S' THEN 'DELETED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[T' THEN 'MISCELLANEOUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[U' THEN 'INVALID SITE ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='[U' THEN 'VIP APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{0' THEN 'NEW PASSWORD REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{1' THEN 'BALANCE NOT AVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{2' THEN 'ACCOUNT LOCKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{3' THEN 'NO PREVIOUS TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{4' THEN 'ALREADY REVERSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{5' THEN 'GENERAL DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{6' THEN 'BAD AUTHORIZATION CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{7' THEN 'TOO MANY TRANSACTIONS REQUESTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{8' THEN 'NO/NO MORE TRANSACTIONS AVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{9' THEN 'TRANSACTION HISTORY NOT AVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{A' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{a' THEN 'INVALID STATUS CHANGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{B' THEN 'ACCOUNT CLOSED (BAL. MAY BE 0)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{b' THEN 'VOID OF ACTIVATION AFTER ACTIVITY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{c' THEN 'NO PHONE SERVICE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{C' THEN 'UNKNOWN ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{D' THEN 'INACTIVE ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{d' THEN 'INTERNET ACCESS DISABLED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{e' THEN 'BAD EAN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{E' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{f' THEN 'BAD MERCHANT KEY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{F' THEN 'INVALID TRANSACTION CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{G' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{g' THEN 'PROMOS FOR INET/PHYS CARDS MISMATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{H' THEN 'ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{h' THEN 'INVALID TRANSACTION SOURCE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{i' THEN 'ACCOUNT ALREADY LINKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{I' THEN 'SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{j' THEN 'ACCOUNT NOT ACTIVE IN STATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{J' THEN 'LOST OR STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{K' THEN 'NOT LOST OR STOLEN (REPLACE TRX)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{k' THEN 'RESVD FOR CALL INTERACTIVE INET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{L' THEN 'INVALID TRANSACTION FORMAT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{l' THEN 'RESVD FOR CALL INTERACTIVE INET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{M' THEN 'BAD MAG STRIPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{m' THEN 'RESVD FOR CALL INTERACTIVE INET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{n' THEN 'CURR FLAG SET BUT INTL FLAG IS NOT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{N' THEN 'INCORRECT MERCHANT LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{o' THEN 'INVALID CURRENCY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{O' THEN 'MAX BALANCE EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{P' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{p' THEN 'REQUEST NOT INTERNATIONAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{q' THEN 'CURRENCY CONVERSION ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{Q' THEN 'INVALID CLERK (WHERE REQUIRED)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{R' THEN 'INVALID PASSWORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{r' THEN 'LINE NOT UP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{s' THEN 'AUTHORIZOR NOT AVAILABLE (TIME OUT)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{S' THEN 'INVALID NEW PASSWORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{T' THEN 'CLERK EXCEEDED ALLOWED ACCT RELOADS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{t' THEN 'SYSTEM MALFUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{U' THEN 'PASSWORD RETRY COUNT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{u' THEN 'PRODUCT CODE RESTRICTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{v' THEN 'FUEL ONLY RESTRICTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{V' THEN 'INCORRECT TRAN VER OR FORMAT NBR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{W' THEN 'INVALID TRX FOR THIS ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{w' THEN 'RELOADABLE ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{X' THEN 'INVALID TRX FOR THIS LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{Y' THEN 'BAD REPLAY DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='{Z' THEN 'BAD CHECKSUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~B' THEN 'FORMAT OF COMMUNICATIONS PACKET IS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~C' THEN 'CARD ACCOUNT NOT FOUND. RESPONSE FO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~D' THEN 'VEHICLE CARD ACCOUNT NOT FOUND. RES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~E' THEN 'EMPLOYEE CARD ACCOUNT NOT FOUND. RE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~F' THEN 'TERMINAL IDENTIFIER IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~G' THEN 'FUEL PRODUCT CODE IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~H' THEN 'PERSON IDENTIFIER NUMBER IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~I' THEN 'PRODUCT CODE NOT ALLOWED FOR LOCATI'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~J' THEN 'CARD ACCOUNT HAS EXCEEDED LIMIT FOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~K' THEN 'CARD ACCOUT HAS EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~L' THEN 'TRANSACTION DECLINED DUE TO MISC. R'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~M' THEN 'CARD(S) SHOULD BE CONFISCATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~N' THEN 'SYSTEM IS UNABLE TO RESPOND/PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~O' THEN 'INTERNAL CODE FOR UNACKNOWLEDGED BU'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~P' THEN 'RESTRICTED USER, EITHER BY SITE OR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~Q' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~R' THEN 'INVALID FORMAT TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~S' THEN 'VEHICLE NUMBER IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~T' THEN 'DRIVER ID IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~U' THEN 'CLIENT AND SITE ID FIELDS NOT PRES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~V' THEN 'EPS SEGMENT NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='~W' THEN 'FAILURE ON CARD ACCT BUILD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+A' THEN 'DECLINED, CALL 800/231-1930 01'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+B' THEN 'ERROR - INVALID ACCOUNT 10'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+C' THEN 'ERROR - ACCT ADD FAILED 11'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+D' THEN 'DUPLICATE CARD 12'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+E' THEN 'ACCT ALREADY EXISTS 13'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+F' THEN 'LOYALTY CARD IS EXPIRED 14'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+G' THEN 'INVALID LOYALTY REQUEST 15'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+H' THEN 'INVALID MERCHANT 16'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+I' THEN 'LOYALTY PROCESSING FAILED 20'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+J' THEN 'INSUFFICIENT POINTS IN ACCT 21'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+K' THEN 'TRAN NOT FOUND 30'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+L' THEN 'TRAN ALREADY REVERSED 31'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+M' THEN 'TRAN FOUND, NO DATA MATCH 32'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+N' THEN 'REVERSAL FAILED 33'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+O' THEN 'CREDIT SERVICE FAILED 34'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='+P' THEN 'SYSTEM FAILURE 90'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=!' THEN 'ISSUER UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=#' THEN 'VIOLATION, CANNOT COMPLETE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=%' THEN 'RE-SEND, SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=&' THEN 'TDES KEYS OR URL MISSING'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=(' THEN 'VERIFICATION ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=)' THEN 'ERROR - SEE MRC RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=*' THEN 'ACCOUNT NUMBER INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=:' THEN 'CASH BACK SERVICE NOT AVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=?' THEN 'CVV@ VALUE SUPPLIED IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=@' THEN 'DESTINATION NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=^' THEN 'CARD ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=^' THEN 'CARD ALREADY ISSUED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=^' THEN 'DUPLICATE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=<' THEN 'BEYOND ALLOWED VOID PERIOD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=<' THEN 'EXPIRE DATE OUTSIDE ISSUE PERIOD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=<' THEN 'INVALID EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='==' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='==' THEN 'VERIFICATION ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=>' THEN 'RE-SUBMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=0' THEN 'TRANSACTION NOT PERMITTED-TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=4' THEN 'NO CHECKING ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=5' THEN 'NO SAVINGS ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=6' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=7' THEN 'INCORRECT PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=8' THEN 'NO CARD RECORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=9' THEN 'TRANSACTION NOT PERMITTED-CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=A' THEN 'SEE RESPONSE_TEXT FOR ISSUER NBR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=a' THEN 'SUSPECTED FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=b' THEN 'INVALID MERCHANT ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=B' THEN 'SEE RESPONSE_TEXT FOR ISSUER NBR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=C' THEN 'INVALID MERCHANT ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=c' THEN 'SYSTEM TEMPORARILY UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=c' THEN 'TEMPORARIYLY UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=D' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=d' THEN 'SECURITY VIOLATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=e' THEN 'ACTIVITY LIMIT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=E' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=f' THEN 'EXCEEDS MAXIMUM LOAD AMOUNT/DAY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=F' THEN 'GENERAL ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=G' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=g' THEN 'EXCEEDS MAXIMUM LOAD AMOUNT/MONTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=h' THEN 'TRANS DESC EXCEEDS MAXIMUM ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=I' THEN 'INVALID EWGC MERCHANT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=i' THEN 'REPALCEMENT CARD NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=J' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=J' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=j' THEN 'MISSING TRACE ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=K' THEN 'INVALID TRANSACTION AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=K' THEN 'INVALID TRASACTION AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=k' THEN 'PIN TRIES EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=L' THEN 'INVALID CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=M' THEN 'NO SUCH ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=m' THEN 'UNABLE TO LOCATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=n' THEN 'INCONSISTENT DATA, REV. OR REPEAT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=N' THEN 'RE-ENTER TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=o' THEN 'NO ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=O' THEN 'UNABLE TO BACK OUT TRASACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=p' THEN 'ALREADY REVERSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=P' THEN 'TEMPORARILY UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=Q' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=q' THEN 'INVALID DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=r' THEN 'CRYPTOGRAPHIC ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=R' THEN 'NO CREDIT ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=R' THEN 'NO CREDIT ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=s' THEN 'CASH BACK LIMIT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=S' THEN 'PICK-UP CARD - LOST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=t' THEN 'CANNOT VERIFY PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=T' THEN 'PICK-UP CARD - STOLEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=u' THEN 'NO REASEON TO DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=v' THEN 'CANNOT VERIFY PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=W' THEN 'BALNCE AT ISSUANCE IS NOT ZERO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=w' THEN 'FIRST OR LAST NAME IS NOT PRESENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=X' THEN 'INCALID STATUS FOR ACCOUT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=x' THEN 'SOCIAL SECURITY NUMBER NOT PRESENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=y' THEN 'DATE OF BIRTH IS NOT PRESENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=Y' THEN 'INVALID STATUS FOR CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='=z' THEN 'ST 1, CITY,, STATE, OR ZIP MISSING'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='0$' THEN 'PIN LOCKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1A' THEN 'INVALID ENTRY MODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1B' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1C' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1D' THEN 'INVALID CHECK DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1E' THEN 'INVALID FLEET DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1F' THEN 'INVALID SUB-FIELD LENGTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1G' THEN 'MANUAL DEBIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1H' THEN 'NO ACCT NUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1I' THEN 'NO EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1J' THEN 'NO TRACK2 EXP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1K' THEN 'TRACK 1 NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1L' THEN 'TRANS TIMEOUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1M' THEN 'UNKNOWN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1N' THEN 'UNKNOWN TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='1O' THEN 'UNMATCHED LINK RCODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2!' THEN 'PERMANENT RESTRAINT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2#' THEN 'TIME OUT - VCC2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2$' THEN 'DUPLICATE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2&' THEN 'PIN REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2*' THEN 'REVERSAL ERROR-ORIGINAL PURCH DECL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2?' THEN 'INVALID NETWORK FOR MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2^' THEN 'MAC CARD ACTIVATION CODE -DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2+' THEN 'MAC CARD ACTIVATION CODE -ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2=' THEN 'TRANSACTION ALREADY REVERSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2A' THEN 'UNAUTHORIZED USAGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2B' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2C' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2D' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2E' THEN 'NOT ABLE TO PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2F' THEN 'NOT ABLE TO PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2G' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2H' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2I' THEN 'ATM OWNER DOES NOT SUPPORT TRANS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2J' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2K' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2L' THEN 'NO FURTHER WITHDRAWAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2M' THEN 'ENTER LESSER AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2N' THEN 'PIN TRIES EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2O' THEN 'OVER DAILY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2P' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2Q' THEN 'SYSTEM ERROR - CONTACT BANK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2R' THEN 'MESSAGE LENGTH ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2S' THEN 'INVALID DESTINATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2T' THEN 'MESSAGE EDIT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2U' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2V' THEN 'DEBIT TRAN AMOUNT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2W' THEN 'REVERSAL FORMATTING ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2X' THEN 'NO SHARING ARRANGEMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2Y' THEN 'ATM OWNER DOES NOT SUPPORT CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='2Z' THEN 'DEBIT TRAN LIMIT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3A' THEN 'EMPLOYEE NUMBER INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3B' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3C' THEN 'BAD ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3D' THEN 'ACCOUNT CLOSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3E' THEN 'OVER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3F' THEN 'BAD PIN NO.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3G' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3H' THEN 'INACTIVE TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3I' THEN 'UNATTENDED USE NOT APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3J' THEN 'OVER GAS AMOUNT FOR PERIOD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3K' THEN 'OVER CASH AMOUNT FOR PERIOD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3L' THEN 'REENTER - GAS ONLY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3M' THEN 'OVER MDSE AMOUNT FOR PERIOD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3N' THEN 'OVER REPAIR AMT FOR PERIOD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3O' THEN 'LOST CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3Q' THEN 'INVALID TERMINAL FOR BUYPASS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3R' THEN 'OVER DAILY GAS AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3S' THEN 'NOT ABLE TO BUY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3T' THEN 'INVALID FUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3U' THEN 'OVER DAILY CASH AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3V' THEN 'OVER PIN RETRY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3W' THEN 'FLEET NOT ACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3X' THEN 'OVER DAILY MERCHANDISE AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3Y' THEN 'OVER DAILY REPAIR AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='3Z' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4-' THEN 'AMT TOO LRG 3 OR 4TH PROMPT (TEX)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4!' THEN 'INVALID TIME OUT REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4#' THEN 'AMEX/DINERS MUST BE AUTH ONLY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4$' THEN 'GO INSIDE FOR AUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4&' THEN 'INVALID CARD TYPE FOR GLOBAL AID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4(' THEN '1DES DUKPT NOT AT AFP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4)' THEN 'TDES MASTER SESSION NOT ENTITLED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4*' THEN 'VOID OF RETURN NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4/' THEN 'EDIT ERROR IN OPTIONAL DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4@' THEN 'INVALID TRANS FOR MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4[' THEN 'FRAUD DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4]' THEN 'FRAUD DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4^' THEN 'TRANS NUM/INV NUM IS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4{' THEN 'FRAUD DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4}' THEN 'FRAUD DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4~' THEN 'DES NOT ALLOWED - PIN COMPLIANCE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4+' THEN 'NCS OVER 75.00 ON DEBIT CARDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4<' THEN 'PROBLEM WITH PIN PAD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4=' THEN 'AMEX START DATE NOT YET HERE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4>' THEN 'OVER MERCHANDISE RETURN LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4A' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4B' THEN 'CHECK DIGIT ERROR ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4C' THEN 'EDIT ERROR DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4D' THEN 'INVALID TERMINAL NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4E' THEN 'INACTIVE TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4F' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4G' THEN 'USED CRD KEY ON DEBIT REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4H' THEN 'OVER FLOOR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4I' THEN 'TRANSACTION TIMED OUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4J' THEN 'INVALID PUMP NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4K' THEN 'ZERO PRICE FOR PUMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4L' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4M' THEN 'PROCESS PATH FAILURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4N' THEN 'PRE-AUTH NOT ALLOWED FOR CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4O' THEN 'EDIT ERROR ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4P' THEN 'ERROR IN ROUTING OR REFERRAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4Q' THEN 'AUTHORIZER UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4R' THEN 'PROBLEM W/ENCRYPTION/DECRYPTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4S' THEN 'UNDELIVERED REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4T' THEN 'NEGATIVE FILE DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4U' THEN 'EDIT ERROR AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4V' THEN 'CREDIT CARD USED AT DFC CASH PUMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4W' THEN 'CREDIT PRICE AT CDW MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4X' THEN 'NO INVENTORY RECORD FOR MERCH/PROD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4Y' THEN 'DUPLICATE TRANSACTION FOR TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='4Z' THEN 'GAS OR MDSE IN CC CASH ADVANCE REQ'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5-' THEN 'RECHARGE AMOUNT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5!' THEN 'PRE-AUTH HOLD ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5#' THEN 'CARD BLOCKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5$' THEN 'BAD DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5&' THEN 'PROMO IS USED UP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5(' THEN 'OVER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5)' THEN 'INVALID AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5*' THEN 'AMOUNT BELOW MINIMUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5?' THEN 'NEEDS APPLICATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5@' THEN 'UNKNOWN STORE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5^' THEN 'DECLINED ACTIVATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5~' THEN 'FUEL ONLY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5+' THEN 'PARTIAL APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5=' THEN 'RECHARGE NUMBER EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5A' THEN 'PASSWORD INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5B' THEN 'INVALID TERMINAL NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5C' THEN 'NO TOTALS FOR DATE ENTERED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5D' THEN 'INVALID EMPLOYEE NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5E' THEN 'TRASH RECEIVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5F' THEN 'INVALID MERCHANT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5G' THEN 'NO INVENTORY RECORD FOR PRODUCT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5H' THEN 'VARIABLE TOTALS ALREAD CUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5I' THEN 'BEFORE 1400 AND HE CANNOT CUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5J' THEN 'SOHIO MERCHANT MUST GET MAILBOX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5K' THEN 'SOHIO MERCHANT EMPTY MAILBOX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5N' THEN 'CUTTIME TO CLOSE TO 1400'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5O' THEN 'CHECKER/MANAGER NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5P' THEN 'SECURITY INSUFFICIENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5Q' THEN 'UPDATE FAILED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5R' THEN 'NO TRANSACTION SECURITY RECORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='5S' THEN 'INSUFFICIENT DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6A' THEN 'PROCESS PATH FAILURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6B' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6C' THEN 'TRANSACTION TIMED OUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6D' THEN 'INPUT DATA FORMAT OR LENGTH ERRO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6E' THEN 'EXCEEDED MAX SIMULTANEOUS XACTIONS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6F' THEN 'COMM TEST PASSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='6G' THEN 'INV CONTACTLESS ENTRY MODE FROM FE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7A' THEN 'SUCCESSFUL TOR MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7B' THEN 'UNSUCCESSFULL TOR MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7C' THEN 'TOR HAS ALREADY BEEN REVERSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7D' THEN 'TOR SUBSYSTEM IS UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7E' THEN 'TOR QUERY RESULT TO LARGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7F' THEN 'TRAN UPDATE SUCCESFUL MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7G' THEN 'TRAN UPDATE UNSUCCESSFUL NO MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7H' THEN 'DUP CHECK SUCCESSFUL, NO MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7I' THEN 'DUP CHECK UNSUCCESSFUL, FOUND MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7J' THEN 'DUP MATCH WITHIN 15 MINUTES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7K' THEN 'DUP MATCH ON TIP EDIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7L' THEN 'HOLD SALE COMPLETION, NO MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7U' THEN 'RETRIEVAL REFERENCE, RET AMT TOO LG'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7V' THEN 'RETRIEVAL REFERENCE, RETURN DUP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7W' THEN 'RETRIEVAL REFERENCE, NO MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7X' THEN 'RETRIEVAL REFERENCE, DUP REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7Y' THEN 'RETRIEVAL REFERENCE, UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='7Z' THEN 'RETRIEVAL REFERENCE, DUP COMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8A' THEN 'INVALID DRIVERS LICENSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8B' THEN 'BIRTH CODE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8C' THEN 'HARD NEGATIVE INFO ON FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8D' THEN 'INVALID TYPE OF SERVICE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8E' THEN 'ID RESTRICTIONS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8F' THEN 'HARD NEGATIVE INFO ON FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8G' THEN 'OVER PERIODIC LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8H' THEN 'OVER MAXIMUM FACE VALUE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8I' THEN 'OVER MAXIMUM CUMULATIVE LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8J' THEN 'EDIT ERRORS IN MESSAGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8K' THEN 'INVALID STATION NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8L' THEN 'I/O ERROR, RESUBMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8M' THEN 'EXCESSIVE ACTIVITY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8O' THEN 'CALL ME'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8P' THEN 'OVER DAILY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8Q' THEN 'ENTER DL/DATE OF BIRTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8R' THEN 'CASH BACK DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8S' THEN 'CASH BACK OVERLIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='8Z' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9!' THEN 'CHECK VEL RFRL-OVER MRCH DLY COUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9#' THEN 'CHECK VEL RFRL-OVER MRCH DLY BOTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9$' THEN 'CHECK VEL RFRL-OVER MRCH PRD AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9&' THEN 'CHECK VEL RFRL-OVER MRCH PRD BOTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9(' THEN 'CHECK VEL RFRL-OVER CHAIN DLY AMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9)' THEN 'CHECK VEL RFRL-OVER CHAIN DLY BOTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9,' THEN 'CHECK VEL RFRL-OVER CHAIN PRD COUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9/' THEN 'CHECK VEL RFRL-OVER CHAIN PRD BOTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9;' THEN 'ETC DECLINE - MRCH NOT ON LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9?' THEN 'INVALID DRIVER/PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9@' THEN 'AMOUNT EXCEEDS $400'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9[' THEN 'CHECK VEL RFRL-OVER MRCH DLY AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9\' THEN 'SYSTEM ERROR - VELOCITY FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9]' THEN 'NO CHAIN ID FOR CHAIN MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9^' THEN 'ETC NEG HIT - MULTI HITS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9{' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9}' THEN 'BUYPASS INTERNAL AVS DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9~' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9+' THEN 'CHECK/LICENSE LENGTH ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9<' THEN 'CHECK VEL RFRL-OVER CHAIN PRD AMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9=' THEN 'ETC NEG HIT - SINGLE HIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9A' THEN 'COUNTRY CLUB ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9C' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9D' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9E' THEN 'DELINQUENT ACCOUNT BALANCE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9F' THEN 'STOLEN CARD REPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9G' THEN 'FRAUD REPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9H' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9I' THEN 'CREDIT LIMIT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9K' THEN 'GENERIC LIMIT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9L' THEN 'GENERIC NON PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9M' THEN 'GENERIC PRIVILEGES REVOKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9N' THEN 'GENERIC CARD SURRENDERED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9O' THEN 'GENERIC LOST OR STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9P' THEN 'GENERIC TEMPORARY HOLD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9Q' THEN 'GENERIC MISCELLANEOUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9R' THEN 'GENERIC DELETED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9S' THEN 'GENERIC INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9T' THEN 'OVER DAILY MDSE LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9U' THEN 'MERCHANT NOT ON POSITIVE FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9V' THEN 'NOT ON FLORAFAX POSITIVE FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9W' THEN 'DIAMOND SHAMROCK INVALID ACCT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9X' THEN 'DIAMOND SHAMROCK BAD CHECK DIGIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9Y' THEN 'DIAMOND - MDSE OVER $50'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='9Z' THEN 'UNOCAL INVALID EVC OR PHH NEG DWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A!' THEN 'APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A$' THEN 'PURCHASE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A:' THEN 'AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A[' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A~' THEN 'AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A+' THEN 'APPROVED 00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED ADMINISTRATIVE REQUEST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED ADMINISTRATIVE REQUEST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'APPROVED ADMINISTRATIVE REQUEST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'CASH BACK VIP OVERLIMIE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'CHECK GUARANTEED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A2' THEN 'SUCCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A3' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A3' THEN 'APPROVED TELECHECK ECA OFFERED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A5' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A8' THEN 'CHECK GUARANTEED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='A9' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AC' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AD' THEN 'APPROVED AD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AF' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AF' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AF' THEN 'APPROVED - AVS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AG' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AH' THEN 'HONOR WITH CUSTOMER ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AI' THEN 'ACCEPT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AI' THEN 'APPROVAL FOR PARTIAL AMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AJ' THEN 'ACCEPT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AJ' THEN 'ACCEPT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AK' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AK' THEN 'APPROVED FOR PARTIAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AL' THEN 'APPROVED AL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AM' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AM' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AM' THEN 'BUYPAY REVERSAL APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AM' THEN 'PARTIAL APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AN' THEN 'ACCEPT AVS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AO' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AQ' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AQ' THEN 'NO REASON TO DECLINE (ACCT VER)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AR' THEN 'BUYPAY REVERSAL APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AS' THEN 'PURCHASE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AT' THEN 'BUYPAY PAYMENT APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AV' THEN 'ACTIVATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AW' THEN 'ACCT MARKED VIP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AW' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AX' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='AZ' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B$' THEN 'PARTIAL PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B:' THEN 'COMPLETION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B~' THEN 'COMPLETION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B0' THEN 'UNKNOWN SUBSCRIBER NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B0' THEN 'UNKNOWN SUBSCRIBER NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B1' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B2' THEN 'CALL AUTH CENTER, DECLINE IN LANE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B3' THEN 'UNKNOWN DRIVERS LICENSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B4' THEN 'ANOTHER MATCH EXISTS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B4' THEN 'BLIND APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B4' THEN 'LAST MATCH CALL CENTER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B4' THEN 'SKIP TRACE INFORMATION NEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B5' THEN 'LOST STOLEN CHECKS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B6' THEN 'DECLINE CODE 3-HIGH RISK CHK WRTER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B7' THEN 'TRY AGAIN - INCORRECT MICR READ'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B8' THEN 'TRY AGAIN - FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='B9' THEN 'REJECTED NEGATIVE INFORMATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BA' THEN 'PREFERRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BB' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BC' THEN 'BLIND APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BC' THEN 'INVALID MICR DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BD' THEN 'DRIVERS LICENSE REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BE' THEN 'ZIP CODE ENTERED WAS INVALID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BJ' THEN 'ACCEPT-PREFERRED CUSTOMER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BJ' THEN 'VIP APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BV' THEN 'DEACTIVATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BW' THEN 'APPROVED 00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BW' THEN 'APPROVED - IMPRINT CARD 00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='BZ' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C-' THEN 'OVER DAILY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C$' THEN 'COMPLETION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C$' THEN 'TEXACO CARD AT NON-TEXACO LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C%' THEN 'PRODUCT NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C&' THEN 'DEACTIVATE NOT ALLOWED YET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C*' THEN 'VELOCITY FILE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C:' THEN 'REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C@' THEN 'REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C^' THEN 'RECHARGE NOT ALLOWED YET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C~' THEN 'TYPE 6 CARD - NO OFF-LINE AUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C+' THEN 'AMOUNT TOO MUCH IN 3 OR 4TH PROMPT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C=' THEN 'HOST UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C0' THEN 'OVER SINGLE TRANSACTION LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C1' THEN 'SEE ATTENDANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C2' THEN 'CALL TEXACO AUTH, RETURN MAIL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C3' THEN 'CALL HELP DESK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C4' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C5' THEN 'BAD MAG STRIPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C6' THEN 'EDIT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C7' THEN 'PICK UP CARD - NOW DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C8' THEN 'UNKNOWN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='C9' THEN 'DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CA' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CB' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CC' THEN 'INVALID VEHICLE NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CD' THEN 'INVALID ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CE' THEN 'INVALID START-UP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CF' THEN 'NETWORK REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CG' THEN 'INVALID FLEET DRIVER NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CH' THEN 'INVALID LRC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CI' THEN 'OVER FLOOR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CJ' THEN 'NETWORK UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CK' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CL' THEN 'NEGATIVE FILE DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CM' THEN 'INVALID PRE-AUTH APPROVAL NO.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CN' THEN 'TOTALS NOT BALANCED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CO' THEN 'INVALID FORMAT TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CP' THEN 'CHECK DIGIT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CQ' THEN 'INVALID ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CR' THEN 'INVALID SUB-ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CS' THEN 'INVALID EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CT' THEN 'CANADIAN CARD - NOT ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CU' THEN 'EXPIRED CARD - OVER 3 MONTHS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CV' THEN 'REFRESH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CW' THEN 'CALL CHG AUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CX' THEN 'HOLD CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CY' THEN 'USE IMPRINTER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='CZ' THEN 'INVALID PRE-AUTH CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D1' THEN 'INVALID CARD TYPE D1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D2' THEN 'TRY AGAIN D2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D3' THEN 'INVALID PREFIX D3'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D4' THEN 'INVALID CHECK DIGIT D4'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D5' THEN 'ACCOUNT NOT ON FILE D5'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D6' THEN 'FAILED ISSURE TESTS D6'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D7' THEN 'COULD NOT UPDATE ACCOUNT D7'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D8' THEN 'TRANSACTION NOT ALLOWED D8'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='D9' THEN 'HOLD CARD D9'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DA' THEN 'ACCOUNT CLOSED DA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DB' THEN 'INVALID AMOUNTS DB'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DC' THEN 'INVALID PIN DC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DE' THEN 'NO MERCHANT RECORD ON FILE DE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DF' THEN 'ACCOUNT NOT 10 DAYS OLD DF'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DG' THEN 'DAILY AMOUNT EXCEEDED DG'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DH' THEN 'DAILY MERCHANDISE AMT EXCEEDED DH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DJ' THEN 'DAILY CASH AMOUNT EXCEEDED DJ'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DK' THEN 'CASH BACK AMT BELOW MINIMUM DK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DL' THEN 'TOO MANY CARD USES TODAY DL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DM' THEN 'TOO MANY CARD USES THIS MONTH DM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DN' THEN 'INVALID TRANSACTION TYPE DN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DP' THEN 'NO SHARING GROUP MATCH DP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DQ' THEN 'OFFSET PIN NOT AVAILABLE DQ'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DR' THEN 'TOTAL TRAN. AMOUNT EXCEEDED DR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DS' THEN 'TOO MANY CARD USES THIS WEEK DS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DT' THEN 'WEEKLY AMOUNT EXCEEDED DT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DU' THEN 'DAILY CASH-ONLY AMOUNT EXCEEDED DU'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DV' THEN 'REFRESH VOID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DV' THEN 'WEEKLY CASH-ONLY AMT EXCEEDED DV'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DW' THEN 'WEEKLY CASH-ONLY CNT EXCEEDED DW'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DX' THEN 'TEMPORARY CARD ONLY DX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='DY' THEN 'VIDEO CARD ONLY DY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E1' THEN 'CALL ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E1' THEN 'CALL ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E2' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E3' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E4' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E4' THEN 'DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E5' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E6' THEN 'INVALID ACCOUNT NBR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E6' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E7' THEN 'FILE UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E8' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='E9' THEN 'INVALID TICKET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EA' THEN 'LOST/STOLEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EA' THEN 'PICK-UP CARD - LOST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EB' THEN 'PICK-UP CARD - STOLEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EC' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ED' THEN 'INCORRECT PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EE' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EF' THEN 'EXCESSIVE PIN ATTEMPTS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EG' THEN 'INVALID CVV'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EH' THEN 'UNABLE TO VERIFY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EI' THEN 'UNABLE TO ROUTE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EJ' THEN 'SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EK' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EL' THEN 'NEG FILE SIGNATURE REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='EX' THEN 'BAD EMV DATA ON REQUEST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F-' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F%' THEN 'UNABLE TO MAKE NETWORK LINK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F(' THEN 'ROUTING ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F)' THEN 'CANNOT COMPLETE (VIOLATION OF LAW)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F*' THEN 'DUPLICATE AUTH REQUEST'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F~' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F+' THEN 'SYSTEM MALFUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F=' THEN 'BUYPASS INTERNAL AVS DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F0' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F1' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F5' THEN 'SECURITY VIOLATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F6' THEN 'WITHDRAWAL FREQUENCY EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F7' THEN 'RESPONSE RECEIVED TOO LATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='F8' THEN 'EXCEEDED ALLOWABLE # PIN ENTRIES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FA' THEN 'CALL DISCOVER CARD CENTRAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FC' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FD' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FE' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FF' THEN 'ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FG' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FH' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FI' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FJ' THEN 'INVALID CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FK' THEN 'INVALID PREFIX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FN' THEN 'CARDMEMBER NOT ON FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FP' THEN 'MESSAGE FORMAT PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FS' THEN 'FUNCTION UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FT' THEN 'PICK UP CARD (LOST CARD)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FU' THEN 'PICK UP CARD (STOLEN CARD)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FV' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FX' THEN 'NO SAVINGS ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='FZ' THEN 'INCORRECT PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='G$' THEN 'REPLACE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='G=' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='G9' THEN 'APPROVED - MDSE GT $20.00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GA' THEN 'DECLINED INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GB' THEN 'DECLINED INVALID SUB-ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GC' THEN 'DECLINED CHECK DIGIT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GD' THEN 'DECLINED - REFERRAL OVER $200'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GE' THEN 'DECLINED - PRE-AUTH OVER $1000'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GF' THEN 'DECLINED - COUNTRY CLUB ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GG' THEN 'NEG - SOHIO/GULF REFERRAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GH' THEN 'NEG - LOST, STOLEN OR DELINQUENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GI' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GJ' THEN 'DECLINED - JOBBER CC ACCT ENTRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GK' THEN 'DECLINED - JOBBER NEED APPRV NO'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GL' THEN 'CHEVRON PRE-AUTH OVER $500'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GM' THEN 'NEG - CHEVRON REFERRAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GN' THEN 'APPROVED - SEND TO HOME OFFICE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GO' THEN 'CARD NOT ACCEPTED AT LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GQ' THEN 'CUMBERLAND LMT OVER 400 REFERAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GR' THEN 'CUMB - CARD INVLD FOR HOME HEAT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='GS' THEN 'DECLINED - MDISE > $35 DAILY LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H!' THEN 'INVALID EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H$' THEN 'CARD ACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H$' THEN 'CARD ACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H&' THEN 'TENDER INSIDE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H@' THEN 'INVALID ACCOUNT GENERAL DECLINE?'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H0' THEN 'ACCOUNT OVER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H1' THEN 'OVER NON-FUEL LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H2' THEN 'OVER DAILY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H3' THEN 'CARD NOT ALLOWED AT NON SUN LOC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H4' THEN 'CARD NOT ALLOWED AT NON SUN LOC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H5' THEN 'TRANSACTION NOT PERMITTED TO CH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H6' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H6' THEN 'NETWORK TIMED OUT/NO RESPONSE RVSL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H7' THEN 'INVALID TXN DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H8' THEN 'DUPLICATE TXN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H9' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='H9' THEN 'NETWORK TIMED OUT/NO RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HA' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HB' THEN 'PLACED ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HC' THEN 'RESPONSE CODE 1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HD' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HE' THEN 'USE IMPRINTER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HF' THEN 'VOYAGER ID PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HG' THEN 'NSF CHECK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HH' THEN 'VOYAGER DRIVER ID VEL EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HI' THEN 'CR CL NON-ELECT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HJ' THEN 'NON-ELECTRONIC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HK' THEN 'LOST CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HL' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HM' THEN 'VELOCITY EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HN' THEN 'REFERRAL AMOUNT EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HO' THEN 'PIN ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HP' THEN 'AUTH CODE NEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HQ' THEN 'DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HR' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HS' THEN 'APPROVED PREAUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HT' THEN 'APPROVED MDSE RETURN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HU' THEN 'COMPLETED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HV' THEN 'ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HW' THEN 'VOIDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HX' THEN 'BAD DRIVER NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HY' THEN 'ACCOUNT VERIFICATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='HZ' THEN 'INVALID ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I$' THEN 'BALANCE INQUIRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I=' THEN 'BUYPASS INTERNAL AVS DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I1' THEN 'INVALID ID NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I2' THEN 'INVALID DRIVER NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I3' THEN 'INVALID VEHICLE NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I4' THEN 'SECURITY VIOLATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I5' THEN 'CRYPTOGRAPHIC FAILURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='I7' THEN 'WAL-MART CVC NO MATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IA' THEN 'REFER TO CARD ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IB' THEN 'CAPTURE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IC' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IC' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IC' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ID' THEN 'INVALID AMOUNT FIELD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IE' THEN 'INVALID CARDHOLDER NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IF' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IG' THEN 'LOST CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IH' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='II' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IJ' THEN 'INVALID EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IK' THEN 'EXCEEDS WITHDRAWAL AMOUNT LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IL' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IM' THEN 'EXCEEDS WITHDRAWAL COUNT LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IN' THEN 'SWITCH/ISSUER INOPERATIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IO' THEN 'UNABLE TO ROUTE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IP' THEN 'SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IQ' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IR' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IS' THEN 'TRANSACTION NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IS' THEN 'TRANSACTION NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IT' THEN 'INVALID ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IT' THEN 'INVALID ACCOUNT SPECIFIED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IU' THEN 'DUPLICATE TRANSMISSION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IU' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IV' THEN 'INVALID ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IW' THEN 'HONOR WITH IDENTIFICATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IX' THEN 'NO ICA FOR THIS BANK FIID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IY' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IY' THEN 'PIN NOT CHANGED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IY' THEN 'PIN VALIDATION NOT POSSIBLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='IY' THEN 'UNACCEPTABLE PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='J$' THEN 'CARD DEACTIVATED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='J=' THEN 'BUYPASS INTERNAL AVS DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JA' THEN 'PLEASE CALL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JA' THEN 'PLEASE CALL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JB' THEN 'DENY - CANCELLED OR CLOSED MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JB' THEN 'INVALID MERCHANT ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JB' THEN 'INVALID MERCHANT ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JC' THEN 'INVALID ACCOUNT - CANCELLED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JC' THEN 'INVALID ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JC' THEN 'INVALID ACCOUNT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JD' THEN 'INVALID DOLLAR AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JD' THEN 'INVALID DOLLAR AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JE' THEN 'INVALID EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JF' THEN 'UNMATCHED LINK RETURN CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JG' THEN 'HOST/CARD ISSUER TIMEOUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JG' THEN 'HOST/CARD ISSUER UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JG' THEN 'LINK NOT AVAILABLE FOR AUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JH' THEN 'DENY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JI' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JK' THEN 'SERVICE NOT PERMITTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JL' THEN 'INVALID CARD SECURITY CODE (CID)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JM' THEN 'INVALID EFFECTIVE DARE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JN' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JO' THEN 'INVALID CURRENCY CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JP' THEN 'DENY - PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JP' THEN 'NEW CARD ISSUED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JQ' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JR' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JS' THEN 'ACCEPT WITH ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JT' THEN 'ACCEPT - GIVE COURTESY CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JU' THEN 'APPROVE VIP CUSTOMER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JV' THEN 'DOUBLE LENGTH PINDATA UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JW' THEN 'EXCESSIVE PIN ATTEMPTS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='JX' THEN 'CRYPTOGRAPHIC ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K!' THEN 'FUEL ONLY CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K#' THEN 'STOP ORDER, THIS PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K$' THEN 'CARD RECHARGED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K@' THEN 'BUYPASS INTERNAL AVS DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K^' THEN 'BUYPASS INTERNAL CVV DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K~' THEN 'ACCOUNT CLOSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K=' THEN 'STOP ORDER, ALL PAYMENTS THIS CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K=' THEN 'STOP ORDER, ALL PAYMENTS THIS CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K1' THEN 'INVALID PRODUCT RESTRICTION CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K2' THEN 'INVALID ID NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K3' THEN 'CANNOT COMPLETE (VIOLATION OF LAW)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K4' THEN 'SYSTEM MALFUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K5' THEN 'INVALID TRACK II LENGTH (REJECT)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K6' THEN 'INVALID TRACK II (REJECT)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K7' THEN 'MATCH FOUND ON VISA BIN TABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K8' THEN 'PIN REQUIRED - SIC 6011 (REJECT)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='K9' THEN 'GENERIC REJECT (REJECT)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KC' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KD' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'BLOCKED CARD,NEED TO BE UNBLOCKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'EXCEEDS APPROVAL LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'NEGATIVE CAM OR DCVV RESULT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'SUSPECTED FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KE' THEN 'VERIFICATION DATA FAILED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KF' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KG' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KH' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KI' THEN 'INVALID CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KJ' THEN 'NO SUCH ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KK' THEN 'RE-ENTER TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KL' THEN 'REVERSAL FAILURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KM' THEN 'PICK UP CARD (LOST CARD)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KN' THEN 'PICK UP CARD (STOLEN CARD)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KO' THEN 'EXCEEDS WITHDRAWAL FREQ LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KO' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KP' THEN 'NO CHECKING ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KQ' THEN 'NO SAVINGS ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KR' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KS' THEN 'INCORRECT PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KS' THEN 'PIN RETRY EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KT' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KU' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KV' THEN 'UNABLE TO LOCATE PREVIOUS MSG'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KW' THEN 'REVERSAL DATA INCONSISTENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KY' THEN 'UNABLE TO VERIFY PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='KZ' THEN 'ISSUER OR SWITCH INOPERATIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L$' THEN 'CANCELLATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L0' THEN 'INSUFFICIENT INFORMATION L0'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L1' THEN 'SLOW PAYMENT L1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L2' THEN 'OUT OF TERRITORY L2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L3' THEN 'STOLEN CARD L3'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L4' THEN 'STOP BY CUSTOMER REQUEST L4'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L5' THEN 'BILLING CYCLE CHANGE L5'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L6' THEN 'DIAMOND SHAMROCK INVALID ACCT L6'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L7' THEN 'DECEASED L7'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L8' THEN 'DEROGATORY L8'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='L9' THEN 'PROBLEM WITH ANOTHER ACCOUNT L9'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LB' THEN 'OVER DAILY LIMIT LB'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LC' THEN 'DIAMOND SHAMROCK BAD CHECK DIG LC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LD' THEN 'DIAMOND MDSE OVER $50 LD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LE' THEN 'COUNTRY CLUB ACCOUNT LE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LF' THEN 'DIAMOND UCC NOT ON FILE LF'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LG' THEN 'DIAMOND UCC NEG FILE DECLINE LG'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LH' THEN 'DIAMOND UCC INVALID STATE LH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LI' THEN 'DIAMOND REPAIR OVER $300 LI'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LJ' THEN 'IMPRINT THE CARD LJ'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LK' THEN 'NON-FUEL ON FUEL ONLY CARD LK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='LL' THEN 'DECLINED AFT - SEE ATTENDANT LL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='M$' THEN 'RETURN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='M[' THEN 'MERCHANDISE RETURN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='M2' THEN 'MERCHANDISE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='M3' THEN 'MERCHANDISE RETURN O.K.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='M4' THEN 'MERCHANDISE RETURN O.K.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='M9' THEN 'MERCHANDISE RETURN O.K.'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MA' THEN 'CALL ACQUIRER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MA' THEN 'CONTACT ACQUIRER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MA' THEN 'REFER TO ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MA' THEN 'REFER TO ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MB' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MB' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'CALL SECURITY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'CAPTURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'CONTACT SECURITY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'EXPIRED CARD, PICK UP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'PICK UP CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'PLEASE RETRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'STOLEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MC' THEN 'SUSPECTED FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MD' THEN 'APPROVE MERCHANDISE RETURN MD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MD' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ME' THEN 'APPROVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ME' THEN 'CUTOFF IN PROGRESSS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ME' THEN 'ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ME' THEN 'LATE RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ME' THEN 'SYSTEM MALFUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MF' THEN 'GET ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MG' THEN 'MERCHANDISE RETURN ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MG' THEN 'REQUEST ALREADY IN PROGRESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MI' THEN 'INACTIVE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MI' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MI' THEN 'NO CARD RECORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MI' THEN 'NO CARD RECORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MJ' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MK' THEN 'NO CHECKING ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MK' THEN 'NO INVESTMENT ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MK' THEN 'NO SAVINGS ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MK' THEN 'NO UNIVERSAL ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ML' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ML' THEN 'MERCHANDISE RETURN O.K. ML'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MM' THEN 'NO SAVINGS ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MM' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MM' THEN 'SECURITY VIOLATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MM' THEN 'SYNC ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'BANK NOT SUPPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'CANNOT BE COMPLATED VIOLATION LAW'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'CANNOT VERIFY PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'CARDHOLDER CANNOT USE POS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'COUNT EXCEEDS LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'FI CANNOT BE COMPLETED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'INFORMATION NOT ON FILE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'INVALID RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'NO SUCH ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'RECONCILE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'STALE DATED TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'TIME FOR PRE-AUTH REACHED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'TRAN NOT PERMITTED TO CARDHOLDER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'TRAN NOT PERMITTED TO TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MN' THEN 'UNACCEPTABLE TRAN FEE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MO' THEN 'EXP DATE MISMATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MO' THEN 'EXP DATE MISMATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MO' THEN 'EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MO' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MP' THEN 'BAD PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MP' THEN 'BAD PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MP' THEN 'PIN TRIES EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MQ' THEN 'SUSPECTED FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MT' THEN 'EXCEEDS WITHDRAWL FREQUENCY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MV' THEN 'INVALID CVV/CVC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MW' THEN 'MERCHANDISE RETURN ACCEPTED 00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MX' THEN 'DUPLICATE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='MZ' THEN 'CARD ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='N$' THEN 'INVALID CUSTOMER TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='N4' THEN 'NTL NEG FILE APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='N7' THEN 'CVV FAILURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NA' THEN 'EXCEEDS DAILY COUNT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NB' THEN 'EXCEEDS DAILY AMOUNT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NC' THEN 'NEG FILE APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ND' THEN 'EXCEEDS PERIOD COUNT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NE' THEN 'EXCEEDS PERIOD AMOUNT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NF' THEN 'EXCEEDS PERIOD CNT, AMT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NG' THEN 'EXCEEDS DAILY COUNT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NH' THEN 'EXCEEDS DAILY AMOUNT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NJ' THEN 'EXCEEDS DAILY CNT, AMT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NK' THEN 'EXCEEDS PERIOD COUNT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NL' THEN 'EXCEEDS PERIOD AMOUNT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NM' THEN 'EXCEEDS PERIOD CNT, AMT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NP' THEN 'NEGATIVE FILE HIT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NR' THEN 'NEGATIVE FILE HIT - CHAIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='NX' THEN 'EXCEEDS DAILY CNT, AMT - MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O!' THEN 'SETTLEMENT OUT OF BALANCE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O#' THEN 'ACH REJECT RESUBMISSION - DR MERCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O$' THEN 'FDC ADJUSTMENT FEE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O%' THEN 'NETWORK ADJUSTMENT FEE PASS THRU'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O@' THEN 'ACH REJECT RESUBMISSION - CR MERCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O^' THEN 'CARD DID 2 TRANS, ONLY CHARGE 1'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O0' THEN 'CARDHOLDER ALREADY CHARGED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O1' THEN 'INVALID DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O2' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O3' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O4' THEN 'DECLINED BY BANK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O5' THEN 'VALID TRAN - MERC PROVIDED RECEIPT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O6' THEN 'ADJUSTMENT UNDER NETWORK MINIMUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O7' THEN 'MERCHANT NEVER CHARGED CARDHOLDER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O8' THEN 'DECLINED BY NETWORK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='O9' THEN 'INSUFFICIENT DOCUMENTATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OA' THEN 'REVERSED IN ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OB' THEN 'CHARGED MULTIPLE TIMES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OC' THEN 'PAID WITH OTHER FORM OF PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OD' THEN 'CHARGED WRONG AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OE' THEN 'AUTO FUEL PUMP PREAUTHORIZE DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OF' THEN 'CHARGED IN ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OG' THEN 'OFFLINE RESUBMITTED FOR PAYMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OH' THEN 'DISPUTING ADJUSTMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OI' THEN 'REPRESENTMENT OF CHARGEBACK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OJ' THEN 'CARDHOLDER NOT CHARGED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OK' THEN 'NO GOODS OR FUNDS RECEIVED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OL' THEN 'PURCHASE DID NOT SETL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OM' THEN 'REVERSAL DID NOT SETL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ON' THEN 'CORRECTING ENTRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OO' THEN 'ADJ REVERSAL - ACCT CLOSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OP' THEN 'ADJ REVERSAL - INVALID DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OQ' THEN 'ADJ REVERSAL - NSF'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OR' THEN 'ADJ REVERSAL - CREDIT CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OS' THEN 'ADJ REVERSAL - PREVIOUSLY PROCESSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OT' THEN 'ADJ REVERSAL - BANK DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OU' THEN 'ADJ REVERSAL - GOOD FAITH DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OV' THEN 'NON-SUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OW' THEN 'PAST NETWORK DEADLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OX' THEN 'ACCOUNT CLOSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OY' THEN 'CREDIT CARD ADJUSTMENT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='OZ' THEN 'PREVIOUSLY PROCESSED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P!' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P#' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P$' THEN 'PRE-AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P%' THEN 'NO ACTION TAKEN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P&' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P(' THEN 'REQUESTED FUNCTION NOT SUPPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P)' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P*' THEN 'SUSPECTED FRAUD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P@' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P^' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P+' THEN 'TRANS NOT PERMITED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P=' THEN 'RESPONSE RECEIVED TOO LATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P>' THEN 'INVALID CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P1' THEN 'CUTOFF IN PROGRESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P2' THEN 'ISSUER OR SWITCH INOPERATIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P3' THEN 'ROUTING ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P4' THEN 'PRE-AUTH ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P5' THEN 'DUPLICATE TRANSMISSION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P6' THEN 'RECONCILE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P7' THEN 'SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P8' THEN 'FASTCARD/FASTPIN ALREADY REDEEMED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='P9' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='PC' THEN 'PRE-AUTH ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='PD' THEN 'APPROVE PREAUTH PD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='PG' THEN 'PRE-AUTH ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='PW' THEN 'PRE-AUTH ACCEPTED 00'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q!' THEN 'ALREADY REDEEMED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q#' THEN 'INVALID PHONE NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q$' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q%' THEN 'MAX RECHARGE REACHED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q&' THEN 'RQST NOT PERMITTED BY MRCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q*' THEN 'ENTER LESSER AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q@' THEN 'UNABLE TO PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q1' THEN 'INVALID TRANSACTION TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q2' THEN 'DUPLICATE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q3' THEN 'GENERAL DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q4' THEN 'INVALID CHECK DIGIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q5' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q7' THEN 'INVALID AUTH TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Q8' THEN 'CARD ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QA' THEN 'REFER TO ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QB' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QC' THEN 'DO NOT HONOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QD' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QE' THEN 'CARD ACTIVATION REQUIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QF' THEN 'CARD ACTIVATION FAILED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QG' THEN 'ENTER LESSER AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QG' THEN 'MERCH APPROVED - CASH DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QH' THEN 'ISSUER UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QH' THEN 'ISSUER UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QI' THEN 'INVALID STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QK' THEN 'CARD ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QL' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QM' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QN' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QO' THEN 'LOST CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QP' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QQ' THEN 'NOT SUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QT' THEN 'CAF NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QU' THEN 'INVALID EXTERN ACCOUNT NUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QV' THEN 'EXCEEDS LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QW' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='QX' THEN 'EXCEEDS WITHDRAWL FREQUENCY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R!' THEN 'INVALID TIME OUT REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R$' THEN 'REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R1' THEN 'NOT A DEBIT CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R3' THEN 'NO VALID NETWORK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R4' THEN 'REVERSAL ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R5' THEN 'NO SHARE GROUP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='R6' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RC' THEN 'DEBIT ONLY MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RD' THEN 'CREDIT ONLY MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RF' THEN 'NOT ABLE TO PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RG' THEN 'INVALID TRANS (TEST CARD ONLY)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RL' THEN 'RETURN MAIL RL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RS' THEN 'SURCHARGE FLAG SET TO "N"'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='RS' THEN 'SURCHARGE NOT ALLOWED FOR NETWORK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='S0' THEN 'TRANS TIMEOUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='S1' THEN 'INVALID TIMESTAMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='S9' THEN 'RETURN MAIL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SA' THEN 'ACCOUNT OVER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SB' THEN 'CAPTURE CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SC' THEN 'ACCOUNT CANCELLED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SD' THEN 'ACCOUNT OVER LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SE' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SF' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SG' THEN 'NO PRE AUTH FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SH' THEN 'NON-ELECTRONIC ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SR' THEN 'INVALID CARD TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SS' THEN 'DENIAL,NO PRE-AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ST' THEN 'INVALID FORMAT TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SU' THEN 'INVALID AMOUNT FOR RECHARGE VALUE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SV' THEN 'UNMATCHED LINK RESPONSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SW' THEN 'LINE IS DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SX' THEN 'FASTWRITE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SY' THEN 'QUEUE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='SZ' THEN 'INVALID REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TA' THEN 'INVALID REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TB' THEN 'BUYPAY BILL NOT = PAYMENTS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TC' THEN 'BUYPAY INVALID UTILITY ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TD' THEN 'BUYPAY NO PAYMRCH RECORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TE' THEN 'BUYPAY INVALID CARD DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TF' THEN 'BUYPAY INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TG' THEN 'BUYPAY AUTH LINK DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TH' THEN 'BUYPAY INVALID PASSWORD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TI' THEN 'BUYPAY ACCOUNT EDIT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TK' THEN 'BUYPAY NEG FILE DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TL' THEN 'APPROVED - MDSE GT $20.00 TL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='TL' THEN 'BUYPAY TOTAL NOT = CSH+CK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U!' THEN 'DRV OVER MTHLY OTHR LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U?' THEN 'SYSTEM ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U<' THEN 'NO DRIVER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U>' THEN 'NO PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U0' THEN 'FLT OVER MTHLY MDSE LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U1' THEN 'FLT OVER MTHLY SRVC LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U2' THEN 'FLT OVER MTHLY OTHR LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U3' THEN 'VEH OVER MTHLY FUEL LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U4' THEN 'VEH OVER MTHLY MDSE LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U5' THEN 'VEH OVER MTHLY SRVC LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U6' THEN 'VEH OVER MTHLY OTHR LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U7' THEN 'DRV OVER MTHLY FUEL LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U8' THEN 'DRV OVER MTHLY MDSE LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U9' THEN 'DRV OVER MTHLY SRVC LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='U9' THEN 'SPECIAL APPROVAL FOR UNOCAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UA' THEN 'INVALID DRIVER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UB' THEN 'INVALID VEHICLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UC' THEN 'INVALID FLEET'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UD' THEN 'NEGATIVE STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UE' THEN 'INVALID FUEL TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UF' THEN 'NOT AUTH FOR MDSE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UG' THEN 'NOT AUTH FOR SRVC'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UH' THEN 'NOT AUTH FOR OTHR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UI' THEN 'NOT ABLE TO BUY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UJ' THEN 'INVALID PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UK' THEN 'EXCEEDED PIN TRIES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UL' THEN 'LOST CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UM' THEN 'INVALID MERCHANT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UN' THEN 'INACTIVE TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UO' THEN 'INVALID TERMINAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UP' THEN 'INVALID FUNCTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UQ' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UR' THEN 'VEH OVER DAILY FUEL LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='US' THEN 'VEH OVER DAILY MDSE LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UT' THEN 'VEH OVER DAILY SRVC LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UU' THEN 'VEH OVER DAILY OTHR LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UV' THEN 'DRV OVER DAILY FUEL LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UW' THEN 'DRV OVER DAILY MDSE LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UX' THEN 'DRV OVER DAILY SRVC LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UY' THEN 'DRV OVER DAILY OTHR LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='UZ' THEN 'FLT OVER MTHLY FUEL LMT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V!' THEN 'CALL AUTHORIZER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V#' THEN 'PIN DOES NOT SUPPORT TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V$' THEN 'FORMAT ERRROR OF SOME SORT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V%' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V%' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V%' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V%' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V%' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V%' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V@' THEN 'INVALID SITE ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V1' THEN 'QUEUE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V2' THEN 'INVALID REVERSAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V3' THEN 'MSG TIMEOUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V4' THEN 'INVALID TIMESTAMP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V5' THEN 'INVALID FORMAT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V6' THEN 'INVALID CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V7' THEN 'UNKNOWN TRANS TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V8' THEN 'INVALID AUTHORIZER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='V9' THEN 'INVALID MESSAGE TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VA' THEN 'PIN TN NOT FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VB' THEN 'CUSTOMER DOES NOT OWN PTN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VC' THEN 'NOT A POS PIN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VD' THEN 'ALREADY ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VE' THEN 'ALREADY INACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VF' THEN 'SUSPENDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VG' THEN 'ALREADY REFRESHED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VH' THEN 'ALREADY REFRESH VOIDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VI' THEN 'NO SUCCESSFUL REFRESH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VJ' THEN 'PIN RECORD LOCKED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VK' THEN 'PIN NOT ACTIVE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VL' THEN 'PIN SUSPENDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VM' THEN 'PIN EXPIRED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VN' THEN 'PIN NOT CHARGEABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VO' THEN 'PIN NOT REFRESHABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VP' THEN 'NUMBER OF UNITS MISMATCHED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VQ' THEN 'BAD PURCHASE AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VR' THEN 'NUMER OF UNITS OUT OF RANGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VS' THEN 'INVALID DOLLAR AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VT' THEN 'TOO MANY UNITS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VU' THEN 'INVALID CUSTOMER/STORE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VV' THEN 'TOO FEW UNITS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VW' THEN 'LOGON/LOGOFF IN PROCESS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VX' THEN 'UNMATCHED HOST RESP'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VY' THEN 'LINE DOWN'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='VZ' THEN 'FASTWRITE ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W!' THEN 'INVALID CARD, USER, OR TERM STATUS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W#' THEN 'EXCEEDS DAILY $LIMIT PER PRODCLASS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W$' THEN 'INVALID WEEKDAY AND TIME OF DAY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W%' THEN 'CAV - SUSPECT COUNTERFEIT CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W&' THEN 'UNRECOGNIZED AREA CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W(' THEN 'EXCEEDS TRANS QTY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W)' THEN 'INVALID PROMPT ENTRY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W*' THEN 'QTY ALLOWED 0 FOR ALL PRODUCTS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W@' THEN 'INVALID PRODUCT CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W^' THEN 'PRODUCT RESTRICTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W+' THEN 'INVALID TRACK2 / INVALID MESSAGE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W=' THEN 'UNABLE TO ACCESS DATABASE FILES'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W0' THEN 'EXCEEDS TOTAL DAILY DOLLAR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W1' THEN 'EXCEEDS DAILY WITHDRAWAL AMT LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W2' THEN 'INVALID DRIVER ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W3' THEN 'INVALID VEHICLE ID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W4' THEN 'INVALID LOCAL DATE/TIME'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W5' THEN 'EXCEEDS DAILY DOLLAR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W6' THEN 'BAD OPTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W7' THEN 'EXCEEDS NBR OF TRANS ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W8' THEN 'CARD OUT OF NETWORK'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='W9' THEN 'INVALID ACCOUNT OR LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WA' THEN 'DECLINED, CALL 800/231-1930 99'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WC' THEN 'EXPIRED CARD 97'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WD' THEN 'EXCEEDS TXN TOTLIMIT PER PRODCLASS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WE' THEN 'EXCEEDS TXN DAYNBR PER PRODCLASS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WF' THEN 'COMPLETION APPRVCD ALL ZEROES BEI'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WG' THEN 'WEX DOES NOT SUPPORT REVERSALS BEI'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WH' THEN 'CALL FOR CREDIT APPROVAL(SEE WA)02'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WI' THEN 'DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WM' THEN 'DECLINED - PICK UP CARD 07'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WO' THEN 'INVALID CARD NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WP' THEN 'APPROVED - PARTIAL AUTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WR' THEN 'NO ACCOUNT OF TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WS' THEN 'WEX CARD NOT ALLOWED 54'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WT' THEN 'TERMINAL RESTRICTION 51'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WU' THEN 'INVALID AMOUNT 52'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WY' THEN 'INSUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='WZ' THEN 'INVALID INDUSTRY FOR PRODUCT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X!' THEN 'ODOMETER PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X#' THEN 'PAY AT PUMP NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X$' THEN 'RESTRICTED TIME OR DAY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X%' THEN 'MERCHANT PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X&' THEN 'PO NUMBER PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X(' THEN 'RVSL: CUSTOMER CANCELLED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X)' THEN 'RVSL: FUNCTION NOT SUPPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X*' THEN 'DUPLICATE INVOICE NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X?' THEN 'INVALID TRACK DATA'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X@' THEN 'INVALID RESTRICTION CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X[' THEN 'RESTRICTED CARD (PICK UP)'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X]' THEN 'RESTRICTED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X^' THEN 'PRODUCT PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X<' THEN 'PARTIAL APPROVAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X=' THEN 'RVSL: DESTINATION NOT AVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X>' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X0' THEN 'NO SUCH ISSUER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X1' THEN 'IMPRINTER SALE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X2' THEN 'COUNTERFEIT DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X3' THEN 'FLEET DRIVER ID, VEH OR PIN PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X4' THEN 'VOYAGER ID PROBLEM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X5' THEN 'VELOCITY DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X6' THEN 'TEXACO PREAUTH ACCEPTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X7' THEN 'BLIND APPR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X8' THEN 'BAD^LOCATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='X9' THEN 'UNMATCHED LINK RESP CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XA' THEN 'DECLINED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XB' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XC' THEN 'INVALID TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XD' THEN 'TRANSACTION NOT ALLOWED TO CRD HLDR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XE' THEN 'INVALID TRACK 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XF' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XG' THEN 'NOT SUFFICIENT FUNDS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XH' THEN 'DUPLICATE TRANSACTION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XI' THEN 'CALL FOR AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XJ' THEN 'CARD NOT SUPPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XK' THEN 'OVER DAILY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XL' THEN 'CAPTURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XM' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XN' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XO' THEN 'OVER FLOOR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XP' THEN 'REFERRAL'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XQ' THEN 'OTB LIMIT OVER OR UNDER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XR' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XS' THEN 'EXCEED DAILY DOLLAR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XT' THEN 'DAILY USAGE EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XU' THEN 'LOST OR STLOEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XV' THEN 'INVALID POSTING DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XW' THEN 'UNABLE TO AUTHORIZE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XX' THEN 'INVALID PAN LENGTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XY' THEN 'INV TRANS DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='XZ' THEN 'INV EXPIRATION DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y0' THEN 'LOAD ABORTED BY INTEFACE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y1' THEN 'NO MASTER KEY FOR BANK FIID'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y2' THEN 'NO BUYNET DIAL RECOR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y3' THEN 'DUPLICATE TPDU SOURCE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y4' THEN 'WORKING KEY -> COMM KEY FAILURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y5' THEN 'FAILURE TO PACK NEW KEY INTO HEX'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y6' THEN 'FAILURE TO UNPACK OLD KEY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y7' THEN 'NON-NUMERIC MERCHANT NUMBER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y8' THEN 'NON-NUMERIC TERMIANL NUBMER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Y9' THEN 'CANNOT CREATE WORKING KEY'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YA' THEN 'LOADER CANNOT ACCEPT MORE LOADS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YB' THEN 'NO TERMINAL RECORD FOUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YC' THEN 'NOT SET FOR LOAD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YD' THEN 'SET FOR FULL RATHER THAN TABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YE' THEN 'APPLICATION NOT SUPPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YF' THEN 'UNKNOWN TERMINAL TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YG' THEN 'TERM TYPE ON PROFILE IS WRONG'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YH' THEN 'PROFILE/TERM STATE CD MISMATCH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YI' THEN 'LOADER TIMED OUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YJ' THEN 'LOST LOAD THREAD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='YK' THEN 'REQ. FULL LOAD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z0' THEN 'CARD NOT SUPPORTED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z1' THEN 'OTB LIMIT OVER OR UNDER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z2' THEN 'INVALID ZIP CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z3' THEN 'INVALID CVV'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z4' THEN 'INV CARD LENGTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z5' THEN 'INVALID TRANSACTION TYPE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z6' THEN 'AUTHORIZER UNAVAILABLE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z7' THEN 'UNMATCHED LINK RESP CODE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='Z8' THEN 'TRANACTION TIMED OUT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZA' THEN 'CALL FOR AUTHORIZATION'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZB' THEN 'INVALID AMOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZC' THEN 'CAPTURE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZD' THEN 'DECLINE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZE' THEN 'UNABLE TO PROCESS TRANS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZF' THEN 'INVALID TRANS'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZG' THEN 'FORMAT ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZH' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZI' THEN 'LOST OR STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZJ' THEN 'STOLEN CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZK' THEN 'NOT SUFFICIENT FUND'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZL' THEN 'EXPIRED CARD'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZM' THEN 'TRANS NOT ALLOWED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZN' THEN 'DAILY USAGE EXCEEDED'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZO' THEN 'INVALID ACCOUNT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZP' THEN 'INVALID TRACK 2'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZQ' THEN 'DUPLICATE SALE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZR' THEN 'FLEET DRV,VEH OR PIN ERROR'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZS' THEN 'INVALID CARD NUM'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZT' THEN 'UNABLE TO AUTHORIZER'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZU' THEN 'INVALID PAN LENGTH'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZV' THEN 'OVER FLOOR LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZW' THEN 'OVER DAILY LIMIT'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZX' THEN 'INVALID TRANS DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZY' THEN 'INVALID EXP DATE'
						WHEN SUBSTRING(APPRV_DCLINE,4,2)='ZZ' THEN 'INVALID SETTLE DATE'
						ELSE NULL
					END
				ELSE NULL
			END
		AS VARCHAR(255))						ProcessorExtraMsg,
		CASE
--			WHEN TRANSACTION_IND IN ('D') THEN SUBSTRING(AUTHZR_CODE,3,2)	--This is a 2-digit number, but does not seem to be good responses, per Geoff
			WHEN TRANSACTION_IND IN ('D') THEN SUBSTRING(APPRV_DCLINE,4,2)	--Geoff decided that we should use the BUYPPASS codes for the responses
		END										ProcessorResponseCode,
		CASE
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('00') THEN 'Unknown'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('01') THEN 'Manual Key Entry'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('02') THEN 'MAG Stripe Read'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('05') THEN 'Chip Card Read'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('07') THEN 'Contactless Payment'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('10') THEN 'Credential on file'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('79') THEN 'Chip read Fallback Failed'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('80') THEN 'MAG stripe read - Chip Failed'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('81') THEN 'Manual Key Entry E-Commerce'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('82') THEN 'PAN Auto Entry via Server'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('83') THEN 'RFI Indicator - Chip'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('85') THEN 'DISC Swiped Fallback'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('90') THEN 'MAG Stripe Read (Full Unaltered)'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('91') THEN 'Contactless - MAG Stripe Rules'
			WHEN SUBSTRING(ENTRY_MODE_1,1,2) IN ('95') THEN 'Chip Card Read - No CVV'
		END										POSEntryMsg,
		SUBSTRING(ENTRY_MODE_1,1,2)				POSEntryMode,
		ECI										EComInd,
		NULL									PreOrFinalAuth,
		BUYPASS_MERCHANT          				ForeignFrontEndMID,
		MERCHANT_SIC							MCC,						--The MCC is provided by the report MD-572
		TRACE_NR								TransTraceAuditNumber,
		AUTHZR_CODE               				TransEntryAuthAccessMode,	--'0002','0003','0040','0014' are most popular. Values: 0001,0002,0003,0004,0006,0007,0009,0013,0014,0017,0021,0023,0028,0033,0036,0040,0048,0053,0055,0058,0060,0062,0068,0069,0075,0079,0083,0086,0094,0096,0097
		CASE
			WHEN HOST_INT IN ('O') THEN 'O'
			ELSE HOST_INT
		END                      				HostInterfaceSystemCode,
		NULL									HostCPUIndCode,
		NULL									HowSentToFiserv,
		NULL									BatchSequence,
		NULL									BatchCutOff,
		NULL									BatchTypeETC,		
		NULL									CreditVoucherCode,		
		CAST(NULL AS MONEY)						SurchargeAmount,
		CAST(CASHBACK_AMOUNT AS MONEY)			CashbackAmount,
		NULL									StarSignatureDebit,
		CASE
			WHEN PYMNT_TYPE IN ('0006') AND TRANSACTION_IND IN ('A') THEN SUBSTRING(AUTHZR_CODE,3,2)
		END										DebitNetworkID,				--Generic Debit (Debit Summary File) --> Debit Networks: 06,07,17,23,28,40,48,58,68,69,86,97
		CAST(DBT_NTWK_FEE AS MONEY)				DebitNetworkFee,
		NULL									PINEntryCapability,
		NULL									PINCaptureCapability,
		NULL									PINVerification,
--		CASE
--			WHEN D_C_FLG IN ('C') THEN 'CreditCard'
--			WHEN D_C_FLG IN ('D') THEN 'DebitCard'
--			ELSE D_C_FLG
--		END										DebitCreditCode,			--Indicate the type of Card: "DebitCard" or "CreditCard"
		NULL									RetrievalRefNumber,		
		CASE
			WHEN MKTSPC_IND IN ('H') THEN 'H'
			WHEN MKTSPC_IND IN ('M') THEN 'M'
			WHEN MKTSPC_IND IN ('N') THEN 'N'
			ELSE MKTSPC_IND
		END										MarketSpecificIndicatorCode,--BUYPASS-assigned code representing the transaction data�s market type
		CASE
			WHEN CMMN_TYPE IN ('E') THEN 'E'
			WHEN CMMN_TYPE IN ('O') THEN 'O'
			WHEN CMMN_TYPE IN ('V') THEN 'V'
			WHEN CMMN_TYPE IN ('W') THEN 'W'
			ELSE CMMN_TYPE
		END										TransCommType,
		STORE_IDENTIFIER						StoreNumber,
		NULL									POSModelInfo,
		POS_DATA								POSDataCode,				--BUYPASS-assigned code representing conditions at the point of sale
		NULL									CardSourceType,
		NULL									TSYSBINBankStore,
		TERM_ID                   				TerminalID,
		NULL									ExternalID,
		USER_DATA								OrderNumber,				--Customer-defined information from the terminal on which the transaction data was captured
		NULL									InvoiceNumber,				--Not available here
		'USD'									CurrencyCode,
		NULL									CardServiceCode,
		CASE
			WHEN TRANS_ENCR IN ('00') THEN 'Unknown'		 				--'00' - Not in the Manual
			WHEN TRANS_ENCR IN ('01') THEN 'RSA/PKI'						--'01' - RSA/PKI software-based encryption
			WHEN TRANS_ENCR IN ('02') THEN 'Reserved'						--'02' - Reserved for restricted use
			WHEN TRANS_ENCR IN ('03') THEN 'VSP'							--'03' - Verifone VSP
			WHEN TRANS_ENCR IN ('04') THEN '3DES'							--'04' - 3DES
			WHEN TRANS_ENCR IN ('05') THEN 'Ingenico On-Guard'				--'05' - Ingenico On-Guard Encryption
			ELSE TRANS_ENCR
		END                      				TransEncryptionType,		--Code representing the type of ENCRYPTION used for TransArmor transactions
		CASE
			WHEN TRNS_SCRT IN ('00') THEN 'No Tokn'							--'00' - None. The merchant does not participate in the TransArmor solution
			WHEN TRNS_SCRT IN ('01') THEN 'TA Tokn Encrypt'					--'01' - The merchant participates in encryption and tokenization. This option is available only to merchants who do not use Global Gateway e4SM (GGe4) processing
			WHEN TRNS_SCRT IN ('03') THEN 'TA Tokn Only'					--'03' - The merchant uses the TransArmor solution tokenized-only authorization requests
			ELSE TRNS_SCRT
		END										AuthSecurityLevel,			--Code representing whether the TransArmor merchant participates in encryption and tokenization or in tokenization only
		ACCOUNT_NUMBER            				CardFingerprint,
		'MD-572'								SourceReport,
		UUID_GENERATE()							PaysafeAuthID				--Unique ID assigned to each record (row)
	FROM BISME.MD572_Omaha md572
        INNER JOIN BI.ReportingChannels rc ON (LEFT(md572.MERCHANT_NUMBER,15)=LEFT(rc.MerchantNumber,15))
		LEFT JOIN BI.MerchantDemographics md ON (LEFT(md572.MERCHANT_NUMBER,15)=LEFT(md.MerchantNumber,15))
	WHERE
--		TRAN_DT >= '2021-06-01' AND TRAN_DT <= '2021-06-30' AND
		TRANSACTION_TYPE IN ('0054','0056','0058','0059','0062','0075')		--'PURCHASE','MAILPHON','RETURN','AUTHONLY','RET ADJ','CAP PUR'
		AND PYMNT_TYPE NOT IN ('0088')										--Telecheck (TELE) Skip these!
		AND TRAN_DT >= '2021-03-01'
--	LIMIT 100   

) UNION ALL (

/*****************************************************************************************
 *   Fiserv North DFM 021 Authorization Card Transactions (Authorization Conform Tables) *
 *    All Cards                                                                          *
 *****************************************************************************************/
	SELECT
		CAST(AUTH_DATE AS DATE)					AuthDate,
		rc.MerchantNumber						MerchantNumber,
		LOCATION_DBA_NAME						DBA,
		CAST(		
			CASE 
	            WHEN CARD_TYPE IN ('003','00002','00079','00080','00081','00082','00083','00084') THEN 'VISA' --Visa
	            WHEN CARD_TYPE IN ('00001','002') THEN 'MC'					--Mastercard
	            WHEN CARD_TYPE IN ('00003') THEN 'DISC'						--Discover
	            WHEN CARD_TYPE IN ('00005') THEN 'DINE'						--Diners Pass through
	            WHEN CARD_TYPE IN ('00006') THEN 'ESA'						--Amex Non-Acquiring - (ESA)
	            WHEN CARD_TYPE IN ('00008') THEN 'OPTB'						--Amex Acquiring - (OptBlue)
	            WHEN CARD_TYPE IN ('00010') THEN 'VOYG'						--[FLEET] Voyager
	            WHEN CARD_TYPE IN ('00018') THEN 'GPIN'						--ATM (Generic PIN Debit) 
	            WHEN CARD_TYPE IN ('00027') THEN 'EBT'						--EBT Electronic Benefits Transfer
	            WHEN CARD_TYPE IN ('00035') THEN 'WEX'						--[FLEET] WEX Wright Express (or 'WAM')???
--	            WHEN CARD_TYPE IN ('00036','00037','00038','00039','00040') --[FLEET] Petroleum - Fleet Core (00036), Petroleum - Fleet One (00037), Petroleum (00038-00040)
	            WHEN CARD_TYPE IN ('00050') THEN 'OTHR'						--(APM) Alternative Payment Method (or 'OTHR')???
	            WHEN CARD_TYPE IN ('00051') THEN 'PPAL'						--Unknown (Not in DFM Document) Generic Fiserv Document says - "PayPal"
	            WHEN CARD_TYPE IN ('05601') THEN 'STAR'						--Star Access
				ELSE RIGHT(CARD_TYPE,4)
	        END
        AS VARCHAR(4))							CardSchemeCode,
		CASE
			WHEN AUTH_TRANS_CODE IN ('Incremental','Original','Others') THEN
				CASE
					WHEN AUTH_AMOUNT_SIGN NOT IN ('-')  THEN 'Sale'			--'Incremental' � Incremental authorizations can be used to increase the total amount authorized if the amount of the estimate/initial authorization is insufficient. An incremental authorization request may also be based on a revised estimate of what the cardholder may spend. Incremental authorizations do not replace the original authorization � they are additional to previously authorized amounts � the sum of all linked estimated and incremental authorizations represent the total amount authorized for a given transaction.  'Original' � Original request for authorization. Can be an estimated authorization depending on the industry.  'Others' � *Fiserv has someone from compliance looking at the "other" category
					ELSE 									 'Return'
				END
			WHEN AUTH_TRANS_CODE IN ('Reversal')		THEN 'Reversal'		--***NOT SEEN NOW, AS WE FILTER THESE OUT. SEE BELOW "WHERE" CLAUSE *** 'Reversals' � Authorization reversals notify the issuer that all, or part, of a transaction has been cancelled and that the authorization hold should be removed and open to buy amounts may be adjusted
			ELSE AUTH_TRANS_CODE
		END										AuthType,
		CASE
			WHEN RESPONSE_CODE IN ('00','01','05','16','24','29','32','34','43','87','90','94','97','PA') THEN 'Yes'
			ELSE 'No'														--All others - Not Approved
		END										isApproved,					--'00'-Approved, '01'-Approved: Approval with ID, '05'-Approved: Approved (usually) if PIN-Debit transaction '00018' and '00027', '16'-Approved: Stand-In Approval, '24'-Approved: Reversal Accepted, '28'-Approved: Reversal, '29'-Approved: Sale Auth EDC, '32'-Approved: Reversal Complete, '43'-Approved: VIP Approval, '87'-Approved: Verification Transaction, '90'-Approved: Transaction Accepted, '94'-Approved: Stand-In Approval, 'PA'-Approved: Partial Approval
		CASE WHEN AUTH_AMOUNT_SIGN NOT IN ('-')	THEN CAST(ZEROIFNULL(AUTH_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END SalesAmountAuth,	--'+' = Sales
		CASE WHEN AUTH_AMOUNT_SIGN	   IN ('-')	THEN CAST(ZEROIFNULL(AUTH_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END ReturnsAmountAuth,	--'-' = Returns
		AUTH_CODE								AuthCode,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b'))<>6 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(6)), 6, '0') END
												CardFirst6,
		CASE WHEN LENGTH(REGEXP_REPLACE(CARDNUMBERLAST4, '[^0-9]', '', 1, 0, 'b'))<>4 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(CARDNUMBERLAST4, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(4)), 4, '0') END
												CardLast4,
		EXPIRATION_DATE                			CardExpDate,				--Seems more like MMYY, but who knows!
		CAST(NULL AS VARCHAR(3))				AuthResponseCode,			--ISO-8583 (DE39) Standard (Decline) Auth Response Code
		CAST(NULL AS VARCHAR(255))				AuthResponseDescription,	--ISO-8583 (DE39) Standard (Decline) Auth Response Description		
		NULL									isKeyed,
		NULL									isChipRead,
		CAST(NULL AS VARCHAR(3))				isReversed,					--Added now for the future usage - per Geoff
		ACI                            			ACI,						--Visa Authorization Characteristic Indicator
		VISA_VALID_CODE							ValidationCode,				--'0'-'9', 'A'-'Z'  ???
		NULL									VisaTranID,
		NULL									MastercardRefNumber,
		NULL									AmexRefNumber,
		NULL									DiscoverNetworkRefID,
		AVS_FLAG								AVSResponse,
		NULL									CVV2ResultCode,
		CAVV									CAVVResultCode,				--' ' [Blank] - CAVV not present or CAVV not verified. Issuer has not selected CAVV verification option. Order Source - any,  'B' - CAVV passed verification, but no liability shift because a) ECI was not 5 or 6 or b) the card type is an excluded (e.g., Commercial Card) Order Source - 3DSAuthenticated or 3DSAttempted,  '0' - CAVV could not be verified or CAVV data was not provided when expected or (for Mastercard) Downgrade to non-3DS transaction, Missing or base64 encoded AAV does not start with j (AAV is invalid for 3dsAuthenticated transaction),  '6' - CAVV not verified, because Issuer not participating. VisaNet processes as if CAVV is valid. Order Source - 3DSAuthenticated,  '1' - CAVV failed verification or (for Visa) TAVV (token authentication verification value) cryptogram failed validation or (for Mastercard) Downgrade to 3DS Attempted transaction, AAV starts with h and not j,  '2' - CAVV passed verification or (for Visa) TAVV cryptogram passed validation,  'D' - Issuer elected to return CAVV verification results and Field 44.13 blank. Value is set by VisaNet; means CAVV Results are valid. Order Source - 3DSAttempted,  '3' - CAVV passed verification or (for Visa) DTVV (dynamic token verification value) or Visa-defined format cryptogram failed validation,  '4' - CAVV failed verification - attempted authentication or (for Visa) DTVV or Visa-defined format cryptogram passed validation,  '5' - Not used,  '7' - CAVV failed verification,  '8' - CAVV passed verification,  '9' - CAVV failed verification; Visa generated CAVV because Issuer ACS was not available.,  'A' - CAVV passed verification; Visa generated CAVV because Issuer Access Control Server (ACS) was not available.,  'B' - CAVV passed verification but no liability shift because a) ECI was not 5 or 6 or b) the card type is an excluded (e.g., Commercial Card),  'C' - Issuer elected to return CAVV verification results and Field 44.13 blank. Value is set by VisaNet; means CAVV Results are valid.
		NULL									UCAFSupportCode,
		NULL									CardProductID,				--Visa Card Product ID and MasterCard Product ID
		CAST(AUTHDATETIME AS TIMESTAMP)			AuthDateTime,
		CAST(NULL AS DATE)						ProcessorRunDate,
		CAST(NULL AS TIMESTAMP)					ProcessorRunDateTime,
		CAST(ENVELOPEFILEDATE AS DATE)			StatementDate,				--Nothing else available!
        --START of lesser priority Columns - Mostly SME info ----------------------------------------------------------------------------------------------------------------
		CASE
			WHEN ENVELOPEPROCESSORPLATFORM = 'North' THEN 'NOR'
			ELSE ENVELOPEPROCESSORPLATFORM
		END										AuthPlatform,				--Processor Platform Name: 'NOR' Fiserv (FDR) North
		CAST(CARD_TYPE AS VARCHAR(6))			ProcessorCardScheme,
		AUTH_TRANS_CODE							ProcessorAuthType,
		CAST(ZEROIFNULL(AUTH_AMOUNT) AS MONEY)	ProcessorAmount,
--		CASE
--			WHEN RESPONSE_CODE IN ('00','01','05','16','24','29','32','34','43','87','90','94','97','PA') THEN 'Approved'
--			ELSE 'Declined'													--All others - Declined
--		END										ProcessorExtraMsg,			--'00'-Approved, '01'-Approved: Approval with ID, '05'-Approved: Approved (usually) if PIN-Debit transaction '00018' and '00027', '16'-Approved: Stand-In Approval, '24'-Approved: Reversal Accepted, '28'-Approved: Reversal, '29'-Approved: Sale Auth EDC, '32'-Approved: Reversal Complete, '43'-Approved: VIP Approval, '87'-Approved: Verification Transaction, '90'-Approved: Transaction Accepted, '94'-Approved: Stand-In Approval, 'PA'-Approved: Partial Approval
		CAST(NULL AS VARCHAR(255))				ProcessorExtraMsg,
		RESPONSE_CODE							ProcessorResponseCode,
		NULL									POSEntryMsg,
		NULL									POSEntryMode,
		NULL									EComInd,
		NULL									PreOrFinalAuth,
		NULL									ForeignFrontEndMID,
		md.MCC									MCC,						--The MCC is provided by the BI.MerchantDemographics table on this report DFM-021
		NULL									TransTraceAuditNumber,
		NULL									TransEntryAuthAccessMode,
		NULL									HostInterfaceSystemCode,
		NULL									HostCPUIndCode,
		NULL									HowSentToFiserv,
		NULL									BatchSequence,
		NULL									BatchCutOff,
		NULL									BatchTypeETC,		
		NULL									CreditVoucherCode,		
		CAST(NULL AS MONEY)						SurchargeAmount,		
		CAST(NULL AS MONEY)						CashbackAmount,
		NULL									StarSignatureDebit,		
		NULL									DebitNetworkID,		
		CAST(NULL AS MONEY)						DebitNetworkFee,
		NULL									PINEntryCapability,
		NULL									PINCaptureCapability,
		NULL									PINVerification,
--		CASE
--			WHEN CARD_TYPE IN ('00018','00027','05601') THEN 'DebitCard'
--			ELSE NULL
--			ELSE 'CreditCard'
--		END										DebitCreditCode,
		NULL									RetrievalRefNumber,
		NULL									MarketSpecificIndicatorCode,
		NULL									TransCommType,
		STORE_NUMBER							StoreNumber,
		NULL									POSModelInfo,
		MC_POS_DATA_CODES						POSDataCode,				--Need the manual and a Secret Decoder Ring to figure this one out
		NULL									CardSourceType,
		NULL									TSYSBINBankStore,
		NULL									TerminalID,
		EXTERNAL_ID								ExternalID,
		ORDER_NUMBER							OrderNumber,
		USER_DATA_2								InvoiceNumber, 				--Mostly unique when NOT NULL, with some exceptions, but mostly NULL
		CASE
			WHEN CURRENCY_CODE = '840' THEN 'USD'
			WHEN CURRENCY_CODE IS NULL THEN 'USD'
			ELSE CURRENCY_CODE
		END										CurrencyCode,				--Currency Code, default is 'USD'
		SERVICE_CODE							CardServiceCode,			--'000'-'999' and NULL.  101�Magnetic-stipe card; international use,  120�Magnetic-stripe card; international use; PIN is required,  121�Magnetic-stripe card; international use; online authorization required for all transactions,  201�EMV chip card; international use,  221�EMV chip card; international use; online authorization required for all transactions,  310�PIN required/May be required,  521�Magnetic Stripe is restricted to domestic use only,  601�National-use EMV chip credit and debit cards
		NULL									TransEncryptionType,
		NULL									AuthSecurityLevel,
		CARDHOLDER_NUMBER              			CardFingerprint,
		'DFM-021'								SourceReport,
		UUID_GENERATE()							PaysafeAuthID				--Unique ID assigned to each record (row)
	FROM BISME.DFM_AuthorizationDetails021_North ad021
        INNER JOIN BI.ReportingChannels rc ON (ad021.LOCATION_ID=rc.MerchantNumber)
		LEFT JOIN BI.MerchantDemographics md ON (ad021.LOCATION_ID=md.MerchantNumber)
	WHERE
--		AUTH_DATE >= '2021-06-01' AND AUTH_DATE <= '2021-06-30' AND
		AUTH_TRANS_CODE IN ('Original','Others','Incremental') AND RESPONSE_CODE NOT in ('23','24','28','31','32','33','34','78','97') --Skip any type of Reversals or Voids
		AND AUTH_DATE >= '2021-03-01'
--	LIMIT 100   

) UNION ALL (

/*****************************************************************************************
 *   TSYS Authorization Detail File [ADF] (Autorization Conform Tables)                  *
 *    All Cards                                                                          *
 *****************************************************************************************/
SELECT
		TD01_TRANSACTION_DATE_TIME::DATE		AuthDate,
		rc.MerchantNumber						MerchantNumber,
		TD01_MERCHANT_NAME						DBA,
		CAST(
			CASE
	            WHEN TD01_NETWORK_ID IN ('0003') AND TD01_CARD_TYPE IN ('G') THEN 'ITLK'	--Interlink
				WHEN TD01_NETWORK_ID IN ('0004') AND TD01_CARD_TYPE IN ('B') THEN 'ITLK'	--Plus ATM
				WHEN TD01_NETWORK_ID IN ('0006') AND TD01_CARD_TYPE IN ('O') THEN 'MAES'	--Cirrus ATM
				WHEN TD01_NETWORK_ID IN ('0007') AND TD01_CARD_TYPE IN ('J') THEN 'MAES'	--Mastercard ATM
				WHEN TD01_NETWORK_ID IN ('0008') AND TD01_CARD_TYPE IN ('N') THEN 'STAR'	--STAR
				WHEN TD01_NETWORK_ID IN ('0009') AND TD01_CARD_TYPE IN ('S') THEN 'PULS'	--PULSE
				WHEN TD01_NETWORK_ID IN ('0010') AND TD01_CARD_TYPE IN ('W') THEN 'STAR'	--STAR Southeast
				WHEN TD01_NETWORK_ID IN ('0011') AND TD01_CARD_TYPE IN ('Z') THEN 'STAR'	--STAR Northeast
				WHEN TD01_NETWORK_ID IN ('0012') AND TD01_CARD_TYPE IN ('Q') THEN 'STAR'	--STAR West
				WHEN TD01_NETWORK_ID IN ('0013') AND TD01_CARD_TYPE IN ('U') THEN 'AFFN'	--AFFN
				WHEN TD01_NETWORK_ID IN ('0015') AND TD01_CARD_TYPE IN ('M') THEN 'STAR'	--STAR
				WHEN TD01_NETWORK_ID IN ('0016') AND TD01_CARD_TYPE IN ('8') THEN 'MAES'	--Maestro
				WHEN TD01_NETWORK_ID IN ('0017') AND TD01_CARD_TYPE IN ('L') THEN 'PULS'	--Pulse
				WHEN TD01_NETWORK_ID IN ('0018') AND TD01_CARD_TYPE IN ('Y') THEN 'NYCE'	--NYCE
				WHEN TD01_NETWORK_ID IN ('0019') AND TD01_CARD_TYPE IN ('H') THEN 'PULS'	--PULSE
				WHEN TD01_NETWORK_ID IN ('0020') AND TD01_CARD_TYPE IN ('E') THEN 'ACCL'	--Accel
				WHEN TD01_NETWORK_ID IN ('0024') AND TD01_CARD_TYPE IN ('C') THEN 'CU24'	--CU24
				WHEN TD01_NETWORK_ID IN ('0027') AND TD01_CARD_TYPE IN ('F') THEN 'NYCE'	--NYCE
				WHEN TD01_NETWORK_ID IN ('0028') AND TD01_CARD_TYPE IN ('7') THEN 'SHZM'	--Shazamsm (ITS)
				WHEN TD01_NETWORK_ID IN ('0029') AND TD01_CARD_TYPE IN ('K') THEN 'EBT'		--EBT
				WHEN TD01_NETWORK_ID IN ('0030') AND TD01_CARD_TYPE IN ('T') THEN 'EBT'		--EBT ATM
				WHEN TD01_NETWORK_ID IN ('0040') AND TD01_CARD_TYPE IN ('A') THEN 'OPTB'	--Amex ATM
				WHEN TD01_NETWORK_ID IN ('0041') AND TD01_CARD_TYPE IN ('D') THEN 'PULS'	--Discover ATM
				WHEN TD01_NETWORK_ID IN ('0042') AND TD01_CARD_TYPE IN ('1') THEN 'AFFN'	--AFFN ATM
				WHEN TD01_NETWORK_ID IN ('0053') AND TD01_CARD_TYPE IN ('2') THEN 'GPIN'	--Fifth Third (TSYS assigned value)
				WHEN TD01_NETWORK_ID IN ('0777') AND TD01_CARD_TYPE IN ('5') THEN 'GPIN'	--Visa Check Card II (TSYS assigned value)
				WHEN TD01_NETWORK_ID IN ('1001') AND TD01_CARD_TYPE IN ('!') THEN 'GPIN'	--Evertech (TSYS assigned value)
				WHEN 								 TD01_CARD_TYPE IN ('4') THEN 'VISA'	--Visa
				WHEN 								 TD01_CARD_TYPE IN ('5') THEN 'MC'		--Mastercard
	            WHEN 								 TD01_CARD_TYPE IN ('3') THEN 'AMEX'	--American Express
	            WHEN 								 TD01_CARD_TYPE IN ('8') THEN 'DISC'	--Discover 
	            WHEN 								 TD01_CARD_TYPE IN ('7') THEN 'JCB'		--JCB 
	            WHEN 								 TD01_CARD_TYPE IN ('9') THEN 'OTHR'	--Other 
	            WHEN 								 TD01_CARD_TYPE IN ('P') THEN 'PPAL'	--PayPal
	            WHEN 								 TD01_CARD_TYPE IN ('?') THEN 'OTHR'	--Other - '?' and [NULL] come directly from the Processor
	            WHEN 								 TD01_CARD_TYPE IS NULL	 THEN 'OTHR'	--Other - '?' and [NULL] come directly from the Processor
				WHEN TD01_NETWORK_ID IS NULL								 THEN 'OTHR'	--Other - '?' and [NULL] come directly from the Processor
				ELSE LEFT(TD01_CARD_TYPE,4)									--'?' and [NULL] come directly from the Processor
			END
		AS VARCHAR(4))							CardSchemeCode,				--A <space> or "?" value in this field indicates the card type was Unknown
		CASE
			WHEN TD01_TRANSACTION_TYPE IN ('00') THEN 'Sale'				--'00' � Goods/Service Purchase POS transaction only
			WHEN TD01_TRANSACTION_TYPE IN ('01') THEN 'CashAdvance'			--'01' � Withdrawal/Cash Advance
			WHEN TD01_TRANSACTION_TYPE IN ('02') THEN 'Sale'				--'02' � Adjustment - Debit
			WHEN TD01_TRANSACTION_TYPE IN ('10') THEN 'Sale'				--'10' � Payment Transaction - MasterCard
			WHEN TD01_TRANSACTION_TYPE IN ('11') THEN 'Sale'				--'11' � Quasi Cash Transaction (POS transaction only) or Online Gambling Transaction
			WHEN TD01_TRANSACTION_TYPE IN ('20') THEN 'Return'				--'20' � Return - Credit
			WHEN TD01_TRANSACTION_TYPE IN ('21') THEN 'Sale'				--'21' � Deposit (Plus)
			WHEN TD01_TRANSACTION_TYPE IN ('22') THEN 'Return'				--'22' � Adjustment - Credit
			WHEN TD01_TRANSACTION_TYPE IN ('28') THEN 'Sale'				--'28' � Pre-Paid Card Load
			WHEN TD01_TRANSACTION_TYPE IN ('30') THEN 'Info'				--'30' � Balance Inquiry
			WHEN TD01_TRANSACTION_TYPE IN ('39') THEN 'Info'				--'39' � Healthcare Eligibility Inquiry
			WHEN TD01_TRANSACTION_TYPE IN ('40') THEN 'Sale'				--'40' � Cardholder Account Transfer
			WHEN TD01_TRANSACTION_TYPE IN ('50') THEN 'Sale'				--'50' � Bill Payment
			WHEN TD01_TRANSACTION_TYPE IN ('72') THEN 'Sale'				--'72' � Pre-Paid Card Activations
			ELSE TD01_TRANSACTION_TYPE
		END										AuthType,
		CASE
			WHEN TD01_AUTHORIZATION_RESPONSE IN ('00','08','10','85') THEN 'Yes'
			ELSE 'No'
		END										isApproved,
		CASE WHEN TD01_TRANSACTION_TYPE NOT	IN ('20','22','30','39')	THEN CAST(ZEROIFNULL(TD01_AUTHORIZED_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END SalesAmountAuth,	--'' = Sales
		CASE WHEN TD01_TRANSACTION_TYPE 	IN ('20','22')				THEN CAST(ZEROIFNULL(TD01_AUTHORIZED_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END ReturnsAmountAuth,	--'' = Returns
		TD01_APPROVAL_CODE						AuthCode,
		CASE WHEN LENGTH(REGEXP_REPLACE(TD01PRIMARYACCOUNTNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b'))<>6 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(TD01PRIMARYACCOUNTNUMBERFIRST6, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(6)), 6, '0') END
												CardFirst6,
		CASE WHEN LENGTH(REGEXP_REPLACE(TD01PRIMARYACCOUNTNUMBERLAST4, '[^0-9]', '', 1, 0, 'b'))<>4 THEN NULL ELSE LPAD(CAST(REGEXP_REPLACE(TD01PRIMARYACCOUNTNUMBERLAST4, '[^0-9]', '', 1, 0, 'b')::INTEGER AS VARCHAR(4)), 4, '0') END
												CardLast4,
		TD01_CARD_EXPIRATION_DATE				CardExpDate,
		CAST(NULL AS VARCHAR(3))				AuthResponseCode,			--ISO-8583 (DE39) Standard (Decline) Auth Response Code
		CAST(NULL AS VARCHAR(255))				AuthResponseDescription,	--ISO-8583 (DE39) Standard (Decline) Auth Response Description		
		CASE
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('00','01','10','79','81')				 			 						THEN 'Yes'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('02','03','05','06','07','09','80','82','83','85','86','90','91','95')	THEN 'No'
			ELSE NULL
        END										isKeyed,					--'Yes' Keyed, 'No" Not Keyed - Swiped or Chipped or Other
		CASE
    		WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('05','07','09','83','86','95')	THEN 'Yes'
			ELSE 'No'
   		END										isChipRead,					--'05','07'(Not Discover-N/A here),'09','83','85','95'
		CAST(NULL AS VARCHAR(3))				isReversed,					--Added now for the future usage - per Geoff		
		TD01_RETURN_ACI							ACI,						--Visa Authorization Characteristic Indicator
		TD01_VALIDATION_CODE					ValidationCode,				--Visa Validation Code when 'Approved'. Other values when NOT 'Approved' and/or other Cards
		CASE
            WHEN TD01_CARD_TYPE IN ('4') AND LENGTH(TD01_TRANSACTION_IDENTIFIER)<>13 THEN TD01_TRANSACTION_IDENTIFIER
        END										VisaTranID,					--Visa 15-digit CPS2000 Transaction ID
		CASE
			WHEN TD01_CARD_TYPE IN ('5') AND LENGTH(TD01_TRANSACTION_IDENTIFIER)=13 AND SUBSTRING(TD01_TRANSACTION_IDENTIFIER,1,4) >= '0101'
            																		AND SUBSTRING(TD01_TRANSACTION_IDENTIFIER,1,4) <= '1231'
            									THEN SUBSTRING(TD01_TRANSACTION_IDENTIFIER,5,9) || '-' || SUBSTRING(TD01_TRANSACTION_IDENTIFIER,1,4)
		END										MastercardRefNumber,		--Mastercard ISO 8583 DE63 Banknet Reference Number + Mastercard MMDD
		CASE
			WHEN TD01_CARD_TYPE IN ('3') THEN TD01_TRANSACTION_IDENTIFIER
		END										AmexRefNumber,
		CASE
			WHEN TD01_CARD_TYPE IN ('8') THEN TD01_TRANSACTION_IDENTIFIER
		END										DiscoverNetworkRefID,
		TD01_AVS_RESULT							AVSResponse,
		CASE 
		    WHEN NVL(TD01_CVV_CVC1_CVC3_RESULT_CODE,'') <> '' AND NVL(TD01_CVV2_CVC2_CID_RESULTS_CODE,'') <> '' THEN  TD01_CVV2_CVC2_CID_RESULTS_CODE || '-' || TD01_CVV_CVC1_CVC3_RESULT_CODE	--Not a pipe, not a comma, "-" per Geoff
		    ELSE COALESCE(TD01_CVV2_CVC2_CID_RESULTS_CODE,TD01_CVV_CVC1_CVC3_RESULT_CODE)
		END										CVV2ResultCode,
		TD01_CAVV_RESULT_CODE					CAVVResultCode,				--' ' [Blank] - CAVV not present or CAVV not verified. Issuer has not selected CAVV verification option. Order Source - any,  'B' - CAVV passed verification, but no liability shift because a) ECI was not 5 or 6 or b) the card type is an excluded (e.g., Commercial Card) Order Source - 3DSAuthenticated or 3DSAttempted,  '0' - CAVV could not be verified or CAVV data was not provided when expected or (for Mastercard) Downgrade to non-3DS transaction, Missing or base64 encoded AAV does not start with j (AAV is invalid for 3dsAuthenticated transaction),  '6' - CAVV not verified, because Issuer not participating. VisaNet processes as if CAVV is valid. Order Source - 3DSAuthenticated,  '1' - CAVV failed verification or (for Visa) TAVV (token authentication verification value) cryptogram failed validation or (for Mastercard) Downgrade to 3DS Attempted transaction, AAV starts with h and not j,  '2' - CAVV passed verification or (for Visa) TAVV cryptogram passed validation,  'D' - Issuer elected to return CAVV verification results and Field 44.13 blank. Value is set by VisaNet; means CAVV Results are valid. Order Source - 3DSAttempted,  '3' - CAVV passed verification or (for Visa) DTVV (dynamic token verification value) or Visa-defined format cryptogram failed validation,  '4' - CAVV failed verification - attempted authentication or (for Visa) DTVV or Visa-defined format cryptogram passed validation,  '5' - Not used,  '7' - CAVV failed verification,  '8' - CAVV passed verification,  '9' - CAVV failed verification; Visa generated CAVV because Issuer ACS was not available.,  'A' - CAVV passed verification; Visa generated CAVV because Issuer Access Control Server (ACS) was not available.,  'B' - CAVV passed verification but no liability shift because a) ECI was not 5 or 6 or b) the card type is an excluded (e.g., Commercial Card),  'C' - Issuer elected to return CAVV verification results and Field 44.13 blank. Value is set by VisaNet; means CAVV Results are valid.
		TD01_UCAF_COLLECTION_INDICATOR			UCAFSupportCode,			--Always NULL
		CASE
			WHEN TD01_CARD_TYPE IN ('4') THEN TD01_PRODUCT_TYPE_IDENTIFICATION
			WHEN TD01_CARD_TYPE IN ('5') AND
				LENGTH(TD01_TRANSACTION_IDENTIFIER)=13 AND SUBSTRING(TD01_TRANSACTION_IDENTIFIER,1,4) >= '0101'
            										   AND SUBSTRING(TD01_TRANSACTION_IDENTIFIER,1,4) <= '1231'
            										  THEN SUBSTRING(TD01_TRANSACTION_IDENTIFIER,5,3)
		END										CardProductID,				--Visa Card Product ID and MasterCard Product ID
		CAST(TD01_TRANSACTION_DATE_TIME AS TIMESTAMP)
												AuthDateTime,
		CAST(NULL AS DATE)						ProcessorRunDate,
		CAST(NULL AS TIMESTAMP)					ProcessorRunDateTime,
		CASE
			WHEN SUBSTRING(TD01_SETTLEMENT_DATE,1,2) || '-' || SUBSTRING(TD01_SETTLEMENT_DATE,3,2) <= SUBSTRING(CAST(TO_DATE(MONTH(GETDATE()) || '/' || DAY(GETDATE()) || '/' || YEAR(GETDATE()), 'MM-DD-YYYY') AS Varchar(50)),6,5) THEN
				CAST(TO_DATE(SUBSTRING(TD01_SETTLEMENT_DATE,1,2) || '/' || SUBSTRING(TD01_SETTLEMENT_DATE,3,2) || '/' || YEAR(GETDATE()),   'MM/DD/YYYY') AS DATE)
			ELSE
				CAST(TO_DATE(SUBSTRING(TD01_SETTLEMENT_DATE,1,2) || '/' || SUBSTRING(TD01_SETTLEMENT_DATE,3,2) || '/' || YEAR(GETDATE())-1, 'MM/DD/YYYY') AS DATE)
		END										StatementDate,				--"TD01_SETTLEMENT_DATE" is in 'MMDD' Format. Need to correct the Year 'YYYY' using the Current Date to decide to use THIS Year or LAST Year
        --START of lesser priority Columns - Mostly SME info ----------------------------------------------------------------------------------------------------------------
		CASE
			WHEN ENVELOPEPROCESSORPLATFORM = 'TSYS' THEN 'TSS'
			ELSE ENVELOPEPROCESSORPLATFORM
		END										AuthPlatform,				--Processor Platform Name: 'TSS' TSYS
		CAST(NVL(TD01_CARD_TYPE,'*') || '-' || NVL(TD01_NETWORK_ID,'****') AS VARCHAR(6))
												ProcessorCardScheme,
		TD01_MESSAGE_TYPE || '-' || TD01_PROCESSING_CODE					--Authorization request ('0100'), Repeat message ('0101') - Request from a point-of-sale terminal for authorization for a cardholder purchase. --Financial Authorization request ('0200'), Repeat message ('0201') - Request for funds, typically from an ATM or pinned point-of-sale device. --Reversals request ('0400'), Repeat message ('0401') - Reverses a transaction. --Financial Reversal Advice ('0420') - Advises that a reversal has taken place
												ProcessorAuthType,			--This concatinates the Message Type like '0100' (Auth Request) + Processing Code (DE03). The Transaction Type like '00' (Sale) is in position 3 for 2 characters.
		CAST(ZEROIFNULL(TD01_AUTHORIZED_AMOUNT) AS MONEY) ProcessorAmount,
--		CASE
--			WHEN TD01_AUTHORIZATION_RESPONSE IN ('00','08','10','85') THEN 'Approved' --'00'-Approved, '08'-Approved: Honor with identification, '10'-Approved: Partial Approval, '85'-Approved: Not Declined. Usually with an AVS Only transaction
--			ELSE 'Declined'													--All others - Declined
--		END										ProcessorExtraMsg,
		CAST(NULL AS VARCHAR(255))				ProcessorExtraMsg,
		TD01_AUTHORIZATION_RESPONSE				ProcessorResponseCode,
		CASE
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('00') THEN 'Unknown'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('01') THEN 'Manual Key Entry'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('02') THEN 'MAG Stripe Read'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('05') THEN 'Chip Card Read'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('07') THEN 'Contactless Payment'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('90') THEN 'MAG Stripe Read (Full Unaltered)'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('91') THEN 'Contactless - MAG Stripe Rules'
			WHEN TD01_PAN_AND_DATA_ENTRY_MODE IN ('95') THEN 'Chip Card Read - No CVV'
		END										POSEntryMsg,
		TD01_PAN_AND_DATA_ENTRY_MODE			POSEntryMode,				--This one is 2 digits --> TD01_PAN_AND_DATA_ENTRY_MODE. This one is 4 digits --> TD01_POS_ENTRY_MODE, but 1st 2 digits match 1st field ???
		TD01_MOTO_ELECTRONIC_COMMERCE_INDICATOR	EComInd,					--E-Commerce and MOTO ?
		NULL									PreOrFinalAuth,
		TD01_ECONNECTIONS_MERCHANT_NUMBER		ForeignFrontEndMID,
		TD01_MCC_CODE							MCC,						--The MCC is provided by the report TSS-ADF
		TD01_SYSTEMS_TRACE_AUDIT_NUMBER			TransTraceAuditNumber,
		NULL									TransEntryAuthAccessMode,
		NULL									HostInterfaceSystemCode,
		NULL									HostCPUIndCode,
		NULL									HowSentToFiserv,
		NULL									BatchSequence,
		NULL									BatchCutOff,
		NULL									BatchTypeETC,		
		NULL									CreditVoucherCode,
		CAST(RIGHT(TD01_TRANSACTION_FEE_AMOUNT,8) AS MONEY) SurchargeAmount,--This is a 9-character field starting with 'C' or 'D', followed by 8-digit numerics (typicall) or NULL		
		CAST(TD01_CASH_BACK_AMOUNT AS MONEY)	CashbackAmount,
		NULL									StarSignatureDebit,
		TD01_NETWORK_ID							DebitNetworkID,				--If NOT 'NULL' and NOT '0002', then this is Debit
		CAST(NULL AS MONEY)						DebitNetworkFee,
		TD01_PIN_ENTRY_CAPABILITY				PINEntryCapability,			--'0','1','2'
		TD01_PIN_CAPTURE_CAPABILITY				PINCaptureCapability,		--'0','1','4','6','8','C'
		NULL									PINVerification,
--		CASE
--			WHEN TD01_NETWORK_ID is NOT NULL and TD01_NETWORK_ID <> '0002' THEN 'DebitCard'
--			ELSE NULL
--			ELSE 'CreditCard'
--		END										DebitCreditCode,
		TD01_RETRIEVAL_REFERENCE_NUMBER			RetrievalRefNumber,
		TD01_MARKET_SPECIFIC_DATA_INDICATOR		MarketSpecificIndicatorCode,
		NULL									TransCommType,
		TD01_STORE_NUMBER						StoreNumber,
		EX01_POS_TYPE_OR_TERMINAL_DEVICE		POSModelInfo,				--Always NULL
		TD01_POS_DATA_CODE						POSDataCode,
		NULL									CardSourceType,
		TD01_ACQUIRER_BIN || '-' || SUBSTRING(ENVELOPEJOBNAME,2,4) || '-' || TD01_STORE_NUMBER
												TSYSBINBankStore,			--TSYS Only, used as formula for MID: This is a 6-digit (Visa BIN) + 4-digit number (Bank Number) + 4-digit number (Store Number)
		TD01_TERMINAL_NUMBER					TerminalID,
		TD01_XID								ExternalID,
		NULL									OrderNumber,
		NULL									InvoiceNumber,
		CASE
			WHEN TD01_TRANSACTION_CURRENCY_CODE = '840' THEN 'USD'
			WHEN TD01_TRANSACTION_CURRENCY_CODE IS NULL THEN 'USD'
			ELSE TD01_TRANSACTION_CURRENCY_CODE
		END										CurrencyCode,				--Currency Code, default is NULL for 'US', so it seems
		TD11_SERVICE_CODE						CardServiceCode,
		NULL									TransEncryptionType,
		NULL									AuthSecurityLevel,
		TD01_PRIMARY_ACCOUNT_NUMBER				CardFingerprint,			--TD11_ISSUER_COUNTRY_CODE is available!!!
		'TSS-ADF'								SourceReport,
		UUID_GENERATE()							PaysafeAuthID				--Unique ID assigned to each record (row)
	FROM
	    BISME.AuthorizationDetailFile_TSYS  adf
	    LEFT JOIN BI.ReportingChannels      rc ON (
	        CASE
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000490009107197'	THEN '4223694500052081'	--SJU - WEB (St Johns University)
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000490009185326'	THEN '4223694400057552'	--EFFORTLESS E (EffortlessE)
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400650648'	THEN '4228993510052529'	--The Steak Out
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400697920'	THEN '4228993510057569'	--SEDUCTIONS LINGERIE
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400614826'	THEN '4228993510049533'	--Clinic Pro Software
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400698662'	THEN '4228993510057684'	--CORKSCREW WINE AND CHEESE
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400696120'	THEN '4228993510057221'	--ALLISON ROYCE & ASSOC, IN
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400002220'	THEN '4228993510044104'	--HAIR RESTORATION CLUB
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400604298'	THEN '4228993510048782'	--CANINE CLEANUP
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400053470'	THEN '4228993510047057'	--BACHMAN TRANSFER & STORAG
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400013706'	THEN '4228993510044542'	--Mary E Durborow
	            WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400681742'	THEN '4228993510055696'	--TECH SUPPLY & SERVICES IN
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000000385591000'	THEN '3286000000385591'	--QUIKSERV
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000990000001828'	THEN '7630990000001828'	--WOMENS ECONOMIC VENTURES
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='590308087488346'	THEN '3286590308087488'	--Segpay
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='990200006500422'	THEN '4228990200006500'	--MIRACLE METHOD OF BUCKS
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000000035733000'	THEN '3286000000035733'	--FRONTIER SUITES AIRPORT H
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='141700105172542'	THEN '3286141700105172'	--NATCHEZ 1.800.251.7839 (NATCHEZ SHOOTERS SUPPLY)
				WHEN TD01_ECONNECTIONS_MERCHANT_NUMBER='000993400679910'	THEN '4228990700035223'	--ONE & ONLY FIGURES
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='9264'
	            	AND LEFT(RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,15),3) = '000'
																				THEN SUBSTRING(ENVELOPEJOBNAME,2,4) || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,11)
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='2870'
					AND LEFT(RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,15),3) = '000'
					AND RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,3) = '000'
																				THEN SUBSTRING(TD01_ECONNECTIONS_MERCHANT_NUMBER,4,9) --Truncate First 3 and Last 3 Zeroes
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='2870'
					AND LEFT(TD01_ECONNECTIONS_MERCHANT_NUMBER,2)='22'
					AND RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,6) IN ('000287','000000')
																				THEN LEFT(TD01_ECONNECTIONS_MERCHANT_NUMBER,9) --Truncate Last 6 Numbers - Regardless
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='3286'
					AND LEFT(RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12),2) IN ('14','49','58','59','78','99') --Added '14' because these ~300 Merchants have account in '3286' and '5428', but '3286' seems to be the one with activity.  Added '78' for 2 MIDs that were not being caught
																				THEN SUBSTRING(ENVELOPEJOBNAME,2,4) || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12) 
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='3286'
					AND TD01_STORE_NUMBER='0001'
					AND RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,3)='000'
																				THEN SUBSTRING(ENVELOPEJOBNAME,2,4) || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12)
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='3286'
					AND TD01_STORE_NUMBER<>'0001'
					AND RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,3)='000'
																				THEN SUBSTRING(ENVELOPEJOBNAME,2,4) || LEFT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12) --Truncate Last 3 Zeroes
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='7630'
	            	AND TD01_STORE_NUMBER=SUBSTRING(ENVELOPEJOBNAME,2,4)
																				THEN SUBSTRING(ENVELOPEJOBNAME,2,4) || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12)
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='7630'
	            	AND TD01_STORE_NUMBER<>SUBSTRING(ENVELOPEJOBNAME,2,4)
																				THEN TD01_STORE_NUMBER || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12)
	            WHEN SUBSTRING(ENVELOPEJOBNAME,2,4)='AYSA'
					AND TD01_STORE_NUMBER<>'0001'
																				THEN TD01_STORE_NUMBER || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12)
	            WHEN LEFT(RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,15),3) ='000'	THEN SUBSTRING(ENVELOPEJOBNAME,2,4) || RIGHT(TD01_ECONNECTIONS_MERCHANT_NUMBER,12)
	            ELSE NULL
	        END = rc.MerchantNumber
	    )
	WHERE
--		TD01_TRANSACTION_DATE_TIME::DATE >= '2021-06-01' AND TD01_TRANSACTION_DATE_TIME::DATE <= '2021-06-30' AND
		TD01_ECONNECTIONS_MERCHANT_NUMBER is NOT NULL
		AND TD01_MESSAGE_TYPE IN ('0100','0101','0200','0201') AND TD01_TRANSACTION_TYPE IN ('00','01','02','10','11','20','21','28','40','50','72')
		AND TD01_TRANSACTION_DATE_TIME::DATE >= '2021-03-01'
----	LIMIT 100   

  )
) aa



----------[ UPDATE the Authorizations Table for the AuthResponseCode & Description for DECLINES ]---------------------
-- Version 1.5  [2021-10-05]

---===[This should run 2nd, after above]

UPDATE
    ppbisandbox.jmoeller_AuthorizationsBeta as A
SET
    AuthResponseCode         = B.AuthResponseCode,
    AuthResponseDescription  = B.AuthResponseDescription
FROM
    ppbisandbox.jmoeller_AuthResponseDescriptions_2021_10_04 as B
WHERE
    A.SourceReport              = B.SourceReport
    AND A.CardSchemeCode        = CASE WHEN B.CardSchemeCode = '*' THEN A.CardSchemeCode ELSE B.CardSchemeCode END
    AND A.ProcessorResponseCode = B.ProcessorResponseCode
    AND A.isApproved='No'
	AND NVL(A.AuthResponseDescription,'')=''
;

----------[ UPDATE the Authorizations Table for the AuthResponseCode & Description for PARTIALLY APPROVED ]-----------

---===[This must run 3rd, before below]

UPDATE
    ppbisandbox.jmoeller_AuthorizationsBeta as A
SET
    AuthResponseCode         = '10',
    AuthResponseDescription  = 'Partially Approved'
WHERE
    isApproved='Yes'
    AND ProcessorResponseCode IN ('10','OC','PA')
    AND NVL(AuthResponseDescription,'')=''
;

----------[ UPDATE the Authorizations Table for the AuthResponseCode & Description for APPROVED ]---------------------

---===[This must run 4th, after above]

UPDATE
    ppbisandbox.jmoeller_AuthorizationsBeta as A
SET
    AuthResponseCode         = '00',
    AuthResponseDescription  = 'Approved'
WHERE
    isApproved='Yes'
    AND NVL(AuthResponseDescription,'')=''
;

----------[ UPDATE of the Authorizations Table for the AuthResponseCode & Description END ]---------------------------
