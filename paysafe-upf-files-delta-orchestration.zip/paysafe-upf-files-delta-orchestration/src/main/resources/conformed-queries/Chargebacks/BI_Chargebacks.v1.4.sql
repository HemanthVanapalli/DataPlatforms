/*
Version 1.4 Changelog
+ Changed the 2-character CardScheme to the standard ~4-character CardScheme
+ Added "CAST as MONEY" to all Amount fields
+ 

*/
(
    /*************************
    * OMAHA PLATFORM SD-119  *
    *       VISA             *
    *************************/
    SELECT
        VS_CPD                          ChargebackDate,
        VS_MERCHANT                     MerchantNumber,
        'VISA'							CardScheme,
        'FirstChargeback'               LifecycleType,
        CASE WHEN NVL(VS_AMOUNT,0)>=0 THEN CAST(VS_AMOUNT AS MONEY) ELSE CAST(0.00 AS MONEY) END
        								"WithdrawalAmt",
        CASE WHEN NVL(VS_AMOUNT,0)<0  THEN CAST(ABS(VS_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END
        								"DepositAmt",
        CASE WHEN NVL(VS_AMOUNT,0)<0  THEN 'C' ELSE 'D' END
        								"AmtDirection",
        VSCARDHOLDERFIRST6              First6,
        VSCARDHOLDERLAST4               Last4,
     
        REPLACE(VS_SEQUENCE_NO,' ','')  DisputeManagerCase,
        NULL                            MerLinkCase,
        REPLACE(VS_VISA_CASE,' ','')    VisaCase, --VROL Case Number: This field will contain the VROL case number assigned through the VROL process.
        NULL                            MasterCardCase,
        NULL                            AMEXCase,
        NULL                            DiscoverCase,
            
        VS_REFERENCE_NUMBER             ARN,
        RIGHT(VS_RSN,2) || CAST('.' AS VARCHAR) || VS_DSP_CND "DisputeReasonCode",

        VS_MRCH_DBA                     DBA, ---The field "VS_MRCH_DBA" appears to be what Visa received, not necessarility what's on file at the Processor.  What's at the Processor seems to be the "VS_FDR_MRCH_DBA" field
        VS_CAT                          MCC,
             
        RIGHT(VS_TRAN,15)               AuthDateCardScheme,  --Need to convert '460182279963414' into a TIMESTAMP using XXYDDDSSSSSXXXX where Y the last digit of the current year; DDD is the day of year (GMT) (Julian date in the format DDD); SSSSS is seconds since midnight.
                                        /*
                                            • Positions 1 and 2 contain proprietary information used by Visa;
                                            • position 3 contains the last digit of the current year; 
                                            • positions 4 through 6 contain the Greenwich mean time (GMT) date (Julian date in the format DDD); 
                                            • positions 7 through 11 contain the GMT in relative seconds since start of day; 
                                            • positions 12 through 15 contain a sequence number.                   
                                        */
        RIGHT(VS_TRAN,15)               AuthTraceCode,                                         
        VS_CD                           AuthCode,
        
        VS_TRN_DATE                     BatchDate,
        
        VSCLEARINGDATEREFERENCENO       TxnClearingDate,    
        CASE 
            WHEN VS_SP_CB IS NOT NULL THEN NULL
            ELSE CAST(ABS(VS_AMOUNT) AS MONEY)
        END                             TxnAmount,
    
        CASE WHEN VS_SP_CB IS NOT NULL THEN 'Y' ELSE 'N' END    "isDisputeAmtLessThanTxnAmt",
        NULL                            MerchantNumberCardScheme,
        CASE WHEN VS_S_CURR='840' THEN 'USD' ELSE VS_S_CURR END "CurrencyCode",                                    
        'OMA'                           Processor,       
        VS_CARDHOLDER                   CardFingerprint,
        MC_FDR_TRAN_ID                  FDRTranID,       
        NULL                            TSYSFamilyID,         
        UUID_GENERATE()                 PaysafeChargebackID,
        NULL                            PaysafeTraceDate,
        NULL                            PaysafeTraceID
    FROM
        BISME.SD119_Omaha                   vv 
        --SELECT DISTINCT VS_CBT FROM BISME.SD119_Omaha WHERE VS_SYSTEM_NUMBER IS NOT NULL
    WHERE
        /*
        First Data manual says:  "DSP ST" = Code representing the status of a dispute
            Valid codes:
            F1 - Dispute financial
            L1 - Dispute response financial reversal - recall
            L2 - Dispute response financial reversal - pre-arbitration acceptance
            L3 - Dispute response financial reversal - arbitration decision
            P1 - Dispute response financial
            R1 - Dispute financial reversal - recall
            R2 - Dispute financial reversal - pre-arbitration acceptance
            R3 - Dispute financial reversal - arbitration decision         
            The dispute status is for acquiring only.
        */  
        VS_DSP_ST IN ('F1')
        --AND VS_CBT ='1' This value is always "1" so that doens't seem helpful.
        /*
        First Data manual says: "CBT" = Code representing the item’s current phase of dispute processing
            Visa valid codes:
            1 - First dispute; initiated by the issuer
            2 - Second presentment; initiated by the acquirer        
        */
        AND VS_DISPOSITION LIKE '** %'  --This is really weird way of FDR communicating to us but this is how FDR does it. 
) UNION ALL (
    /*************************
    *   OMAHA PLATFORM       *
    *   SD-119 MasterCard    *
    *************************/
    SELECT
        MC_CPD                          ChargebackDate,
        MC_MERCHANT                     MerchantNumber,
        'MC'                            CardScheme,
        'FirstChargeback'               LifecycleType,        
        CASE 
            WHEN MC_REVERSAL IS NULL AND LEFT(MC_PROC_CD,2)='20' THEN CAST(0.00 AS MONEY)		--A normal chargeback of a merchandise return would deposit funds to the merchant's DDA
            WHEN MC_REVERSAL='R'     AND LEFT(MC_PROC_CD,2)='20' THEN CAST(MC_AMOUNT AS MONEY)	--A *reversal* of chargeback of a merchandise return would withdraw funds from the merchant's DDA
            WHEN MC_REVERSAL='R'                                 THEN CAST(0.00 AS MONEY)		--All other reversals would deposit funds from the merchant's DDA
            WHEN MC_REVERSAL IS NULL                             THEN CAST(MC_AMOUNT AS MONEY)	--If it's not being reversed, and it's not a weird merchandise return, then it's a normal withdrawal.
            ELSE 0 
        END								"WithdrawalAmt",
        CASE 
            WHEN MC_REVERSAL IS NULL AND LEFT(MC_PROC_CD,2)='20' THEN (MC_AMOUNT AS MONEY)	--A normal chargeback of a merchandise return would deposit funds to the merchant's DDA
            WHEN MC_REVERSAL='R'     AND LEFT(MC_PROC_CD,2)='20' THEN CAST(0.00 AS MONEY)	--A *reversal* of chargeback of a merchandise return would withdraw funds from the merchant's DDA
            WHEN MC_REVERSAL='R'                                 THEN (MC_AMOUNT AS MONEY)	--All other reversals would deposit funds from the merchant's DDA
            WHEN MC_REVERSAL IS NULL                             THEN CAST(0.00 AS MONEY)	--If it's not being reversed, and it's not a weird merchandise return, then it's a normal withdrawal.
            ELSE 0
        END								"DepositAmt",
        CASE 
            WHEN MC_REVERSAL IS NULL AND LEFT(MC_PROC_CD,2)='20' THEN 'C'  
            WHEN MC_REVERSAL='R'     AND LEFT(MC_PROC_CD,2)='20' THEN 'D'  
            WHEN MC_REVERSAL='R'                                 THEN 'C'  
            WHEN MC_REVERSAL IS NULL                             THEN 'D'
            ELSE '?'
        END								"AmtDirection",
        MCCARDHOLDERFIRST6              First6,
        MCCARDHOLDERLAST4               Last4,
     
        MC_SEQUENCE_NUM                 DisputeManagerCase, 
        NULL                            MerLinkCase,
        NULL                            VisaCase, 
        /*
        CB REF NUM/CBXREF = First data manaul says: Chargeback reference number or chargeback cross-reference number 
        Number identifying the item that you are charging back. System-assigned unique sequence number identifying the chargeback    
        */
        MC_CBREFNUM                     MasterCardCase, -- MC_CBXREF should likely be included here but not sure yet.
        NULL                            AMEXCase,
        NULL                            DiscoverCase,
            
        MC_REFERENCE_NUMBER             ARN,
        MC_RSN                          "DisputeReasonCode",
        MC_MERCHANT_NAME                DBA, 
        MC_CAT_CD                       MCC,
             
        TO_CHAR(TO_DATE('0001'||SUBSTRING(MC_TRACE_ID,11,2)||RIGHT(MC_TRACE_ID,2),'YYYYMMDD'),'Mon DD')   AuthDateCardScheme,  
        MC_TRACE_ID                     AuthTraceCode,                                      
        MC_AUTH_CD                      AuthCode,
        
        MC_TRN_DATE						BatchDate,
        
        MCCLEARINGDATEREFERENCENO       TxnClearingDate,    
        CAST(ABS(MC_TRAN_AMOUNT) AS MONEY) TxnAmount,
    
        CASE WHEN MC_FNC_CD IN ('282','453','454') THEN 'Y' ELSE 'N' END        "isDisputeAmtLessThanTxnAmt",
        NULL                            MerchantNumberCardScheme,
        CASE WHEN MC_CURR_CHBK_FEE='840' THEN 'USD' ELSE MC_CURR_CHBK_FEE END   "CurrencyCode",                                    
        'OMA'                           Processor,       
        MC_CARDHOLDER                   CardFingerprint,
        MC_FDR_TRAN_ID                  FDRTranID,   
        NULL                            TSYSFamilyID,        
        UUID_GENERATE()                 PaysafeChargebackID,
        NULL                            PaysafeTraceDate,
        NULL                            PaysafeTraceID
    FROM
        BISME.SD119_Omaha                   vv  
    WHERE
        MC_SYSTEM_NUMBER IS NOT NULL
        AND MC_DISPOSITION LIKE '** %'
        --AND MC_REVERSAL='R' -- Per First Data manual, "If the item is a reversal, R prints after the amount."
        AND (
                /*
                Per First Data manual: CBT = Code representing the item’s current phase of chargeback processing
                    Mastercard valid codes:
                    1 - First chargeback; initiated by the issuer
                    2 - Second presentment; initiated by the acquirer
                    3 - Arbitration chargeback; initiated by the issuer
                    blank? This code is only valid for international disputes.            
                */
                MC_CBT='1'  --Per First Data manual, CBT = Code representing the item’s current phase of chargeback processing. And a value of "1" means "First chargeback; initiated by the issuer"
                /*
                205 - Type 2 full amount chargeback
                282 - Type 2 partial amount chargeback
                450 - Type 1 full amount chargeback
                451 - Type 3 full amount chargeback
                453 - Type 1 partial amount chargeback
                454 - Type 3 partial amount chargeback            
                */
                OR  MC_FNC_CD IN ('450','453') 
            )              
) UNION ALL (
    /*************************
    *   NORTH PLATFORM       *
    *    All Cards           *
    *************************/
    SELECT 
        FIRST_CHARGEBACK_DATE           ChargebackDate,
        LOCATION_ID                     MerchantNumber,     
        CASE 
            WHEN CARD_TYPE IN ('003','00002','00079','00080','00081','00082','00083','00084') THEN 'VISA'
            WHEN CARD_TYPE IN ('00001','002') THEN 'MC'
            WHEN CARD_TYPE IN ('00003') THEN 'DISC' --Discover
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '060007' THEN 'MAES' --MAESTRO
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '060005' THEN 'ITLK' --INTERLINK
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID IN('060003','060006','060004') THEN 'STAR' --STAR
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '060011' THEN 'PULS' --PULSE
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '060141' THEN 'ACCL' --ACCEL
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '060010' THEN 'NYCE' --NYCE
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '070000' THEN 'AFFN' --AFFN
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '060013' THEN 'SHZM' --SHAZAM
            WHEN CARD_TYPE IN ('00018') AND DEBIT_NETWORK_ID = '065000' THEN 'JEAN' --JEANIE                  
            WHEN CARD_TYPE IN ('00018') THEN 'GPIN' --ATM (Debit) 
            WHEN CARD_TYPE IN ('00008') THEN 'OPTB' -- Amex Acquiring
            WHEN CARD_TYPE IN ('00035') THEN 'WEX' 	-- WEX Wright Express
            WHEN CARD_TYPE IN ('00027') THEN 'EBT'	-- EBT Electronic Benefits Transfer
            ELSE LEFT(CARD_TYPE,2) 
        END                             CardScheme,    
        'FirstChargeback'               LifecycleType,
        CASE WHEN NVL(DISPUTEAMOUNTSIGNED,0)>=0 THEN CAST(DISPUTEAMOUNTSIGNED AS MONEY) ELSE CAST(0.00 AS MONEY) END         
                                        WithdrawalAmt,
        CASE WHEN NVL(DISPUTEAMOUNTSIGNED,0)<0  THEN CAST(ABS(DISPUTEAMOUNTSIGNED) AS MONEY) ELSE CAST(0.00 AS MONEY) END    
                                        DepositAmt,
        CASE WHEN NVL(DISPUTEAMOUNTSIGNED,0)<0  THEN 'C' ELSE 'D' END
                                        AmtDirection,
        CARDNUMBERFIRST6                First6,
        CARDNUMBERLAST4                 Last4,
                          
        nn.IDS_CASE_NUMBER              DisputeManagerCase,
        NULL                            MerLinkCase,
        
        NULL                            VisaCase,
        NULL                            MasterCardCase,
        NULL                            AMEXCase,
        NULL                            DiscoverCase,
            
        ACQUIRER_REFERENCE_NUMBER       ARN,
        ---== START: This section of the query translates the processor's proprietary chargeback reason codes into the universal industry standard codes ==---
        CASE
            --Visa card scheme
            WHEN CARD_TYPE IN ('003','00002','00079','00080','00081','00082','00083','00084')
                THEN LEFT(REASON_CODE,2) || CAST('.' AS VARCHAR) || SUBSTRING(REASON_CODE,3,1)
            --Mastercard card scheme #1 of #2
            WHEN CARD_TYPE IN ('00001','002') AND NVL(LEFT(REASON_CODE,2),'ERROR') IN ('07','08','12','31','34','37','40','41','42','46','49','53','54','55','59','60','63','70','71') 
                THEN '48' || LEFT(REASON_CODE,2)
            --Mastercard card scheme #2 of #2                
            WHEN CARD_TYPE IN ('00001','002') AND NVL(LEFT(REASON_CODE,2),'ERROR') NOT IN ('07','08','12','31','34','37','40','41','42','46','49','53','54','55','59','60','63','70','71')      
                THEN REASON_CODE
            ELSE
                REASON_CODE
        END                             DisputeReasonCode,
        ---== END: This section of the query translates the processor's proprietary chargeback reason codes into the universal industry standard codes ==---
//        SELECT * FROM BISME.DFM_ChargebackDetail009_North WHERE IDS_CASE_NUMBER='010000390501'
//        SELECT CARD_TYPE,DEBIT_NETWORK_DESCRIPTION, count(*) FROM BISME.DFM_ChargebackDetail009_North GROUP BY CARD_TYPE,DEBIT_NETWORK_DESCRIPTION
//        SELECT * FROM BISME.DFM_ChargebackDetail009_North WHERE IDS_CASE_NUMBER='402600095101' --This is the Discover Chargeback that needs reserach.
        LOCATION_DBA_NAME               DBA, 
        SIC_CODE                        MCC,
             
        NULL                            AuthDateCardScheme,  
        NULL                            AuthTraceCode, -- Could this be SPECIAL_REFERENCE_2 or maybe SPECIAL_REFERENCE_1 ?                                         
        AUTHORIZATION_CODE              AuthCode,
        
        BATCH_DATE                      BatchDate,
        
        CLEARINGDATEREFERENCENUMBER     TxnClearingDate,   --Might need to include TRANSACTION_DATE somewhere for NORTH 
        CAST(ABS(PROCESSEDTRANSACTIONAMOUNTSIGNED) AS MONEY) TxnAmount,
    
        CASE WHEN PROCESSEDTRANSACTIONAMOUNTSIGNED < DISPUTEAMOUNTSIGNED THEN 'Y' ELSE 'N' END
                                        isDisputeAmtLessThanTxnAmt,
        NULL                            MerchantNumberCardScheme,                                    
        CASE WHEN CHARGEBACK_CURRENCY_CODE='840' THEN 'USD' ELSE CHARGEBACK_CURRENCY_CODE END                                    
                                        CurrencyCode,
        'NOR'                           Processor,  
        CARD_NUMBER                     CardFingerprint,
        NULL                            FDRTranID,     
        NULL                            TSYSFamilyID,
        UUID_GENERATE()                 PaysafeChargebackID,
        NULL                            PaysafeTraceDate,
        NULL                            PaysafeTraceID                                 
    FROM 
        (
            SELECT 
                IDS_CASE_NUMBER, 
                MIN(STATUS_DATE) STATUS_DATE
            FROM
                BISME.DFM_ChargebackDetail009_North
            WHERE
                CHARGEBACK_CYCLE='F' // Chargeback Cycle Code: F=First Chargeback/Reversal, S=Second Chargeback/Reversal, I=Exception Case, R=Representment Reject
            GROUP BY
                IDS_CASE_NUMBER
         ) aa
        INNER JOIN BISME.DFM_ChargebackDetail009_North  nn ON (aa.IDS_CASE_NUMBER=nn.IDS_CASE_NUMBER AND aa.STATUS_DATE=nn.STATUS_DATE)     
        -- SELECT * FROM BISME.DFM_ChargebackDetail009_North WHERE LENGTH(ACQUIRER_REFERENCE_NUMBER) != 23
        -- SELECT * FROM BISME.DFM_ChargebackDetail009_North WHERE IDS_CASE_NUMBER='890243850301'
        -- SELECT REASON_CODE, SPLIT_PART(REASON_CODE_DESCRIPTION,' ',1), count(*) FROM BISME.DFM_ChargebackDetail009_North WHERE CARD_TYPE IN ('00003') GROUP BY REASON_CODE, SPLIT_PART(REASON_CODE_DESCRIPTION,' ',1)
        -- SELECT * FROM BISME.DFM_ChargebackDetail009_North WHERE ACQUIRER_REFERENCE_NUMBER='66503410093839000154420'
        -- SELECT DISTINCT TRANSACTION_SERVICE_CODE FROM BISME.DFM_ChargebackDetail009_North
        -- SELECT DISTINCT DEBIT_NETWORK_DESCRIPTION, DEBIT_NETWORK_ID	FROM BISME.DFM_ChargebackDetail009_North
        -- SELECT *	FROM BISME.DFM_ChargebackDetail009_North WHERE CARD_TYPE IN ('00003') AND CHARGEBACK_CYCLE='F'
        -- SELECT *	FROM BISME.DFM_ChargebackDetail009_North WHERE CHARGEBACK_CYCLE='F' AND FIRST_CHARGEBACK_DATE>='07-SEP-2020' ORDER BY DISPUTEAMOUNTSIGNED ASC
        -- SELECT *	FROM BISME.DFM_ChargebackDetail009_North WHERE SOFT_DESCRIPTOR IS NOT NULL
        -- SELECT *	FROM BISME.DFM_ChargebackDetail009_North WHERE SUBMERCHANT_ID IS NOT NULL
        -- SELECT *	FROM BISME.DFM_ChargebackDetail009_North WHERE SUBMERCHANT_ID IS NOT NULL
) UNION ALL (        
    /*************************
    *      TSYS PLATFORM     *
    *         VISA           *
    *************************/  
    SELECT 
        CASENUMBERDATE                  ChargebackDate,
        MERCHANT_NUMBER                 MerchantNumber,
        CASE
            WHEN CARD_BRAND='1' THEN 'VISA'
            WHEN CARD_BRAND='2' THEN 'MC'
            WHEN CARD_BRAND='3' THEN 'DISC'
            WHEN CARD_BRAND='4' THEN 'OPTB'
            WHEN CARD_BRAND='5' THEN 'PPAL'  --'PY' (old) = 'PPAL'
            ELSE CARD_BRAND
        END                             CardScheme,    
        'FirstChargeback'               LifecycleType,        
        CASE WHEN DEBIT_CREDIT='D' THEN CAST(CASE_AMOUNT AS MONEY) ELSE CAST(0.00 AS MONEY) END         
                                        WithdrawalAmt,
        CASE WHEN DEBIT_CREDIT='C' THEN CAST(CASE_AMOUNT AS MONEY) ELSE CAST(0.00 AS MONEY) END    
                                        DepositAmt,
        CASE WHEN DEBIT_CREDIT IN ('D','C') THEN DEBIT_CREDIT ELSE '?' END
                                        AmtDirection,
        CARDHOLDERACCOUNTNUMBERFIRST6   First6,
        CARDHOLDERACCOUNTNUMBERLAST4    Last4,
        
        NULL                            DisputeManagerCase,
        CASE_NUMBER                     MerLinkCase,
        VROL_CASE_NUMBER                VisaCase, -- VROL Case Number: Length: 10, This field will contain the VROL case number assigned through the VROL process. This is a required field for endpoint-initiated transactions.
        CASE
            WHEN CARD_BRAND='2' THEN CHARGEBACK_REFERENCE_NUMBER 
        END                             MasterCardCase, --Could also be useful to have this 12-digit value, MCOMM_CLAIM_ID, but it's not alwyas there, not sure why. 
        CASE
            WHEN CARD_BRAND='4' THEN CHARGEBACK_REFERENCE_NUMBER 
        END                             AMEXCase,
        CASE
            WHEN CARD_BRAND='3' THEN CHARGEBACK_REFERENCE_NUMBER 
        END                             DiscoverCase,    
        
        ACQUIRER_REFERENCE_NUMBER       ARN,
        CASE 
            WHEN CARD_BRAND='1' THEN LEFT(REASON_CODE,2) || CAST('.' AS VARCHAR) || SUBSTRING(REASON_CODE,4,1)
            WHEN CARD_BRAND='4' THEN FULL_REASON_CODE
            ELSE REASON_CODE
        END                             DisputeReasonCode,
        DBA_NAME                        DBA, 
        MCC                             MCC,
             
        TRANS_ID                        AuthDateCardScheme,  
                                        ---== for Visa (CARD_BRAND='1') ==---
                                        ---Need to convert '300073412324434' into a TIMESTAMP using XXYDDDSSSSSXXXX where Y the last digit of the current year; DDD is the day of year (GMT) (Julian date in the format DDD); SSSSS is seconds since midnight.
                                        /*
                                            • Positions 1 and 2 contain proprietary information used by Visa;
                                            • position 3 contains the last digit of the current year; 
                                            • positions 4 through 6 contain the Greenwich mean time (GMT) date (Julian date in the format DDD); 
                                            • positions 7 through 11 contain the GMT in relative seconds since start of day; 
                                            • positions 12 through 15 contain a sequence number.                   
                                        */    
                                        ---== For other card brands: Not sure if there's a Julian date or other logic built into the value.  If not, please use NULL value here. ==-- 
        TRANS_ID                        AuthTraceCode,                                         
        AUTH_CODE                       AuthCode,
        
        DATE_TRANSACTION                BatchDate,
        
        CLEARINGDATEACQUIRERREFERENCENUMBER TxnClearingDate,   
        NULL                            TxnAmount,
    
        NULL                            isDisputeAmtLessThanTxnAmt,
        NULL                            MerchantNumberCardScheme,    
        NULL                            CurrencyCode,
        'TSS'                           Processor,    
        CARDHOLDER_ACCOUNT_NUMBER       CardFingerprint,
        NULL                            FDRTranID,     
        ts.FAMILY_ID                    TSYSFamilyID,        
        UUID_GENERATE()                 PaysafeChargebackID,
        NULL                            PaysafeTraceDate,
        NULL                            PaysafeTraceID    
    FROM 
        BISME.MerlinCaseActionFile_TSYS     ts  -- SELECT * FROM BISME.MerlinCaseActionFile_TSYS LIMIT 1000
        --INNER JOIN BI.ReportingChannels     rc ON (ts.MERCHANT_NUMBER=rc.MerchantNumber)
        --SELECT * FROM BISME.MerlinCaseActionFile_TSYS WHERE LENGTH(ACQUIRER_REFERENCE_NUMBER)!=23
        --SELECT * FROM BISME.MerlinCaseActionFile_TSYS WHERE CARD_BRAND='3'
        -- SELECT CARD_BRAND, CHARGEBACK_REFERENCE_NUMBER, * FROM BISME.MerlinCaseActionFile_TSYS WHERE CHARGEBACK_REFERENCE_NUMBER != '000000' AND ITEM_TYPE='01' AND CASE_TYPE IN ('01','12','18','20','21') AND RECORD_TYPE IS NULL
    WHERE
        ITEM_TYPE='01' -- 1 - New Cases: New chargebacks and new reversal cases loaded today.
        AND CASE_TYPE IN ('01','12','18','20','21') --1: First Chargeback, 12: Discover Chargeback, 18: American Express Chargeback, ??? 20: Allocation ??? 21: Collaboration ??
        AND RECORD_TYPE IS NULL --Indicates whether a record is a regular (original) chargeback or a chargeback reversal. Possible values: <SPACE>: Regular Record,  R: Reversal
        --AND HoustonLevel1Desc='iPayment'      
) UNION ALL (
    /*************************
    *      OMAHA PLATFORM    *
    *      SD206 Discover    *
    *************************/  
    SELECT
        DISPUTE_DATE                    ChargebackDate,
        FDR_MRCH_NR                     MerchantNumber,
        'DISC'							CardScheme,    
        'FirstChargeback'               LifecycleType,        
        CASE WHEN LEFT(PRSC_CODE,2) != '20' THEN CAST(ABS(TRANS_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END         
                                        WithdrawalAmt,
        CASE WHEN LEFT(PRSC_CODE,2)  = '20' THEN CAST(ABS(TRANS_AMOUNT) AS MONEY) ELSE CAST(0.00 AS MONEY) END    
                                        DepositAmt,
        CASE WHEN LEFT(PRSC_CODE,2)  = '20' THEN 'C' ELSE 'D' END
                                        AmtDirection,
        CARDNUMBERFIRST6                First6,
        CARDNUMBERLAST4                 Last4,
            
        DISP_CASE_NR                    DisputeManagerCase,
        NULL                            MerLinkCase,
        NULL                            VisaCase,
        NULL                            MasterCardCase,
        NULL                            AMEXCase,
        DISP_CASE_NR                    DiscoverCase,    --Could also be CASE_SEQ_NR.  Also looks like TRACE_AUDIT_NR might be PO Number?
        
        ACQUIRER_REFERENCE_NO           ARN,
        DISPUTE_RESN                    DisputeReasonCode, -- DISPUTE_RESN has values like "7030" but DISPUTE_RESN_CD has values like "UA02" which mean "Fraud – Card Present Transaction" per https://chargeback.com/chargeback-reason-codes/discover-reason-codes/
        
        FDR_MERCHANT_NAME               DBA, 
        MCC                             MCC,
             
        NULL                            AuthDateCardScheme,  -- A auth date is likely embeded in the NETWORK_ID but I don't have the auth manual (yet) so cannot figure it out. 
        NETWORK_ID                      AuthTraceCode, -- Network Reference Identifier (NRID): Unique ID assigned at the time of the Authorization Response      
                                                                                    
        AUTH_CD                         AuthCode,
        
        NULL                            BatchDate,
        
        CLEARINGDATEACQUIRERREFERENCENO TxnClearingDate,   
        NULL                            TxnAmount,  --Per FDR sepc, this should be the "RECONS AMT" column but it's always blank. 
    
        CASE WHEN FUNCCD='453' THEN 'Y' WHEN FUNCCD='450' THEN 'N' ELSE FUNCCD END    
                                        isDisputeAmtLessThanTxnAmt,                                    
        DISCV_MRCH_NR                   MerchantNumberCardScheme,
        ISSR_CNCY                       CurrencyCode,
        'OMA'                           Processor,     
        CARDHOLDER_NR                   CardFingerprint,
        TRANS_ID                        FDRTranID,     
        NULL                            TSYSFamilyID,         
        
        UUID_GENERATE()                 PaysafeChargebackID,
        NULL                            PaysafeTraceDate,
        NULL                            PaysafeTraceID
    FROM
        BISME.SD206_Omaha   
        -- SELECT ACTN_CD, count(*) FROM BISME.SD206_Omaha GROUP BY ACTN_CD
        -- SELECT FUNCCD, count(*) FROM BISME.SD206_Omaha GROUP BY FUNCCD
        -- SELECT * FROM BISME.SD206_Omaha WHERE JULIANCONVERTEDTRANSSTTLDT != CLEARINGDATEACQUIRERREFERENCENO
        -- SELECT * FROM BISME.SD206_Omaha WHERE JULIANCONVERTEDTRANSSTTLDT != SETTL_DATE
    WHERE 
    //REC_TYPE is always is 2422 so nothing useful here.
    FUNCCD IN ('450','453')
    /* FUNCCD aka "Function Code"
        450="First Chargeback, Full"  
        453="First Chargeback, Partial"
        491="Ticket Retrieval fulfilled"
        492="Ticket Retrieval not fulfilled"
        205="Chargeback Reversal, Full"
        211="Chargeback Reversal, Partial"
        280="Representment Request"
        ..more in the Discover Network doc... 
    */            
    /*
    PRSC_CODE akak "PROCESSING CODE"
    -- Almost always 000000 but 10% is 130000 and some  140000, 150000 and 200000
    - First 2 digits of the 6 digit code mean:
    00 = Purchase (of Goods or Service): A Card Sale for the purchase of goods or services
    13 = Address Verification with a Goods or Service Authorization for Recurring Billing (Automatic Payment): Provide street address and postal code for a recurring charge (e.g.,monthly, bimonthly) for the purchase of goods or services     
    14 = Recurring Billing (Automatic Payment) – Goods or Service: A recurring charge (e.g., monthly, bimonthly) for the purchase of goods or services
    15 = Installment Payment – Goods or Service: Paying for the purchase of goods or services with installment payments (e.g., monthly) for a defined period of time
    20 = Merchandise Return Used when placing Credit on Prepaid Gift Card for returned merchandise
    */   
) UNION ALL (
    /*************************
    *      OMAHA PLATFORM    *
    *      SD-430B AMEX      *
    *************************/
	SELECT
        ADJ_DT                          ChargebackDate,
        FDR_MRCH_NR                     MerchantNumber,
        'OPTB'							CardScheme,   --Was 'AX', now 'OPTB'
        'FirstChargeback'               LifecycleType,         
        CASE WHEN CB_AMT<0 THEN CAST(ABS(CB_AMT) AS MONEY) ELSE CAST(0.00 AS MONEY) END         
                                        WithdrawalAmt,
        CASE WHEN CB_AMT>=0 THEN CAST(ABS(CB_AMT) AS MONEY) ELSE CAST(0.00 AS MONEY) END    
                                        DepositAmt,
        CASE WHEN CB_AMT<0 THEN 'D' ELSE 'C' END
                                        AmtDirection,
        CARDNUMBERFIRST6                First6,
        CARDNUMBERLAST4                 Last4,
            
        ADJ_NR                          DisputeManagerCase,
        NULL                            MerLinkCase,
        
        NULL                            VisaCase,
        NULL                            MasterCardCase,
        CURRENT_CASE                    AMEXCase,
        NULL                            DiscoverCase,
        
        IND_REF_NR                      ARN,
        CB_REASON                       DisputeReasonCode,
       
        MRCH_NAME                       DBA, 
        NULL                            MCC,
             
        NULL                            AuthDateCardScheme,  
        NULL                            AuthTraceCode,                                         
        NULL                            AuthCode,
        
        TRAN_DT                         BatchDate,  --TRAN_DT and JULIANCONVERTEDSEPROCDATE are always the same
        
        NULL                            TxnClearingDate, --Need to figure out how to get this out of the IND_REF_NR (ARN)
        CAST(ABS(ROC_AMT) AS MONEY)		TxnAmount,
    
        CASE WHEN ABS(CB_AMT)<ABS(ROC_AMT) THEN 'Y' ELSE 'N' END
                                        isDisputeAmtLessThanTxnAmt,
        SE_NR                           MerchantNumberCardScheme,
        NULL                            CurrencyCode,
        'OMA'                           Processor,   
        CARDHOLDER_NR                   CardFingerprint,
        NULL                            FDRTranID,     
        NULL                            TSYSFamilyID,           
        UUID_GENERATE()                 PaysafeChargebackID,
        NULL                            PaysafeTraceDate,
        NULL                            PaysafeTraceID
    FROM 
        BISME.SD430B_Omaha
        --(SELECT MIN(CURRENT_CASE) AS CURRENT_CASE, MAX(ADJ_DT) AS ADJ_DT FROM BISME.SD430B_Omaha GROUP BY CURRENT_CASE, ADJ_DT) AS bb
        -- SELECT AMEX_ID,CURRENT_CASE, REFERENCE_NR, ADJ_NR, * FROM BISME.SD430B_Omaha WHERE CARDHOLDER_NR IS NULL
        -- SELECT * FROM BISME.SD430B_Omaha WHERE ABS(CB_AMT) != ABS(ROC_AMT)
        -- SELECT FDR_MRCH_NR, MRCH_NAME, count(*)  FROM BISME.SD430B_Omaha WHERE SE_NR='1260527650' GROUP BY FDR_MRCH_NR, MRCH_NAME
        -- SELECT * FROM BISME.SD430B_Omaha WHERE ADJ_NR='518868'
        -- SELECT * FROM BISME.SD430B_Omaha WHERE ADJ_NR='518868'
    WHERE
	    FINANCIAL_INDICATOR='Y'
        -- Really do not know how to limit the rows so that only 1st chargebacks because we still do not (yet) have the AMEX manuals and the FDR manuals are nearly worthless.
        -- Likely has something to do with CURRENT_ACT='10' and maybe the CB_REASON.  Look at ADJ_NR='518868' for example of issues.
) 
;
---=== STOP HERE ==---
---=== STOP HERE ==---
---=== STOP HERE ==---


SELECT
    *  
FROM 
    BISME.SD430B_Omaha 
LIMIT 500
;
SELECT
    PRSC_CODE,
    count(*)
FROM
    BISME.SD206_Omaha
GROUP BY
    PRSC_CODE
;
SELECT
    *
FROM
    BISME.SD206_Omaha
LIMIT
    500
;    

SELECT 
    ACQUIRER_REFERENCE_NUMBER, COUNT(*)
FROM
    BISME.MerlinCaseActionFile_TSYS
WHERE
    --DEBIT_CREDIT='N'
    CARD_BRAND='1'
    AND RECORD_TYPE IS NULL
    AND ITEM_TYPE='01'
    AND CASE_TYPE IN ('01','12','18','20','21')
    --AND ACQUIRER_REFERENCE_NUMBER='24239000085900018796609'
GROUP BY
    ACQUIRER_REFERENCE_NUMBER
HAVING
   COUNT(*)>=2 
;
SELECT
    MERCH_AMOUNT, CASE_AMOUNT,REASON_CODE,*
FROM
    BISME.MerlinCaseActionFile_TSYS
WHERE
    CARD_BRAND='1'
    --AND RECORD_TYPE IS NULL
    --AND ITEM_TYPE='01'
    --AND CASE_TYPE IN ('01','12','18','20','21')
    --AND CHARGEBACK_REFERENCE_NUMBER!='000000'
    AND ACQUIRER_REFERENCE_NUMBER='74239000212900011502922'
    AND RECORD_TYPE IS NULL
    AND ITEM_TYPE='01'
    AND CASE_TYPE IN ('01','12','18','20','21')  
    --AND MERCH_AMOUNT!=CASE_AMOUNT 
LIMIT 500    
;
SELECT
   *
FROM 
    BISME.MerlinCaseActionFile_TSYS
WHERE
    -- Visa chargebacks only for starters.
    CARD_BRAND='1' 
    
    -- 01 = New Cases: New chargebacks and 
    -- new reversal cases loaded today.
    AND ITEM_TYPE='01' 
    
    --1: First Chargeback
    --12: Discover Chargeback
    --18: American Express Chargeback
    --20: Allocation ??? 
    --21: Collaboration ??
    AND CASE_TYPE IN ('01','12','18','20','21')
    AND ENVELOPEBUSINESSLOCATION='Irvine'
    --Indicates whether a record is a regular (original) chargeback
    --or a chargeback reversal. Possible values: 
    --<SPACE>: Regular Record
    --R: Reversal
    AND RECORD_TYPE='R'
LIMIT 
    500        
;
SELECT
   *
FROM 
    BISME.MerlinCaseActionFile_TSYS
WHERE
    -- Visa chargebacks only for starters.
    CARD_BRAND='1' 
    
    -- 01 = New Cases: New chargebacks and 
    -- new reversal cases loaded today.
    --AND ITEM_TYPE='01' 
    --AND ENVELOPEBUSINESSLOCATION='Irvine'
    --AND RECORD_TYPE='R'
    --AND CASE_TYPE IN ('01','12','18','20','21')
    --AND ACQUIRER_REFERENCE_NUMBER='24181950114900018661083'
    AND MERCHANT_NUMBER='3286000000228874'
    --AND VROL_CASE_NUMBER='1908115136'
LIMIT 500
;
    
---== Irvine MSFT SQL Server code ==---    
SELECT 
    a.MerchantID,
    a.CardTypeID,
    CONVERT(VARCHAR(6), a.ReportDate, 112) [Month],
    Sum(a.CBCount)                         [CB Count],
    Sum(a.CBAmount)                        [CB Volume]
INTO   
    #CBs
FROM   
    ChargebacksSummary      a
    INNER JOIN #merchants   b ON a.MerchantID = b.MID
WHERE  
    a.CBType = 1 --filter for 1st chargebacks
    AND 
        (
            a.CardTypeID IN (1,2,4) --1 is Visa, 2 is MasterCard, 3 is Amex, 4 is Discover
            OR (a.CardTypeID=3 AND b.[Amex Flag]>0) --Amex Flag
        ) 
    AND CAST(ReportDate AS DATE) BETWEEN @StartDate AND @EndDate
GROUP BY
    a.MerchantID,
    a.CardTypeID,
    CONVERT(VARCHAR(6), a.ReportDate, 112)
/*
DROP TABLE IF EXISTS ChargebackDescriptions
;
CREATE LOCAL TEMPORARY TABLE ChargebackDescriptions
(
    DisputeReasonCode       VARCHAR(500) NOT NULL,
    DisputeDesc             VARCHAR(500) NULL,
    DisputeDescCardScheme   VARCHAR(500) NULL
) ON COMMIT PRESERVE ROWS NO PROJECTION 
;

INSERT INTO ChargebackDescriptions 
SELECT '4507',NULL,'Incorrect Transaction Amount or Primary Account Number (PAN) Presented' UNION
SELECT '4512',NULL,'Multiple Processing' UNION
SELECT '4513',NULL,'Credit Not Presented' UNION
SELECT '4515',NULL,'Paid Through Other Means' UNION
SELECT '4516',NULL,'Request for Support Not Fulfilled' UNION
SELECT '4517',NULL,'Request for Support Illegible/Incomplete' UNION
SELECT '4521',NULL,'Invalid Authorization' UNION
SELECT '4523',NULL,'Unassigned Cardmember Account Number' UNION
SELECT '4527',NULL,'Missing Imprint' UNION
SELECT '4530',NULL,'Currency Discrepancy' UNION
SELECT '4534',NULL,'Multiple ROCs' UNION
SELECT '4536',NULL,'Late Presentment' UNION
SELECT '4540',NULL,'Card Not Present' UNION
SELECT '4541',NULL,'Recurring Payment' UNION
SELECT '4544',NULL,'Cancellation of Recurring Goods/Services' UNION
SELECT '4553',NULL,'Not as Described or Defective Merchandise' UNION
SELECT '4554',NULL,'Goods and Services Not Received' UNION
SELECT '4586',NULL,'Altered Amount' UNION
SELECT '4750',NULL,'Car Rental Charge Non-Qualified or Unsubstantiated' UNION
SELECT '4752',NULL,'Credit/Debit Presentment Error' UNION
SELECT '4754',NULL,'Local Regulatory/Legal Dispute' UNION
SELECT '4755',NULL,'No Valid Authorization' UNION
SELECT '4763',NULL,'Fraud Full Recourse' UNION
SELECT '4798',NULL,'Fraud Liability Shift - Counterfeit' UNION
SELECT '4799',NULL,'Fraud Liability Shift - Lost/Stolen/Non-Received' UNION
SELECT '05',NULL,'Good Faith Investigation' UNION
SELECT 'AA',NULL,'Does Not Recognize' UNION
SELECT 'AP',NULL,'Recurring Payments' UNION
SELECT 'AT',NULL,'Authorization Noncompliance' UNION
SELECT 'AW',NULL,'Altered Amount' UNION
SELECT 'CD',NULL,'Credit/Debit Posted Incorrectly' UNION
SELECT 'DC',NULL,'Dispute Compliance' UNION
SELECT 'DP',NULL,'Duplicate Processing' UNION
SELECT 'IN',NULL,'Invalid Card Number' UNION
SELECT 'LP',NULL,'Late Presentation' UNION
SELECT 'PM',NULL,'Paid by Other Means' UNION
SELECT 'RG',NULL,'Non-Receipt of Goods, Services, or Cash' UNION
SELECT 'RM',NULL,'Cardholder Disputes Quality of Goods or Services' UNION
SELECT 'RN2',NULL,'Credit Not Processed' UNION
SELECT 'UA01',NULL,'Fraud – Card Present Transaction' UNION
SELECT 'UA02',NULL,'Fraud – Card Not Present Transaction' UNION
SELECT 'UA05',NULL,'Fraud – Chip Counterfeit Transaction' UNION
SELECT 'UA06',NULL,'Fraud – Chip and PIN Transaction' UNION
SELECT '4807',NULL,'Warning Bulletin File' UNION
SELECT '4808',NULL,'Authorization-Related Chargeback' UNION
SELECT '4812',NULL,'Account Number Not On File' UNION
SELECT '4831',NULL,'Transaction Amount Differs' UNION
SELECT '4834',NULL,'Point-of-Interaction Error' UNION
SELECT '4837',NULL,'No Cardholder Authorization' UNION
SELECT '4840',NULL,'Fraudulent Processing of Transactions' UNION
SELECT '4841',NULL,'Canceled Recurring or Digital Goods Transactions' UNION
SELECT '4842',NULL,'Late Presentment' UNION
SELECT '4846',NULL,'Correct Transaction Currency Code Not Provided' UNION
SELECT '4849',NULL,'Questionable Merchant Activity' UNION
SELECT '4850',NULL,'Installment Billing Dispute' UNION
SELECT '4853',NULL,'Cardholder Dispute' UNION
SELECT '4854',NULL,'Cardholder Dispute-Not Elsewhere Classified (U.S. Region Only)' UNION
SELECT '4855',NULL,'Goods or Services Not Provided' UNION
SELECT '4859',NULL,'Addendum, No-show, or ATM Dispute' UNION
SELECT '4860',NULL,'Credit Not Processed' UNION
SELECT '4863',NULL,'Cardholder Does Not Recognize-Potential Fraud' UNION
SELECT '4865',NULL,'Paid by Other Means' UNION
SELECT '4866',NULL,'Fraud Chip Card Counterfeit Transaction' UNION
SELECT '7010',NULL,'Fraud Card Present Transaction' UNION
SELECT '7030',NULL,'Fraud Card Not Present Transaction' UNION
SELECT '8002',NULL,'Credit Not Processed' UNION
SELECT '4870',NULL,'Chip Liability Shift' UNION
SELECT '4871',NULL,'Chip/PIN Liability Shift' UNION
SELECT '10.1',NULL,'EMV Liability Shift Counterfeit Fraud' UNION
SELECT '10.2',NULL,'EMV Liability Shift – Non-Counterfeit Fraud' UNION
SELECT '10.3',NULL,'Other Fraud – Card-Present Environment' UNION
SELECT '10.4',NULL,'Other Fraud – Card-Absent Environment' UNION
SELECT '10.5',NULL,'Visa Fraud Monitoring Program' UNION
SELECT '11.1',NULL,'Card Recovery Bulletin' UNION
SELECT '11.2',NULL,'Declined Authorization' UNION
SELECT '11.3',NULL,'No Authorization' UNION
SELECT '12.1',NULL,'Late Presentment' UNION
SELECT '12.2',NULL,'Incorrect Transaction Code' UNION
SELECT '12.3',NULL,'Incorrect Currency' UNION
SELECT '12.4',NULL,'Incorrect Account Number' UNION
SELECT '12.5',NULL,'Incorrect Amount' UNION
SELECT '12.6',NULL,'Duplicate Processing/Paid by Other Means' UNION
SELECT '12.7',NULL,'Invalid Data' UNION
SELECT '13.1',NULL,'Merchandise/Services Not Received' UNION
SELECT '13.2',NULL,'Cancelled Recurring Transaction' UNION
SELECT '13.3',NULL,'Not as Described or Defective Merchandise/Services' UNION
SELECT '13.4',NULL,'Counterfeit Merchandise' UNION
SELECT '13.5',NULL,'Misrepresentation' UNION
SELECT '13.6',NULL,'Credit Not Processed' UNION
SELECT '13.7',NULL,'Cancelled Merchandise/Services' UNION
SELECT '13.8',NULL,'Original Credit Transaction Not Accepted' UNION
SELECT '13.9',NULL,'Non-Receipt of Cash or Load Transaction Value' 
;
--SELECT * FROM ChargebackDescriptions
;
*/