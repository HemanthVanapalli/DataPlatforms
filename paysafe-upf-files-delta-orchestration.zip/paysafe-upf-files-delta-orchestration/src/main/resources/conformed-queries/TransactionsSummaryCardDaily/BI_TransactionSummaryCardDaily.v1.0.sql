/************************************************************************
 * SQL Query to produce the Transaction Summary Daily Card Totals       *
 * Data from the 4 tables (TSYS, North - Funded/Non-Funded, PIN Debit)  *
 ************************************************************************/
DROP TABLE IF EXISTS ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0
;

/************************************************************************
 * Create Table                                                         *
 ************************************************************************/
CREATE TABLE ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0  ( 
   ClearingDate     date NOT NULL,
   MerchantNumber   varchar(255) NOT NULL,
   CardSchemeCode	varchar(4) NOT NULL,
   SalesCount       integer,
   SalesAmount      numeric(18,4),
   ReturnsCount     integer,
   ReturnsAmount    numeric(18,4)
)
;
ALTER TABLE ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 ADD UNIQUE(ClearingDate, MerchantNumber,CardSchemeCode)
;
ALTER TABLE ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 ALTER CONSTRAINT C_UNIQUE ENABLED
;
GRANT SELECT ON ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 TO verticappbisandbox
;

/************************************************************************
 * Update Table with Clearing Date and Merchant Number fields           *
 ************************************************************************/
INSERT INTO ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 (ClearingDate,MerchantNumber,CardSchemeCode)
SELECT
    DISTINCT
    ClearingDate,
    MerchantNumber,
    CardSchemeCode
FROM
    ppbisandbox.jmoeller_North_TransactionSummaryCardDaily_v1_1
WHERE NOT EXISTS
(
    SELECT
        DISTINCT
        ClearingDate,
        MerchantNumber,
        CardSchemeCode
    FROM
        ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0
)
;
/************************************************************************
 * Update Table with Clearing Date and Merchant Number fields           *
 ************************************************************************/
INSERT INTO ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 (ClearingDate,MerchantNumber,CardSchemeCode)
SELECT
    DISTINCT
    ClearingDate,
    MerchantNumber,
    CardSchemeCode
FROM
    ppbisandbox.jmoeller_North_TransactionSummaryDBCardDaily_v1_0
WHERE NOT EXISTS
(
    SELECT
        DISTINCT
        ClearingDate,
        MerchantNumber,
        CardSchemeCode
    FROM
        ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0
)
;
/************************************************************************
 * Update Table with Clearing Date and Merchant Number fields           *
 ************************************************************************/
INSERT INTO ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 (ClearingDate,MerchantNumber,CardSchemeCode)
SELECT
    DISTINCT
    ClearingDate,
    MerchantNumber,
    CardSchemeCode
FROM
    ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0
WHERE NOT EXISTS
(
    SELECT
        DISTINCT
        ClearingDate,
        MerchantNumber,
        CardSchemeCode
    FROM
        ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0
)
;
/************************************************************************
 * Update Table with Clearing Date and Merchant Number fields           *
 ************************************************************************/
INSERT INTO ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 (ClearingDate,MerchantNumber,CardSchemeCode)
SELECT
    DISTINCT
    ClearingDate,
    MerchantNumber,
    CardSchemeCode
FROM
    ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_2
WHERE NOT EXISTS
(
    SELECT
        DISTINCT
        ClearingDate,
        MerchantNumber,
        CardSchemeCode
    FROM
        ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0
)
;
/************************************************************************
 * Update Table to load the Count and Amount Fields                     *
 ************************************************************************/
/*
SELECT *
FROM ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0
WHERE SalesCount + SalesAmount + ReturnsCount + ReturnsAmount is NULL
LIMIT 100;
*/
UPDATE
	ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 AS A
SET
	SalesCount		= B.SalesCount,
	SalesAmount		= B.SalesAmount,
	ReturnsCount	= B.ReturnsCount,
	ReturnsAmount	= B.ReturnsAmount
FROM 
(
SELECT
    ff.ClearingDate,
    ff.MerchantNumber,
    ff.CardSchemeCode,
    SUM(NVL(aa.SalesCount,0)+NVL(bb.SalesCount,0)+NVL(cc.SalesCount,0)+NVL(dd.SalesCount,0)) SalesCount,
    SUM(NVL(aa.SalesAmount,0)+NVL(bb.SalesAmount,0)+NVL(cc.SalesAmount,0)+NVL(dd.SalesAmount,0)) SalesAmount,
    SUM(NVL(aa.ReturnsCount,0)+NVL(bb.ReturnsCount,0)+NVL(cc.ReturnsCount,0)+NVL(dd.ReturnsCount,0)) ReturnsCount,
    SUM(NVL(aa.ReturnsAmount,0)+NVL(bb.ReturnsAmount,0)+NVL(cc.ReturnsAmount,0)+NVL(dd.ReturnsAmount,0)) ReturnsAmount
FROM
    ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0                  ff --Foundation table
    LEFT JOIN ppbisandbox.jmoeller_North_TransactionSummaryCardDaily_v1_1   aa ON (ff.ClearingDate=aa.ClearingDate AND ff.MerchantNumber=aa.MerchantNumber AND ff.CardSchemeCode=aa.CardSchemeCode)
    LEFT JOIN ppbisandbox.jmoeller_North_TransactionSummaryDBCardDaily_v1_0	bb ON (ff.ClearingDate=bb.ClearingDate AND ff.MerchantNumber=bb.MerchantNumber AND ff.CardSchemeCode=bb.CardSchemeCode)
    LEFT JOIN ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0	cc ON (ff.ClearingDate=cc.ClearingDate AND ff.MerchantNumber=cc.MerchantNumber AND ff.CardSchemeCode=cc.CardSchemeCode)
    LEFT JOIN ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_2    dd ON (ff.ClearingDate=dd.ClearingDate AND ff.MerchantNumber=dd.MerchantNumber AND ff.CardSchemeCode=dd.CardSchemeCode)
GROUP BY
    ff.ClearingDate,
    ff.MerchantNumber,
    ff.CardSchemeCode
HAVING
    SUM(NVL(aa.SalesCount,0)+NVL(bb.SalesCount,0)+NVL(cc.SalesCount,0)+NVL(dd.SalesCount,0)) !=0 OR
    SUM(NVL(aa.SalesAmount,0)+NVL(bb.SalesAmount,0)+NVL(cc.SalesAmount,0)+NVL(dd.SalesAmount,0)) !=0 OR
    SUM(NVL(aa.ReturnsCount,0)+NVL(bb.ReturnsCount,0)+NVL(cc.ReturnsCount,0)+NVL(dd.ReturnsCount,0)) !=0 OR
    SUM(NVL(aa.ReturnsAmount,0)+NVL(bb.ReturnsAmount,0)+NVL(cc.ReturnsAmount,0)+NVL(dd.ReturnsAmount,0)) !=0 
) AS B
WHERE 
	A.ClearingDate 			= B.ClearingDate
 	AND A.MerchantNumber	= B.MerchantNumber
 	AND A.CardSchemeCode	= B.CardSchemeCode
;
