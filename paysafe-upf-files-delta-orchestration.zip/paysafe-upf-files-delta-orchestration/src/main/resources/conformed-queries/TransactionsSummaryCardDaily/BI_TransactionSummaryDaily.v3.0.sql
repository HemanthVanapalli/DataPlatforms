/************************************************************************
 * Update Final Table to load the Count and Amount Fields               *
 ************************************************************************/
/*
SELECT *
FROM ppbisandbox.jmoeller_TransactionsSummaryDaily_v1_0
LIMIT 1000;
*/
SELECT
    ClearingDate,
    MerchantNumber,
    SUM(CASE WHEN aa.CardSchemeCode IN ('VISA','MC','DISC','OPTB','ONE') THEN SalesCount ELSE 0 END) SalesCountBankcard,
    SUM(CASE WHEN aa.CardSchemeCode IN ('VISA','MC','DISC','OPTB','ONE') THEN SalesAmount ELSE 0 END) SalesAmountBankcard,
    SUM(CASE WHEN aa.CardSchemeCode IN ('VISA','MC','DISC','OPTB','ONE') THEN ReturnsCount ELSE 0 END) ReturnsCountBankcard,
    SUM(CASE WHEN aa.CardSchemeCode IN ('VISA','MC','DISC','OPTB','ONE') THEN ReturnsAmount ELSE 0 END) ReturnsAmountBankcard,
    SUM(CASE WHEN aa.CardSchemeCode NOT IN ('ESA','DNAQ')	 			 THEN SalesCount ELSE 0 END) SalesCountAllCards,
    SUM(CASE WHEN aa.CardSchemeCode NOT IN ('ESA','DNAQ') 				 THEN SalesAmount ELSE 0 END) SalesAmountAllCards,
    SUM(CASE WHEN aa.CardSchemeCode NOT IN ('ESA','DNAQ')	 			 THEN ReturnsCount ELSE 0 END) ReturnsCountAllCards,
    SUM(CASE WHEN aa.CardSchemeCode NOT IN ('ESA','DNAQ')	 			 THEN ReturnsAmount ELSE 0 END) ReturnsAmountAllCards
INTO
	ppbisandbox.jmoeller_TransactionsSummaryDaily_v1_0
FROM
    ppbisandbox.jmoeller_TransactionsSummaryCardDaily_v1_0 aa
GROUP BY
    ClearingDate,
    MerchantNumber