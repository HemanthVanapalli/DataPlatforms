/************************************************************************
 * SQL Query to product the Transaction Summary Daily Card Totals       *
 * Fiserv - Omaha                                                       *
 ************************************************************************/
/*
 *  ---[ Additional Notes on Fields used below ]---
 * 
	TRAN_CODE IN ('253')			--Credit Card Sale (-Card, +Merch)
	TRAN_CODE IN ('255')			--Return of Goods (+Card, -Merch)
	TRAN_CODE IN ('254')			--Cash Advance from Card (-Card, +Merch)

	CARD_TYPE IN ('4') 	THEN 'VISA'			--Visa�
	CARD_TYPE IN ('1') 	THEN 'MC'			--Mastercard�
	CARD_TYPE IN ('3') 	THEN 'ESA'			--American Express� Pass-through
	CARD_TYPE IN ('6') 	THEN 'DNAQ'			--Discover NonAcq
	CARD_TYPE IN ('7') 	THEN 'JCB'			--JCB International (Discover)
	CARD_TYPE IN ('12') THEN 'GPIN'			--Generic Debit (Debit Summary File) 
	CARD_TYPE IN ('13') THEN 'STAR'			--Star Debit PIN Debit
	CARD_TYPE IN ('14') THEN 'MAES'			--Maestro
	CARD_TYPE IN ('15') THEN 'ITLK'			--Interlink
	CARD_TYPE IN ('16') THEN 'NYCE'			--NYCE
	CARD_TYPE IN ('17') THEN 'SHZM'			--SHAZAM
	CARD_TYPE IN ('18') THEN 'STAR'			--Star Debit
	CARD_TYPE IN ('21') THEN 'STAR'			--Star Debit
	CARD_TYPE IN ('22') THEN 'EBT'			--EBT (Tape Only)
	CARD_TYPE IN ('23') THEN 'PULS'			--PULSE
	CARD_TYPE IN ('24') THEN 'ACCL'			--Accel
	CARD_TYPE IN ('25') THEN 'CU24'			--CUALIANCE (CU24)
	CARD_TYPE IN ('26') THEN 'AFFN'			--AFFN
	CARD_TYPE IN ('27') THEN 'AKOP'			--Alaska Option
	CARD_TYPE IN ('28') THEN 'EBTF'			--EBT (Food Stamps)
	CARD_TYPE IN ('29') THEN 'JEAN'			--Jeanie
	CARD_TYPE IN ('30') THEN 'EBTC'			--EBT (Cash Benefit)
	CARD_TYPE IN ('43') THEN 'OPTB'			--American Express OptBlue
	CARD_TYPE IN ('50') THEN 'WEX'			--Wright Express�
	CARD_TYPE IN ('57') THEN 'VOYG'			--Voyager�
	CARD_TYPE IN ('61') THEN 'DISC'			--Discover Acquiring (Discover Network) - This card type includes the PayPal In-Store credit card
	CARD_TYPE IN ('63') THEN 'ONE'			--American Express OnePoint

*/
--DROP TABLE ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0
DROP TABLE IF EXISTS ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0
;
/************************************************************************
 * Create Table to load the intial Fields (Keys)                        *
 ************************************************************************/
CREATE TABLE ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0  ( 
	ClearingDate       	date NOT NULL,
	MerchantNumber    	varchar(255) NOT NULL,
	CardSchemeCode      varchar(4) NOT NULL,
	SalesCount			integer,
	SalesAmount			numeric(18,4),
	ReturnsCount		integer,
	ReturnsAmount		numeric(18,4)
)
;
ALTER TABLE ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0 ADD UNIQUE(ClearingDate, MerchantNumber, CardSchemeCode)
;
ALTER TABLE ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0 ALTER CONSTRAINT C_UNIQUE ENABLED
;
GRANT SELECT ON ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0 TO verticappbisandbox
;
TRUNCATE TABLE ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0
/************************************************************************
 * Update Table to load the Count and Amount Fields (SalesCard)         *
 ************************************************************************/
 ;
INSERT INTO
    ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0 (ClearingDate,MerchantNumber,CardSchemeCode,SalesCount,SalesAmount,ReturnsCount,ReturnsAmount)  
SELECT
    *
FROM
    (
        SELECT
            COALESCE(CLEARINGDATEREFRNR,DATE_POST)  ClearingDate,	--Clearing Date appers to be NULL sometimes **but** DATE_POST can be bigger and smaller than clearing date which is odd, need to have someone research why this happening and fix it.
            MRCH_NO                                 MerchantNumber,
            CASE
	            WHEN CARD_TYPE IN ('4') 	THEN 'VISA'	--Visa�
	            WHEN CARD_TYPE IN ('1') 	THEN 'MC'	--Mastercard�
	            WHEN CARD_TYPE IN ('3') 	THEN 'ESA'	--American Express� Pass-through
	            WHEN CARD_TYPE IN ('6') 	THEN 'DNAQ'	--Discover NonAcq
	            WHEN CARD_TYPE IN ('7') 	THEN 'JCB'	--JCB International (Discover)
	            WHEN CARD_TYPE IN ('12') 	THEN 'GPIN'	--Generic Debit (Debit Summary File) 
	            WHEN CARD_TYPE IN ('13') 	THEN 'STAR'	--Star Debit PIN Debit
	            WHEN CARD_TYPE IN ('14') 	THEN 'MAES'	--Maestro
	            WHEN CARD_TYPE IN ('15') 	THEN 'ITLK'	--Interlink
	            WHEN CARD_TYPE IN ('16') 	THEN 'NYCE'	--NYCE
	            WHEN CARD_TYPE IN ('17') 	THEN 'SHZM'	--SHAZAM
	            WHEN CARD_TYPE IN ('18') 	THEN 'STAR'	--Star Debit
	            WHEN CARD_TYPE IN ('21') 	THEN 'STAR'	--Star Debit
	            WHEN CARD_TYPE IN ('22') 	THEN 'EBT'	--EBT (Tape Only)
	            WHEN CARD_TYPE IN ('23') 	THEN 'PULS'	--PULSE
	            WHEN CARD_TYPE IN ('24') 	THEN 'ACCL'	--Accel
	            WHEN CARD_TYPE IN ('25') 	THEN 'CU24'	--CUALIANCE (CU24)
	            WHEN CARD_TYPE IN ('26') 	THEN 'AFFN'	--AFFN
	            WHEN CARD_TYPE IN ('27') 	THEN 'AKOP'	--Alaska Option
	            WHEN CARD_TYPE IN ('28') 	THEN 'EBTF'	--EBT (Food Stamps)
	            WHEN CARD_TYPE IN ('29') 	THEN 'JEAN'	--Jeanie
	            WHEN CARD_TYPE IN ('30') 	THEN 'EBTC'	--EBT (Cash Benefit)
	            WHEN CARD_TYPE IN ('43') 	THEN 'OPTB'	--American Express OptBlue
	            WHEN CARD_TYPE IN ('50') 	THEN 'WEX'	--Wright Express�
	            WHEN CARD_TYPE IN ('57') 	THEN 'VOYG'	--Voyager�
	            WHEN CARD_TYPE IN ('61') 	THEN 'DISC'	--Discover Acquiring (Discover Network) - This card type includes the PayPal In-Store credit card
	            WHEN CARD_TYPE IN ('63') 	THEN 'ONE'	--American Express OnePoint
                ELSE CARD_TYPE 
            END                    			        	CardSchemeCode,
            SUM(CASE WHEN TRAN_CODE IN ('253', '254') 	THEN 1                    ELSE 0 END) SalesCount,
            SUM(CASE WHEN TRAN_CODE IN ('253', '254') 	THEN ZEROIFNULL(TRAN_AMT) ELSE 0 END) SalesAmount,
            SUM(CASE WHEN TRAN_CODE IN ('255')      	THEN 1                    ELSE 0 END) ReturnsCount,
            SUM(CASE WHEN TRAN_CODE IN ('255')      	THEN ZEROIFNULL(TRAN_AMT) ELSE 0 END) ReturnsAmount
        FROM    
            BISME.FF152_Omaha				ffo
            INNER JOIN BI.ReportingChannels	rc ON (ffo.MRCH_NO=rc.MerchantNumber)
        WHERE
            (
	            CARD_TYPE IN ('4') 	OR					--Visa�
	            CARD_TYPE IN ('1') 	OR					--Mastercard�
	            CARD_TYPE IN ('3') 	OR					--American Express� Pass-through
	            CARD_TYPE IN ('6') 	OR					--Discover NonAcq
	            CARD_TYPE IN ('7') 	OR					--JCB International (Discover)
	            CARD_TYPE IN ('12') OR					--Generic Debit (Debit Summary File) 
	            CARD_TYPE IN ('13') OR					--Star Debit PIN Debit
	            CARD_TYPE IN ('14') OR					--Maestro
	            CARD_TYPE IN ('15') OR					--Interlink
	            CARD_TYPE IN ('16') OR					--NYCE
	            CARD_TYPE IN ('17') OR					--SHAZAM
	            CARD_TYPE IN ('18') OR					--Star Debit
	            CARD_TYPE IN ('21') OR					--Star Debit
	            CARD_TYPE IN ('22') OR					--EBT (Tape Only)
	            CARD_TYPE IN ('23') OR					--PULSE
	            CARD_TYPE IN ('24') OR					--Accel
	            CARD_TYPE IN ('25') OR					--CUALIANCE (CU24)
	            CARD_TYPE IN ('26') OR					--AFFN
	            CARD_TYPE IN ('27') OR					--Alaska Option
	            CARD_TYPE IN ('28') OR					--EBT (Food Stamps)
	            CARD_TYPE IN ('29') OR					--Jeanie
	            CARD_TYPE IN ('30') OR					--EBT (Cash Benefit)
	            CARD_TYPE IN ('43') OR					--American Express OptBlue
	            CARD_TYPE IN ('50') OR					--Wright Express�
	            CARD_TYPE IN ('57') OR					--Voyager�
	            CARD_TYPE IN ('61') OR					--Discover Acquiring (Discover Network) - This card type includes the PayPal In-Store credit card
	            CARD_TYPE IN ('63') 					--American Express OnePoint
            )
            AND TRAN_CODE IN ('253','254','255')		--253 = Credit Card Sale (-Card, +Merch), 254 = Cash Advance from Card (-Card, +Merch), 255 = Return of Goods (+Card, -Merch)
        GROUP BY
            COALESCE(CLEARINGDATEREFRNR,DATE_POST),
            MRCH_NO,
            CASE
	            WHEN CARD_TYPE IN ('4') 	THEN 'VISA'	--Visa�
	            WHEN CARD_TYPE IN ('1') 	THEN 'MC'	--Mastercard�
	            WHEN CARD_TYPE IN ('3') 	THEN 'ESA'	--American Express� Pass-through
	            WHEN CARD_TYPE IN ('6') 	THEN 'DNAQ'	--Discover NonAcq
	            WHEN CARD_TYPE IN ('7') 	THEN 'JCB'	--JCB International (Discover)
	            WHEN CARD_TYPE IN ('12') 	THEN 'GPIN'	--Generic Debit (Debit Summary File) 
	            WHEN CARD_TYPE IN ('13') 	THEN 'STAR'	--Star Debit PIN Debit
	            WHEN CARD_TYPE IN ('14') 	THEN 'MAES'	--Maestro
	            WHEN CARD_TYPE IN ('15') 	THEN 'ITLK'	--Interlink
	            WHEN CARD_TYPE IN ('16') 	THEN 'NYCE'	--NYCE
	            WHEN CARD_TYPE IN ('17') 	THEN 'SHZM'	--SHAZAM
	            WHEN CARD_TYPE IN ('18') 	THEN 'STAR'	--Star Debit
	            WHEN CARD_TYPE IN ('21') 	THEN 'STAR'	--Star Debit
	            WHEN CARD_TYPE IN ('22') 	THEN 'EBT'	--EBT (Tape Only)
	            WHEN CARD_TYPE IN ('23') 	THEN 'PULS'	--PULSE
	            WHEN CARD_TYPE IN ('24') 	THEN 'ACCL'	--Accel
	            WHEN CARD_TYPE IN ('25') 	THEN 'CU24'	--CUALIANCE (CU24)
	            WHEN CARD_TYPE IN ('26') 	THEN 'AFFN'	--AFFN
	            WHEN CARD_TYPE IN ('27') 	THEN 'AKOP'	--Alaska Option
	            WHEN CARD_TYPE IN ('28') 	THEN 'EBTF'	--EBT (Food Stamps)
	            WHEN CARD_TYPE IN ('29') 	THEN 'JEAN'	--Jeanie
	            WHEN CARD_TYPE IN ('30') 	THEN 'EBTC'	--EBT (Cash Benefit)
	            WHEN CARD_TYPE IN ('43') 	THEN 'OPTB'	--American Express OptBlue
	            WHEN CARD_TYPE IN ('50') 	THEN 'WEX'	--Wright Express�
	            WHEN CARD_TYPE IN ('57') 	THEN 'VOYG'	--Voyager�
	            WHEN CARD_TYPE IN ('61') 	THEN 'DISC'	--Discover Acquiring (Discover Network) - This card type includes the PayPal In-Store credit card
	            WHEN CARD_TYPE IN ('63') 	THEN 'ONE'	--American Express OnePoint
                ELSE CARD_TYPE 
            END
    ) aa WHERE NOT EXISTS 
    (
        SELECT
            ClearingDate,MerchantNumber,CardSchemeCode,SalesCount,SalesAmount,ReturnsCount,ReturnsAmount
        FROM    
            ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0
    )        
;  
/************************************************************************
 * Update Table - END                                                   *
 ************************************************************************/

----------[ STOP ]------------------------------------------------------------------------------------------------------------------------------------------------------

-- SELECT * FROM BISME.DFM_CreditDetailFunded003_North WHERE COALESCE(CLEARINGDATEREFRNR,TRANSACTION_DATE)='4/14/2020' AND MRCH_NO='497206505883' AND CARD_TYPE='00008'
;
SELECT  
    FUNDED_DATE,
    DATE_POST,
    CLEARINGDATEREFRNR,
    TRANSACTION_TYPE,
    TRANSACTIONAMOUNTSIGNED,
    * 
FROM 
    BISME.DFM_CreditDetailFunded003_North   ffo
    INNER JOIN BI.ReportingChannels         rc ON (ffo.MRCH_NO=rc.MerchantNumber)
--WHERE
    --CARD_TYPE IN ('00018')
GROUP BY
     
--    AND DATE_POST BETWEEN '02-OCT-2020' AND '30-OCT-2020'
--ORDER BY
--    TRANSACTIONAMOUNTSIGNED dESC
LIMIT
    500
;
SELECT  
    TRANSACTION_TYPE,
    CARD_TYPE,
    COUNT(*),
    SUM(TRAN_AMT)
FROM 
    BISME.DFM_CreditDetailFunded003_North   ffo
    INNER JOIN BI.ReportingChannels         rc ON (ffo.MRCH_NO=rc.MerchantNumber)
--WHERE 
    
GROUP BY
    TRANSACTION_TYPE,
    CARD_TYPE    
    --CARD_TYPE IN ('00018') 
--    AND DATE_POST BETWEEN '02-OCT-2020' AND '30-OCT-2020'
--ORDER BY
--    TRANSACTIONAMOUNTSIGNED dESC
LIMIT
    500
;
WHEN CARD_TYPE IN ('00006') THEN 'ESA' 					--Amex
WHEN CARD_TYPE IN ('00008') THEN 'OPTB' 				--Amex Acquiring
;
SELECT  
    FUNDED_DATE,
    DATE_POST,
    CLEARINGDATEREFRNR,
    TRANSACTION_TYPE,
    TRANSACTIONAMOUNTSIGNED,
    * 
FROM 
    BISME.DFM_CreditDetailFunded003_North   ffo
    INNER JOIN BI.ReportingChannels         rc ON (ffo.MRCH_NO=rc.MerchantNumber)
WHERE 
    --TRANSACTION_TYPE IN ('5','7','6')
    TRANSACTION_TYPE IN ('5','7')
    AND TRANSACTIONAMOUNTSIGNED =0
    --AND DATE_POST > CLEARINGDATEREFRNR
    --AND CLEARINGDATEREFRNR IS NOT NULL
    --AND MRCH_NO='296202436881'
    --AND ENVELOPEFILEDATE='11/9/2020'
    --AND BATCH_NUMBER='032305480008'
;    
---== No NULL's in value fields. YEah! ==---
SELECT
    *
FROM
    ppbisandbox.jmoeller_Omaha_TransactionSummaryCardDaily_v1_0
WHERE
	ClearingDate is NULL
    --SalesCount > 0 AND ReturnsCount > 0
    --SalesCount+SalesAmount+ReturnsCount+ReturnsAmount IS NULL
;
