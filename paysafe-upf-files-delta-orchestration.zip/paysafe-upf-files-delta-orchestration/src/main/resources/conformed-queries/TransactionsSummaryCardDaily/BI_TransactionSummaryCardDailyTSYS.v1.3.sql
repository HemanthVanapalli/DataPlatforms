/************************************************************************
 * SQL Query to product the Transaction Summary Daily Card Totals       *
 * TSYS                                                                 *
 ************************************************************************/
/*
 *  ---[ Additional Notes on Fields used below ]---
 * 
	DT_TRANSACTION_CODE IN ('0101') --Credit Card Sale (-Card, +Merch)
    DT_TRANSACTION_CODE IN ('0102') --Cash Advance from Card (-Card, +Merch)
    DT_TRANSACTION_CODE IN ('0106') --Return of Goods (+Card, -Merch)
    DT_TRANSACTION_CODE IN ('0330') --Debit Card Sale (-Card, +Merch)
    DT_TRANSACTION_CODE IN ('0331') --Debit Card Return (+Card, -Merch)
    DT_TRANSACTION_CODE IN ('7056') --Food Stamp Purchase - Federal (-Card, +Merch)
    DT_TRANSACTION_CODE IN ('7057') --Food Stamp Return - Federal (+Card, -Merch)
    DT_TRANSACTION_CODE IN ('7061') --Federal Cash POS Debit (-Card, +Merch)

	DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL')	--Visa--'VS' Visa, 'VD' Visa Debit, 'VB' Visa Business, 'V$' Visa Cash, 'VL' Visa Large Ticket 
	DT_CARD_TYPE_1 IN ('MC', 'MD', 'MB', 'M$', 'ML')	--MasterCard--'MD' MasterCard Debit, 'MC' MasterCard, 'MB' MasterCard Business, 'M$' MasterCard Cash, 'ML' MasterCard Large Ticket
	DT_CARD_TYPE_1 IN ('AM') 							--American Express--'AM' American Express
	DT_CARD_TYPE_1 IN ('DS', 'DD', 'DZ', 'DJ', 'D$') 	--Discover--'DZ' Discover Business, 'DS' Discover, 'DJ' Discover JCB, 'DD' Discover Debit, 'DB' Debit Card, 'D$' Discover Cash
	DT_CARD_TYPE_1 IN ('EB')							--EBT Electronic Benefits Transfer--'EB' EBT 
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='IL' THEN 'ITLK'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ME' THEN 'MAES'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='XL' THEN 'ACCL'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='PL' THEN 'PULS'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='AF' THEN 'AFFN'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='CU' THEN 'CU24'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='HO' THEN 'STAR' --Start SE
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='YN' THEN 'NYCE'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ST' THEN 'STAR' --Star West
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='SZ' THEN 'SHZM'
	DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='MA' THEN 'STAR' --Star NE
 
*/
--DROP TABLE ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3
DROP TABLE IF EXISTS ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3
;
/************************************************************************
 * Create Table to load the intial Fields (Keys)                        *
 ************************************************************************/
CREATE TABLE ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3  ( 
	ClearingDate       			date NULL,
	MerchantNumber    			varchar(255) NULL,
	CardSchemeCode				varchar(255) NULL,
	SalesCount					integer,
	SalesAmount					numeric(18,4),
	ReturnsCount				integer,
	ReturnsAmount				numeric(18,4)
)
;
ALTER TABLE ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 ADD UNIQUE(ClearingDate, MerchantNumber, CardSchemeCode)
;
ALTER TABLE ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 ALTER CONSTRAINT C_UNIQUE ENABLED
;
GRANT SELECT ON ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 TO verticappbisandbox
;
/************************************************************************
 * Insert to Table and load Keys that don't already exist               *
 ************************************************************************/
INSERT INTO
    ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 (ClearingDate, MerchantNumber, CardSchemeCode)
SELECT 
    ClearingDate, MerchantNumber, CardSchemeCode
FROM
	(
		(
			SELECT 
			    DTCLEARINGDATEREFERENCENUMBER	                AS ClearingDate,
			    CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)  AS MerchantNumber,
				CASE
					WHEN DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL') THEN 'VISA'	--Visa
					WHEN DT_CARD_TYPE_1 IN ('MC', 'MD', 'MB', 'M$', 'ML') THEN 'MC'		--MasterCard
					WHEN DT_CARD_TYPE_1 IN ('AM') THEN 'OPTB'							--American Express
					WHEN DT_CARD_TYPE_1 IN ('DS', 'DD', 'DZ', 'DJ', 'D$') THEN 'DISC'	--Discover
					WHEN DT_CARD_TYPE_1 IN ('EB') THEN 'EBT'							--EBT Electronic Benefits Transfer
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='IL' THEN 'ITLK'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ME' THEN 'MAES'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='XL' THEN 'ACCL'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='PL' THEN 'PULS'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='AF' THEN 'AFFN'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='CU' THEN 'CU24'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='HO' THEN 'STAR' --Start SE
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='YN' THEN 'NYCE'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ST' THEN 'STAR' --Star West
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='SZ' THEN 'SHZM'
					WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='MA' THEN 'STAR' --Star NE
					ELSE DT_CARD_TYPE_1
				END                            	   CardSchemeCode
			FROM
                BISME.DailyDetailFile_TSYS ddf
  		        INNER JOIN BI.ReportingChannels         rc ON (CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)=rc.MerchantNumber)
			WHERE 
			    DTCLEARINGDATEREFERENCENUMBER IS NOT NULL
			    AND BH_MERCHANT_ACCOUNT_NUMBER IS NOT NULL
			    AND DT_TRANSACTION_CODE IN ('0101', '0102', '0330', '7056', '7061','0106', '0331', '7057')
			GROUP BY 
			    ClearingDate, CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT), CardSchemeCode
		)
    ) aa   
WHERE NOT EXISTS
    (
        SELECT
            ClearingDate, MerchantNumber, CardSchemeCode
        FROM
            ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 mm
        WHERE
            mm.ClearingDate		    = aa.ClearingDate
            AND mm.MerchantNumber   = aa.MerchantNumber
            AND mm.CardSchemeCode 	= aa.CardSchemeCode
    )
;
/************************************************************************
 * Update Table to load the Count and Amount Fields (SalesCard)         *
 ************************************************************************/
UPDATE
    ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 AS A
SET 
	CardSchemeCode 		= B.CardSchemeCode,
	SalesCount			= B.SalesCount,
	SalesAmount			= B.SalesAmount
FROM 
    (
        SELECT
            ddf1.DTCLEARINGDATEREFERENCENUMBER	            ClearingDate,
            CAST(ddf1.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT) MerchantNumber,
            ddf2.CardSchemeCode,
            ddf2.SalesCount,
            ddf2.SalesAmount
        FROM
            BISME.DailyDetailFile_TSYS ddf1
            INNER JOIN 
                (
                    SELECT
                        DTCLEARINGDATEREFERENCENUMBER,
                        CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT) BH_MERCHANT_ACCOUNT_NUMBER,
						CASE
							WHEN DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL') THEN 'VISA'	--Visa
							WHEN DT_CARD_TYPE_1 IN ('MC', 'MD', 'MB', 'M$', 'ML') THEN 'MC'		--MasterCard
							WHEN DT_CARD_TYPE_1 IN ('AM') THEN 'OPTB'							--American Express
							WHEN DT_CARD_TYPE_1 IN ('DS', 'DD', 'DZ', 'DJ', 'D$') THEN 'DISC'	--Discover
							WHEN DT_CARD_TYPE_1 IN ('EB') THEN 'EBT'							--EBT Electronic Benefits Transfer
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='IL' THEN 'ITLK'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ME' THEN 'MAES'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='XL' THEN 'ACCL'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='PL' THEN 'PULS'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='AF' THEN 'AFFN'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='CU' THEN 'CU24'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='HO' THEN 'STAR' --Start SE
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='YN' THEN 'NYCE'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ST' THEN 'STAR' --Star West
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='SZ' THEN 'SHZM'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='MA' THEN 'STAR' --Star NE
							ELSE DT_CARD_TYPE_1
						END                  				       CardSchemeCode,
                        COUNT (*) 								AS SalesCount,
                        SUM(ZEROIFNULL(DT_TRANSACTION_AMOUNT)) 	AS SalesAmount
                    FROM    
                        BISME.DailyDetailFile_TSYS ddf -- SELECT * FROM BISME.DailyDetailFile_TSYS WHERE DT_CARD_TYPE_1='AM' ORDER BY DT_TRANSACTION_AMOUNT DESC LIMIT 500
	    		        INNER JOIN BI.ReportingChannels         rc ON (CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)=rc.MerchantNumber)
                    WHERE
                        /*
                          NEed to test if we have ESA or OptBlue in here.  Ditto Discover NonAcqurier.  
                        */
                    	--DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL', 'MC', 'MD', 'MB', 'M$', 'ML', 'AM', 'DS', 'DD', 'DZ', 'DJ', 'D$')	--'VS' Visa, 'VD' Visa Debit, 'VB' Visa Business, 'V$' Visa Cash, 'VL' Visa Large Ticket, 'MD' MasterCard Debit, 'MC' MasterCard, 'MB' MasterCard Business, 'M$' MasterCard Cash, 'ML' MasterCard Large Ticket, 'EB' EBT, 'DZ' Discover Business, 'DS' Discover, 'DJ' Discover JCB, 'DD' Discover Debit, 'DB' Debit Card, 'D$' Discover Cash, 'AM' American Express
						DT_TRANSACTION_CODE IN ('0101', '0102', '0330', '7056', '7061') --Credit/Debit Card Sales + Cash Advance from Card + Cash Advance from Card + Food Stamp Purchase + Federal Cash POS Debit
                    GROUP BY
                        DTCLEARINGDATEREFERENCENUMBER,
                        CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT),
						CASE
							WHEN DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL') THEN 'VISA'	--Visa
							WHEN DT_CARD_TYPE_1 IN ('MC', 'MD', 'MB', 'M$', 'ML') THEN 'MC'		--MasterCard
							WHEN DT_CARD_TYPE_1 IN ('AM') THEN 'OPTB'							--American Express
							WHEN DT_CARD_TYPE_1 IN ('DS', 'DD', 'DZ', 'DJ', 'D$') THEN 'DISC'	--Discover
							WHEN DT_CARD_TYPE_1 IN ('EB') THEN 'EBT'							--EBT Electronic Benefits Transfer
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='IL' THEN 'ITLK'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ME' THEN 'MAES'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='XL' THEN 'ACCL'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='PL' THEN 'PULS'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='AF' THEN 'AFFN'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='CU' THEN 'CU24'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='HO' THEN 'STAR' --Start SE
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='YN' THEN 'NYCE'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ST' THEN 'STAR' --Star West
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='SZ' THEN 'SHZM'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='MA' THEN 'STAR' --Star NE
							ELSE DT_CARD_TYPE_1
						END
                ) ddf2 ON (ddf1.DTCLEARINGDATEREFERENCENUMBER=ddf2.DTCLEARINGDATEREFERENCENUMBER AND CAST(ddf1.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)=CAST(ddf2.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT))    
    ) as B
WHERE 
    A.ClearingDate		= B.ClearingDate
    AND
    A.MerchantNumber	= B.MerchantNumber
    AND
    A.CardSchemeCode 	= B.CardSchemeCode
;
/************************************************************************
 * Update Table to load the Count and Amount Fields (ReturnsCard)       *
 ************************************************************************/
UPDATE
    ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3 AS A
SET 
	CardSchemeCode 			= B.CardSchemeCode,
    ReturnsCount			= B.ReturnsCount,
	ReturnsAmount			= B.ReturnsAmount
FROM 
    (
        SELECT
            ddf1.DTCLEARINGDATEREFERENCENUMBER	            ClearingDate,
            CAST(ddf1.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT) MerchantNumber,
            ddf2.CardSchemeCode,
            ddf2.ReturnsCount,
            ddf2.ReturnsAmount
        FROM    
            BISME.DailyDetailFile_TSYS ddf1
            INNER JOIN 
                (
                    SELECT
                        DTCLEARINGDATEREFERENCENUMBER,
                        CAST(BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)  BH_MERCHANT_ACCOUNT_NUMBER,
						CASE
							WHEN DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL') THEN 'VISA'	--Visa
							WHEN DT_CARD_TYPE_1 IN ('MC', 'MD', 'MB', 'M$', 'ML') THEN 'MC'		--MasterCard
							WHEN DT_CARD_TYPE_1 IN ('AM') THEN 'OPTB'							--American Express
							WHEN DT_CARD_TYPE_1 IN ('DS', 'DD', 'DZ', 'DJ', 'D$') THEN 'DISC'	--Discover
							WHEN DT_CARD_TYPE_1 IN ('EB') THEN 'EBT'							--EBT Electronic Benefits Transfer
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='IL' THEN 'ITLK'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ME' THEN 'MAES'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='XL' THEN 'ACCL'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='PL' THEN 'PULS'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='AF' THEN 'AFFN'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='CU' THEN 'CU24'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='HO' THEN 'STAR' --Start SE
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='YN' THEN 'NYCE'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ST' THEN 'STAR' --Star West
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='SZ' THEN 'SHZM'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='MA' THEN 'STAR' --Star NE
							ELSE DT_CARD_TYPE_1
						END                            			   CardSchemeCode,
                        COUNT (*) 								AS ReturnsCount,
						SUM(ZEROIFNULL(DT_TRANSACTION_AMOUNT)) 	AS ReturnsAmount
                    FROM    
                        BISME.DailyDetailFile_TSYS ddf
	    		        INNER JOIN BI.ReportingChannels         rc ON (CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)=rc.MerchantNumber)
                    WHERE
						DT_TRANSACTION_CODE IN ('0106', '0331', '7057')		--Return of Goods + Debit Card Return + Food Stamp Return
                    GROUP BY
                        DTCLEARINGDATEREFERENCENUMBER,
                        CAST(BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT),
						CASE
							WHEN DT_CARD_TYPE_1 IN ('VS', 'VD', 'VB', 'V$', 'VL') THEN 'VISA'	--Visa
							WHEN DT_CARD_TYPE_1 IN ('MC', 'MD', 'MB', 'M$', 'ML') THEN 'MC'		--MasterCard
							WHEN DT_CARD_TYPE_1 IN ('AM') THEN 'OPTB'							--American Express
							WHEN DT_CARD_TYPE_1 IN ('DS', 'DD', 'DZ', 'DJ', 'D$') THEN 'DISC'	--Discover
							WHEN DT_CARD_TYPE_1 IN ('EB') THEN 'EBT'							--EBT Electronic Benefits Transfer
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='IL' THEN 'ITLK'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ME' THEN 'MAES'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='XL' THEN 'ACCL'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='PL' THEN 'PULS'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='AF' THEN 'AFFN'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='CU' THEN 'CU24'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='HO' THEN 'STAR' --Start SE
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='YN' THEN 'NYCE'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='ST' THEN 'STAR' --Star West
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='SZ' THEN 'SHZM'
							WHEN DT_CARD_TYPE_1='DB' AND LEFT(DT_NETWORK_IDENTIFIER_DEBIT,2) ='MA' THEN 'STAR' --Star NE
							ELSE DT_CARD_TYPE_1
						END
                ) ddf2 ON (ddf1.DTCLEARINGDATEREFERENCENUMBER=ddf2.DTCLEARINGDATEREFERENCENUMBER AND CAST(ddf1.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)=CAST(ddf2.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT))    
    ) as B
WHERE 
    A.ClearingDate		= B.ClearingDate
    AND
    A.MerchantNumber	= B.MerchantNumber
    AND
    A.CardSchemeCode	= B.CardSchemeCode
;
/************************************************************************
 * Update Table - END                                                   *
 ************************************************************************/

----------[ STOP ]------------------------------------------------------------------------------------------------------------------------------------------------------
;
SELECT
    DT_CARD_TYPE_1,
    SUM(DT_TRANSACTION_AMOUNT)
FROM
   BISME.DailyDetailFile_TSYS 
GROUP BY
   DT_CARD_TYPE_1
 ;
SELECT
    *
FROM
   BISME.DailyDetailFile_TSYS 
WHERE
    DT_CARD_TYPE_1='DB'
LIMIT
    500

SELECT
    DT_NETWORK_IDENTIFIER_DEBIT,
    COUNT(*),
    SUM(DT_TRANSACTION_AMOUNT)
FROM
   BISME.DailyDetailFile_TSYS 
WHERE
	DT_CARD_TYPE_1 = 'DB'
GROUP BY
	DT_NETWORK_IDENTIFIER_DEBIT
;

SELECT CardSchemeCode, SUM(ReturnsCount), SUM(ReturnsAmount) FROM ppbisandbox.jmoeller_TSYS_TransactionSummaryCardDaily_v1_3
--WHERE ReturnsCount > 0
GROUP BY CardSchemeCode
ORDER BY CardSchemeCode
;