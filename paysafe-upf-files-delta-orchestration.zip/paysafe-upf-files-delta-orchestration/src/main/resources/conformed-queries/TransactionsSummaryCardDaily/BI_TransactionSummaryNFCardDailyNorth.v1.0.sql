/************************************************************************
 * SQL Query to product the Transaction Summary Daily Card Totals       *
 * Fiserv - North                                                       *
 ************************************************************************/
/*
 *  ---[ Additional Notes on Fields used below ]---
 * 
	TRANSACTION_TYPE IN ('5')		--Debit Card Sale (-Card, +Merch)
	TRANSACTION_TYPE IN ('6')		--Return of Goods (+Card, -Merch)
	TRANSACTION_TYPE IN ('7')		--Cash Advance from Card (-Card, +Merch)

	CARD_TYPE IN ('00003') THEN 'DNAQ'		--Discover
	CARD_TYPE IN ('00006') THEN 'ESA'		--Amex (ESA)
	CARD_TYPE IN ('00030') THEN 'STOR'		--Stored Value
	CARD_TYPE IN ('00035') THEN 'WEX' 		--WEX � Wright Express
	
	00003	4686241		324425620.4900
	00006	16838691	1803340489.6100
	00030	49			3222.7100
	00035	184862		7760202.8100

*/
--DROP TABLE ppbisandbox.jmoeller_North_TransactionSummaryCardDaily
DROP TABLE IF EXISTS ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0
;
/************************************************************************
 * Create Table to load the intial Fields (Keys)                        *
 ************************************************************************/
CREATE TABLE ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0  ( 
	ClearingDate       	date NOT NULL,
	MerchantNumber    	varchar(255) NOT NULL,
	CardSchemeCode      varchar(4) NOT NULL,
	SalesCount			integer,
	SalesAmount			numeric(18,4),
	ReturnsCount		integer,
	ReturnsAmount		numeric(18,4)
)
;
ALTER TABLE ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0 ADD UNIQUE(ClearingDate, MerchantNumber, CardSchemeCode)
;
ALTER TABLE ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0 ALTER CONSTRAINT C_UNIQUE ENABLED
;
GRANT SELECT ON ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0 TO verticappbisandbox
;
TRUNCATE TABLE ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0
/************************************************************************
 * Update Table to load the Count and Amount Fields (SalesCard)         *
 ************************************************************************/
 ;
INSERT INTO
    ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0 (ClearingDate,MerchantNumber,CardSchemeCode,SalesCount,SalesAmount,ReturnsCount,ReturnsAmount)  
SELECT
    *
FROM
    (
        SELECT
            COALESCE(CLEARINGDATEREFERENCENUMBER,BATCH_DATE)  ClearingDate, --BATCH DATE appers to never be NULL **but** BATCH_DATE can be bigger than carling date whihc should be impossible, need to have someone reserach why this happening and fix it.
            LOCATION_ID                                       MerchantNumber,
            CASE
				WHEN CARD_TYPE IN ('00003') THEN 'DNAQ'		--Discover
				WHEN CARD_TYPE IN ('00006') THEN 'ESA'		--Amex (ESA)
				WHEN CARD_TYPE IN ('00030') THEN 'GC'		--Stored Value (Gift Card)
				WHEN CARD_TYPE IN ('00035') THEN 'WEX' 		--WEX � Wright Express
                ELSE CARD_TYPE
            END                    			                        CardSchemeCode,
            SUM(CASE WHEN TRANSACTION_TYPE IN ('5','7') THEN 1                              ELSE 0 END) SalesCount,
            SUM(CASE WHEN TRANSACTION_TYPE IN ('5','7') THEN ZEROIFNULL(TRANSACTION_AMOUNT) ELSE 0 END) SalesAmount,
            SUM(CASE WHEN TRANSACTION_TYPE IN ('6') 	THEN 1                              ELSE 0 END) ReturnsCount,
            SUM(CASE WHEN TRANSACTION_TYPE IN ('6') 	THEN ZEROIFNULL(TRANSACTION_AMOUNT) ELSE 0 END) ReturnsAmount
        FROM    
            BISME.DFM_CreditDetailNonFunded004_North	cdf
            INNER JOIN BI.ReportingChannels         	rc ON (cdf.LOCATION_ID=rc.MerchantNumber)
        WHERE
            TRANSACTION_TYPE IN ('5','7','6') 								-- 5 = Debit Card Sale (-Card, +Merch), 6 = Debit Card Return (+Card, -Merch), 7 = Cash Advance from Card (-Card, +Merch)
            AND	REJECT_INDICATOR <> 'Y'									    --Reject Indicator = 'Y' (Non-Successful)
        GROUP BY
            COALESCE(CLEARINGDATEREFERENCENUMBER,BATCH_DATE),
            LOCATION_ID,
            CASE
				WHEN CARD_TYPE IN ('00003') THEN 'DNAQ'		--Discover
				WHEN CARD_TYPE IN ('00006') THEN 'ESA'		--Amex (ESA)
				WHEN CARD_TYPE IN ('00030') THEN 'GC'		--Stored Value (Gift Card)
				WHEN CARD_TYPE IN ('00035') THEN 'WEX' 		--WEX � Wright Express
                ELSE CARD_TYPE
            END
    ) aa WHERE NOT EXISTS 
    (
        SELECT
            ClearingDate,MerchantNumber,CardSchemeCode,SalesCount,SalesAmount,ReturnsCount,ReturnsAmount
        FROM    
            ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0
    )        
;  
/************************************************************************
 * Update Table - END                                                   *
 ************************************************************************/

----------[ STOP ]------------------------------------------------------------------------------------------------------------------------------------------------------

-- SELECT * FROM BISME.DFM_CreditDetailNonFunded004_North WHERE COALESCE(CLEARINGDATEREFERENCENUMBER,TRANSACTION_DATE)='4/14/2020' AND LOCATION_ID='497206505883' AND CARD_TYPE='00008'
;
SELECT  
    FUNDED_DATE,
    BATCH_DATE,
    CLEARINGDATEREFERENCENUMBER,
    TRANSACTION_TYPE,
    TRANSACTIONAMOUNTSIGNED,
    * 
FROM 
    BISME.DFM_CreditDetailNonFunded004_North   cdf
    INNER JOIN BI.ReportingChannels         rc ON (cdf.LOCATION_ID=rc.MerchantNumber)
WHERE
    REJECT_INDICATOR <> 'Y'
    --CARD_TYPE IN ('00018')
GROUP BY
     
--    AND BATCH_DATE BETWEEN '02-OCT-2020' AND '30-OCT-2020'
--ORDER BY
--    TRANSACTIONAMOUNTSIGNED dESC
LIMIT
    500
;
SELECT  
    TRANSACTION_TYPE,
    CARD_TYPE,
    COUNT(*),
    SUM(TRANSACTION_AMOUNT)
FROM 
    BISME.DFM_CreditDetailNonFunded004_North   cdf
    INNER JOIN BI.ReportingChannels         rc ON (cdf.LOCATION_ID=rc.MerchantNumber)
--WHERE 
    --REJECT_INDICATOR <> 'Y'
GROUP BY
    TRANSACTION_TYPE,
    CARD_TYPE    
    --CARD_TYPE IN ('00018') 
--    AND BATCH_DATE BETWEEN '02-OCT-2020' AND '30-OCT-2020'
--ORDER BY
--    TRANSACTIONAMOUNTSIGNED dESC
LIMIT
    500
;
WHEN CARD_TYPE IN ('00006') THEN 'ESA' 					--Amex
WHEN CARD_TYPE IN ('00008') THEN 'OPTB' 				--Amex Acquiring
;
SELECT  
    FUNDED_DATE,
    BATCH_DATE,
    CLEARINGDATEREFERENCENUMBER,
    TRANSACTION_TYPE,
    TRANSACTIONAMOUNTSIGNED,
    * 
FROM 
    BISME.DFM_CreditDetailNonFunded004_North   cdf
    INNER JOIN BI.ReportingChannels         rc ON (cdf.LOCATION_ID=rc.MerchantNumber)
WHERE 
    --TRANSACTION_TYPE IN ('5','7','6')
    TRANSACTION_TYPE IN ('5','7')
    AND	REJECT_INDICATOR <> 'Y'
    AND TRANSACTIONAMOUNTSIGNED =0
    --AND BATCH_DATE > CLEARINGDATEREFERENCENUMBER
    --AND CLEARINGDATEREFERENCENUMBER IS NOT NULL
    --AND LOCATION_ID='296202436881'
    --AND ENVELOPEFILEDATE='11/9/2020'
    --AND BATCH_NUMBER='032305480008'
;    
---== No NULL's in value fields. YEah! ==---
SELECT
    *
FROM
    ppbisandbox.jmoeller_North_TransactionSummaryNFCardDaily_v1_0
WHERE 
    SalesCount+SalesAmount+ReturnsCount+ReturnsAmount IS NULL
;
