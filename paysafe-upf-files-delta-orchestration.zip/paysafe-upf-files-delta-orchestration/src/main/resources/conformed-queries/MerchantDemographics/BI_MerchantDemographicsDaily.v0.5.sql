-- Put all known "real" Merchant Numbers into the table. By "real" we mean, we have some kind of actual information on them
-- from the Processor confirming they are actually setup in the Processors's system.
-- Merchants reported by the BU in the daily MIF, but for whihc we have no confirmation on (yet) from the Processor, are not
-- "real" merchants (yet).
-- BTW, can test if Omaha MID is Luhn10 compliant here: https://www.mymathtables.com/numbers/luhn-algorithm-calculator.html
-- And can generate the merchant's 16th digit (using the first 15 digits as input) at the link here: https://planetcalc.com/2464/
-- TRUNCATE TABLE ppbisandbox.millikan_MerchantDemographics
;
---== OMAHA: Put new ACTIVE Omaha merchants into the table - 1 of 2 ==---
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber,ClearingPlatform,hasBillingOrVolume
FROM 
    (
        --There are never any "bad" HQ merchants in the FF152 so they do not need to be removed like in the other Omaha reports where we need to only use "R" merhcants instead of "H" merchants. 
        SELECT
            DISTINCT 
            ffo.MRCH_NO MerchantNumber, 
            'Omaha'     ClearingPlatform,
            1           hasBillingOrVolume
        FROM
            BISME.FF152_Omaha						ffo
            INNER JOIN BI.ReportingChannels         rc ON (LEFT(ffo.MRCH_NO,15)=LEFT(rc.MerchantNumber,15)) --This "LEFT" needs only to be added for Omaha!
        WHERE
            ffo.ENVELOPEFILEDATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )
;
---== OMAHA: Put new NON-ACTIVE Omaha merchants into the table - 2 of 2 ==---
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber,ClearingPlatform,hasBillingOrVolume
FROM 
    (
        (
            SELECT
                DISTINCT 
                md32.MerchantNumber MerchantNumber, 
                'Omaha'             ClearingPlatform,
                0                   hasBillingOrVolume
            FROM
                BISME.MD033_Omaha               md33  --This is a mix of 15 and 16-digit MID's. SELECT DISTINCT LEFT(MERCHANTNUMBERSPACEREMOVED,15) FROM   BISME.MD033_Omaha WHERE MRCH_TYPE='R' --5185
                LEFT JOIN BI.ReportingChannels rc ON (LEFT(md33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(rc.MerchantNumber,15)) --This "LEFT" needs only to be added for Omaha!       
                INNER JOIN 
                (
                    SELECT
                        DISTINCT ACCOUNT_NUMBER  MerchantNumber -- These are all 16-digit MIDs
                    FROM
                        BISME.MD032_Omaha  
                ) md32 ON (LEFT(md33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(md32.MerchantNumber,15)) --Do not need to do LEFT(15) here because md32 always has 16-digit MID but just doing it to be consistant.
            WHERE
                md33.MRCH_TYPE='R' 
                AND md33.FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)
                --AND rc.MerchantNumber IS NULL  --Uncommenting this line shows the gap between the MIF 
        ) 
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )
;
---== OMAHA: Load base demographic information ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                     = B.DBA,
    LocationAddressPart     = B.LocationAddressPart,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationZIP             = B.LocationZIP,
    LocationCountry         = B.LocationCountry,
    LocationPhoneLast4      = B.LocationPhoneLast4,    
    OwnerNameLast25Pct      = B.OwnerNameLast25Pct,
    LegalBusinessName       = B.LegalBusinessName,
    DiscountMethod          = B.DiscountMethod,
    BillingProgram          = B.BillingProgram,
    MCC                     = B.MCC,
    EmailFirst25Pct         = B.EmailFirst25Pct,
    OwnerTaxIDLast4         = B.OwnerTaxIDLast4,
    CorpTaxIDLast25Pct      = B.CorpTaxIDLast25Pct,
    CorpTaxIDFingerprint    = B.CorpTaxIDFingerprint,
    OwnerTaxIDFingerprint   = B.OwnerTaxIDFingerprint,
    EmailFingerprint        = B.EmailFingerprint,
    ClearingPlatform        = 'Omaha'   
FROM 
    (    
    SELECT 
        md.MerchantNumber                                       MerchantNumber,
        md33.MERCHANT_ADDRESS_MRCH_NAME                         DBA,
        md33.MERCHANTADDRESSADDRESS1FIRST25PCT                  LocationAddressPart,
        SPLIT_PART(md33.MERCHANT_ADDRESS_ADDRESS_3, ' ', 1)     LocationCity, --This will return "PANAMA" from an expected text string like "PANAMA CITY BEACH FL 32413"
        COALESCE(md33.BNKCRD_DBA_MERCHANT_STATE_OR_COUNTRY)     LocationState,  --Do not use md33.IFC column which is a state but it's "Reserved for First Data use only"
        NULL                                                    LocationZIP,  --RIGHT(MERCHANT_ADDRESS_ADDRESS_3,5) on some card types
        'USA'                                                   LocationCountry,  
        COALESCE(md33.PHONENUMBERLAST4,md33.CONTACTPHONELAST4)  LocationPhoneLast4, 
        COALESCE(md33.LEGALNAMELAST25PCT)                       LegalBusinessName,
        COALESCE(md33.CONTACTNAMELAST25PCT)                     OwnerNameLast25Pct,
        md33.EMAILFIRST25PCT                                    EmailFirst25Pct,
        md33.TAXPAYERIDLAST25PCT                                CorpTaxIDLast25Pct,
        md33.TAXPAYERIDLAST25PCT                                OwnerTaxIDLast4,
        CASE WHEN md33.METHOD='06' THEN 'Daily' WHEN md33.METHOD='01' THEN 'MonthEnd' ELSE 'Other' END DiscountMethod,    
        CASE 
            WHEN NVL(INTERCHANGE_FEE_FLAG,'0') IN ('1','2','4','5') THEN 'CostPlus'
            WHEN NVL(INTERCHANGE_FEE_FLAG,'0') IN ('0') AND QUAL_RATE!=NQUAL_RATE AND NQUAL_RATE!=0 THEN 'Tiered'
            WHEN NVL(INTERCHANGE_FEE_FLAG,'0') IN ('0') AND QUAL_RATE=NQUAL_RATE THEN 'FlatRate'
            WHEN NVL(INTERCHANGE_FEE_FLAG,'0') IN ('3') THEN 'ERR'
            WHEN QUAL_RATE>0 AND MQUAL_RATE=0 AND NQUAL_RATE=0 THEN 'CostPlus' --Shouldn't need to do this but appears lots of MID's get boarded with "0" in the INTERCHANGE_FEE_FLAG that gets corrected later (in the MD-032).
            ELSE '?'
        END                       BillingProgram,   	
        md33.SIC_CODE             MCC,
        md33.TAXPAYER_ID          CorpTaxIDFingerprint,
        md33.TAXPAYER_ID          OwnerTaxIDFingerprint,
        md33.EMAIL                EmailFingerprint
    FROM 
        BISME.MD033_Omaha                                       md33
        INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON  (LEFT(md33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(md.MerchantNumber,15))
    WHERE
        md33.CARD_TYPE='MASTERCARD'
        AND md33.FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)        
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== OMAHA: Update Discount Method from MD032 ==--- 
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DiscountMethod = CASE WHEN B.DiscountMethod='06' THEN 'Daily' WHEN B.DiscountMethod='01' THEN 'MonthEnd' ELSE 'Other' END 
FROM 
    (     
        SELECT 
            aa.MerchantNumber,
            SUBSTRING(md32.NEWFIELDPARTIALDATA,9,2) DiscountMethod  -- Returns "01" from "001 C   01  .00050   004 "
        FROM 
            BISME.MD032_Omaha   md32
            INNER JOIN (
                SELECT
                    md32.ACCOUNT_NUMBER             MerchantNumber,                 
                    LEFT(md32.ACCOUNT_NUMBER,15)    MerchantNumber15,
                    MAX(md32.FC_DATE)               FC_DATE
                FROM 
                    BISME.MD033_Omaha               md33  -- MD033 is 15- and 16-digit MIDs
                    INNER JOIN BISME.MD032_Omaha    md32  ON (LEFT(md33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(md32.ACCOUNT_NUMBER,15)) -- MD032 is all 16-digit MIDs --Do not need to do LEFT(15) here because md32 always has 16-digit MID but just doing it to be consistant.
                GROUP BY
                    md32.ACCOUNT_NUMBER               
            ) aa ON (md32.FC_DATE=aa.FC_DATE AND md32.ACCOUNT_NUMBER=aa.MerchantNumber)
        WHERE 
            md32.TC='505' -- 505 = "DISCOUNT METHO"
            AND LEFT(md32.OLDFIELDPARTIALDATA,5)='001 C'  -- "001 C   00  .00000   004 "  This is the MasterCard Credit card type which is our primary driver.
            AND SUBSTRING(md32.NEWFIELDPARTIALDATA,9,2) NOT IN (' .')
            AND aa.FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)   
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;    
---== OMAHA: Non-Profit flag 1 of 2 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isNonProfit             = 'Y'
FROM 
    (    
        SELECT
            DISTINCT 
            md.MerchantNumber
        FROM
            BISME.MD033_Omaha                                       m33
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON  (LEFT(m33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(md.MerchantNumber,15))
        WHERE
            /*
            MD-033 Manual
            1 - Individual sole/proprietorship
            2 - Partnership
            3 - Corporation - Chapter S, Chapter C
            4 - Medical or legal corporation
            5 - Associations/estates and trusts
            6 - Tax exempt organizations (501C)
            7 - Government (Federal/state/local)
            8 - International organizations
            9 - Limited liability companies    
            */    
            ("501C_TAX_EXEMPT"='Y' OR INCORP_STATUS='6')  --Sometimes INCORP_STATUS='6' and 501C_TAX_EXEMPT is always "N" so we'll accept either as indicator.
            AND CARD_TYPE IN ('AMEXCT043','VS OFLN DB','VISA','MASTERCARD','MC OFLN DB','DCVR ACQ','DCVR AQ DB')
            AND FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;    
---== OMAHA: Non-Profit flag 2 of 2 ==---
-- We've done everything we can to set the flag to YES for accounts we know, so now set everything else to NO
UPDATE 
    ppbisandbox.millikan_MerchantDemographics 
SET 
    isNonProfit='N' 
WHERE 
    ClearingPlatform = 'Omaha' 
    AND isNonProfit IS NULL
;
---== OMAHA: Set open date ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    OpenDate        = DATE_OPENED,
    OpenYearMonth   = TO_DATE(TO_CHAR(B.DATE_OPENED,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    isOpen          = 1,
    CloseDate       = NULL, 
    CloseYearMonth  = NULL,
    CloseCode       = NULL
FROM 
    (    
        SELECT
            md.MerchantNumber,
            MIN(DATE_OPENED) DATE_OPENED
        FROM
            BISME.MD033_Omaha                                     m33
            INNER JOIN ppbisandbox.millikan_MerchantDemographics  md ON  (LEFT(m33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(md.MerchantNumber,15))            
        WHERE
            FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)
            --AND CARD_TYPE IN ('AMEXCT043','VS OFLN DB','VISA','MASTERCARD','MC OFLN DB','DCVR ACQ','DCVR AQ DB') --Would usually use MasterCard Cedit card type but don't care here. Whatever the smallest date on record we have is valid. 
        GROUP BY
            md.MerchantNumber
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;  
---== OMAHA: Set close date ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    CloseDate        = B.CloseDate,
    CloseYearMonth   = TO_DATE(TO_CHAR(B.CloseDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode        = B.CloseCode
FROM 
    (    
        SELECT 
            md.MerchantNumber,
            MAX(md32.FC_DATE)                           CloseDate,
            MAX(RIGHT(RTRIM(NEWFIELDPARTIALDATA),3))    CloseCode
        FROM 
            BISME.MD032_Omaha                                       md32 
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON  (LEFT(md32.ACCOUNT_NUMBER,15)=LEFT(md.MerchantNumber,15)) --Do not need to do LEFT(15) here because md32 always has 16-digit MID but just doing it to be consistant.            
        WHERE 
            TC='000'  
            AND LEFT(NEWFIELDPARTIALDATA,6)='CLOSE '
            AND FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)
        GROUP BY
            md.MerchantNumber
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;  
---== OMAHA: Reopen - Mark accounts who have reopened as "not closed." Keep the original Open Date ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isOpen          = 1,
    CloseDate       = NULL,
    CloseYearMonth  = NULL,
    CloseCode       = NULL
FROM 
    (    
        SELECT 
            md32.ACCOUNT_NUMBER                         MerchantNumber,
            MAX(md32.FC_DATE)                           OpenDate
        FROM 
            ppbisandbox.millikan_MerchantDemographics   md
            INNER JOIN BISME.MD032_Omaha                md32 ON (LEFT(md.MerchantNumber,15)=LEFT(md32.ACCOUNT_NUMBER,15)) --Do not need to do LEFT(15) here because md32 always has 16-digit MID but just doing it to be consistant.
            INNER JOIN (
                SELECT 
                    LAST_DAY(MAX(MRCH_STMT_MTH)) MRCH_STMT_MTH 
                FROM 
                    BISME.MASSOFlat_ControlData_R10
            ) zz ON (md32.FC_DATE>zz.MRCH_STMT_MTH)
        WHERE 
            md32.TC='000'  
            AND TRIM(md32.NEWFIELDPARTIALDATA) IN ('ACCT RE-OPENED') 
            AND md32.FC_DATE >= md.CloseDate
        GROUP BY
            md32.ACCOUNT_NUMBER
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;  
---==   END OMAHA PLATFORM ==---
---== START NORTH PLATFORM ==---
---== NORTH: Put new ACTIVE North merchants into the table - 1 of 2 ==---
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber,ClearingPlatform,hasBillingOrVolume
FROM 
    (
        (
            SELECT
                DISTINCT 
                nfh.FDMSACCOUNTNO   MerchantNumber, 
                'North'             ClearingPlatform,
                1                   hasBillingOrVolume
            FROM
                BISME.MASSNFlat_FeeHistory_RFH  nfh
                INNER JOIN BI.ReportingChannels rc ON (nfh.FDMSACCOUNTNO=rc.MerchantNumber)
            WHERE
                RETAIL_AMOUNT<>0
        ) UNION (     
            SELECT
                DISTINCT 
                cdf.LOCATION_ID MerchantNumber, 
                'North'         ClearingPlatform,
                1               hasBillingOrVolume                 
            FROM
                BISME.DFM_CreditDetailFunded003_North   cdf  
                INNER JOIN BI.ReportingChannels         rc ON (cdf.LOCATION_ID=rc.MerchantNumber)    
            WHERE
                TRANSACTION_AMOUNT <> 0
        ) UNION (     
            SELECT
                DISTINCT 
                cdnf.LOCATION_ID    MerchantNumber, 
                'North'             ClearingPlatform,
                1                   hasBillingOrVolume                 
            FROM
                BISME.DFM_CreditDetailNonFunded004_North    cdnf  
                INNER JOIN BI.ReportingChannels             rc ON (cdnf.LOCATION_ID=rc.MerchantNumber)    
            WHERE
                TRANSACTION_AMOUNT <> 0
        ) UNION (     
            SELECT
                DISTINCT 
                dd.LOCATION_ID  MerchantNumber, 
                'North'         ClearingPlatform,
                1               hasBillingOrVolume                                 
            FROM
                BISME.DFM_DebitDetail005_North    dd 
                INNER JOIN BI.ReportingChannels   rc ON (dd.LOCATION_ID=rc.MerchantNumber)     
            WHERE
                 TRANSACTION_AMOUNT <> 0 
        ) 
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )  
;
---== NORTH: Put new NON-ACTIVE North merchants into the table - 2 of 2 ==---
-- Authorizations don't count as billing or "volume."  "Volume" means Cardholder money has to move.  An "auth" doesn't do that.
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber,ClearingPlatform,hasBillingOrVolume
FROM 
    (
        SELECT
            DISTINCT 
            ad.LOCATION_ID  MerchantNumber, 
            'North'         ClearingPlatform,
            0               hasBillingOrVolume
        FROM
            BISME.DFM_AuthorizationDetails021_North     ad
            INNER JOIN BI.ReportingChannels             rc ON (ad.LOCATION_ID=rc.MerchantNumber)     
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )  
;
---== NORTH: Load basic demographic info ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                     = B.DBA,
    LocationAddressPart     = B.LocationAddressPart,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationZIP             = B.LocationZIP,
    LocationPhoneLast4      = B.LocationPhoneLast4,    
    OwnerNameLast25Pct      = B.OwnerNameLast25Pct,
    MCC                     = B.MCC
FROM 
    ( 
        SELECT
            LH.LOCATION_ID                                                  MerchantNumber,
            COALESCE(LH.SIC_CODE,md.MCC)                                    MCC,
            COALESCE(LH.LOCATION_DBA_NAME,md.DBA)                           DBA,
            COALESCE(LH.LOCATIONADDRESSFIRST50PCT,md.LocationAddressPart)   LocationAddressPart,
            COALESCE(LH.LOCATION_CITY,md.LocationCity)                      LocationCity,
            COALESCE(LH.LOCATION_STATE,md.LocationState)                    LocationState,
            COALESCE(LH.LOCATION_ZIP,md.LocationZIP)                        LocationZIP,
            COALESCE(LH.LOCATIONPHONENUMBERLAST4,md.LocationPhoneLast4)     LocationPhoneLast4,    
            COALESCE(LH.LOCATIONCONTACTNAMELAST25PCT,md.OwnerNameLast25Pct) OwnerNameLast25Pct
--            NULL                        LegalBusinessName,
--            NULL                        DiscountMethod,
--            NULL                        BillingProgram,
--            NULL                        EmailFirst25Pct,
--            NULL                        OwnerTaxIDLast4,
--            NULL                        CorpTaxIDLast25Pct,
--            NULL                        CorpTaxIDFingerprint,
--            NULL                        OwnerTaxIDFingerprint,
--            NULL                        EmailFingerprint,
--            'North'                     ClearingPlatform       
        FROM
            BISME.DFM_LocationHeader002_North                       LH
            INNER JOIN (
                SELECT
                    lh.LOCATION_ID,
                    MAX(lh.FUNDED_DATE)    FUNDED_DATE --BTW, ENVELOPEFILEDATE always equals TIMESTAMPADD('day',+1,FUNDED_DATE)
                FROM
                    BISME.DFM_LocationHeader002_North                       lh  
                    INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (lh.LOCATION_ID=md.MerchantNumber)
                    INNER JOIN (
                        SELECT 
                            LAST_DAY(MAX(MRCH_STMT_MTH)) MonthlyReportingLastDayOfMonth 
                        FROM 
                            BISME.MASSNFlat_MerchantControlData_RAA                    
                    ) aa ON (lh.FUNDED_DATE>aa.MonthlyReportingLastDayOfMonth)
                GROUP BY
                    lh.LOCATION_ID
            )                                                       aa ON (lh.LOCATION_ID=aa.LOCATION_ID AND lh.FUNDED_DATE=aa.FUNDED_DATE)
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (aa.LOCATION_ID=md.MerchantNumber)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber            
;   
---==   END NORTH PLATFORM ==---
---== START TSYS PLATFORM ==---
---== TSYS: Put new ACTIVE North merchants into the table - 1 of 2 ==---
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber, ClearingPlatform, hasBillingOrVolume
FROM 
    (
        (
            SELECT 
                DISTINCT 
                MERCHANT_ID     MerchantNumber, 
                'TSYS'          ClearingPlatform, 
                1               hasBillingOrVolume
            FROM 
                BISME.PPMFeeItemTotalsMonthly_TSYS  fit 
                INNER JOIN BI.ReportingChannels     rc ON (fit.MERCHANT_ID=rc.MerchantNumber)     
            WHERE 
                CAST(rc.MerchantNumber AS BIGINT) <> 0    
                AND INCOME <> 0 --Purposely limited this to just the INCOME column and not hte COUNT or AMOUNT columns.
        ) UNION ( 
            SELECT 
                DISTINCT 
                MERCHANT_ID     MerchantNumber, 
                'TSYS'          ClearingPlatform,
                1               hasBillingOrVolume
            FROM 
                BISME.PPMProfitabilityTotalsMonthly_TSYS    ptm   
                INNER JOIN BI.ReportingChannels             rc ON (ptm.MERCHANT_ID=rc.MerchantNumber)    
            WHERE 
                CAST(rc.MerchantNumber AS BIGINT) <> 0     
                AND (INCOME <> 0 OR AMOUNT_OF_SALES <> 0 OR AMOUNT_OF_CREDITS <> 0)
        ) UNION (
            SELECT 
                DISTINCT 
                MERCHANT_ID     MerchantNumber, 
                'TSYS'          ClearingPlatform,
                1               hasBillingOrVolume
            FROM 
                BISME.PPMProfitabilityTotalsDaily_TSYS  ptd  
                INNER JOIN BI.ReportingChannels         rc ON (ptd.MERCHANT_ID=rc.MerchantNumber)    
            WHERE 
                CAST(rc.MerchantNumber AS BIGINT) <> 0    
                AND (INCOME <> 0 OR AMOUNT_OF_SALES <> 0 OR AMOUNT_OF_CREDITS <> 0)      
        ) UNION (
            SELECT 
                DISTINCT 
                rc.MerchantNumber   MerchantNumber, 
                'TSYS'              ClearingPlatform,
                1                   hasBillingOrVolume
            FROM  
                BISME.DailyDetailFile_TSYS      ddf  -- Unlike all the other other TSYS tables, this table has leading zeros on the merchant number thus the need to CAST(MID AS BIGINT)
                INNER JOIN BI.ReportingChannels rc  ON (CAST(ddf.BH_MERCHANT_ACCOUNT_NUMBER AS BIGINT)=rc.MerchantNumber)
            WHERE 
                CAST(rc.MerchantNumber AS BIGINT) <> 0             
                AND DT_TRANSACTION_AMOUNT<>0
        )   
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )
;
---== TSYS: Put new NON-ACTIVE North merchants into the table - 2 of 2 ==---
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber, ClearingPlatform, hasBillingOrVolume
FROM 
    (
        (
            SELECT 
                DISTINCT 
                ACCOUNT_NUMBER  MerchantNumber, 
                'TSYS'          ClearingPlatform,
                0               hasBillingOrVolume
            FROM 
                BISME.MerchantDetailFile_TSYS       mdf  
                INNER JOIN BI.ReportingChannels     rc ON (mdf.ACCOUNT_NUMBER=rc.MerchantNumber)     
            WHERE
                 CAST(rc.MerchantNumber AS BIGINT) <> 0              
        ) UNION (
            SELECT 
                DISTINCT 
                rc.MerchantNumber   MerchantNumber, 
                'TSYS'              ClearingPlatform,
                0                   hasBillingOrVolume                
            FROM 
                BISME.AuthorizationDetailFile_TSYS  adf
                LEFT JOIN BI.ReportingChannels      rc ON (LEFT(adf.TD01_CARD_ACCEPTOR_ID,9)=rc.MerchantNumber)
            WHERE 
                CAST(rc.MerchantNumber AS BIGINT) <> 0    
				--Only look back in time 60 days as this is a huge table.  
        )
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )        
;
---== TSYS: Load basic merchant demographic  ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A 
SET 
    DBA                     = B.DBA,
    MCC                     = B.MCC,
    OpenDate                = B.OpenDate,
    OpenYearMonth           = TO_DATE(TO_CHAR(B.OpenDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseDate               = B.CloseDate,
    CloseYearMonth          = TO_DATE(TO_CHAR(B.CloseDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode               = CASE WHEN B.CloseDate IS NOT NULL THEN 'TBD' ELSE NULL END,
    isOpen                  = CASE WHEN B.CloseDate IS NOT NULL THEN 0 ELSE 1 END,        
    LocationAddressPart     = B.LocationAddressPart,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationZIP             = B.LocationZIP,
    LocationCountry         = B.LocationCountry,
    LocationPhoneLast4      = B.LocationPhoneLast4,    
    OwnerNameLast25Pct      = B.TheOwnerNameLast25Pct,
    LegalBusinessName       = B.LegalBusinessName,
    --DiscountMethod          = B.DiscountMethod,
    --isNonProfit             = B.isNonProfit,
    EmailFirst25Pct         = B.EmailFirst25Pct,
    OwnerTaxIDLast4         = B.OwnerTaxIDLast4,
    CorpTaxIDLast25Pct      = B.CorpTaxIDLast25Pct,
    CorpTaxIDFingerprint    = B.CorpTaxIDFingerprint,
    OwnerTaxIDFingerprint   = B.OwnerTaxIDFingerprint,
    EmailFingerprint        = B.EmailFingerprint,
    ClearingPlatform        = 'TSYS'   
FROM 
    (   
        SELECT
            mdf.ACCOUNT_NUMBER      MerchantNumber,
            DBA_NAME                DBA,    
            SIC                     MCC,
            OPEN_DATE               OpenDate,
            CASE 
                WHEN MERCHANT_STATUS IS NOT NULL AND STATUS_CHANGED_DATE IS NOT NULL THEN STATUS_CHANGED_DATE ELSE NULL
            END                     CloseDate,
            NULL                    LocationAddressPart,
            DBA_ADDRESS_CITY        LocationCity,
            DBA_ADDRESS_STATE       LocationState,
            LEFT(DBA_ZIP,5)         LocationZIP,
            'USA'                   LocationCountry,
            CASE 
                WHEN NVL(CAST(PHONE1LAST4 AS INT),0)>0                  THEN PHONE1LAST4
                WHEN NVL(CAST(PHONE2LAST4 AS INT),0)>0                  THEN PHONE2LAST4 
                WHEN NVL(CAST(CUSTOMERSERVICENUMBERLAST4 AS INT),0)>0   THEN CUSTOMERSERVICENUMBERLAST4
                ELSE NULL
            END                     LocationPhoneLast4,
            CASE 
                WHEN LENGTH(mdf.OWNERNAMELAST25PCT)>0   THEN mdf.OWNERNAMELAST25PCT
                WHEN LENGTH(MANAGERNAMELAST25PCT)>0     THEN MANAGERNAMELAST25PCT 
                ELSE NULL
            END                     TheOwnerNameLast25Pct,
            NULL                    LegalBusinessName,
            NULL                    DiscountMethod,
            NULL                    isNonProfit,
            MERCHANTEMAILADDRESSFIRST25PCT  EmailFirst25Pct,
            OWNERSSNLAST4           OwnerTaxIDLast4,
            FEDERALTAXIDLAST25PCT   CorpTaxIDLast25Pct,
            OWNER_SSN               OwnerTaxIDFingerprint,
            FEDERAL_TAX_ID          CorpTaxIDFingerprint,
            MERCHANT_EMAIL_ADDRESS  EmailFingerprint
        FROM
            BISME.MerchantDetailFile_TSYS   mdf
            INNER JOIN (
                SELECT 
                    ACCOUNT_NUMBER      ACCOUNT_NUMBER,
                    MAX(UNITYFILEDATE)  UNITYFILEDATE
                FROM 
                    BISME.MerchantDetailFile_TSYS   
                GROUP BY
                    ACCOUNT_NUMBER    
            ) aa ON (mdf.UNITYFILEDATE=aa.UNITYFILEDATE AND mdf.ACCOUNT_NUMBER=aa.ACCOUNT_NUMBER)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber  
;
---== TSYS: "isNonProfit" cannot be set using daily data from Processsor. There is no known way at this time ==---
---== TSYS: "DiscountMethod" cannot be set using daily data from Processsor. There is no known way at this time ==---
---== TSYS: END ==--- 
---== TSYS: END ==---
;
---== MIF: Fall back to using demographic info from the MIF since we've tried everything we could to get it directly from the Processor ==---
---== MIF: Start but resetting rows with "Other" values back to NULL so we have a shot a something more accurate from the latest MIF.  
UPDATE ppbisandbox.millikan_MerchantDemographics SET DiscountMethod = NULL WHERE DiscountMethod='Other'
;
UPDATE ppbisandbox.millikan_MerchantDemographics SET isNonProfit = NULL WHERE isNonProfit='N'
;
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isOpen                  = CASE WHEN B.CloseDate IS NOT NULL THEN 0 ELSE 1 END,    
    OpenDate                = B.OpenDate,
    CloseDate               = B.CloseDate,
    OpenYearMonth           = TO_DATE(TO_CHAR(B.OpenDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseYearMonth          = TO_DATE(TO_CHAR(B.CloseDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode               = CASE WHEN B.CloseDate IS NOT NULL THEN 'TBD' ELSE NULL END,   
    DBA                     = B.DBA,
    MCC                     = B.MCC,
    
    LocationAddressPart     = B.LocationAddressPart,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationCountry         = B.LocationCountry,
    LocationPhoneLast4      = B.LocationPhoneLast4,
                    
    DiscountMethod          = B.DiscountMethod,
    isNonProfit             = B.isNonProfit,
    
    CorpTaxIDLast25Pct      = B.CorpTaxIDLast25Pct,    
    OwnerTaxIDLast4         = B.OwnerTaxIDLast4,
    LegalBusinessName       = B.LegalBusinessName,
    CorpTaxIDFingerprint    = B.CorpTaxIDFingerprint,
    OwnerTaxIDFingerprint   = B.OwnerTaxIDFingerprint,
    EmailFirst25Pct         = B.EmailFirst25Pct
FROM 
    ( 
        SELECT 
            md.MerchantNumber,
            COALESCE(md.DBA,mar.MERCHANT_NAME)                              DBA,
            COALESCE(md.MCC,mar.MCC_CODE)                                   MCC,
            COALESCE(md.OpenDate,mar.DATE_OPEN)                             OpenDate,
            -- When the date closed in the MIF is in the current month, then we'll accept it as accurate. 
            -- If it's older than *this month* then don't trust it because the monthly data feeds are more accurate.
            -- Has seen many times where the CRM tool (iWorkflow, SOS, ZEUS, etc) think a merhcant is closed but at the Processor, it really isn't
            COALESCE(md.CloseDate,
                CASE
                    WHEN mar.DATE_CLOSED > LAST_DAY(TIMESTAMPADD('month', -1, SYSDATE())) THEN mar.DATE_CLOSED  
                    ELSE NULL
                END
            )                          CloseDate,
            COALESCE(md.LocationAddressPart,mar.ADDR1STREETNOFIRST50PCT)    LocationAddressPart,	
            COALESCE(md.LocationCity,mar.CITY)                              LocationCity,	
            COALESCE(md.LocationState,mar.STATE)                            LocationState,	
            COALESCE(md.LocationZIP,mar.ZIP)                                LocationZIP,	
            COALESCE(md.LocationCountry,'USA')                              LocationCountry,  -- COUNTY field sometimes has values like "ALAMEDA COUNTY" or "MONTGOMERY COUNTY" so just going to ignore it.	
            COALESCE(md.LocationPhoneLast4,NULL)                            LocationPhoneLast4,
            COALESCE(md.BillingProgram,NULL)                                BillingProgram,
            COALESCE(md.DiscountMethod,
                CASE 
                    WHEN DISCOUNT_METHOD IN ('01','1') THEN 'Daily'
                    WHEN DISCOUNT_METHOD IN ('06','6') THEN 'MonthEnd'
                    ELSE 'Other'  --01 - MONTHLY; 06 - DAILY
                END
            )                                                               DiscountMethod, 
            COALESCE(md.EmailFirst25Pct,NULL)                               EmailFirst25Pct,
            COALESCE(md.CorpTaxIDLast25Pct,mar.TAXIDLAST25PCT)              CorpTaxIDLast25Pct,	
            COALESCE(md.OwnerTaxIDLast4,mar.SSNLAST4)                       OwnerTaxIDLast4,        	
            COALESCE(md.LegalBusinessName,mar.CORPNAMELAST25PCT,mar.IRSNAMELAST25PCT)   LegalBusinessName,	
            COALESCE(md.CorpTaxIDFingerprint,mar.TAX_ID)                    CorpTaxIDFingerprint,	
            COALESCE(md.OwnerTaxIDFingerprint,mar.SSN)                      OwnerTaxIDFingerprint,	
            COALESCE(md.EmailFingerprint,NULL)                              EmailFingerprint,
            /*
            1 - Sole Proprietorship; 
            2 - Partnership; 
            3 - LLC & Corporation ; 
            4 - Non Profit
            */
            COALESCE(md.isNonProfit,
                CASE 
                    WHEN BUS_TYPE = 4 THEN 'Y' ELSE 'N'
                END
            )                                                               isNonProfit            
        FROM 
            ppbisandbox.millikan_MerchantDemographics                   md
            INNER JOIN BISME.SupplementalMIF_ApplicationRecord_Internal mar ON (md.MerchantNumber=mar.MERCHANT_SEQUENCE)
            INNER JOIN (
                SELECT 
                    MAX(ENVELOPECREATIONTIME) ENVELOPECREATIONTIME 
                FROM 
                    BISME.SupplementalMIF_ApplicationRecord_Internal
            )                                                           aa ON (mar.ENVELOPECREATIONTIME=aa.ENVELOPECREATIONTIME)
        WHERE
            COALESCE(md.DBA,mar.MERCHANT_NAME) IS NULL
            OR COALESCE(md.MCC,mar.MCC_CODE) IS NULL
            OR COALESCE(md.OpenDate,mar.DATE_OPEN) IS NULL
            OR COALESCE(md.LocationAddressPart,mar.ADDR1STREETNOFIRST50PCT) IS NULL
            OR COALESCE(md.LocationCity,mar.CITY) IS NULL
            OR COALESCE(md.LocationState,mar.STATE) IS NULL
            OR COALESCE(md.LocationZIP,mar.ZIP) IS NULL
            OR COALESCE(md.LocationCountry,'USA') IS NULL
            OR COALESCE(md.LocationPhoneLast4,NULL) IS NULL
            OR COALESCE(md.BillingProgram,NULL) IS NULL
            OR COALESCE(md.DiscountMethod,
                CASE 
                    WHEN DISCOUNT_METHOD IN ('01','1') THEN 'Daily'
                    WHEN DISCOUNT_METHOD IN ('06','6') THEN 'MonthEnd'
                    ELSE 'Other'  --01 - MONTHLY; 06 - DAILY
                END
            ) IS NULL
            OR COALESCE(md.EmailFirst25Pct,NULL) IS NULL
            OR COALESCE(md.CorpTaxIDLast25Pct,mar.TAXIDLAST25PCT) IS NULL
            OR COALESCE(md.OwnerTaxIDLast4,mar.SSNLAST4) IS NULL
            OR COALESCE(md.LegalBusinessName,mar.CORPNAMELAST25PCT,mar.IRSNAMELAST25PCT) IS NULL
            OR COALESCE(md.CorpTaxIDFingerprint,mar.TAX_ID) IS NULL
            OR COALESCE(md.OwnerTaxIDFingerprint,mar.SSN) IS NULL
            OR COALESCE(md.EmailFingerprint,NULL) IS NULL
            OR COALESCE(md.isNonProfit,
                CASE 
                    WHEN BUS_TYPE = 4 THEN 'Y' ELSE 'N'
                END
            ) IS NULL
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber 
;
---== MIF: Email address ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    EmailFirst25Pct     = B.EmailFirst25Pct, 
    EmailFingerprint    = B.EmailFingerprint
FROM 
    (
        SELECT
            ao.MERCHANT_SEQUENCE    MerchantNumber,
            ao.EMAIL                EmailFingerprint, 
            ao.EMAILFIRST25PCT      EmailFirst25Pct
        FROM
            ppbisandbox.millikan_MerchantDemographics                   md
            INNER JOIN BISME.SupplementalMIF_ApplicationOwners_Internal ao ON (
                CASE 
                    WHEN md.ClearingPlatform='Omaha' THEN LEFT(md.MerchantNumber,15) 
                    ELSE md.MerchantNumber 
                END 
                = 
                CASE 
                    WHEN md.ClearingPlatform='Omaha' 
                    THEN LEFT(ao.MERCHANT_SEQUENCE,15) 
                    ELSE ao.MERCHANT_SEQUENCE 
                END 
            ) 
            INNER JOIN (
                SELECT
                    MERCHANT_SEQUENCE,
                    MAX(ENVELOPECREATIONTIME)   ENVELOPECREATIONTIME
                FROM
                    BISME.SupplementalMIF_ApplicationOwners_Internal
                WHERE
                    EMAIL IS NOT NULL
                GROUP BY
                    MERCHANT_SEQUENCE
            )                                                           aa ON (ao.ENVELOPECREATIONTIME=aa.ENVELOPECREATIONTIME AND ao.MERCHANT_SEQUENCE=aa.MERCHANT_SEQUENCE)
        WHERE
            md.EmailFirst25Pct IS NULL 
            OR md.EmailFingerprint IS NULL
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;    
---== Sponsor Bank ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    SponsorBank  = B.SponsorBank
FROM 
    (
        SELECT 
            md.MerchantNumber,
            pbm.SponsorBank
        FROM
            ppbisandbox.millikan_MerchantDemographics   md
            INNER JOIN BI_DIMENSION.ProcessorBankMatrix pbm ON (LEFT(md.MerchantNumber,pbm.MerchantNumberPrefixLength)=pbm.MerchantNumberPrefix)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== Update hasBillingOrVolume ==--
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    hasBillingOrVolume  = 1
FROM 
    (
        SELECT 
            DISTINCT MerchantNumber
        FROM 
            BI.TransactionsSummaryDaily
        WHERE
            ClearingDate > TIMESTAMPADD('day', -60, SYSDATE()) --Only look back in time 60 days as this is a huge table. 
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;
---== Update CloseDate 1 of 2 ==--
-- Not sure the merchant is even closed however since it was reported closed, and very well coudl be due to no activity in 15 days, use a more realistic close date.
-- If the below 2 things are true, change the close date to be their biggest transaction date.
-- 1. The merchant's last transaction date is more than a 14 days ago.
-- 2. The difference between the merchant's reported close date and their last transaction date is more than 15 days apart.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isOpen          = 0,
    CloseDate       = B.CloseDate, 
    CloseYearMonth  = TO_DATE(TO_CHAR(B.CloseDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode       = NULL
FROM 
    (
        SELECT
            md.MerchantNumber   MerchantNumber,
            aa.ClearingDate     CloseDate
        FROM
            ppbisandbox.millikan_MerchantDemographics   md
            INNER JOIN (
                SELECT 
                    MerchantNumber,
                    MAX(ClearingDate)   ClearingDate
                FROM 
                    BI.TransactionsSummaryDaily
                GROUP BY
                    MerchantNumber
            ) aa ON (md.MerchantNumber=aa.MerchantNumber)
        WHERE
            DATEDIFF('day', md.CloseDate,aa.ClearingDate)>15
            AND DATEDIFF('day', aa.ClearingDate,(SELECT MAX(ClearingDate) FROM BI.TransactionsSummaryDaily))>=14
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;        
---== Update CloseDate 1 of 2 ==--
-- Remove the merchant's close date because it's highly unlikely they are closed because they've recently transacted and they close date was a long time ago.
-- If the below 2 things are true, remove the merchant's closed status.
-- 1. The merchant's biggest transaction date is within 2 days of the most recent transaction date in the system. 
-- 2. The difference between the merchant's reported close date and their last transaction date is more than 15 days apart.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isOpen          = 1,
    CloseDate       = NULL,
    CloseYearMonth  = NULL,
    CloseCode       = NULL
FROM 
    (
        SELECT
            md.MerchantNumber
        FROM
            ppbisandbox.millikan_MerchantDemographics   md
            INNER JOIN (
                SELECT 
                    MerchantNumber,
                    MAX(ClearingDate)   ClearingDate
                FROM 
                    BI.TransactionsSummaryDaily
                GROUP BY
                    MerchantNumber
            ) aa ON (md.MerchantNumber=aa.MerchantNumber)
        WHERE
            DATEDIFF('day', md.CloseDate,aa.ClearingDate)>15
            AND DATEDIFF('day', aa.ClearingDate,(SELECT MAX(ClearingDate) FROM BI.TransactionsSummaryDaily))>=2
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;        
---== Only QA/SandBox below here, ignore everything below this line ==---
---== Only QA/SandBox below here, ignore everything below this line ==---
---== Only QA/SandBox below here, ignore everything below this line ==---

SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE OpenDate IS NULL  --This should return no rows. Expect OpenDate to always to be populated 
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE DBA IS NULL  --This should return no rows. Expect DBA to always to be populated 
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE hasBillingOrVolume IS NULL  --This should return no rows. Expect DBA to always to be populated
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE OpenDate > NVL(CloseDate, SYSDATE)  --This should return no rows. Expect CloseDate to always be bigger than the OpenDate
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE hasBillingOrVolume=0 AND isOpen=1  --Merchants who old open dates (more than 60 days ago) who still have no billing and no volume are unlikely to be "real" merchants and should liekly be purged off the system.
;

--=== Opened ticket with TSYS on this ==---
SELECT * FROM BISME.PPMFeeItemTotalsMonthly_TSYS WHERE MERCHANT_ID='3286591848434185' --Merchant has billing starting Dec 2020
SELECT * FROM BISME.MerchantDetailFile_TSYS mdf WHERE mdf.ACCOUNT_NUMBER='3286591848434185' --But merhcant never showed up here, in the MDF.
;

---== MIF Discovery ==---
;
SELECT CONTACT_TYPE, count(*) FROM BISME.SupplementalMIF_ApplicationCommunications_Internal WHERE ENVELOPECREATIONTIME='2/2/2021 3:30:04 AM' GROUP BY CONTACT_TYPE
;    
SELECT * FROM BISME.SupplementalMIF_ApplicationContacts_Internal WHERE ENVELOPECREATIONTIME='2/2/2021 3:30:04 AM' 
;
SELECT * FROM BISME.SupplementalMIF_ApplicationOwners_Internal WHERE ENVELOPECREATIONTIME >= '25-JAN-2021' ORDER BY ENVELOPECREATIONTIME DESC LIMIT 500
;

;
SELECT 
    DISTINCT mar.DISCOUNT_METHOD 
FROM
    ppbisandbox.millikan_MerchantDemographics                   md
    INNER JOIN BISME.SupplementalMIF_ApplicationRecord_Internal mar ON (md.MerchantNumber=mar.MERCHANT_SEQUENCE)
    INNER JOIN (
        SELECT 
            MAX(ENVELOPECREATIONTIME) ENVELOPECREATIONTIME 
        FROM 
            BISME.SupplementalMIF_ApplicationRecord_Internal
    )                                                           aa ON (mar.ENVELOPECREATIONTIME=aa.ENVELOPECREATIONTIME) 
;
SELECT * FROM BISME.DFM_FileHeader001_North WHERE HIERARCHY_ID='296201227885' LIMIT 500
;
;
SELECT * FROM BISME.DFM_LocationHeader002_North ORDER BY ENVELOPEFILEDATE DESC LIMIT 500
;
SELECT * FROM BISME.DFM_LocationTrailer014_North WHERE LOCATION_ID='296201227885' LIMIT 500
;
SELECT * FROM BISME.DFM_LocationBankDepositsSummary013_North  LIMIT 500
;
SELECT * FROM BISME.DFM_RetrievalDetail010_North  LIMIT 500
;
SELECT * FROM  BISME.DFM_QualificationExpense007_North WHERE LOCATION_ID='296201227885' LIMIT 500
;
SELECT * FROM BISME.DFM_AdjustmentDetail006_North  WHERE LOCATION_ID='067008132994' LIMIT 500
;
SELECT * FROM BISME.DFM_CreditDetailFunded003_North WHERE LOCATION_ID='067008132994' LIMIT 500
;
--Reopen example
SELECT 
    md32.ACCOUNT_NUMBER                 MerchantNumber,
    *
FROM 
    BISME.MD032_Omaha    md32 
WHERE 
   ACCOUNT_NUMBER='4228997700452118'
--    TC='000'
--    AND TRIM(NEWFIELDPARTIALDATA) NOT IN ('ACCT RE-OPENED') 
--    AND LEFT(NEWFIELDPARTIALDATA,6) NOT IN ('CLOSE ','ADD CL','DELETE')
ORDER BY
    FC_DATE

;

SELECT
    RPAD(MERCHANTNUMBERSPACEREMOVED,16,'0') MerchantNumber,
    SIC_CODE,
    *
FROM
    BISME.MD033_Omaha
WHERE
    --FC_DATE > (SELECT LAST_DAY(MAX(MRCH_STMT_MTH)) FROM BISME.MASSOFlat_ControlData_R10)
    --AND CARD_TYPE IN ('AMEXCT043','VS OFLN DB','VISA','MASTERCARD','MC OFLN DB','DCVR ACQ','DCVR AQ DB') --Would usually use MasterCard Cedit card type but don't care here. Whatever the smallest date on record we have is valid.
    --NVL(ENHANCED_RECOVER_REDUCED,0)=0
    --RPAD(MERCHANTNUMBERSPACEREMOVED,16,'0')='5428141600825259'
    CARD_TYPE='MASTERCARD'
    --AND NVL(ENHANCED_RECOVER_REDUCED,0) >0 
    --AND NVL(INTERCHANGE_FEE_FLAG,'0')  IN ('3')
    --AND NVL(INTERCHANGE_FEE_FLAG,'0') NOT IN ('0','1','2','3','4','5')
    AND SIC_CODE IS NULL
;
SELECT DATE_OPENED,* FROM BISME.MD033_Omaha   md33
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE PlatformClearing = 'Omaha' AND OpenDate IS NULL
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE MerchantNumber='5482982800000198'
;
SELECT * FROM BISME.MD032_Omaha    md32  WHERE ACCOUNT_NUMBER='4223699155545081' ORDER BY FC_DATE dESC
;
       ;
        SELECT CARD_TYPE,* FROM BISME.MD033_Omaha md33 WHERE md33.CARD_TYPE='MASTERCARD' AND MERCHANT_ADDRESS_ADDRESS_3 IS NOT NULL ORDER BY ENVELOPECREATIONTIME DESC LIMIT 500
        ;
        SELECT MRCH_ADV_FLAG,MRCH_ADVC_IND,* FROM BISME.MD033_Omaha WHERE MERCHANTNUMBERSPACEREMOVED='510159650008691'
        ;
        SELECT METHOD, * FROM BISME.MD033_Omaha md33 WHERE  md33.CARD_TYPE='MASTERCARD' AND METHOD NOT IN ('01','06') LIMIT 500
        ;
        SELECT CARD_TYPE,"501C_TAX_EXEMPT",INCORP_STATUS,* FROM BISME.MD033_Omaha md33 WHERE  MERCHANTNUMBERSPACEREMOVED='536387130700388' LIMIT 500  -- md33.CARD_TYPE='MASTERCARD' AND "501C_TAX_EXEMPT"='Y'
        ;
        SELECT DISBURSE_FREQ,DISBURSEMENT_METHOD_CODE,DISB_DETAIL,METHOD,* FROM BISME.MD033_Omaha WHERE DISBURSE_FREQ IS NOT NULL AND MERCHANTNUMBERSPACEREMOVED='510159650008691'
        ;
        SELECT 
            md32.ACCOUNT_NUMBER,
            MAX(md32.FC_DATE) FC_DATE
        FROM 
            BISME.MD033_Omaha               md33  -- MD033 is 15- and 16-digit MIDs
            INNER JOIN BISME.MD032_Omaha    md32  ON (LEFT(md33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(md32.ACCOUNT_NUMBER,15))  -- MD032 is all 16-digit MIDs
        GROUP BY
            md32.ACCOUNT_NUMBER
            --ACCOUNT_NUMBER='5428141600379828'
        ;
            --AND md32.ACCOUNT_NUMBER='5428141600379828'  
      
;

  


SELECT MRCH_NO, MIN(ff.CLEARINGDATEREFRNR) FirstTxnDate FROM BISME.FF152_Omaha ff GROUP BY MRCH_NO
;
SELECT UNITYFILEDATE, count(*) FROM BISME.MD033_Omaha   md33 GROUP BY UNITYFILEDATE
;
SELECT distinct LEFT(UNITYFILENAME,23) FROM BISME.MD033_Omaha   md33 WHERE UNITYFILEDATE='1/1/2021 3:10:25 AM'
;
SELECT 
    DATE_OPENED,DATE_CLOSED, ALTERNATE_DATE_CLOSED, aa.FirstTxnDate, * 
FROM 
    BISME.MD033_Omaha   md33
    INNER JOIN (
        SELECT MRCH_NO, MIN(ff.CLEARINGDATEREFRNR) FirstTxnDate FROM BISME.FF152_Omaha ff GROUP BY MRCH_NO
    ) aa ON (LEFT(md33.MERCHANTNUMBERSPACEREMOVED,15)=LEFT(aa.MRCH_NO,15))
WHERE
   aa.FirstTxnDate = md33.DATE_OPENED
;
SELECT CARD_TYPE,	PROCESS_SW,	METHOD, QUAL_RATE,	MQUAL_RATE,	NQUAL_RATE, INCORP_STATUS, 
CAT_CODE, ENHANCED_RECOVER_REDUCED, DATE_OPENED,DATE_CLOSED, ALTERNATE_DATE_CLOSED,* FROM BISME.MD033_Omaha   md33 WHERE MERCHANTNUMBERSPACEREMOVED='4223698701039375'
;

SELECT CARD_TYPE, count(*) FROM BISME.MD033_Omaha GROUP BY CARD_TYPE
;
SELECT DATE_CLOSED, count(*) FROM BISME.MD033_Omaha GROUP BY DATE_CLOSED 
;


SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE PlatformClearing='Omaha' AND DBA IS NULL MerchantNumber='4223690201000015'
;
SELECT * FROM BISME.MASSOFlat_ControlData_R10 cd WHERE cd.ACCOUNT_NO='4223695900041335'
;

; 
---== TSYS: DiscountMethod ==---
SELECT
    FEE_CATEGORY, 
    FEE_ITEM_KEY_1,
    SUM(FEES_PAID_DAILY_VERSION) FEES_PAID_DAILY_VERSION
FROM 
    BISME.PPMProfitabilityTotalsDaily_TSYS
WHERE
    FEES_PAID_DAILY_VERSION!=0
    AND (
            FEE_ITEM_KEY_1 IN ('VS','VD','VB','V$','VL')    --Visa
            OR FEE_ITEM_KEY_1 IN ('MC','MD','MB','M$','ML') --MasterCard
            OR FEE_ITEM_KEY_1 IN ('DS','DD','DZ','DJ','D$') --Discover
            --Skipping AMEX because it's often differnt the others and not considered "core" offering.
    )
;    
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                 = B.DBA, 
    LocationAddressPart = B.LocationAddressPart,
    LocationCity        = B.LocationCity,
    LocationState       = B.LocationState,
    LocationZIP         = B.LocationZIP,
    LocationCounty      = B.LocationCounty,
    LocationPhoneLast4  = B.LocationPhoneLast4,
    OwnerNameLast25Pct  = B.OwnerNameLast25Pct,
    Platform            ='OMA'
FROM 
    (    
        SELECT 
            aa.ACCOUNT_NO                   MerchantNumber,    
            TRIM(DBA_NAME24 || DBA_NAME6)   DBA, 
            DBAADDRESSONE24FIRST50PCT       LocationAddressPart,
            DBA_CITY21 || DBA_CITY11        LocationCity,
            DBA_STATE                       LocationState,	
            DBA_ZIP5                        LocationZIP,
            CASE WHEN DBA_COUNTRY_CODE='US' THEN 'USA' ELSE DBA_COUNTRY_CODE END LocationCounty,
            TELEPHONENOLAST4                LocationPhoneLast4,
            SOLEPROPRIETORNAMELAST25PCT     OwnerNameLast25Pct
            --EmailFirst25Pct         
            --OwnerTaxIDLast4         
            --CorpTaxIDLast25Pct    
            --CorpTaxIDFingerprint  
            --OwnerTaxIDFingerprint 
            --EmailFingerprint          
        FROM 
            BISME.MASSOFlat_AddressDBA_R20 AS aa
            INNER JOIN 
                (
                    SELECT
                        ACCOUNT_NO, 
                        MAX(MRCH_STMT_MTH)   MRCH_STMT_MTH
                    FROM    
                        BISME.MASSOFlat_AddressDBA_R20
                    GROUP BY
                        ACCOUNT_NO     
                ) AS bb ON (aa.MRCH_STMT_MTH=bb.MRCH_STMT_MTH  AND aa.ACCOUNT_NO=bb.ACCOUNT_NO)   
    ) B
WHERE
    A.MerchantNumber = B.MerchantNumber
;
SELECT
    CAST(LTRIM(RTRIM(aa.FDMSAccountNo)) AS CHAR(12))    "MerchantNumber", 
	--BillingProgram    	varchar(255) NULL,
	--isOpen            	tinyint NULL,
	--OpenedYearMonth   	date NULL,
	--ClosedYearMonth   	date NULL,
	--SponsorBank       	varchar(255) NULL,
    'NOR'               "Platform",
	DBA_Name            "DBA",
	DBAADDRESS1FIRST25PCT   LocationAddressPart,
    DBA_CITY LocationCity        varchar(255) NULL,
    DBA_STATE LocationState       varchar(255) NULL,
    DBA_ZIP_FIRST5 LocationZIP         varchar(255) NULL,  
    CASE WHEN COUNTRY_CODE='US' THEN 'USA' ELSE COUNTRY_CODE END    LocationCounty,  
    DBAPHONELAST4   LocationPhoneLast4  varchar(255) NULL,     
	--OpenedDate        	date NULL,
	--ClosedDate        	date NULL,
	--hasEcommerceVol     tinyint NULL,	
	--MCC               	varchar(4) NULL,	
	--CloseCode         	varchar(255) NULL,
	--CloseDescription  	varchar(255) NULL,
	--isPremier     	    tinyint NULL,
	--PremierRep     	    varchar(255) NULL,
	CORPCONTACTLAST25PCT    "OwnerNameLast25Pct",
	NULL                    "EmailFirst25Pct",
    CorpTaxIDLast25Pct  varchar(255) NULL,
    OwnerTaxIDLast4     varchar(255) NULL,	
	CorpTaxIDFingerprint varchar(255) NULL,
	OwnerTaxIDFingerprint varchar(255) NULL,
	EmailFingerprint        varchar(255) NULL    
FROM
    (
        SELECT 
            mcd.FDMSAccountNo,
            MAX(mcd.MRCH_STMT_MTH) MRCH_STMT_MTH
        FROM 
            BISME.MASSNFlat_MerchantControlData_RAA                     mcd 
            INNER JOIN BISME.MASSNFlat_MerchantAddressesDBA_RBB         dba ON (mcd.MRCH_STMT_MTH=dba.MRCH_STMT_MTH AND mcd.FDMSACCOUNTNO=dba.FDMSACCOUNTNO)
            -- SELECT * FROM BISME.MASSNFlat_MerchantAddressesDBA_RBB LIMIT 5000
            LEFT JOIN BISME.MASSNFlat_MerchantAddressesCorporate_RCC    cor ON (mcd.MRCH_STMT_MTH=cor.MRCH_STMT_MTH AND mcd.FDMSACCOUNTNO=cor.FDMSACCOUNTNO)
            -- SELECT * FROM BISME.MASSNFlat_MerchantAddressesCorporate_RCC LIMIT 5000
            -- SELECT * FROM BISME.MASSNFlat_BankEntitlement_RBE LIMIT 5000
        WHERE 
            mcd.Account_Status IN ('11','14','15','16')
            AND LTRIM(RTRIM(DBA_Name))!='' 
        GROUP BY 
            mcd.FDMSAccountNo
    ) aa
    INNER JOIN BISME.MASSNFlat_MerchantAddressesDBA_RBB bb ON (aa.FDMSAccountNo=bb.FDMSAccountNo AND aa.MRCH_STMT_MTH=bb.MRCH_STMT_MTH)
    --LEFT JOIN BISME.MASSNFlat_CardEntitlements_RII      cc ON (aa.FDMSAccountNo=cc.FDMSAccountNo AND aa.MRCH_STMT_MTH=cc.MRCH_STMT_MTH)
; 

;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE Platform!='TSS' LIMIT 5000

;

---== IRvine's BBVA merchants ==---
SELECT
    *
FROM
    BISME.MASSOFlat_ControlData_R10 cd
WHERE
    cd.SYSTEM_NO || '/' || cd.PRINCIPLE_BANK = '5378/4900'  ---Exclude System 5378 and PRIN 4900 because this data belongs to Irvine/Meritus and is being reported by them under separte cover.
    AND MERCHANT_TYPE='R'
    AND ACCOUNT_STATUS=''
    AND MRCH_STMT_MTH='01-SEP-2020'
;       
SELECT * FROM BISME.MASSOFlat_Miscellaneous_R40 LIMIT 500
;
SELECT * FROM BISME.MASSOFlat_Miscellaneous2_R42 LIMIT 500
;
SELECT
    ms.MerchStmtMth,	
    ms.MerchantNumber,	
    ms.BilledAmount,
    mm.Platform,
    mm.DBA,
    rc.HoustonAgentNumber,
    rc.HoustonAgentDesc,
    rc.HoustonLevel1Code    "TopParentCode",
    rc.HoustonLevel1Desc    "TopParentDesc",
    HoustonLevel2Code,	
    HoustonLevel2Desc,	
    HoustonLevel3Code,	
    HoustonLevel3Desc,	
    HoustonLevel4Code,	
    HoustonLevel4Desc,	
    HoustonLevel5Code,	
    HoustonLevel5Desc,	
    HoustonLevel6Code,	
    HoustonLevel6Desc,	
    HoustonLevel7Code,	
    HoustonLevel7Desc
FROM
    ppbisandbox.millikan_RevenueMerchantMonthlyStatement    ms
    LEFT JOIN ppbisandbox.millikan_MerchantDemographics           mm ON (ms.MerchantNumber=mm.MerchantNumber)
    LEFT JOIN BI.ReportingChannels                          rc ON (LEFT(ms.MerchantNumber,15)=LEFT(rc.MerchantNumber,15))
WHERE
    ms.MerchStmtMth='9/1/2020'
    --AND rc.HoustonLevel1Code='1877'
    AND LEFT(ms.MerchantNumber,9)='422899490'  --4228994900099997
    --AND ms.BilledAmount!=0
;
SELECT * FROM BI.ReportingChannels WHERE LEFT(ms.MerchantNumber,9)='422899490' 
IF OBJECT_ID('tempdb..#BillingPlanLastKnownGoodDate', 'U') IS NOT NULL DROP TABLE #BillingPlanLastKnownGoodDate
SELECT
    bcs.[Account No    MerchantNumber,
    MAX(RptDate)        RptDate
INTO
    #BillingPlanLastKnownGoodDate
FROM
    FDR_MASS_TEST.dbo.[FDR Billing - Card Specific bcs (NOLOCK)
    ---[Execution: 3m 41s] using the INNER JOIN
    --INNER JOIN #BillingPlanNeedsUpdating            bon ON (bcs.[Account No]=CAST(bon.MerchantNumber AS VARCHAR(16)))
WHERE
    bcs.RptDate>='01-JAN-2016'
    AND [Card Type]='00001'
    AND Debit_Credit_Ind='C'
    AND ISNULL(bcs.Interchange_Income_Flag,'')!=''
    ---[Execution: 3m 21s] using the subquery
    AND bcs.[Account No] IN (SELECT * FROM #BillingPlanNeedsUpdating)
GROUP BY
    bcs.[Account No]
CREATE UNIQUE CLUSTERED INDEX PK ON #BillingPlanLastKnownGoodDate (MerchantNumber)

IF OBJECT_ID('tempdb..#BillingPlan', 'U') IS NOT NULL DROP TABLE #BillingPlan
SELECT
    bcs.[Account No]                                    "MerchantNumber",
    CASE 
        WHEN bcs.Interchange_Income_Flag IN ('1','2','4','5') THEN 'CostPlus'
        WHEN bcs.Interchange_Income_Flag IN ('0') AND [Straight Disc Rate]!=[Non Qual Rate] AND [Non Qual Rate]!=0 THEN 'Tiered'
        WHEN bcs.Interchange_Income_Flag IN ('0') AND [Straight Disc Rate]=[Non Qual Rate] THEN 'FlatRate'
        WHEN bcs.Interchange_Income_Flag IN ('3') THEN 'ERR'
        ELSE '?'
    END                                                 BillingProgram
INTO
    #BillingPlan
FROM
    FDR_MASS_TEST.dbo.[FDR Billing - Card Specific] bcs (NOLOCK)
    INNER JOIN #BillingPlanLastKnownGoodDate                     bpl ON (bcs.RptDate=bpl.RptDate AND bcs.[Account No]=bpl.MerchantNumber)
WHERE
    bcs.RptDate>='01-JAN-2016'
    AND [Card Type]='00001'
    AND Debit_Credit_Ind='C'
    AND ISNULL(bcs.Interchange_Income_Flag,'')!=''
CREATE UNIQUE CLUSTERED INDEX PK ON #BillingPlan (MerchantNumber)
;
SELECT
    aa.MerchantNumber,
    rc.*
FROM    
    (
    SELECT
        DISTINCT cd.ACCOUNT_NO   MerchantNumber
    FROM
        BISME.MASSOFlat_ControlData_R10                 cd
        INNER JOIN BI.ReportingChannels                 rc ON (LEFT(cd.ACCOUNT_NO,15)=LEFT(rc.MerchantNumber,15))
    WHERE
        cd.MERCHANT_TYPE='H'
    ) aa LEFT JOIN  BI.ReportingChannels                 rc ON (LEFT(aa.MerchantNumber,15)=LEFT(rc.MerchantNumber,15))
;
SELECT * FROM BISME.SupplementalMIF_ApplicationRecord_Internal WHERE MERCHANT_SEQUENCE='4228997724139691' AND UNITYFILEDATE='11/4/2020 3:30:00 AM' LIMIT 500 
;
SELECT 
    DATE_CLOSED,
    DATE_OPEN,
    MERCHANT_TYPE,
    aa.*
FROM 
    BISME.SupplementalMIF_ApplicationRecord_Internal aa
    INNER JOIN 
    (   
        SELECT 
            MAX(UNITYFILEDATE) UNITYFILEDATE 
        FROM 
            BISME.SupplementalMIF_ApplicationRecord_Internal 
    ) bb ON (aa.UNITYFILEDATE=bb.UNITYFILEDATE)
WHERE
   MERCHANT_SEQUENCE='4228997700442689'
   --MERCHANT_TYPE NOT IN ('','R')
LIMIT 500
;      
SELECT ACCOUNT_NUMBER,* FROM BISME.MD032_Omaha WHERE ACCOUNT_NUMBER='4228997700442689'
;
SELECT MERCHANTNUMBERSPACEREMOVED,* FROM BISME.MD033_Omaha WHERE MERCHANTNUMBERSPACEREMOVED='4228997700442689'
;
MRCH_TYPE
SELECT MRCH_TYPE,* FROM BISME.MD033_Omaha WHERE MERCHANTNUMBERSPACEREMOVED='4228997700442689'
;
SELECT * FROM BISME.FF152_Omaha ff152
INNER JOIN (
SELECT
    DISTINCT 
    cd.ACCOUNT_NO   MerchantNumber,
    mm.DATE_OPEN
FROM
    BISME.MASSOFlat_ControlData_R10                 cd
    INNER JOIN BISME.MASSOFlat_Miscellaneous_R40    mm  ON (cd.MRCH_STMT_MTH=mm.MRCH_STMT_MTH AND cd.ACCOUNT_NO=mm.ACCOUNT_NO)
    --INNER JOIN BI.ReportingChannels                 rc ON (LEFT(cd.ACCOUNT_NO,15)=LEFT(rc.MerchantNumber,15))
WHERE
    cd.MERCHANT_TYPE!='R'
    ) aa ON (LEFT(ff152.MRCH_NO,15)=LEFT(aa.MerchantNumber,15))
;
    SELECT DATE_OPEN, * FROM BISME.MASSOFlat_Miscellaneous_R40 ORDER BY DATE_OPEN ASC LIMIT 1000
; 