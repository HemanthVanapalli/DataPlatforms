/*
  CHANGE LOG v0.7.2 (v0.7 was inital release)
  + v0.7.1 is Pradeep Dyapa's changes.
  + Removed lines 118 thru 167 and replaced with below lines X thru Y 
*/
CREATE TABLE ppbisandbox.millikan_MerchantDemographics ( 
	MerchantNumber    	varchar(255) NOT NULL,
	BillingProgram    	varchar(255) NULL,
	isOpen            	tinyint NULL,
	OpenDate        	date NULL,
	CloseDate        	date NULL,	
	SponsorBank       	varchar(255) NULL, -- Grab the column [SponsorBank] out of ppbisandbox.ProcessorBankMatrix table.
    ClearingPlatform    varchar(255) NULL, 
	DBA               	varchar(255) NULL,
	DiscountMethod      varchar(255) NULL,
	OpenYearMonth   	date NULL,
	CloseYearMonth   	date NULL,
	hasBillingOrVolume  varchar(1) NULL,
	--hasEcommerceVol     tinyint NULL,         --Will add this column in later	
	isNonProfit         varchar(1) NULL,
	MCC               	varchar(4) NULL,	
	CloseCode         	varchar(255) NULL,
	--CloseDescription  	varchar(255) NULL,  --Will add this column in later
	--isPremier     	    tinyint NULL,       --Will add this column in later
	--PremierRep     	    varchar(255) NULL,  --Will add this column in later
	LocationAddressPart varchar(255) NULL,
    LocationCity        varchar(255) NULL,
    LocationState       varchar(255) NULL,
    LocationZIP         varchar(255) NULL,  
    LocationCountry     varchar(255) NULL,  
    LocationPhoneLast4  varchar(255) NULL,	
	OwnerNameLast25Pct  varchar(255) NULL,
	EmailFirst25Pct     varchar(255) NULL,
    CorpTaxIDLast25Pct  varchar(255) NULL,
    OwnerTaxIDLast4     varchar(255) NULL,	
    LegalBusinessName   varchar(255) NULL,	
	CorpTaxIDFingerprint varchar(255) NULL,
	OwnerTaxIDFingerprint varchar(255) NULL,
	EmailFingerprint    varchar(255) NULL
)
;
ALTER TABLE ppbisandbox.millikan_MerchantDemographics ADD UNIQUE(MerchantNumber)
;
ALTER TABLE ppbisandbox.millikan_MerchantDemographics ALTER CONSTRAINT C_UNIQUE ENABLED
;
GRANT SELECT ON ppbisandbox.millikan_MerchantDemographics TO verticappbisandbox
;	
-- Put all known "real" Merchant Numbers into the table. By "real" we mean...
-- 1. We have some kind of actual information from the Processor confirming they are actually setup in the Processor's system.
-- 2. The merchant has been billed some non-zero amount OR
-- 3. The merchant has sales or returns volume (from any card scheme).
-- Merchants reported by the BU in the daily MIF, but for which we have no confirmation on (yet) from the Processor, are not
-- "real" merchants (yet).
-- BTW, can test if Omaha MID is Luhn10 compliant here: https://www.mymathtables.com/numbers/luhn-algorithm-calculator.html
-- And can generate the merchant's 16th check digit (using the first 15 digits as input) at the link here: https://planetcalc.com/2464/
-- TRUNCATE TABLE ppbisandbox.millikan_MerchantDemographics
;
INSERT INTO 
    ppbisandbox.millikan_MerchantDemographics (MerchantNumber,ClearingPlatform,hasBillingOrVolume)
SELECT 
    MerchantNumber,
    ClearingPlatform,
    hasBillingOrVolume
FROM 
    (
        (
            ---== Omaha platform billing and volume ==---
            SELECT
                cd.ACCOUNT_NO   MerchantNumber, 
                'Omaha'         ClearingPlatform,
                MAX(
                    CASE 
                        WHEN pp.RMH_MTH_INC_TOTAL_CHARGE<>0 THEN 1
                        WHEN fh.OFFUS_SALES_TRN<>0          THEN 1
                        WHEN fh.OFFUS_RTRNS_TRN<>0          THEN 1
                        ELSE 0
                    END
                )               hasBillingOrVolume
            FROM
                BISME.MASSOFlat_ControlData_R10                 cd
                INNER JOIN BISME.MASSOFlat_Profitability_R02    pp ON (cd.MRCH_STMT_MTH=pp.MRCH_STMT_MTH AND cd.ACCOUNT_NO=pp.ACCOUNT_NO)
                INNER JOIN BISME.MASSOFlat_FinancialHistory_R01 fh  ON (cd.MRCH_STMT_MTH=fh.MRCH_STMT_MTH AND cd.ACCOUNT_NO=fh.ACCOUNT_NO)
                INNER JOIN BI.ReportingChannels                 rc ON (LEFT(cd.ACCOUNT_NO,15)=LEFT(rc.MerchantNumber,15))
            WHERE
                cd.MERCHANT_TYPE='R'
                AND (pp.RMH_MTH_INC_TOTAL_CHARGE<>0 OR fh.OFFUS_SALES_TRN<>0 OR fh.OFFUS_RTRNS_TRN<>0 OR cd.ACCOUNT_STATUS!='C')
                --AND cd.ACCOUNT_NO='4228997200003353'
            GROUP BY
                cd.ACCOUNT_NO 
        ) UNION (       
            ---== North platform billing and volume ==---
            SELECT
                DISTINCT 
                aa.FDMSACCOUNTNO    MerchantNumber, 
                'North'             ClearingPlatform,
                 1                  hasBillingOrVolume
            FROM
                BISME.MASSNFlat_Link_RO1                        aa
                LEFT JOIN (
                        SELECT 
                            DISTINCT HST_MERCHNUM 
                        FROM 
                            BISME.MASSNFlat_FinancialHistory_RF1 
                        WHERE 
                            HST_SALES_TRAN<>0 
                            OR HST_RETURNS_TRAN<>0
                ) fh ON (aa.FDMSACCOUNTNOFIRST9=fh.HST_MERCHNUM)
                LEFT JOIN (
                        SELECT 
                            DISTINCT FDMSACCOUNTNO 
                        FROM 
                            BISME.MASSNFlat_FeeHistory_RFH 
                        WHERE 
                            RETAIL_AMOUNT<>0
                ) nfh ON (aa.FDMSACCOUNTNO=nfh.FDMSACCOUNTNO)
                INNER JOIN BI.ReportingChannels rc  ON (aa.FDMSACCOUNTNO=rc.MerchantNumber)                      
            WHERE
                nfh.FDMSACCOUNTNO  IS NOT NULL 
                OR fh.HST_MERCHNUM IS NOT NULL 
        ) UNION (  
            ---== TSYS merchants with processing/billing activity: sales or merchandise returns or *authorizations/declines* or billing ==---
             SELECT 
                DISTINCT 
                MERCHANT_ID     MerchantNumber, 
                'TSYS'          ClearingPlatform,
                1               hasBillingOrVolume
            FROM 
                BISME.PPMProfitabilityTotalsMonthly_TSYS    ptm   
                INNER JOIN BI.ReportingChannels             rc ON (ptm.MERCHANT_ID=rc.MerchantNumber)    
            WHERE 
                INCOME <> 0 OR AMOUNT_OF_SALES <> 0 OR AMOUNT_OF_CREDITS <> 0
        ) UNION (
            ---== TSYS Billing ==---
            SELECT 
                DISTINCT MERCHANT_ID    MerchantNumber, 
                'TSYS'                  ClearingPlatform,
                1                       hasBillingOrVolume
            FROM 
                BISME.PPMFeeItemTotalsMonthly_TSYS  fit  
                INNER JOIN BI.ReportingChannels     rc ON (fit.MERCHANT_ID=rc.MerchantNumber)
            WHERE 
                INCOME <> 0           
        )
    ) aa   
WHERE NOT EXISTS 
    (
        SELECT 
            MerchantNumber  
        FROM 
            ppbisandbox.millikan_MerchantDemographics mm
        WHERE
            mm.MerchantNumber = aa.MerchantNumber
    )
;
---== Sponsor Bank ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    SponsorBank  = B.SponsorBank
FROM 
    (
        SELECT 
            md.MerchantNumber,
            pbm.SponsorBank
        FROM
            ppbisandbox.millikan_MerchantDemographics   md
            INNER JOIN BI_DIMENSION.ProcessorBankMatrix pbm ON (LEFT(md.MerchantNumber,pbm.MerchantNumberPrefixLength)=pbm.MerchantNumberPrefix)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== START OMAHA PLATFORM ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                     = B.DBA,
    --MCC                     = B.MCC,
    --OpenedYearMonth         = B.OpenedYearMonth,
    LocationAddressPart     = B.LocationAddressPart,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationZIP             = B.LocationZIP,
    LocationCountry         = B.LocationCountry,
    LocationPhoneLast4      = B.LocationPhoneLast4,    
    OwnerNameLast25Pct      = B.OwnerNameLast25Pct,
    LegalBusinessName       = B.LegalBusinessName,
    --OpenedDate              = B.OpenedDate,
    DiscountMethod          = B.DiscountMethod,
    isNonProfit             = B.isNonProfit,
    EmailFirst25Pct         = B.EmailFirst25Pct,
    OwnerTaxIDLast4         = B.OwnerTaxIDLast4,
    CorpTaxIDLast25Pct      = B.CorpTaxIDLast25Pct,
    CorpTaxIDFingerprint    = B.CorpTaxIDFingerprint,
    OwnerTaxIDFingerprint   = B.OwnerTaxIDFingerprint,
    EmailFingerprint        = B.EmailFingerprint,
    ClearingPlatform        = 'Omaha'   
FROM 
    (    
    SELECT 
        cd.ACCOUNT_NO                                                   MerchantNumber,
        CONCAT(ad.DBA_NAME24,ad.DBA_NAME6)                              DBA,
        COALESCE(ad.DBAADDRESSONE24FIRST50PCT, ac.CORPADDRESSONE24FIRST50PCT)               LocationAddressPart,
        COALESCE(CONCAT(ad.DBA_CITY21,ad.DBA_CITY11),CONCAT(ac.CORP_CITY21,ac.CORP_CITY11)) LocationCity,
        COALESCE(ad.DBA_STATE,ac.CORP_STATE)                            LocationState,
        COALESCE(ad.DBA_ZIP5,ac.CORP_ZIP5)                              LocationZIP,  
        CASE WHEN NVL(ad.DBA_COUNTRY_CODE,'US')='US' OR ac.CORP_COUNTRY_CODE='USA' THEN 'USA' ELSE ad.DBA_COUNTRY_CODE END LocationCountry,  
        ad.TELEPHONENOLAST4                                             LocationPhoneLast4, 
        COALESCE(ad.LEGL_BSNS_NM, CONCAT(ac.CORP_NAME24,ac.CORP_NAME6)) LegalBusinessName,
        COALESCE(ad.SOLEPROPRIETORNAMELAST25PCT)                        OwnerNameLast25Pct,
        mm.EMAILFIRST25PCT      EmailFirst25Pct,
        mm.TAXPAYERIDLAST25PCT  CorpTaxIDLast25Pct,
        mm.TAXPAYERIDLAST25PCT  OwnerTaxIDLast4,
        m2."501C_TAX_EXMP_CD"   isNonProfit, --Must enclose this source column name with quotes because column names cannot start with a number
        CASE WHEN bcs.DISCOUNT_METHOD='0006' THEN 'Daily' WHEN bcs.DISCOUNT_METHOD='0001' THEN 'MonthEnd' ELSE 'Other' END DiscountMethod,  
        --CASE WHEN CAST(NVL(cd.CLOSED_REASON_CODE,0) AS BIGINT)!=0 THEN cd.CLOSED_REASON_CODE ELSE NULL END CloseCode
        --CloseDescription  	varchar(255) NULL,	  	
        mm.TAXPAYER_ID          CorpTaxIDFingerprint,
        mm.TAXPAYER_ID          OwnerTaxIDFingerprint,
        mm.EMAIL                EmailFingerprint
    FROM 
        BISME.MASSOFlat_ControlData_R10                     cd  
        LEFT JOIN BISME.MASSOFlat_AddressDBA_R20            ad ON (cd.MRCH_STMT_MTH=ad.MRCH_STMT_MTH AND cd.ACCOUNT_NO=ad.ACCOUNT_NO)
        LEFT JOIN BISME.MASSOFlat_AddressCorp_R25           ac ON (cd.MRCH_STMT_MTH=ac.MRCH_STMT_MTH AND cd.ACCOUNT_NO=ac.ACCOUNT_NO)
        LEFT JOIN BISME.MASSOFlat_Miscellaneous_R40         mm ON (cd.MRCH_STMT_MTH=mm.MRCH_STMT_MTH AND cd.ACCOUNT_NO=mm.ACCOUNT_NO)
        LEFT JOIN BISME.MASSOFlat_Miscellaneous2_R42        m2 ON (cd.MRCH_STMT_MTH=m2.MRCH_STMT_MTH AND cd.ACCOUNT_NO=m2.ACCOUNT_NO)
        LEFT JOIN BISME.MASSOFlat_BillingCardSpecific_R50  bcs ON (cd.MRCH_STMT_MTH=bcs.MRCH_STMT_MTH AND cd.ACCOUNT_NO=bcs.ACCOUNT_NO AND bcs.CARD_TYPE='00001' AND bcs.DEBIT_CREDIT_IND='C')
        INNER JOIN (
            SELECT 
                cd.ACCOUNT_NO, 
                MAX(cd.MRCH_STMT_MTH)  MRCH_STMT_MTH 
            FROM 
                BISME.MASSOFlat_ControlData_R10                 cd
                INNER JOIN BISME.MASSOFlat_Profitability_R02    pp ON (cd.MRCH_STMT_MTH=pp.MRCH_STMT_MTH AND cd.ACCOUNT_NO=pp.ACCOUNT_NO)
                INNER JOIN BISME.MASSOFlat_FinancialHistory_R01 fh  ON (cd.MRCH_STMT_MTH=fh.MRCH_STMT_MTH AND cd.ACCOUNT_NO=fh.ACCOUNT_NO)
            WHERE
                cd.MERCHANT_TYPE='R'
                AND (pp.RMH_MTH_INC_TOTAL_CHARGE<>0 OR fh.OFFUS_SALES_TRN<>0 OR fh.OFFUS_RTRNS_TRN<>0 OR cd.ACCOUNT_STATUS!='C')                
            GROUP BY
                cd.ACCOUNT_NO
        )   aa ON (cd.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND cd.ACCOUNT_NO=aa.ACCOUNT_NO)
    WHERE
        cd.MERCHANT_TYPE='R'
        --AND cd.ACCOUNT_NO='4223690201000015' 
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== OMAHA: Billing program 1 of 3 (happy path, uses the billing program from the MasterCard traditional credit card setup) ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = B.BillingProgram
FROM 
    (
        SELECT
            bcs.ACCOUNT_NO  "MerchantNumber",
            CASE 
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('1','2','4','5') THEN 'CostPlus'
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('0') AND bcs.STRAIGHT_DISC_RATE!=bcs.NON_QUAL_RATE AND bcs.NON_QUAL_RATE!=0 THEN 'Tiered'
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('0') AND bcs.STRAIGHT_DISC_RATE=bcs.NON_QUAL_RATE THEN 'FlatRate'
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('3') THEN 'ERR'
                ELSE NULL
            END             "BillingProgram"
        FROM
            BISME.MASSOFlat_BillingCardSpecific_R50 bcs
            INNER JOIN (
                SELECT
                    bcs.ACCOUNT_NO          ACCOUNT_NO,
                    MAX(bcs.MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.MASSOFlat_BillingCardSpecific_R50 bcs
                WHERE
                    bcs.CARD_TYPE='00001'
                    AND bcs.DEBIT_CREDIT_IND='C'
                    AND ISNULL(bcs.INTERCHANGE_INCOME_FLAG,'')!=''    
                GROUP BY
                    bcs.ACCOUNT_NO
            ) bcs2 ON (bcs.ACCOUNT_NO=bcs2.ACCOUNT_NO AND bcs.MRCH_STMT_MTH=bcs2.MRCH_STMT_MTH)
        WHERE
            bcs.CARD_TYPE='00001'
            AND bcs.DEBIT_CREDIT_IND='C'
            AND ISNULL(bcs.INTERCHANGE_INCOME_FLAG,'')!=''
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== OMAHA: Billing program 2 of 3 (less happy path, uses the billing program from the Visa traditional credit card setup) ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = B.BillingProgram
FROM 
    (
        SELECT
            bcs.ACCOUNT_NO  "MerchantNumber",
            CASE 
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('1','2','4','5') THEN 'CostPlus'
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('0') AND bcs.STRAIGHT_DISC_RATE!=bcs.NON_QUAL_RATE AND bcs.NON_QUAL_RATE!=0 THEN 'Tiered'
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('0') AND bcs.STRAIGHT_DISC_RATE=bcs.NON_QUAL_RATE THEN 'FlatRate'
                WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('3') THEN 'ERR'
                ELSE NULL
            END             "BillingProgram"
        FROM
            BISME.MASSOFlat_BillingCardSpecific_R50 bcs
            INNER JOIN (
                SELECT
                    bcs.ACCOUNT_NO          ACCOUNT_NO,
                    MAX(bcs.MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.MASSOFlat_BillingCardSpecific_R50 bcs
                WHERE
                    bcs.CARD_TYPE='00004'
                    AND bcs.DEBIT_CREDIT_IND='C'
                    AND ISNULL(bcs.INTERCHANGE_INCOME_FLAG,'')!=''    
                GROUP BY
                    bcs.ACCOUNT_NO
            ) bcs2 ON (bcs.ACCOUNT_NO=bcs2.ACCOUNT_NO AND bcs.MRCH_STMT_MTH=bcs2.MRCH_STMT_MTH)
        WHERE
            bcs.CARD_TYPE='00004'
            AND bcs.DEBIT_CREDIT_IND='C'
            AND ISNULL(bcs.INTERCHANGE_INCOME_FLAG,'')!=''
            AND bcs.ACCOUNT_NO IN (SELECT MerchantNumber FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='Omaha' AND BillingProgram IS NULL)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== OMAHA: Billing program 3 of 3 (catch all: uses whatever billing program we can find, somewhat at random due to use of MAX() function) ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = B.BillingProgram
FROM 
    (
        SELECT
            bcs.ACCOUNT_NO  "MerchantNumber",
            MAX(
                CASE 
                    WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('1','2','4','5') THEN 'CostPlus'
                    WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('0') AND bcs.STRAIGHT_DISC_RATE!=bcs.NON_QUAL_RATE AND bcs.NON_QUAL_RATE!=0 THEN 'Tiered'
                    WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('0') AND bcs.STRAIGHT_DISC_RATE=bcs.NON_QUAL_RATE THEN 'FlatRate'
                    WHEN bcs.INTERCHANGE_INCOME_FLAG IN ('3') THEN 'ERR'
                    ELSE NULL
                END
            )             "BillingProgram"
        FROM
            BISME.MASSOFlat_BillingCardSpecific_R50 bcs
            INNER JOIN (
                SELECT
                    bcs.ACCOUNT_NO          ACCOUNT_NO,
                    MAX(bcs.MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.MASSOFlat_BillingCardSpecific_R50 bcs
                WHERE
                    ISNULL(bcs.INTERCHANGE_INCOME_FLAG,'')!=''    
                GROUP BY
                    bcs.ACCOUNT_NO
            ) bcs2 ON (bcs.ACCOUNT_NO=bcs2.ACCOUNT_NO AND bcs.MRCH_STMT_MTH=bcs2.MRCH_STMT_MTH)
        WHERE
            ISNULL(bcs.INTERCHANGE_INCOME_FLAG,'')!=''
            AND bcs.ACCOUNT_NO IN (SELECT MerchantNumber FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='Omaha' AND BillingProgram IS NULL)
        GROUP BY
            bcs.ACCOUNT_NO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== OMAHA: MCC 1 of 2 (happy path, uses the billing program from the MasterCard traditional credit card setup) ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    MCC  = B.MCC
FROM 
    (
        SELECT
            bcs.ACCOUNT_NO              "MerchantNumber",
            bcs.BUSINESS_CATEGORY_CODE  "MCC"
        FROM
            BISME.MASSOFlat_BillingCardSpecific_R50 bcs
            INNER JOIN (
                SELECT
                    bcs.ACCOUNT_NO          ACCOUNT_NO,
                    MAX(bcs.MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.MASSOFlat_BillingCardSpecific_R50 bcs
                WHERE
                    bcs.CARD_TYPE='00001'
                    AND bcs.DEBIT_CREDIT_IND='C'
                    AND ISNULL(bcs.BUSINESS_CATEGORY_CODE,'')!=''   
                GROUP BY
                    bcs.ACCOUNT_NO
            ) bcs2 ON (bcs.ACCOUNT_NO=bcs2.ACCOUNT_NO AND bcs.MRCH_STMT_MTH=bcs2.MRCH_STMT_MTH)
        WHERE
            bcs.CARD_TYPE='00001'
            AND bcs.DEBIT_CREDIT_IND='C'
            AND ISNULL(bcs.BUSINESS_CATEGORY_CODE,'')!='' 
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;
---== OMAHA: MCC 2 of 2 (catch all, uses whatever we've got) ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    MCC  = B.MCC
FROM 
    (
        SELECT  
            bcs.ACCOUNT_NO                  "MerchantNumber",
            MAX(bcs.BUSINESS_CATEGORY_CODE) "MCC"  -- Not best practice to MAX() this.  Sometimes you win, sometimes you lose.
        FROM
            BISME.MASSOFlat_BillingCardSpecific_R50 bcs
            INNER JOIN (
                SELECT
                    bcs.ACCOUNT_NO          ACCOUNT_NO,
                    MAX(bcs.MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.MASSOFlat_BillingCardSpecific_R50 bcs
                WHERE
                    ISNULL(bcs.BUSINESS_CATEGORY_CODE,'')!=''   
                GROUP BY
                    bcs.ACCOUNT_NO
            ) bcs2 ON (bcs.ACCOUNT_NO=bcs2.ACCOUNT_NO AND bcs.MRCH_STMT_MTH=bcs2.MRCH_STMT_MTH)
        WHERE
            ISNULL(bcs.BUSINESS_CATEGORY_CODE,'')!=''
            AND bcs.ACCOUNT_NO IN (SELECT MerchantNumber FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='Omaha' AND MCC IS NULL)
        GROUP BY
            bcs.ACCOUNT_NO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
;

/*
---== OMAHA: Open Date: A couple of assumptions here:
-- +  We're assuming the first reported open date is the best open date to use but there could be 2 edge cases where this is not true:
-- 1. Edge case is a merchant who was closed, then re-opened.  Do we use their inital open date (before they closed) or their
--    re-open date?  The Processor continues to report the merchant's first open date even if the merhcant clsoed, then re-opened.
-- 2. The first reported open date was incorrect (for whatever reason) and in more recent months, the open date was fixed.  
--    This is very unlikely to happen (it hasn't ever in the last 18 months) but it could.
*/
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    OpenDate       = B.DATE_OPEN, 
    OpenYearMonth  = TO_DATE(TO_CHAR(B.DATE_OPEN,'YYYY-Mon-01'),'YYYY-Mon-DD')
FROM 
    (
        SELECT 
            md.MerchantNumber,
            mi.DATE_OPEN 
        FROM 
            ppbisandbox.millikan_MerchantDemographics       md
            INNER JOIN BISME.MASSOFlat_Miscellaneous_R40    mi ON (md.MerchantNumber=mi.ACCOUNT_NO)
            INNER JOIN (
                SELECT 
                    ACCOUNT_NO, 
                    MIN(MRCH_STMT_MTH) "MRCH_STMT_MTH" 
                FROM 
                    BISME.MASSOFlat_Miscellaneous_R40 
                GROUP BY 
                    ACCOUNT_NO
            ) aa ON (mi.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND mi.ACCOUNT_NO=aa.ACCOUNT_NO)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;
/*
---== OMAHA: Close Date: A couple of things here:
-- +  A merhcant can be closed and re-opened, multiple times, for example see this:
--    SELECT MRCH_STMT_MTH, DATE_OPEN, REOPEN_DATE, DATE_CLOSED, * FROM BISME.MASSOFlat_Miscellaneous_R40 WHERE ACCOUNT_NO='4223699300017119' ORDER BY MRCH_STMT_MTH
-- + So we look at the most recent data we have for a merchant: If the merchant is reported as closed, then that's the close date we use.
     If the next month, they are reported as open, then we remove the close date.  If they close (again), then we use that new (more recent) close date.
*/
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    CloseDate       = B.DATE_CLOSED,
    CloseYearMonth  = TO_DATE(TO_CHAR(B.DATE_CLOSED,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode       = CASE WHEN B.CLOSED_REASON_CODE='000' THEN NULL ELSE B.CLOSED_REASON_CODE END
FROM 
    (
        SELECT 
            cd.ACCOUNT_NO "MerchantNumber",
            mi.DATE_OPEN,
            mi.REOPEN_DATE,
            mi.DATE_CLOSED,
            cd.CLOSED_REASON_CODE
        FROM 
            BISME.MASSOFlat_ControlData_R10                 cd
            INNER JOIN BISME.MASSOFlat_Miscellaneous_R40    mi ON (cd.MRCH_STMT_MTH=mi.MRCH_STMT_MTH AND cd.ACCOUNT_NO=mi.ACCOUNT_NO) 
            INNER JOIN (
                SELECT
                    cd.ACCOUNT_NO,
                    MAX(cd.MRCH_STMT_MTH)   MRCH_STMT_MTH
                FROM
                    BISME.MASSOFlat_ControlData_R10  cd
                GROUP BY
                    cd.ACCOUNT_NO
            ) aa ON (cd.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND cd.ACCOUNT_NO=aa.ACCOUNT_NO)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;
UPDATE ppbisandbox.millikan_MerchantDemographics SET isOpen=1 WHERE OpenDate IS NOT NULL AND CloseDate IS NULL AND ClearingPlatform='Omaha'
;
UPDATE ppbisandbox.millikan_MerchantDemographics SET isOpen=0 WHERE OpenDate IS NOT NULL AND CloseDate IS NOT NULL AND ClearingPlatform='Omaha'
;
---== END OMAHA PLATFORM ==---
;
---== START NORTH PLATFORM ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                         = B.DBA,
    LocationAddressPart         = B.LocationAddressPart,
    LocationCity                = B.LocationCity,
    LocationState               = B.LocationState,
    LocationZIP                 = B.LocationZIP,
    LocationCountry             = B.LocationCountry,
    LocationPhoneLast4          = B.LocationPhoneLast4,
    EmailFirst25Pct             = B.EmailFirst25Pct,
    EmailFingerprint            = B.EmailFingerprint,
    LegalBusinessName           = B.LegalBusinessName,
    OwnerNameLast25Pct          = B.OwnerNameLast25Pct,
    
    CorpTaxIDFingerprint        = B.CorpTaxIDFingerprint,
    CorpTaxIDLast25Pct          = B.CorpTaxIDLast25Pct,
    
    OwnerTaxIDFingerprint       = B.OwnerTaxIDFingerprint,
    OwnerTaxIDLast4             = B.OwnerTaxIDLast4
FROM 
    (
        SELECT
            TRIM(bb.FDMSACCOUNTNO)      MerchantNumber, 
            bb.DBA_NAME                 DBA,
            bb.DBAADDRESS1FIRST25PCT    LocationAddressPart,
            bb.DBA_CITY                 LocationCity,
            bb.DBA_STATE                LocationState,
            bb.DBA_ZIP_FIRST5           LocationZIP,
            CASE WHEN bb.COUNTRY_CODE IN ('US','USA') THEN 'USA' ELSE bb.COUNTRY_CODE END LocationCountry,
            bb.DBAPHONELAST4            LocationPhoneLast4,
            cc.EMAILFIRST25PCT          EmailFirst25Pct,
            cc.EMAIL                    EmailFingerprint,
            dd.CORP_NAME                LegalBusinessName,
            dd.CORPCONTACTLAST25PCT     OwnerNameLast25Pct,
            
            ee.TAX_ID                   CorpTaxIDFingerprint,
            ee.TAXIDLAST25PCT           CorpTaxIDLast25Pct,
                
            ee.TAX_ID                   OwnerTaxIDFingerprint,
            ee.TAXIDLAST25PCT           OwnerTaxIDLast4
        FROM
            (
                SELECT 
                    FDMSACCOUNTNO,
                    MAX(MRCH_STMT_MTH) MRCH_STMT_MTH
                FROM 
                    BISME.MASSNFlat_MerchantAddressesDBA_RBB
                WHERE 
                    LTRIM(RTRIM(DBA_NAME))!='' 
                GROUP BY 
                    FDMSACCOUNTNO
            ) aa
            INNER JOIN BISME.MASSNFlat_MerchantAddressesDBA_RBB         bb ON (aa.FDMSACCOUNTNO=bb.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=bb.MRCH_STMT_MTH)
            LEFT JOIN BISME.MASSNFlat_MM2Other_RQQ                      cc ON (aa.FDMSACCOUNTNO=cc.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=cc.MRCH_STMT_MTH)
            LEFT JOIN BISME.MASSNFlat_MerchantAddressesCorporate_RCC    dd ON (aa.FDMSACCOUNTNO=dd.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=dd.MRCH_STMT_MTH)
            LEFT JOIN BISME.MASSNFlat_PhaseIIAdditionalInfo_RPP         ee ON (aa.FDMSACCOUNTNO=ee.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=ee.MRCH_STMT_MTH)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber   
;
---== NORTH: MCC - 1 of 2, happy path, use MasterCard card scheme and use the most recent month the account was open ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    MCC = B.MCC
FROM 
    (
        SELECT
            aa.FDMSACCOUNTNO                MerchantNumber,
            MAX(LPAD(MCCCODE,4,'0'))        MCC
        FROM
            (
                SELECT
                    cd.FDMSACCOUNTNO        FDMSACCOUNTNO,
                    MAX(cd.MRCH_STMT_MTH)   MRCH_STMT_MTH
                FROM
                    BISME.MASSNFlat_CardEntitlements_RII                ce 
                    INNER JOIN BISME.MASSNFlat_MerchantControlData_RAA  cd ON (ce.MRCH_STMT_MTH=cd.MRCH_STMT_MTH AND ce.FDMSACCOUNTNO=cd.FDMSACCOUNTNO)
                WHERE
                    cd.ACCOUNT_STATUS IN ('11','14','15','16')
                    AND ce.PRODUCT_CODE='01'
                    AND NVL(ce.MCCCODE,'0')>0 
                GROUP BY
                    cd.FDMSACCOUNTNO    
            ) aa
            INNER JOIN BISME.MASSNFlat_CardEntitlements_RII ce ON (aa.FDMSACCOUNTNO=ce.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=ce.MRCH_STMT_MTH)
        WHERE
            ce.PRODUCT_CODE='01'
        GROUP BY
            aa.FDMSACCOUNTNO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber               
;
---== NORTH: MCC - 2 of 2, catch all, use any card scheme and doens't matter if the accoutn is open or closed, just try to get something. ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    MCC = B.MCC
FROM 
    (
        SELECT
            aa.FDMSACCOUNTNO                MerchantNumber,
            MAX(LPAD(MCCCODE,4,'0'))        MCC
        FROM
            (
                SELECT
                    cd.FDMSACCOUNTNO        FDMSACCOUNTNO,
                    MAX(cd.MRCH_STMT_MTH)   MRCH_STMT_MTH
                FROM
                    BISME.MASSNFlat_CardEntitlements_RII                ce 
                    INNER JOIN BISME.MASSNFlat_MerchantControlData_RAA  cd ON (ce.MRCH_STMT_MTH=cd.MRCH_STMT_MTH AND ce.FDMSACCOUNTNO=cd.FDMSACCOUNTNO)
                WHERE
                    NVL(ce.MCCCODE,'0')>0 
                GROUP BY
                    cd.FDMSACCOUNTNO    
            ) aa
            INNER JOIN BISME.MASSNFlat_CardEntitlements_RII ce ON (aa.FDMSACCOUNTNO=ce.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=ce.MRCH_STMT_MTH)
        WHERE
            aa.FDMSACCOUNTNO IN (SELECT MerchantNumber FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='North' AND MCC IS NULL)
        GROUP BY
            aa.FDMSACCOUNTNO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber               
;
---== NORTH: isNonProfit 1 of 2 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isNonProfit = B.isNonProfit
FROM 
    (
        SELECT
            aa.FDMSACCOUNTNO        MerchantNumber,
            MAX(TAXEXEMPTIND)       isNonProfit
        FROM
            (
                SELECT
                    cd.FDMSACCOUNTNO        FDMSACCOUNTNO,
                    MAX(cd.MRCH_STMT_MTH)   MRCH_STMT_MTH
                FROM
                    BISME.MASSNFlat_MerchantControlData_RAA  cd 
                WHERE
                    cd.ACCOUNT_STATUS IN ('11','14','15','16')
                GROUP BY
                    cd.FDMSACCOUNTNO    
            ) aa
            INNER JOIN BISME.MASSNFlat_MerchantMembershipData_RDD mm ON (aa.FDMSACCOUNTNO=mm.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=mm.MRCH_STMT_MTH)
        WHERE
            TAXEXEMPTIND='Y'
        GROUP BY
            aa.FDMSACCOUNTNO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber 
;
---== NORTH: isNonProfit 2 of 2 ==---
--This isn't best practice to assume it's "N" if we can't identify it as a Y". Fix in later versions.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics 
SET 
    isNonProfit='N' 
WHERE 
    ClearingPlatform='North' 
    AND NVL(isNonProfit,'N')<>'Y'
;

---== NORTH: Open Date, 1 of 2, Uses only months  the merchant was reported as open to determine open date.  Seems like this is more reliable but not sure why.  ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    OpenDate        = B.OpenDate,
    OpenYearMonth   = TO_DATE(TO_CHAR(B.OpenDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    isOpen          = 1,
    CloseDate       = NULL, 
    CloseYearMonth  = NULL,
    CloseCode       = NULL
FROM 
    (
        SELECT
            cd.FDMSACCOUNTNO    MerchantNumber,
            MIN(
                CASE 
                    WHEN    
                        mmd.OPEN_DATE > '01-JAN-1980' 
                        THEN mmd.OPEN_DATE
                    WHEN 
                        ce.CONTRACTDATE > '01-JAN-1980' 
                        THEN ce.CONTRACTDATE
                    WHEN 
                        mmd.OPEN_DATE <='01-JAN-1980' 
                        AND mmd.FIRST_POST_DATE > '01-JAN-1980' 
                        THEN mmd.FIRST_POST_DATE
                    WHEN 
                        ce.LASTEDCDATE > '01-JAN-1980'
                        THEN ce.LASTEDCDATE
                    WHEN 
                        ce.SIGNEDVOLUMEDATE > '01-JAN-1980'
                        THEN ce.SIGNEDVOLUMEDATE
                    ELSE NULL
                END
            )   OpenDate
        FROM
            ppbisandbox.millikan_MerchantDemographics               md
            INNER JOIN BISME.MASSNFlat_MerchantControlData_RAA      cd  ON (md.MerchantNumber=cd.FDMSACCOUNTNO)
            LEFT JOIN BISME.MASSNFlat_CardEntitlements_RII          ce  ON (cd.MRCH_STMT_MTH=ce.MRCH_STMT_MTH  AND cd.FDMSACCOUNTNO=ce.FDMSACCOUNTNO)
            LEFT JOIN BISME.MASSNFlat_MerchantMembershipData_RDD    mmd ON (cd.MRCH_STMT_MTH=mmd.MRCH_STMT_MTH AND cd.FDMSACCOUNTNO=mmd.FDMSACCOUNTNO)
        WHERE
            /*
            Account Status Description
            01 Pending Credit Approval (MAI)
            02 Cancelled - Fraud Merchant
            03 Cancelled by Credit (MAI) - Never Approved
            11 Active - Settles Weekly on Friday
            13 Cancelled Merchant
            14 Active - Settles Last Friday of Month
            15 Active - Direct Payment Plan - See Pay Plan
            16 Active - Settles Last Calendar Day of Month
            */
            cd.ACCOUNT_STATUS IN ('11','14','15','16') 
            --AND cd.FDMSACCOUNTNO='497219587886'
        GROUP BY
            cd.FDMSACCOUNTNO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber             
; 
---== NORTH: Open Date, 2 of 2, for any remaining merchants we don't yet have open date, get open date from any reasonable place ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    OpenDate        = B.OpenDate,
    OpenYearMonth   = TO_DATE(TO_CHAR(B.OpenDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    isOpen          = 1,
    CloseDate       = NULL, 
    CloseYearMonth  = NULL,
    CloseCode       = NULL
FROM 
    (
        SELECT
            cd.FDMSACCOUNTNO    MerchantNumber,
            MIN(
                CASE 
                    WHEN    
                        mmd.OPEN_DATE > '01-JAN-1980' 
                        THEN mmd.OPEN_DATE
                    WHEN 
                        ce.CONTRACTDATE > '01-JAN-1980' 
                        THEN ce.CONTRACTDATE
                    WHEN 
                        mmd.OPEN_DATE <='01-JAN-1980' 
                        AND mmd.FIRST_POST_DATE > '01-JAN-1980' 
                        THEN mmd.FIRST_POST_DATE
                    WHEN 
                        ce.LASTEDCDATE > '01-JAN-1980'
                        THEN ce.LASTEDCDATE
                    WHEN 
                        ce.SIGNEDVOLUMEDATE > '01-JAN-1980'
                        THEN ce.SIGNEDVOLUMEDATE
                    ELSE NULL
                END
            )   OpenDate
        FROM
            ppbisandbox.millikan_MerchantDemographics               md
            INNER JOIN BISME.MASSNFlat_MerchantControlData_RAA      cd  ON (md.MerchantNumber=cd.FDMSACCOUNTNO)
            LEFT JOIN BISME.MASSNFlat_CardEntitlements_RII          ce  ON (cd.MRCH_STMT_MTH=ce.MRCH_STMT_MTH  AND cd.FDMSACCOUNTNO=ce.FDMSACCOUNTNO)
            LEFT JOIN BISME.MASSNFlat_MerchantMembershipData_RDD    mmd ON (cd.MRCH_STMT_MTH=mmd.MRCH_STMT_MTH AND cd.FDMSACCOUNTNO=mmd.FDMSACCOUNTNO)
        WHERE
            md.MerchantNumber IN (SELECT MerchantNumber FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='North' AND OpenDate IS NULL)
        GROUP BY
            cd.FDMSACCOUNTNO
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber             
;
---== NORTH: Close Date ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    isOpen          = CASE WHEN B.CloseDate IS NULL THEN 1 ELSE 0 END,
    CloseDate       = B.CloseDate,  
    CloseYearMonth  = TO_DATE(TO_CHAR(B.CloseDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode       = CASE WHEN B.CloseDate IS NULL THEN NULL ELSE 'TBD' END
FROM 
    (
        SELECT
            vmm.MerchantNumber,
            CASE
                WHEN mmd.CANCEL_DATE IS NOT NULL THEN
                    CASE
                        -- This is happy path, where the close date is after any billing or transaction activity.  
                        WHEN mmd.CANCEL_DATE >= NVL(ba.MrchStmtMth,'01-JAN-1901') AND mmd.CANCEL_DATE >= NVL(mra.MostRecentActivityDate,'01-JAN-1901') THEN mmd.CANCEL_DATE
                        
                        -- The cancel date is in the past, but they have activy since then.  This likely a re-open senerio plus data glitch (which happens) where 
                        -- the merchant was cancelled, start processing again, then dropped
                        -- off the books without a new close date being issued.  When this happens, 
                        -- we use the date of last activity (billing or transactional) as their close date.
                        WHEN mmd.CANCEL_DATE <= ld.MrchStmtMth AND (NVL(ba.MrchStmtMth,'01-JAN-1901') >= mmd.CANCEL_DATE OR NVL(mra.MostRecentActivityDate,'01-JAN-1901') >= mmd.CANCEL_DATE)
                            THEN CASE WHEN NVL(ba.MrchStmtMth,'01-JAN-1901') > NVL(mra.MostRecentActivityDate,'01-JAN-1901') THEN NVL(ba.MrchStmtMth,'01-JAN-1901') ELSE NVL(mra.MostRecentActivityDate,'01-JAN-1901') END
                            
                        -- If the merchant continues to process after the close date (including in the most recent month on file) then it's not closed.
                        WHEN mmd.CANCEL_DATE < NVL(mra.MostRecentActivityDate,'01-JAN-1901') AND NVL(TO_DATE(TO_CHAR(mra.MostRecentActivityDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),'01-JAN-1901') >= NVL(ld.MrchStmtMth,'01-JAN-1901')
                            THEN NULL --It's open.
                        ELSE '01-JAN-0001' --Catch errors
                    END
                    
                WHEN 
                    /*
                    Account Status Description
                    01 Pending Credit Approval (MAI)
                    02 Cancelled - Fraud Merchant
                    03 Cancelled by Credit (MAI) - Never Approved
                    11 Active - Settles Weekly on Friday
                    13 Cancelled Merchant
                    14 Active - Settles Last Friday of Month
                    15 Active - Direct Payment Plan - See Pay Plan
                    16 Active - Settles Last Calendar Day of Month
                    */
                    --If the latest report says it's closed, then use the generic report date as the closed date
                    cd.ACCOUNT_STATUS NOT IN ('11','14','15','16') 
                    AND ld.MrchStmtMth > CASE WHEN NVL(ba.MrchStmtMth,'01-JAN-1901') > NVL(mra.MostRecentActivityDate,'01-JAN-1901') THEN NVL(ba.MrchStmtMth,'01-JAN-1901') ELSE NVL(mra.MostRecentActivityDate,'01-JAN-1901') END
                        THEN vmm.MrchStmtMthMostRecent
                    
                -- If the latest report date is in the past, then it's no longer on the books, thus use last report date as closed date.
                WHEN ld.MrchStmtMth IS NULL THEN vmm.MrchStmtMthMostRecent
                -- Since the MID is on record, and there's no idication from First Data it's closed, must assume it's open.
                ELSE NULL
            END "CloseDate"             
        FROM    
            (
                --#RptDateMaxMin
                SELECT 
                    cd.FDMSACCOUNTNO        MerchantNumber,
                    MIN(cd.MRCH_STMT_MTH)   MrchStmtMthOldest,
                    MAX(cd.MRCH_STMT_MTH)   MrchStmtMthMostRecent           
                FROM  
                    BISME.MASSNFlat_MerchantControlData_RAA cd
                GROUP BY
                    cd.FDMSACCOUNTNO
            )                                                       vmm
            INNER JOIN BISME.MASSNFlat_MerchantControlData_RAA      cd  ON (vmm.MrchStmtMthMostRecent=cd.MRCH_STMT_MTH AND vmm.MerchantNumber=cd.FDMSACCOUNTNO)
            LEFT JOIN  (
                --#LastestMassCDRptDate
                SELECT MAX(MRCH_STMT_MTH) MrchStmtMth FROM BISME.MASSNFlat_MerchantControlData_RAA      cd
            )                                                       ld  ON (vmm.MrchStmtMthMostRecent=ld.MrchStmtMth)
            LEFT JOIN BISME.MASSNFlat_MerchantMembershipData_RDD    mmd ON (ld.MrchStmtMth=mmd.MRCH_STMT_MTH AND cd.FDMSACCOUNTNO=mmd.FDMSACCOUNTNO)    
            LEFT JOIN (
                --Most recent month with any merchant billing activity
                SELECT
                    fh.FDMSAccountNo        MerchantNumber,
                    MAX(fh.MRCH_STMT_MTH)   MrchStmtMth
                FROM
                    BISME.MASSNFlat_FeeHistory_RFH  fh
                WHERE
                    fh.BUCKET_NUMBER='002' -- 002 = Current month, if BUCKET_NUMBER = 003 then it's "last month" and  004 is the month before that. Every month we receive the past few months of data (again).
                    AND fh.RETAIL_AMOUNT<>0
                GROUP BY
                    fh.FDMSAccountNo    
            )                                                       ba  ON (vmm.MerchantNumber=ba.MerchantNumber)
            LEFT JOIN (
                ---== Determine if the merchant is still processing, if they are, they can't be closed ==---
                SELECT
                    aa.MerchantNumber,
                    MAX(aa.MostRecentActivityDate)  MostRecentActivityDate
                FROM
                    (
                        (
                            SELECT 
                                cdf.LOCATION_ID                     MerchantNumber,
                                MAX(CLEARINGDATEREFERENCENUMBER)    MostRecentActivityDate --ClearingDate
                            FROM 
                                BISME.DFM_CreditDetailFunded003_North       cdf
                            WHERE
                                TRANSACTION_STATUS <> 'R'
                            GROUP BY
                                cdf.LOCATION_ID
                        ) UNION ALL (   
                            SELECT 
                                LOCATION_ID                         MerchantNumber,
                                MAX(AUTH_DATE)                      MostRecentActivityDate --AuthDate
                            FROM 
                                BISME.DFM_AuthorizationDetails021_North ad
                            GROUP BY
                                LOCATION_ID
                        )     
                    ) aa
                GROUP BY
                    aa.MerchantNumber    
            )                                                       mra ON (vmm.MerchantNumber=mra.MerchantNumber)
--        WHERE
--            vmm.MerchantNumber='296201565888'
    ) B
WHERE
    A.MerchantNumber = B.MerchantNumber     
;    
---== NORTH: Discount Method ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DiscountMethod  = B.DiscountMethod
FROM 
    (
        SELECT
            md.MerchantNumber,
            CASE 
                WHEN daily.FDMSACCOUNTNO    IS NOT NULL THEN 'Daily'  
                WHEN monthly.FDMSACCOUNTNO  IS NOT NULL THEN 'MonthEnd'
                ELSE 'Other'
            END DiscountMethod
        FROM
            ppbisandbox.millikan_MerchantDemographics   md
            LEFT JOIN (
                SELECT
                    DISTINCT
                    bf.FDMSACCOUNTNO
                FROM
                    BISME.MASSNFlat_BillingFees_RMM     bf
                    INNER JOIN (
                        SELECT 
                            bf.FDMSACCOUNTNO        FDMSACCOUNTNO,
                            MAX(bf.MRCH_STMT_MTH)   MRCH_STMT_MTH
                        FROM 
                            BISME.MASSNFlat_BillingFees_RMM                         bf 
                            --LEFT JOIN BISME.MASSNFlat_DescFeeOrRateDescription_RAB  rd ON (bf.MRCH_STMT_MTH=rd.MRCH_STMT_MTH AND bf.FEE_SEQUENCE=rd.SEQUENCE AND bf.TYPE=rd.RECORD_ID) --11G
                        WHERE
                            bf.FEE_RETAIL_AMT_NEW > 0
                            AND bf.FEE_RETAIL_AMT_NEW < 0.0400  --Want low billing rate items like discount fees which are more likely to be passed daily
                            AND ASCII(FEE_FREQUENCY_IND) IS NOT NULL
                            --AND FDMSACCOUNTNO ='000000114991'
                        GROUP BY
                            bf.FDMSACCOUNTNO    
                    ) aa ON (bf.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND bf.FDMSACCOUNTNO=aa.FDMSACCOUNTNO)
                WHERE
                    bf.FEE_FREQUENCY_IND='D'    
            ) daily ON (md.MerchantNumber=daily.FDMSACCOUNTNO)
            LEFT JOIN (
                SELECT
                    DISTINCT
                    bf.FDMSACCOUNTNO
                FROM
                    BISME.MASSNFlat_BillingFees_RMM     bf
                    INNER JOIN (
                        SELECT 
                            bf.FDMSACCOUNTNO        FDMSACCOUNTNO,
                            MAX(bf.MRCH_STMT_MTH)   MRCH_STMT_MTH
                        FROM 
                            BISME.MASSNFlat_BillingFees_RMM                         bf 
                            --LEFT JOIN BISME.MASSNFlat_DescFeeOrRateDescription_RAB  rd ON (bf.MRCH_STMT_MTH=rd.MRCH_STMT_MTH AND bf.FEE_SEQUENCE=rd.SEQUENCE AND bf.TYPE=rd.RECORD_ID) --11G
                        WHERE
                            bf.FEE_RETAIL_AMT_NEW > 0
                            AND bf.FEE_RETAIL_AMT_NEW < 0.0400  --Want low billing rate items like discount fees which are more likely to be passed daily
                            AND ASCII(FEE_FREQUENCY_IND) IS NOT NULL
                        GROUP BY
                            bf.FDMSACCOUNTNO    
                    ) aa ON (bf.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND bf.FDMSACCOUNTNO=aa.FDMSACCOUNTNO)
                WHERE
                    bf.FEE_FREQUENCY_IND='M'    
            ) monthly ON (md.MerchantNumber=monthly.FDMSACCOUNTNO)    
        WHERE
            md.ClearingPlatform='North'
    ) B
WHERE
    A.MerchantNumber = B.MerchantNumber               
;    
---== NORTH: Billing program 1 of X ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A 
SET 
    BillingProgram = 'Billback'
FROM 
    (    
        SELECT
            DISTINCT  
            mbb.FDMSACCOUNTNO MerchantNumber
        FROM
            BISME.MASSNFlat_MerchantBillbackInformation_RGG mbb
            INNER JOIN (
                SELECT
                    FDMSACCOUNTNO,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.MASSNFlat_MerchantBillbackInformation_RGG
                GROUP BY
                    FDMSACCOUNTNO
            ) aa ON (mbb.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND mbb.FDMSACCOUNTNO=aa.FDMSACCOUNTNO)
        WHERE
            mbb.AUTO_BILLBACK_IND='A'
    ) B
WHERE
    A.MerchantNumber = B.MerchantNumber  
;
---== NORTH: END ==---
;
---== TSYS: START ==---    
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A 
SET 
    DBA                     = B.DBA,
    MCC                     = B.MCC,
    OpenDate                = B.OpenDate,
    OpenYearMonth           = TO_DATE(TO_CHAR(B.OpenDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseDate               = B.CloseDate,
    CloseYearMonth          = TO_DATE(TO_CHAR(B.CloseDate,'YYYY-Mon-01'),'YYYY-Mon-DD'),
    CloseCode               = CASE WHEN B.CloseDate IS NOT NULL THEN 'TBD' ELSE NULL END,
    isOpen                  = CASE WHEN B.CloseDate IS NOT NULL THEN 0 ELSE 1 END,        
    LocationAddressPart     = B.LocationAddressPart,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationZIP             = B.LocationZIP,
    LocationCountry         = B.LocationCountry,
    LocationPhoneLast4      = B.LocationPhoneLast4,    
    OwnerNameLast25Pct      = B.TheOwnerNameLast25Pct,
    LegalBusinessName       = B.LegalBusinessName,
    DiscountMethod          = B.DiscountMethod,
    isNonProfit             = B.isNonProfit,
    EmailFirst25Pct         = B.EmailFirst25Pct,
    OwnerTaxIDLast4         = B.OwnerTaxIDLast4,
    CorpTaxIDLast25Pct      = B.CorpTaxIDLast25Pct,
    CorpTaxIDFingerprint    = B.CorpTaxIDFingerprint,
    OwnerTaxIDFingerprint   = B.OwnerTaxIDFingerprint,
    EmailFingerprint        = B.EmailFingerprint,
    ClearingPlatform        = 'TSYS'   
FROM 
    (   
        SELECT
            mdf.ACCOUNT_NUMBER      MerchantNumber,
            DBA_NAME                DBA,    
            SIC                     MCC,
            OPEN_DATE               OpenDate,
            CASE 
                WHEN MERCHANT_STATUS IS NOT NULL AND STATUS_CHANGED_DATE IS NOT NULL THEN STATUS_CHANGED_DATE ELSE NULL
            END                     CloseDate,
            NULL                    LocationAddressPart,
            DBA_ADDRESS_CITY        LocationCity,
            DBA_ADDRESS_STATE       LocationState,
            LEFT(DBA_ZIP,5)         LocationZIP,
            'USA'                   LocationCountry,
            CASE 
                WHEN NVL(CAST(PHONE1LAST4 AS INT),0)>0                  THEN PHONE1LAST4
                WHEN NVL(CAST(PHONE2LAST4 AS INT),0)>0                  THEN PHONE2LAST4 
                WHEN NVL(CAST(CUSTOMERSERVICENUMBERLAST4 AS INT),0)>0   THEN CUSTOMERSERVICENUMBERLAST4        
                
        
                ELSE NULL
            END                     LocationPhoneLast4,
            CASE 
                WHEN LENGTH(mdf.OWNERNAMELAST25PCT)>0   THEN mdf.OWNERNAMELAST25PCT
                WHEN LENGTH(MANAGERNAMELAST25PCT)>0     THEN MANAGERNAMELAST25PCT 
                ELSE NULL
            END                     TheOwnerNameLast25Pct,
            NULL                    LegalBusinessName,
            NULL                    DiscountMethod,
            NULL                    isNonProfit,
            MERCHANTEMAILADDRESSFIRST25PCT  EmailFirst25Pct,
            OWNERSSNLAST4           OwnerTaxIDLast4,
            FEDERALTAXIDLAST25PCT   CorpTaxIDLast25Pct,
            OWNER_SSN               OwnerTaxIDFingerprint,
            FEDERAL_TAX_ID          CorpTaxIDFingerprint,
            MERCHANT_EMAIL_ADDRESS  EmailFingerprint,
            mdf.*
        FROM
            BISME.MerchantDetailFile_TSYS   mdf
            INNER JOIN (
                SELECT 
                    ACCOUNT_NUMBER      ACCOUNT_NUMBER,
                    MAX(UNITYFILEDATE)  UNITYFILEDATE
                FROM 
                    BISME.MerchantDetailFile_TSYS 
                --WHERE
                    -- If we want to take histocial monthly snapshots, then we will only want the data from this table up thru 
                    -- the last second of the month, for example January 31, 2021 23:59:59.
                    -- Data from February 01 does not apply to the January 2021 metrics.
                    -- Then means that when we run historical months, this value must be manually configured for example...
                    -- We want to get data for OCtober 2020 (but it's currently February 2021)...  WE'd need to manually set this 
                    -- date value to November 1, 2020.
                    --ENVELOPEFILEDATE < TO_DATE(TO_CHAR(SYSDATE(),'YYYY-Mon-01'),'YYYY-Mon-DD')  
                GROUP BY
                    ACCOUNT_NUMBER    
            ) aa ON (mdf.UNITYFILEDATE=aa.UNITYFILEDATE AND mdf.ACCOUNT_NUMBER=aa.ACCOUNT_NUMBER)
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber    
;    
---== TSYS: DiscountMethod 1 of 2 ==---
-- Get daily fees (if any) assocaited with just Visa, MC and Discover. Skip AMEX becasue it's often a wild card.  
-- If any of these fees are daily, then we'll say the merchant is on daily discount.  
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DiscountMethod  = 'Daily' 
FROM 
    (
        SELECT
            DISTINCT 
            fit.MERCHANT_ID     MerchantNumber
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS  fit
            INNER JOIN (
                SELECT
                    MERCHANT_ID,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.PPMFeeItemTotalsMonthly_TSYS
                WHERE
                    INCOME!=0
                GROUP BY
                    MERCHANT_ID
            ) aa ON (fit.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND fit.MERCHANT_ID=aa.MERCHANT_ID)
        WHERE
            fit.FEES_PAID_DAILY_VERSION!=0
            AND (
                SPLIT_PART(fit.FEE_ITEM_NAME,' ',1) IN ('Visa','MasterCard','Discover','VS/MC/DS','V/MC/D','MC/VI/DV')
                OR fit.FEE_ITEM_NAME IN ('Qual Disc - VS/MC/DS Debit','Qual Disc - VS/MC/DS Credit','Intrchg-Tiered MC Mid Qual','Intrchg-Tiered MC Qual','Intrchg-Tiered Visa Mid Qual',
                                  'Intrchg-Tiered MC Non Qual','Intrchg-Tiered Visa Qual','Intrchg-Tiered Visa Non Qual','Interchg Pass-thru - VS/MC/DS',
                                  'Flat Rate - VI Debit','Flat Rate - MC Debit','Flat Rate - Discover Credit','Flat Rate - Discover Debit','Flat Rate - VI Credit',
                                  'Flat Rate - MC Credit','Additional Discount - VS/MC/DS')
            )
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber  
;
---== TSYS: DiscountMethod 2 of 2 ==---
-- This isn't best practice to assume everythign is MonthEnd if we can't determine it's daily but ran out of time.  Will get more precise down the road.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics 
SET 
    DiscountMethod='MonthEnd' 
WHERE 
    ClearingPlatform='TSYS' 
    AND NVL(DiscountMethod,'') <> 'Daily'
;
---== TSYS: BillingProgram 1 of 9 ==---
-- Set everything back to NULL when we have data in the PPMFeeItemTotalsMonthly_TSYS table.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = NULL 
FROM 
    (
        SELECT DISTINCT MERCHANT_ID MerchantNumber FROM BISME.PPMFeeItemTotalsMonthly_TSYS
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber       
;
---== TSYS: BillingProgram 2 of 9 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'Tiered' 
FROM 
    (
        SELECT
            DISTINCT 
            fit.MERCHANT_ID     MerchantNumber
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS  fit
            INNER JOIN (
                SELECT
                    MERCHANT_ID,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.PPMFeeItemTotalsMonthly_TSYS fit
                WHERE
                    INCOME!=0
                    AND (
                        fit.FEE_ITEM_NAME IN ('Interchg Pass-thru - VS/MC/DS','V/MC/D Interchange-Pass Thru','Interchange Plus (Bankcard)','V/MC/D Interchange-Pass Thru','Interchg Pass-thru - VS/MC/DS')
                        OR fit.FEE_ITEM_NAME IN ('Interchange Pass-through','Interchange-Pass Thru')
                        OR FEE_ITEM_NAME IN ('Visa Non-Qual Credit','MasterCard Non-Qual Credit','Visa Mid-Qual Debit','Mastercard Mid-Qual Debit','Visa Mid-Qual Credit',
                        'Visa Non-Qual Debit','Mastercard Mid-Qual Credit','Discover Non-Qual Credit','MasterCard Mid-Qual Credit','Visa Non-Qual',
                        'MasterCard Mid-Qual Debit','MasterCard Mid-Qual','Visa Mid-Qual','MasterCard Non-Qual Debit','MasterCard Non-Qual Debit','Discover Mid-Qual Credit',
                        'Intrchg-Tiered Visa Mid Qual','Intrchg-Tiered MC Mid Qual','MasterCard Non-Qual','Intrchg-Tiered MC Non Qual','Discover Mid-Qual Debit',
                        'Discover Non-Qual Debit','Qual Disc - VS/MC/DS Credit','Qual Disc - VS/MC/DS Debit','Visa Qual Debit','Visa Qual Credit','MasterCard Qual Debit',
                        'Qualified Discount - VS/MC/DS','MasterCard Qual Credit','Debit Qual Tier - Regulated','Intrchg-Tiered Visa Qual','Discover Qual Credit',
                        'Intrchg-Tiered MC Qual')
                        OR LEFT(fit.FEE_ITEM_NAME,19) IN ('Debit Mid Qual Tier','Credit Non Qual Tie','Credit Mid Qual Tie','Credit Non Qual Tie','Credit Mid Qual Tie')
                        OR fit.FEE_ITEM_NAME IN ('Flat Rate - Discover Credit','Flat Rate - Discover Debit','Flat Rate - MC Credit','Flat Rate - MC Debit','Flat Rate - VI Credit','Flat Rate - VI Debit')
                        OR fit.FEE_ITEM_NAME IN ('Visa Discount','MasterCard Discount','Discover Discount')
                        OR fit.FEE_ITEM_NAME IN ('Visa ERR','Visa ERR Surcharge','Mastercard ERR','Mastercard ERR Surcharge','Discover ERR Surcharge','Discover ERR')
                    )
                GROUP BY
                    MERCHANT_ID
            )                                                       aa ON (fit.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND fit.MERCHANT_ID=aa.MERCHANT_ID)
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (aa.MERCHANT_ID=md.MerchantNumber)  
        WHERE
            md.BillingProgram IS NULL
            AND INCOME!=0
            AND (
                fit.FEE_ITEM_NAME IN ('Visa Non-Qual Credit','MasterCard Non-Qual Credit','Visa Mid-Qual Debit','Mastercard Mid-Qual Debit','Visa Mid-Qual Credit',
                'Visa Non-Qual Debit','Mastercard Mid-Qual Credit','Discover Non-Qual Credit','MasterCard Mid-Qual Credit','Visa Non-Qual',
                'MasterCard Mid-Qual Debit','MasterCard Mid-Qual','Visa Mid-Qual','MasterCard Non-Qual Debit','MasterCard Non-Qual Debit','Discover Mid-Qual Credit',
                'Intrchg-Tiered Visa Mid Qual','Intrchg-Tiered MC Mid Qual','MasterCard Non-Qual','Intrchg-Tiered MC Non Qual','Discover Mid-Qual Debit',
                'Discover Non-Qual Debit')
                --BReaking the "qual" items out because sometimes they are not a good indicator of Tiered Billing Program because sometimes the "qual" bucket is used for lot sof billing programs. 
                --OR fit.FEE_ITEM_NAME IN ('Qual Disc - VS/MC/DS Credit','Qual Disc - VS/MC/DS Debit','Visa Qual Debit','Visa Qual Credit','MasterCard Qual Debit',
                --'Qualified Discount - VS/MC/DS','MasterCard Qual Credit','Debit Qual Tier - Regulated','Intrchg-Tiered Visa Qual','Discover Qual Credit',
                --'Intrchg-Tiered MC Qual')
                OR LEFT(fit.FEE_ITEM_NAME,19) IN ('Debit Mid Qual Tier','Credit Non Qual Tie','Credit Mid Qual Tie','Credit Non Qual Tie','Credit Mid Qual Tie')
            )
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber  
;
---== TSYS: BillingProgram 3 of 9 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'ERR' 
FROM 
    (
        SELECT
            DISTINCT 
            fit.MERCHANT_ID     MerchantNumber
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS  fit
            INNER JOIN (
                SELECT
                    MERCHANT_ID,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.PPMFeeItemTotalsMonthly_TSYS fit
                WHERE
                    INCOME!=0
                    AND (
                        fit.FEE_ITEM_NAME IN ('Interchg Pass-thru - VS/MC/DS','V/MC/D Interchange-Pass Thru','Interchange Plus (Bankcard)','V/MC/D Interchange-Pass Thru','Interchg Pass-thru - VS/MC/DS')
                        OR fit.FEE_ITEM_NAME IN ('Interchange Pass-through','Interchange-Pass Thru')
                        OR FEE_ITEM_NAME IN ('Visa Non-Qual Credit','MasterCard Non-Qual Credit','Visa Mid-Qual Debit','Mastercard Mid-Qual Debit','Visa Mid-Qual Credit',
                        'Visa Non-Qual Debit','Mastercard Mid-Qual Credit','Discover Non-Qual Credit','MasterCard Mid-Qual Credit','Visa Non-Qual',
                        'MasterCard Mid-Qual Debit','MasterCard Mid-Qual','Visa Mid-Qual','MasterCard Non-Qual Debit','MasterCard Non-Qual Debit','Discover Mid-Qual Credit',
                        'Intrchg-Tiered Visa Mid Qual','Intrchg-Tiered MC Mid Qual','MasterCard Non-Qual','Intrchg-Tiered MC Non Qual','Discover Mid-Qual Debit',
                        'Discover Non-Qual Debit','Qual Disc - VS/MC/DS Credit','Qual Disc - VS/MC/DS Debit','Visa Qual Debit','Visa Qual Credit','MasterCard Qual Debit',
                        'Qualified Discount - VS/MC/DS','MasterCard Qual Credit','Debit Qual Tier - Regulated','Intrchg-Tiered Visa Qual','Discover Qual Credit',
                        'Intrchg-Tiered MC Qual')
                        OR LEFT(fit.FEE_ITEM_NAME,19) IN ('Debit Mid Qual Tier','Credit Non Qual Tie','Credit Mid Qual Tie','Credit Non Qual Tie','Credit Mid Qual Tie')
                        OR fit.FEE_ITEM_NAME IN ('Flat Rate - Discover Credit','Flat Rate - Discover Debit','Flat Rate - MC Credit','Flat Rate - MC Debit','Flat Rate - VI Credit','Flat Rate - VI Debit')
                        OR fit.FEE_ITEM_NAME IN ('Visa Discount','MasterCard Discount','Discover Discount')
                        OR fit.FEE_ITEM_NAME IN ('Visa ERR','Visa ERR Surcharge','Mastercard ERR','Mastercard ERR Surcharge','Discover ERR Surcharge','Discover ERR')
                    )                    
                GROUP BY
                    MERCHANT_ID
            ) aa ON (fit.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND fit.MERCHANT_ID=aa.MERCHANT_ID)
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (aa.MERCHANT_ID=md.MerchantNumber)  
        WHERE
            md.BillingProgram IS NULL
            AND INCOME!=0
            AND fit.FEE_ITEM_NAME IN ('Visa ERR','Visa ERR Surcharge','Mastercard ERR','Mastercard ERR Surcharge','Discover ERR Surcharge','Discover ERR')
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber   
;  
---== TSYS: BillingProgram 4 of 9 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'FlatRate' 
FROM 
    (
        SELECT
            DISTINCT 
            fit.MERCHANT_ID     MerchantNumber
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS  fit
            INNER JOIN (
                SELECT
                    MERCHANT_ID,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.PPMFeeItemTotalsMonthly_TSYS fit
                WHERE
                    INCOME!=0
                    AND (
                        fit.FEE_ITEM_NAME IN ('Interchg Pass-thru - VS/MC/DS','V/MC/D Interchange-Pass Thru','Interchange Plus (Bankcard)','V/MC/D Interchange-Pass Thru','Interchg Pass-thru - VS/MC/DS')
                        OR fit.FEE_ITEM_NAME IN ('Interchange Pass-through','Interchange-Pass Thru')
                        OR FEE_ITEM_NAME IN ('Visa Non-Qual Credit','MasterCard Non-Qual Credit','Visa Mid-Qual Debit','Mastercard Mid-Qual Debit','Visa Mid-Qual Credit',
                        'Visa Non-Qual Debit','Mastercard Mid-Qual Credit','Discover Non-Qual Credit','MasterCard Mid-Qual Credit','Visa Non-Qual',
                        'MasterCard Mid-Qual Debit','MasterCard Mid-Qual','Visa Mid-Qual','MasterCard Non-Qual Debit','MasterCard Non-Qual Debit','Discover Mid-Qual Credit',
                        'Intrchg-Tiered Visa Mid Qual','Intrchg-Tiered MC Mid Qual','MasterCard Non-Qual','Intrchg-Tiered MC Non Qual','Discover Mid-Qual Debit',
                        'Discover Non-Qual Debit','Qual Disc - VS/MC/DS Credit','Qual Disc - VS/MC/DS Debit','Visa Qual Debit','Visa Qual Credit','MasterCard Qual Debit',
                        'Qualified Discount - VS/MC/DS','MasterCard Qual Credit','Debit Qual Tier - Regulated','Intrchg-Tiered Visa Qual','Discover Qual Credit',
                        'Intrchg-Tiered MC Qual')
                        OR LEFT(fit.FEE_ITEM_NAME,19) IN ('Debit Mid Qual Tier','Credit Non Qual Tie','Credit Mid Qual Tie','Credit Non Qual Tie','Credit Mid Qual Tie')
                        OR fit.FEE_ITEM_NAME IN ('Flat Rate - Discover Credit','Flat Rate - Discover Debit','Flat Rate - MC Credit','Flat Rate - MC Debit','Flat Rate - VI Credit','Flat Rate - VI Debit')
                        OR fit.FEE_ITEM_NAME IN ('Visa Discount','MasterCard Discount','Discover Discount')
                        OR fit.FEE_ITEM_NAME IN ('Visa ERR','Visa ERR Surcharge','Mastercard ERR','Mastercard ERR Surcharge','Discover ERR Surcharge','Discover ERR')
                    )                    
                GROUP BY
                    MERCHANT_ID
            ) aa ON (fit.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND fit.MERCHANT_ID=aa.MERCHANT_ID)
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (aa.MERCHANT_ID=md.MerchantNumber)  
        WHERE
            md.BillingProgram IS NULL
            AND INCOME!=0
            AND (
                fit.FEE_ITEM_NAME IN ('Flat Rate - Discover Credit','Flat Rate - Discover Debit','Flat Rate - MC Credit','Flat Rate - MC Debit','Flat Rate - VI Credit','Flat Rate - VI Debit')
                OR fit.FEE_ITEM_NAME IN ('Visa Discount','MasterCard Discount','Discover Discount')
            )
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber   
;
---== TSYS: BillingProgram 5 of 9 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'CostPlus' 
FROM 
    (
        SELECT
            DISTINCT 
            fit.MERCHANT_ID     MerchantNumber
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS  fit
            INNER JOIN (
                SELECT
                    MERCHANT_ID,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.PPMFeeItemTotalsMonthly_TSYS fit
                WHERE
                    INCOME!=0
                    AND (
                        fit.FEE_ITEM_NAME IN ('Interchg Pass-thru - VS/MC/DS','V/MC/D Interchange-Pass Thru','Interchange Plus (Bankcard)','V/MC/D Interchange-Pass Thru','Interchg Pass-thru - VS/MC/DS')
                        OR fit.FEE_ITEM_NAME IN ('Interchange Pass-through','Interchange-Pass Thru')
                        OR FEE_ITEM_NAME IN ('Visa Non-Qual Credit','MasterCard Non-Qual Credit','Visa Mid-Qual Debit','Mastercard Mid-Qual Debit','Visa Mid-Qual Credit',
                        'Visa Non-Qual Debit','Mastercard Mid-Qual Credit','Discover Non-Qual Credit','MasterCard Mid-Qual Credit','Visa Non-Qual',
                        'MasterCard Mid-Qual Debit','MasterCard Mid-Qual','Visa Mid-Qual','MasterCard Non-Qual Debit','MasterCard Non-Qual Debit','Discover Mid-Qual Credit',
                        'Intrchg-Tiered Visa Mid Qual','Intrchg-Tiered MC Mid Qual','MasterCard Non-Qual','Intrchg-Tiered MC Non Qual','Discover Mid-Qual Debit',
                        'Discover Non-Qual Debit','Qual Disc - VS/MC/DS Credit','Qual Disc - VS/MC/DS Debit','Visa Qual Debit','Visa Qual Credit','MasterCard Qual Debit',
                        'Qualified Discount - VS/MC/DS','MasterCard Qual Credit','Debit Qual Tier - Regulated','Intrchg-Tiered Visa Qual','Discover Qual Credit',
                        'Intrchg-Tiered MC Qual')
                        OR LEFT(fit.FEE_ITEM_NAME,19) IN ('Debit Mid Qual Tier','Credit Non Qual Tie','Credit Mid Qual Tie','Credit Non Qual Tie','Credit Mid Qual Tie')
                        OR fit.FEE_ITEM_NAME IN ('Flat Rate - Discover Credit','Flat Rate - Discover Debit','Flat Rate - MC Credit','Flat Rate - MC Debit','Flat Rate - VI Credit','Flat Rate - VI Debit')
                        OR fit.FEE_ITEM_NAME IN ('Visa Discount','MasterCard Discount','Discover Discount')
                        OR fit.FEE_ITEM_NAME IN ('Visa ERR','Visa ERR Surcharge','Mastercard ERR','Mastercard ERR Surcharge','Discover ERR Surcharge','Discover ERR')
                    )
                GROUP BY
                    MERCHANT_ID
            ) aa ON (fit.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND fit.MERCHANT_ID=aa.MERCHANT_ID)
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (aa.MERCHANT_ID=md.MerchantNumber)  
        WHERE
            md.BillingProgram IS NULL
            AND INCOME!=0
            AND (
                fit.FEE_ITEM_NAME IN ('Interchg Pass-thru - VS/MC/DS','V/MC/D Interchange-Pass Thru','Interchange Plus (Bankcard)','V/MC/D Interchange-Pass Thru','Interchg Pass-thru - VS/MC/DS')
                -- This is NOT card-specific but there are merchants, like 3286000000017442 in Dec 2020, that don't have billing broken out by card scheme so can't figure 
                -- out any other way of determiing billing program by card scheme so have to do this until we figgure out a better way to do it only on V, MC, D liek we want to.
                OR fit.FEE_ITEM_NAME IN ('Interchange Pass-through','Interchange-Pass Thru')  
            )
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber   
;    
---== TSYS: BillingProgram 6 of 9 ==---
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'FeePerItem' 
FROM 
    (
        SELECT
            DISTINCT 
            fit.MERCHANT_ID     MerchantNumber
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS  fit
            INNER JOIN (
                SELECT
                    MERCHANT_ID,
                    MAX(MRCH_STMT_MTH)  MRCH_STMT_MTH
                FROM
                    BISME.PPMFeeItemTotalsMonthly_TSYS fit
                WHERE
                    INCOME!=0
                    AND FEE_ITEM_NAME IN ('Authorization','Captured Per Item Fee')
                    ---We only apply this if we could find no other proper fee program.
                    AND MERCHANT_ID IN (SELECT MerchantNumber FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='TSYS' AND BillingProgram IS NULL)
                    --AND MERCHANT_ID='3286000000533059'
                GROUP BY
                    MERCHANT_ID
            ) aa ON (fit.MRCH_STMT_MTH=aa.MRCH_STMT_MTH AND fit.MERCHANT_ID=aa.MERCHANT_ID)
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (aa.MERCHANT_ID=md.MerchantNumber)  
        WHERE
            md.BillingProgram IS NULL
            AND INCOME!=0
            AND fit.FEE_ITEM_NAME IN ('Authorization','Captured Per Item Fee')
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber  
;     
---== TSYS: BillingProgram 7 of 9 ==---
--If we've never billed the merchant anything, and the merchant is a bank, then it's cash advance billing program.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'CashAdvance' 
FROM 
    (
        SELECT
            MERCHANT_ID MerchantNumber,
            SUM(INCOME) INCOME
        FROM
            BISME.PPMFeeItemTotalsMonthly_TSYS                      fit
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md  ON (fit.MERCHANT_ID=md.MerchantNumber AND ClearingPlatform='TSYS' AND BillingProgram IS NULL)
        WHERE
            md.MCC IN ('6010','6012')
            AND FEE_ITEM_NAME NOT IN ('ARU Authorization','Annual Fee') --This looks like an oversight, sometimes we bill banks this.
            --AND fit.MERCHANT_ID='3286589997893464'
        GROUP BY
            MERCHANT_ID
        HAVING
            SUM(INCOME) = 0
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber  
; 
---== TSYS: BillingProgram 8 of 9 ==---
-- we do not bill any of the Change Healthcare accounts. The residual team calculates the amounts due and the ISO is billed 
-- by Accounting. It is a manual process, so I don’t think there are any data feeds that you can pull from to get the amounts. 
-- It would have to come from the residual team/Accounting.  Outside of not having any pricing set up at TSYS, there is no 
-- flag or setting that can be utilized to identify these merchants. The only thing that can be referenced is the agent ID. 
-- Change Healthcare is agent #3541. There is one other setup similar to this under Convenient Payments (agent #1200). 
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'ThirdPartyBilled' 
FROM 
    (
        SELECT
            md.MerchantNumber
        FROM
            ppbisandbox.millikan_MerchantDemographics   md
            INNER JOIN BI.ReportingChannels             rc ON (md.MerchantNumber=rc.MerchantNumber)  
        WHERE
            md.ClearingPlatform='TSYS' 
            AND md.BillingProgram IS NULL
            AND rc.HoustonAgentNumber IN ('3541','1200')
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber 
;    
---== TSYS: BillingProgram 9 of 9 ==---
-- Billing program follows no known normal rules.
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    BillingProgram  = 'Other' 
FROM 
    (
        SELECT
            MerchantNumber
        FROM
            ppbisandbox.millikan_MerchantDemographics    md
        WHERE
            ClearingPlatform='TSYS' 
            AND BillingProgram IS NULL
    ) as B
WHERE   
    A.MerchantNumber = B.MerchantNumber
; 
---== TSYS: isNonProfit ==---
-- Solve isNonProfit using MERCHANT_TYPE or INC_STATUS in BISME.PPMFeeItemTotalsMonthly_TSYS
---== TSYS: END ==---
---== TSYS: END ==---
---== TSYS: END ==---

---== Only QA / SandBox below this point. Disregard everythign below this point  ==---
---== Only QA / SandBox below this point. Disregard everythign below this point  ==---
---== Only QA / SandBox below this point. Disregard everythign below this point  ==---
---== Only QA / SandBox below this point. Disregard everythign below this point  ==---
;
--Not in MASSNFlat_CardEntitlements_RII, might be PRICINGPLANCODE but doubt it.
--Not BISME.MASSNFlat_CardEntDetails_RED
--Not BISME.MASSNFlat_CardEntDetails_RED
-- Might be able to figure it out from the BISME.MASSNFlat_BillingFees_RMM 
SELECT * FROM BISME.MASSNFlat_BillingFees_RMM WHERE FDMSACCOUNTNO='296201451881' AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM  BISME.MASSNFlat_BillingFees_RMM WHERE FDMSACCOUNTNO='296201722885' AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM BISME.MASSNFlat_MerchantBillbackInformation_RGG WHERE FDMSACCOUNTNO='296201722885' AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM BISME.MASSNFlat_MerchantProgramFields_RP1 WHERE MRCH_NO IN ('434349018888','296203900885','296202109884','296201722885','296201451881') AND MRCH_STMT_MTH='01-DEC-2020'
;
-- There is a website and an email in this RQQ table.
SELECT * FROM BISME.MASSNFlat_MM2Other_RQQ WHERE FDMSACCOUNTNO IN ('434349018888','296203900885','296202109884','296201722885','296201451881') AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM BISME.MASSNFlat_ProgramFields_RP3 
;
SELECT * FROM BISME.MASSNFlat_MerchantMembershipData_RDD WHERE FDMSACCOUNTNO IN ('434349018888','296203900885','296202109884','296201722885','296201451881') AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM BISME.MASSNFlat_MerchantFundingCategoryDDAs_RFB WHERE FDMSACCOUNTNO IN ('434349018888','296203900885','296202109884','296201722885','296201451881') AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM BISME.MASSNFlat_FeeHistory_RFH WHERE BUCKET_NUMBER='002' AND FDMSACCOUNTNO IN ('434349018888','296203900885','296202109884','296201722885','296201451881') AND MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM BISME.MASSNFlat_DescFeeOrRateDescription_RAB WHERE  FDMSACCOUNTNO IN ('434349018888','296203900885','296202109884','296201722885','296201451881') AND MRCH_STMT_MTH='01-DEC-2020'
;
 
;    
SELECT
    fh.MRCH_STMT_MTH    MrchStmtMth,
    fh.FDMSACCOUNTNO    MerchantNumber,
    frd.FeeSequenceDesc FeeDescription,
    fh.*
FROM
    BISME.MASSNFlat_FeeHistory_RFH                          fh 
    INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (fh.FDMSACCOUNTNO=md.MerchantNumber)
    LEFT JOIN (
        SELECT
            MRCH_STMT_MTH       MRCH_STMT_MTH,
            SEQUENCE            SEQUENCE,
            MAX(DESCRIPTION)    FeeSequenceDesc    
        FROM 
            BISME.MASSNFlat_DescFeeOrRateDescription_RAB            rd  
        GROUP BY
            MRCH_STMT_MTH,
            SEQUENCE    
    ) frd ON (fh.MRCH_STMT_MTH=frd.MRCH_STMT_MTH AND fh.FEE_SEQUENCE_NUMBER=frd.SEQUENCE)
WHERE
    fh.FDMSACCOUNTNO='296201722885'
    AND fh.MRCH_STMT_MTH='01-DEC-2020'
    AND fh.BUCKET_NUMBER='002'
LIMIT 2000
;    
SELECT SEQUENCE,SEQUENCE_FEE_NO, * FROM BISME.MASSNFlat_DescFeeOrRateDescription_RAB WHERE MRCH_STMT_MTH='01-DEC-2020' AND SEQUENCE LIKE '%P77%'  --FEE_SEQUENCE_NUMBER 677  V677 Bucket 002
;
SELECT SEQUENCE, count(*) FROM BISME.MASSNFlat_DescFeeOrRateDescription_RAB WHERE MRCH_STMT_MTH='01-DEC-2020' GROUP BY SEQUENCE
;
---== TSYS: Lists "Paper Statement Fee" in FEE_ITEM_NAME in PPMFeeItemTotalsMonthly_TSYS ==---
-- UPDATE ppbisandbox.millikan_MerchantDemographics SET BillingProgram = NULL WHERE ClearingPlatform='TSYS'
-- No billing done: 3286000000004564
-- Only a FPT being billed: 9109000068493028 = "Captured Per Item Fee"  Ditto 9109000049864274 just income on FEE_ITEM_NAME='Captured Per Item Fee' but the motnh prior they had "Visa Discount" so looks more liek FlatRate 
-- 3286591505563705 is Flat Rate in SOS.  FEE_ITEM_NAME = Visa Discount, MasterCard Discount, Discover Discount
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE MCC IN ('6010','6012') AND isOpen=1
;
SELECT COUNT(*) FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='TSYS' --20463
;
---== QA with Dallas's MIF becasue it shoudl be pretty accurate because Chriss Thill is keepign an eye on it ==---
-- ..if you’re ever looking to see what Dallas has in our CRM you can run below query. 
-- Please note this is dependent on MIF being loaded into Vertica which can sometimes 
-- not finish until 11am / 12pm CST.
SELECT 
    *
FROM 
    BISME.SupplementalMIF_ApplicationRecord_Internal
where 
    AGENT_NUMBER in ('2006','2282','2283','2277') and ENVELOPEFILEDATE = CURRENT_DATE
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform  = 'TSYS' AND OpenDAte IS NOT NULL
;
SELECT * FROM BISME.PPMFeeItemTotalsMonthly_TSYS WHERE MERCHANT_ID='220310794' AND MRCH_STMT_MTH='10/1/2020' LIMIT 500 
;
SELECT * FROM BISME.PPMFeeItemTotalsMonthly_TSYS WHERE MERCHANT_ID='3286000000593541' AND INCOME<>0 LIMIT 500 
;
SELECT * FROM BISME.PPMProfitabilityTotalsMonthly_TSYS WHERE MERCHANT_ID='9109000049864274' AND MRCH_STMT_MTH='12/1/2020' LIMIT 500 
;
SELECT * FROM BISME.AuthorizationDetailFile_TSYS WHERE MERCHANT_ID='3286000000004564' AND MRCH_STMT_MTH='12/1/2020' LIMIT 500 
;
SELECT DAILY_DISCOUNT_DAILY_INTERCHANGE_FLAG, * FROM BISME.MerchantDetailFile_TSYS WHERE ACCOUNT_NUMBER='3286000000225979'  LIMIT 500 
;
SELECT *
 FROM BISME.PPMFeeItemTotalsMonthly_TSYS WHERE MRCH_STMT_MTH='12/1/2020'LIMIT 500
;
-- NonProfit interchagne:  "VS CPS/Charity and Religious", "MC Charities Debit", "MC Commercial Charities"
SELECT 
    FEE_ITEM_KEY_2, 
    SUM(EXPENSE) 
FROM 
    BISME.PPMProfitabilityTotalsDaily_TSYS                  ptd
    INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (ptd.MERCHANT_ID=md.MerchantNumber)
WHERE
    md.MCC IN('8661','8398') --8661 = Religious Organizations, 8398= Charitable Social  Service Organizations
    AND FEE_CATEGORY='Interchange' GROUP BY FEE_ITEM_KEY_2
;

SELECT
    FEE_CATEGORY, 
    FEE_ITEM_KEY_1,
    SUM(FEES_PAID_DAILY_VERSION) FEES_PAID_DAILY_VERSION
FROM 
    BISME.PPMProfitabilityTotalsDaily_TSYS
WHERE
    FEES_PAID_DAILY_VERSION!=0
    AND (
            FEE_ITEM_KEY_1 IN ('VS','VD','VB','V$','VL')    --Visa
            OR FEE_ITEM_KEY_1 IN ('MC','MD','MB','M$','ML') --MasterCard
            OR FEE_ITEM_KEY_1 IN ('DS','DD','DZ','DJ','D$') --Discover
            --Skipping AMEX because it's often differnt the others and not considered "core" offering.
    )
GROUP BY
    FEE_CATEGORY, 
    FEE_ITEM_KEY_1    
;
SELECT
    md.DiscountMethod,
    *
FROM
    BI.VolumeBankCardMonthly        bcm
    INNER JOIN ppbisandbox.millikan_MerchantDemographics md ON (bcm.MerchantNumber=md.MerchantNumber)
WHERE
    bcm.MerchStmtMth='01-DEC-2020'
    AND md.ClearingPlatform='North'
    AND md.DiscountMethod='Other'
ORDER BY
    bcm.BankCardVolume DESC
LIMIT 
    500
;
SELECT 
    bf.FEE_FREQUENCY_IND,
    ASCII(bf.FEE_FREQUENCY_IND),
    bf.*,
    rd.*
FROM 
    BISME.MASSNFlat_BillingFees_RMM              bf 
    LEFT JOIN BISME.MASSNFlat_DescFeeOrRateDescription_RAB  rd ON (bf.MRCH_STMT_MTH=rd.MRCH_STMT_MTH AND bf.FEE_SEQUENCE=rd.SEQUENCE AND bf.TYPE=rd.RECORD_ID) --11G
WHERE 
    bf.MRCH_STMT_MTH='01-DEC-2020' 
    AND bf.FDMSACCOUNTNO ='497213354887' 
LIMIT 
    500 
;
SELECT 
    bf.*,
    rd.*
FROM 
    ppbisandbox.millikan_MerchantDemographics               md
    INNER JOIN BISME.MASSNFlat_BillingFees_RMM              bf ON (md.MerchantNumber=bf.FDMSACCOUNTNO)
    LEFT JOIN BISME.MASSNFlat_DescFeeOrRateDescription_RAB  rd ON (bf.MRCH_STMT_MTH=rd.MRCH_STMT_MTH AND bf.FEE_SEQUENCE=rd.SEQUENCE AND bf.TYPE=rd.RECORD_ID) --11G
WHERE 
    bf.MRCH_STMT_MTH='01-DEC-2020' 
    AND bf.FDMSACCOUNTNO ='497213354887' 
LIMIT 
    500 
    ;
SELECT * FROM BISME.MASSNFlat_BillingFees_RMM WHERE MRCH_STMT_MTH='01-DEC-2020'
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics LIMIT 500
;
SELECT 
    FEE_FREQUENCY_IND, 
    ASCII(FEE_FREQUENCY_IND), 
    NVL(FEE_FREQUENCY_IND,'I AM NULL'), 
    * 
FROM 
    BISME.MASSNFlat_BillingFees_RMM 
WHERE 
    FDMSACCOUNTNO ='000000114991' 
    AND MRCH_STMT_MTH='01-DEC-2020'
;
---== TSYS: 
SELECT 
    ENVELOPEFILEDATE, 
    count(*)
FROM 
    BISME.MerchantDetailFile_TSYS 
GROUP BY 
    ENVELOPEFILEDATE    
;
;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics wHERE ClearingPlatform='TSYS' AND DBA IS NOT NULL
;
SELECT
    ACCOUNT_NUMBER,
    MIN(OPEN_DATE)  --In 6 months of data there was never an altered OPEN_DATE so doing a MIN() on it should be overkill.
FROM
    BISME.MerchantDetailFile_TSYS
;    
SELECT ACCOUNT_NUMBER, count(*) FROM BISME.MerchantDetailFile_TSYS WHERE MERCHANT_STATUS IS NOT NULL GROUP BY ACCOUNT_NUMBER HAVING count(*)>=2
;
SELECT
    *
FROM
    (
        SELECT 
            ACCOUNT_NUMBER, 
            MAX(UNITYFILEDATE)  UNITYFILEDATE 
        FROM 
            BISME.MerchantDetailFile_TSYS 
        WHERE 
            MERCHANT_STATUS IS NOT NULL
        GROUP BY
            ACCOUNT_NUMBER            
    ) aa
    LEFT JOIN 
    (
        SELECT 
            ACCOUNT_NUMBER, 
            MAX(UNITYFILEDATE)  UNITYFILEDATE 
        FROM 
            BISME.MerchantDetailFile_TSYS 
        WHERE 
            MERCHANT_STATUS IS NULL    
        GROUP BY
            ACCOUNT_NUMBER
    ) bb ON (aa.ACCOUNT_NUMBER=bb.ACCOUNT_NUMBER)
    INNER JOIN (
        SELECT 
            *
        FROM  
            BISME.SupplementalMIF_ApplicationRecord_Internal 
        WHERE 
            UNITYFILEDATE = (SELECT MAX(UNITYFILEDATE) FROM BISME.SupplementalMIF_ApplicationRecord_Internal)
            AND DATE_CLOSED IS NULL
    ) cc ON (aa.ACCOUNT_NUMBER=cc.MERCHANT_SEQUENCE)
WHERE
    bb.UNITYFILEDATE<aa.UNITYFILEDATE 
    aND LEFT(bb.ACCOUNT_NUMBER,4) NOT IN ('9109','8960')
;

SELECT 
    ACCOUNT_NUMBER, ENVELOPEFILEDATE, OPEN_DATE,MERCHANT_STATUS, STATUS_CHANGED_DATE, * 
FROM 
    BISME.MerchantDetailFile_TSYS 
WHERE 
    ACCOUNT_NUMBER='3286000000491464' 
ORDER BY 
    UNITYFILEDATE
;
SELECT 
    MERCHANT_STATUS, DATE_CLOSED, DATE_OPEN, * 
FROM  
    BISME.SupplementalMIF_ApplicationRecord_Internal 
WHERE 
    MERCHANT_SEQUENCE='9109000040631697' ORDER BY UNITYFILEDATE
;
SELECT MERCHANT_STATUS, count(*) FROM BISME.MerchantDetailFile_TSYS  GROUP BY MERCHANT_STATUS
;
SELECT
    aa.FDMSACCOUNTNO,
    mm.CANCEL_DATE,
    mm.LAST_POST_DATE,
    LAST_SETTLE_DATE
FROM
    (
        SELECT
            cd.FDMSACCOUNTNO        FDMSACCOUNTNO,
            MAX(cd.MRCH_STMT_MTH)   MRCH_STMT_MTH
        FROM
            BISME.MASSNFlat_MerchantControlData_RAA                 cd 
            INNER JOIN ppbisandbox.millikan_MerchantDemographics    md ON (cd.FDMSACCOUNTNO=md.MerchantNumber)
        WHERE
            cd.ACCOUNT_STATUS IN ('11','14','15','16')
        GROUP BY
            cd.FDMSACCOUNTNO      
    ) aa
    INNER JOIN BISME.MASSNFlat_MerchantMembershipData_RDD  mm ON (aa.FDMSACCOUNTNO=mm.FDMSACCOUNTNO AND aa.MRCH_STMT_MTH=mm.MRCH_STMT_MTH)
;     






SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE ClearingPlatform='North' AND MerchantNumber=497216193886
;
SELECT * FROM BISME.MASSNFlat_MerchantAddressesDBA_RBB WHERE  FDMSACCOUNTNO='887200564888' --THE BROKEN YOLK CAFE PLA
;
SELECT * FROM BISME.MASSNFlat_MerchantAddressesCorporate_RCC WHERE  FDMSACCOUNTNO='887200564888'
;
SELECT * FROM BISME.MASSNFlat_MM2Other_RQQ WHERE  FDMSACCOUNTNO='887200564888'  --THE BROKEN YOLK CAFE P
;
SELECT * FROM BISME.MASSNFlat_MerchantDescriptorAddress_RB1 WHERE  FDMSACCOUNTNO='887200564888'  --THE BROKEN YOLK CAFE P
;
SELECT * FROM BISME.MASSNFlat_MerchantEntitlements_RME WHERE  FDMSACCOUNTNO='887200564888';
;
SELECT * FROM BISME.MASSNFlat_MerchantIRSBUW_RWW WHERE  FDMSACCOUNTNO='887200564888';
;
SELECT * FROM BISME.MASSNFlat_MerchantMembershipData_RDD WHERE  FDMSACCOUNTNO='497219587886'; --OPEN_DATE, ACTIVATIONDATE, ESTIMATEDSUBMITDATE, REVENUE_BOOKED_DATE, FIRST_POST_DATE

;
SELECT * FROM BISME.MASSNFlat_PhaseIIAdditionalInfo_RPP WHERE  FDMSACCOUNTNO='887200564888'; 
;
SELECT TAXEXEMPTIND,* FROM BISME.MASSNFlat_MerchantMembershipData_RDD WHERE TRIM(TAXEXEMPTIND) NOT IN ('','N')
;
SELECT * FROM BISME.MASSNFlat_CardEntitlements_RII WHERE  FDMSACCOUNTNO='434950140880'; 
;

SELECT * FROM BISME.MASSNFlat_CardEntitlements_RII WHERE FDMSACCOUNTNO IN ('434950140880','497212814881')
;
UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                     = B.DBA,
    MCC                     = B.MCC,
    OpenedYearMonth         = B.OpenedYearMonth,
    LocationCity            = B.LocationCity,
    LocationState           = B.LocationState,
    LocationZIP             = B.LocationZIP,
    LocationPhoneLast4      = B.LocationPhoneLast4,    
    OwnerNameLast25Pct      = B.OwnerNameLast25Pct,
    OpenedDate              = B.OpenedDate,
    EmailFirst25Pct         = B.EmailFirst25Pct,
    OwnerTaxIDLast4         = B.OwnerTaxIDLast4,
    CorpTaxIDLast25Pct      = B.CorpTaxIDLast25Pct,
    CorpTaxIDFingerprint    = B.CorpTaxIDFingerprint,
    OwnerTaxIDFingerprint   = B.OwnerTaxIDFingerprint,
    EmailFingerprint        = B.EmailFingerprint,
    Platform                ='TSS'    
FROM 
    (
        SELECT
            mdf1.ACCOUNT_NUMBER     MerchantNumber,
            DBA_Name                DBA,
            SIC                     MCC,
            CAST(to_char(OPEN_DATE::date, 'YYYY-MM-01') AS DATE) OpenedYearMonth, 
            OPEN_DATE               OpenedDate,            
            DBA_ADDRESS_CITY        LocationCity,
            DBA_ADDRESS_STATE       LocationState,
            LEFT(DBA_ZIP,5)         LocationZIP,
            OWNERNAMELAST25PCT      OwnerNameLast25Pct,    
            PHONE1LAST4             LocationPhoneLast4,
            MERCHANTEMAILADDRESSFIRST25PCT  EmailFirst25Pct,
            FEDERALTAXIDLAST25PCT   CorpTaxIDLast25Pct,
            OWNERSSNLAST4           OwnerTaxIDLast4,    
            FEDERAL_TAX_ID          CorpTaxIDFingerprint,
            OWNER_SSN               OwnerTaxIDFingerprint,
            MERCHANT_EMAIL_ADDRESS  EmailFingerprint
        FROM    
            SELECT DAILY_DISCOUNT_DAILY_INTERCHANGE_FLAG, count(*) FROM BISME.MerchantDetailFile_TSYS GROUP BY DAILY_DISCOUNT_DAILY_INTERCHANGE_FLAG
            BISME.MerchantDetailFile_TSYS   mdf1
            INNER JOIN 
                (
                    SELECT
                        ACCOUNT_NUMBER, 
                        MAX(ENVELOPECREATIONTIME)   ENVELOPECREATIONTIME
                    FROM    
                        BISME.MerchantDetailFile_TSYS
                    GROUP BY
                        ACCOUNT_NUMBER     
                ) mdf2 ON (mdf1.ENVELOPECREATIONTIME=mdf2.ENVELOPECREATIONTIME  AND mdf1.ACCOUNT_NUMBER=mdf2.ACCOUNT_NUMBER)    
    ) as B
WHERE 
    A.MerchantNumber = B.MerchantNumber
; 

UPDATE 
    ppbisandbox.millikan_MerchantDemographics as A
SET 
    DBA                 = B.DBA, 
    LocationAddressPart = B.LocationAddressPart,
    LocationCity        = B.LocationCity,
    LocationState       = B.LocationState,
    LocationZIP         = B.LocationZIP,
    LocationCounty      = B.LocationCounty,
    LocationPhoneLast4  = B.LocationPhoneLast4,
    OwnerNameLast25Pct  = B.OwnerNameLast25Pct,
    Platform            ='OMA'
FROM 
    (    
        SELECT 
            aa.ACCOUNT_NO                   MerchantNumber,    
            TRIM(DBA_NAME24 || DBA_NAME6)   DBA, 
            DBAADDRESSONE24FIRST50PCT       LocationAddressPart,
            DBA_CITY21 || DBA_CITY11        LocationCity,
            DBA_STATE                       LocationState,	
            DBA_ZIP5                        LocationZIP,
            CASE WHEN DBA_COUNTRY_CODE='US' THEN 'USA' ELSE DBA_COUNTRY_CODE END LocationCounty,
            TELEPHONENOLAST4                LocationPhoneLast4,
            SOLEPROPRIETORNAMELAST25PCT     OwnerNameLast25Pct
            --EmailFirst25Pct         
            --OwnerTaxIDLast4         
            --CorpTaxIDLast25Pct    
            --CorpTaxIDFingerprint  
            --OwnerTaxIDFingerprint 
            --EmailFingerprint          
        FROM 
            BISME.MASSOFlat_AddressDBA_R20 AS aa
            INNER JOIN 
                (
                    SELECT
                        ACCOUNT_NO, 
                        MAX(MRCH_STMT_MTH)   MRCH_STMT_MTH
                    FROM    
                        BISME.MASSOFlat_AddressDBA_R20
                    GROUP BY
                        ACCOUNT_NO     
                ) AS bb ON (aa.MRCH_STMT_MTH=bb.MRCH_STMT_MTH  AND aa.ACCOUNT_NO=bb.ACCOUNT_NO)   
    ) B
WHERE
    A.MerchantNumber = B.MerchantNumber
;
SELECT
    CAST(LTRIM(RTRIM(aa.FDMSAccountNo)) AS CHAR(12))    "MerchantNumber", 
	--BillingProgram    	varchar(255) NULL,
	--isOpen            	tinyint NULL,
	--OpenedYearMonth   	date NULL,
	--ClosedYearMonth   	date NULL,
	--SponsorBank       	varchar(255) NULL,
    'NOR'               "Platform",
	DBA_Name            "DBA",
	DBAADDRESS1FIRST25PCT   LocationAddressPart,
    DBA_CITY LocationCity        varchar(255) NULL,
    DBA_STATE LocationState       varchar(255) NULL,
    DBA_ZIP_FIRST5 LocationZIP         varchar(255) NULL,  
    CASE WHEN COUNTRY_CODE='US' THEN 'USA' ELSE COUNTRY_CODE END    LocationCounty,  
    DBAPHONELAST4   LocationPhoneLast4  varchar(255) NULL,     
	--OpenedDate        	date NULL,
	--ClosedDate        	date NULL,
	--hasEcommerceVol     tinyint NULL,	
	--MCC               	varchar(4) NULL,	
	--CloseCode         	varchar(255) NULL,
	--CloseDescription  	varchar(255) NULL,
	--isPremier     	    tinyint NULL,
	--PremierRep     	    varchar(255) NULL,
	CORPCONTACTLAST25PCT    "OwnerNameLast25Pct",
	NULL                    "EmailFirst25Pct",
    CorpTaxIDLast25Pct  varchar(255) NULL,
    OwnerTaxIDLast4     varchar(255) NULL,	
	CorpTaxIDFingerprint varchar(255) NULL,
	OwnerTaxIDFingerprint varchar(255) NULL,
	EmailFingerprint        varchar(255) NULL    
FROM
    (
        SELECT 
            mcd.FDMSAccountNo,
            MAX(mcd.MRCH_STMT_MTH) MRCH_STMT_MTH
        FROM 
            BISME.MASSNFlat_MerchantControlData_RAA                     mcd 
            INNER JOIN BISME.MASSNFlat_MerchantAddressesDBA_RBB         dba ON (mcd.MRCH_STMT_MTH=dba.MRCH_STMT_MTH AND mcd.FDMSACCOUNTNO=dba.FDMSACCOUNTNO)
            -- SELECT * FROM BISME.MASSNFlat_MerchantAddressesDBA_RBB LIMIT 5000
            LEFT JOIN BISME.MASSNFlat_MerchantAddressesCorporate_RCC    cor ON (mcd.MRCH_STMT_MTH=cor.MRCH_STMT_MTH AND mcd.FDMSACCOUNTNO=cor.FDMSACCOUNTNO)
            -- SELECT * FROM BISME.MASSNFlat_MerchantAddressesCorporate_RCC LIMIT 5000
            -- SELECT * FROM BISME.MASSNFlat_BankEntitlement_RBE LIMIT 5000
        WHERE 
            mcd.Account_Status IN ('11','14','15','16')
            AND LTRIM(RTRIM(DBA_Name))!='' 
        GROUP BY 
            mcd.FDMSAccountNo
    ) aa
    INNER JOIN BISME.MASSNFlat_MerchantAddressesDBA_RBB bb ON (aa.FDMSAccountNo=bb.FDMSAccountNo AND aa.MRCH_STMT_MTH=bb.MRCH_STMT_MTH)
    --LEFT JOIN BISME.MASSNFlat_CardEntitlements_RII      cc ON (aa.FDMSAccountNo=cc.FDMSAccountNo AND aa.MRCH_STMT_MTH=cc.MRCH_STMT_MTH)
; 

;
SELECT * FROM ppbisandbox.millikan_MerchantDemographics WHERE Platform!='TSS' LIMIT 5000

;

---== IRvine's BBVA merchants ==---
SELECT
    *
FROM
    BISME.MASSOFlat_ControlData_R10 cd
WHERE
    cd.SYSTEM_NO || '/' || cd.PRINCIPLE_BANK = '5378/4900'  ---Exclude System 5378 and PRIN 4900 because this data belongs to Irvine/Meritus and is being reported by them under separte cover.
    AND MERCHANT_TYPE='R'
    AND ACCOUNT_STATUS=''
    AND MRCH_STMT_MTH='01-SEP-2020'
;       
SELECT * FROM BISME.MASSOFlat_Miscellaneous_R40 LIMIT 500
;
SELECT * FROM BISME.MASSOFlat_Miscellaneous2_R42 LIMIT 500
;
SELECT
    ms.MerchStmtMth,	
    ms.MerchantNumber,	
    ms.BilledAmount,
    mm.Platform,
    mm.DBA,
    rc.HoustonAgentNumber,
    rc.HoustonAgentDesc,
    rc.HoustonLevel1Code    "TopParentCode",
    rc.HoustonLevel1Desc    "TopParentDesc",
    HoustonLevel2Code,	
    HoustonLevel2Desc,	
    HoustonLevel3Code,	
    HoustonLevel3Desc,	
    HoustonLevel4Code,	
    HoustonLevel4Desc,	
    HoustonLevel5Code,	
    HoustonLevel5Desc,	
    HoustonLevel6Code,	
    HoustonLevel6Desc,	
    HoustonLevel7Code,	
    HoustonLevel7Desc
FROM
    ppbisandbox.millikan_RevenueMerchantMonthlyStatement    ms
    LEFT JOIN ppbisandbox.millikan_MerchantDemographics           mm ON (ms.MerchantNumber=mm.MerchantNumber)
    LEFT JOIN BI.ReportingChannels                          rc ON (LEFT(ms.MerchantNumber,15)=LEFT(rc.MerchantNumber,15))
WHERE
    ms.MerchStmtMth='9/1/2020'
    --AND rc.HoustonLevel1Code='1877'
    AND LEFT(ms.MerchantNumber,9)='422899490'  --4228994900099997
    --AND ms.BilledAmount!=0
;
SELECT * FROM BI.ReportingChannels WHERE LEFT(ms.MerchantNumber,9)='422899490' 
;

  

;
SELECT
    aa.MerchantNumber,
    rc.*
FROM    
    (
    SELECT
        DISTINCT cd.ACCOUNT_NO   MerchantNumber
    FROM
        BISME.MASSOFlat_ControlData_R10                 cd
        INNER JOIN BI.ReportingChannels                 rc ON (LEFT(cd.ACCOUNT_NO,15)=LEFT(rc.MerchantNumber,15))
    WHERE
        cd.MERCHANT_TYPE='H'
    ) aa LEFT JOIN  BI.ReportingChannels                 rc ON (LEFT(aa.MerchantNumber,15)=LEFT(rc.MerchantNumber,15))
;
SELECT * FROM BISME.SupplementalMIF_ApplicationRecord_Internal WHERE MERCHANT_SEQUENCE='4228997724139691' AND UNITYFILEDATE='11/4/2020 3:30:00 AM' LIMIT 500 
;
SELECT 
    DATE_CLOSED,
    DATE_OPEN,
    MERCHANT_TYPE,
    aa.*
FROM 
    BISME.SupplementalMIF_ApplicationRecord_Internal aa
    INNER JOIN 
    (   
        SELECT 
            MAX(UNITYFILEDATE) UNITYFILEDATE 
        FROM 
            BISME.SupplementalMIF_ApplicationRecord_Internal 
    ) bb ON (aa.UNITYFILEDATE=bb.UNITYFILEDATE)
WHERE
   MERCHANT_SEQUENCE='4228997700442689'
   --MERCHANT_TYPE NOT IN ('','R')
LIMIT 500
;      
SELECT ACCOUNT_NUMBER,* FROM BISME.MD032_Omaha WHERE ACCOUNT_NUMBER='4228997700442689'
;
SELECT MERCHANTNUMBERSPACEREMOVED,* FROM BISME.MD033_Omaha WHERE MERCHANTNUMBERSPACEREMOVED='4228997700442689'
;
MRCH_TYPE
SELECT MRCH_TYPE,* FROM BISME.MD033_Omaha WHERE MERCHANTNUMBERSPACEREMOVED='4228997700442689'
;
SELECT * FROM BISME.FF152_Omaha ff152
INNER JOIN (
SELECT
    DISTINCT 
    cd.ACCOUNT_NO   MerchantNumber,
    mm.DATE_OPEN
FROM
    BISME.MASSOFlat_ControlData_R10                 cd
    INNER JOIN BISME.MASSOFlat_Miscellaneous_R40    mm  ON (cd.MRCH_STMT_MTH=mm.MRCH_STMT_MTH AND cd.ACCOUNT_NO=mm.ACCOUNT_NO)
    --INNER JOIN BI.ReportingChannels                 rc ON (LEFT(cd.ACCOUNT_NO,15)=LEFT(rc.MerchantNumber,15))
WHERE
    cd.MERCHANT_TYPE!='R'
    ) aa ON (LEFT(ff152.MRCH_NO,15)=LEFT(aa.MerchantNumber,15))
;
;

;
    