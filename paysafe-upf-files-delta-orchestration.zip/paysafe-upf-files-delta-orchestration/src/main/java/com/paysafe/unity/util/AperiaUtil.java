package com.paysafe.unity.util;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.ppbi.model.AperiaLog;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class AperiaUtil extends DBUtil {

  public AperiaUtil(DBConnection dbConnection) throws DBQueryException {
    super(dbConnection);
  }

  /**
   * Fetches Aperia logs from lastRunId
   * 
   * @param LastRunId
   * @return List of AperiaLog
   * @throws DBQueryException
   */
  public List<AperiaLog> fetchLogs(Long lastRunId) throws SQLException, DBQueryException {
    List<AperiaLog> aperiaLogs = new ArrayList<>();
    String query = (lastRunId != null ? MessageFormat.format(DBConstants.FETCH_APERIA_LOGS, lastRunId.toString())
        : DBConstants.FETCH_ALL_APERIA_LOGS);
    logger.log(Level.INFO, "Executing query {0}", query);
    try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
      logger.log(Level.INFO, "Executed query {0} obtained result {1}", new Object[] {query, resultSet});
      while (resultSet.next()) {
        AperiaLog aperiaLog = convert(resultSet, AperiaLog.class);
        aperiaLogs.add(aperiaLog);
      }
    }
    return aperiaLogs;
  }

}
