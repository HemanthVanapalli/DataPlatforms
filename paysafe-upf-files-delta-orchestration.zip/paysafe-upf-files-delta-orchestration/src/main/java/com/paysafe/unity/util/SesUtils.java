// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2018. For more information see LICENSE

package com.paysafe.unity.util;

import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.RawMessage;
import com.amazonaws.services.simpleemail.model.SendRawEmailRequest;
import com.amazonaws.services.simpleemail.model.SendRawEmailResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paysafe.unity.ppbi.model.EmailSenderReceiver;
import com.paysafe.unity.ppbi.model.SesPayload;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SesUtils {

    private final Logger logger = Logger.getLogger(SesUtils.class.getName());
    private final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public void sendMail(SesPayload sesPayload) {
        try {
            String payloadString = OBJECT_MAPPER.writeValueAsString(sesPayload);
            logger.log(Level.INFO, "received ses payload " + payloadString);

            Session session = Session.getDefaultInstance(new Properties());
            MimeMessage message = new MimeMessage(session);

            // Add subject, sender and recipients.
            message.setSubject(sesPayload.getSubject(), "UTF-8");
            message.setFrom(new InternetAddress(sesPayload.getSender()));
            if (sesPayload.getRecipients() != null) {
                message.addRecipients(Message.RecipientType.TO, sesPayload.getRecipients());
            }
            if (sesPayload.getCc() != null) {
                message.addRecipients(Message.RecipientType.CC, sesPayload.getCc());
            }
            if (sesPayload.getBcc() != null) {
                message.addRecipients(Message.RecipientType.BCC, sesPayload.getBcc());
            }

            // Create a multipart/mixed container for body text and attachment
            MimeMultipart messageBody = new MimeMultipart("mixed");

            // Add the text and HTML parts to the container.
            messageBody.addBodyPart(getBodyPartText(sesPayload));

            // Add the message body container to the message.
            message.setContent(messageBody);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            message.writeTo(outputStream);
            RawMessage rawMessage = new RawMessage(ByteBuffer.wrap(outputStream.toByteArray()));

            SendRawEmailRequest rawEmailRequest = new SendRawEmailRequest(rawMessage);

            AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard().build();
            SendRawEmailResult result = client.sendRawEmail(rawEmailRequest);
            logger.log(Level.INFO, "ses email sent with message id: " + result.getMessageId());
        } catch (IOException | MessagingException exception) {
            logger.log(Level.SEVERE, "exception while sending ses raw email", exception);
            throw new RuntimeException("exception while sending ses raw email", exception);
        }
    }
    public void sendMailWithAttachment(SesPayload sesPayload, boolean attachment, ByteArrayOutputStream file) {
        try {
            String payloadString = OBJECT_MAPPER.writeValueAsString(sesPayload);
            logger.log(Level.INFO, "received ses payload " + payloadString);

            Session session = Session.getDefaultInstance(new Properties());
            MimeMessage message = new MimeMessage(session);

            // Add subject, sender and recipients.
            message.setSubject(sesPayload.getSubject().toString(), "UTF-8");
            message.setFrom(new InternetAddress(sesPayload.getSender()));
            if (sesPayload.getRecipients() != null) {
                message.addRecipients(Message.RecipientType.TO, sesPayload.getRecipients());
            }
            if (sesPayload.getCc() != null) {
                message.addRecipients(Message.RecipientType.CC, sesPayload.getCc());
            }
            if (sesPayload.getBcc() != null) {
                message.addRecipients(Message.RecipientType.BCC, sesPayload.getBcc());
            }

            // Create a multipart/mixed container for body text and attachment
            MimeMultipart messageBody = new MimeMultipart("mixed");

            MimeBodyPart bodyAttachmentPart = new MimeBodyPart();
            DataSource dataSource = new ByteArrayDataSource(file.toByteArray(), "application/vnd.ms-excel");
            bodyAttachmentPart.setDataHandler(new DataHandler(dataSource));

            bodyAttachmentPart.setFileName(dataSource.getName());
            logger.log(Level.INFO, "Attachment created  "+ dataSource.getName());

            // Add the text and HTML parts to the container.
            messageBody.addBodyPart(getBodyPartText(sesPayload));
            messageBody.addBodyPart(bodyAttachmentPart);

            // Add the message body container to the message.
            message.setContent(messageBody);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            message.writeTo(outputStream);
            RawMessage rawMessage = new RawMessage(ByteBuffer.wrap(outputStream.toByteArray()));

            SendRawEmailRequest rawEmailRequest = new SendRawEmailRequest(rawMessage);

            AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard().build();
            SendRawEmailResult result = client.sendRawEmail(rawEmailRequest);
            logger.log(Level.INFO, "ses email sent with message id: " + result.getMessageId());
        } catch (IOException | MessagingException exception) {
            logger.log(Level.SEVERE, "exception while sending ses raw email", exception);
            throw new RuntimeException("exception while sending ses raw email", exception);
        }
    }

    // Get body text and html as alternative options for message body text.
    private MimeBodyPart getBodyPartText(SesPayload sesPayload) throws MessagingException {
        // Define the text part.
        MimeBodyPart textPart = new MimeBodyPart();
        logger.log(Level.INFO, "body " + sesPayload.getBodyText());
        textPart.setContent(sesPayload.getBodyText(), "text/plain; charset=UTF-8");

        // Define the HTML part.
        MimeBodyPart htmlPart = new MimeBodyPart();
        htmlPart.setContent(sesPayload.getBodyHtml(), "text/html; charset=UTF-8");

        // Create a multipart/alternative container for body text/html parts.
        MimeMultipart bodyTextOptions = new MimeMultipart("alternative");

        // Add the text to the container.
        bodyTextOptions.addBodyPart(textPart);

        // Add the HTML parts to the container.
        bodyTextOptions.addBodyPart(htmlPart);

        // Create a wrapper for the HTML and text parts.
        MimeBodyPart bodyTextContainer = new MimeBodyPart();

        // Add the alternative container to the wrapper object.
        bodyTextContainer.setContent(bodyTextOptions);

        return bodyTextContainer;
    }

    public void sendSesMail(String Subject, String Body,String sesPath, boolean BusinessUser) {
        try {
            S3Util s3Util = new S3Util();
            EmailSenderReceiver emailSenderReceiver =
                    s3Util.getObjectFromJson(sesPath, EmailSenderReceiver.class);
            sendSesMail(Subject, Body, BusinessUser, emailSenderReceiver);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "exception while reading ses details", ex);
            throw new RuntimeException("exception while reading ses details", ex);
        }
    }

    public void sendSesMail(String Subject, String Body, boolean BusinessUser,
                            EmailSenderReceiver emailSenderReceiver) {
        try {
            SesPayload sesPayload = new SesPayload();
            sesPayload.setSender(emailSenderReceiver.getSender());

            if (BusinessUser && emailSenderReceiver.getBusinessReceiver() != null) {
                sesPayload.setRecipients(emailSenderReceiver.getNonBusinessReceiver() + ", " + emailSenderReceiver.getBusinessReceiver());
            } else {
                sesPayload.setRecipients(emailSenderReceiver.getNonBusinessReceiver());
            }
            logger.log(Level.SEVERE, "recipients are **", sesPayload.getRecipients());
            sesPayload.setCc(emailSenderReceiver.getCc());
            sesPayload.setSubject(Subject);
            String htmlBody = "<html><head></head><body><p>" + Body + "</p></body></html>";
            sesPayload.setBodyText("");
            sesPayload.setBodyHtml(htmlBody);
            sendMail(sesPayload);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "exception while reading ses details", ex);
            throw new RuntimeException("exception while reading ses details", ex);
        }
    }
}