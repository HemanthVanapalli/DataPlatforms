package com.paysafe.unity.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class LivyInput {

    private String usecase;
    private EmrDetails emrDetails;
    private LivyCommand livyCommand;
    private String jobName;
    private String configId;
    private Long timeoutSeconds = 10800L;

    public String getUsecase() {
        return usecase;
    }

    public void setUsecase(String usecase) {
        this.usecase = usecase;
    }

    public EmrDetails getEmrDetails() {
        return emrDetails;
    }

    public void setEmrDetails(EmrDetails emrDetails) {
        this.emrDetails = emrDetails;
    }

    public LivyCommand getLivyCommand() {
        return livyCommand;
    }

    public void setLivyCommand(LivyCommand livyCommand) {
        this.livyCommand = livyCommand;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public Long getTimeoutSeconds() {
        return timeoutSeconds;
    }

    public void setTimeoutSeconds(Long timeoutSeconds) {
        this.timeoutSeconds = timeoutSeconds;
    }

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }

}
