package com.paysafe.unity.constants;

public class SecretConstants {

  private SecretConstants() {

  }

  public static final String SECRET_KEY = "secretKey";

  public static final String DB_USER_KEY = "DBUser";

  public static final String DB_PASSWORD_KEY = "DBPassword";

}
