package com.paysafe.unity.service.helper;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.Pipeline;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DataSinkDeleteProcessor;
import com.paysafe.unity.service.impl.SparkEtlPipeLineDeleteProcessor;
import com.paysafe.unity.service.impl.VerticaPipeLineDeleteProcessor;

import java.util.logging.Logger;

public class DataSinkDeleteProcessorFactory {

  static final Logger logger = Logger.getLogger(DataSinkDeleteProcessorFactory.class.getName());

  private DataSinkInput dataSinkJobInput;
  private DBConnection connection;

  public DataSinkDeleteProcessorFactory(DataSinkInput dataSinkJobInput, DBConnection connection) {
    this.dataSinkJobInput = dataSinkJobInput;
    this.connection = connection;
  }

  public DataSinkDeleteProcessor getProcessor() throws DataSinkException, DBQueryException {

    Pipeline type = dataSinkJobInput.getPipeline();
    switch (type) {
    case VERTICA_PIPELINE:
      return new VerticaPipeLineDeleteProcessor(dataSinkJobInput, connection);
    case SPARK_ETL_FRAMEWORK:
      return new SparkEtlPipeLineDeleteProcessor(dataSinkJobInput, connection);
    default:
      throw new DataSinkException("No relevant pipeline found");
    }

  }
}
