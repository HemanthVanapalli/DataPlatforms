package com.paysafe.unity.lambda.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkEvent;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.FilesNotFoundException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DataSinkOutput;
import com.paysafe.unity.model.JobDetails;
import com.paysafe.unity.service.DataSinkConfiguration;
import com.paysafe.unity.service.DataSinkDeleteProcessor;
import com.paysafe.unity.service.DataSinkPipelineProcessor;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.helper.DataSinkDeleteProcessorFactory;
import com.paysafe.unity.service.helper.DataSinkPipelineProcessorFactory;
import com.paysafe.unity.service.helper.EventFPDataSinkJobProcessor;
import com.paysafe.unity.service.impl.DataSinkConfigurationImpl;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;
import com.paysafe.unity.util.VerticaUtil;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EventDataSinkRequestHandler {

  static final Logger logger = Logger.getLogger(EventDataSinkRequestHandler.class.getName());

  private DBConnection connection;
  private FileSystemConnector fileSystemConnector;
  private VerticaUtil verticaUtil;

  private DataSinkEvent event;

  public EventDataSinkRequestHandler(DataSinkEvent event) throws ClusterException, IOException, DBQueryException {
    this.event = event;
    AwsConnection awsConnection = new AwsConnection();

    fileSystemConnector = new S3Connector(awsConnection);

    AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

    InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

    CommonUtil commonUtil = new CommonUtil();

    Map<String, String> connProperties =
        commonUtil.fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

    connection = new DBConnection(connProperties);
    this.verticaUtil = new VerticaUtil(connection);

  }

  public DataSinkOutput handleRequest() throws Exception {
    DataSinkConfiguration configuration = new DataSinkConfigurationImpl(fileSystemConnector);
    DataSinkInput dataSinkInput = configuration.getPayload(event.getPayloadPath());
    logger.log(Level.INFO, "Processing dataSinkInput :: {0}", dataSinkInput);
    try {
      List<DataSinkConfig> processedConfigs = fetchFiles(dataSinkInput);
      deleteFiles(dataSinkInput, processedConfigs);
      DataSinkOutput dataSinkOutput = processFiles(dataSinkInput, processedConfigs);
      BeanUtils.copyProperties(dataSinkOutput, dataSinkInput);
      updateJarDetails(dataSinkOutput);
      logger.log(Level.INFO, "DataSinkOutput :: {0}", dataSinkOutput);
      return dataSinkOutput;
    } catch (Exception ex) {
      logger.log(Level.SEVERE, "Exception occured while running job ::" + ex.getMessage());
      upsertJobStatus(dataSinkInput, ex.getMessage());
      throw ex;
    }
  }

  private List<DataSinkConfig> fetchFiles(DataSinkInput dataSinkInput) throws Exception {
    EventFPDataSinkJobProcessor dataSinkJobProcessor = new EventFPDataSinkJobProcessor();
    List<DataSinkConfig> processedConfigs = dataSinkJobProcessor.fetchDeltaFiles(event);
    return processedConfigs;
  }

  private boolean deleteFiles(DataSinkInput dataSinkInput, List<DataSinkConfig> processedConfigs) throws Exception {
    DataSinkDeleteProcessorFactory dataSinkDeleteProcessorFactory =
        new DataSinkDeleteProcessorFactory(dataSinkInput, connection);
    DataSinkDeleteProcessor dataSinkDeleteProcessor = dataSinkDeleteProcessorFactory.getProcessor();
    return dataSinkDeleteProcessor.execute(processedConfigs);
  }

  private DataSinkOutput processFiles(DataSinkInput dataSinkInput, List<DataSinkConfig> processedConfigs)
      throws Exception {
    DataSinkOutput dataSinkOutput = new DataSinkOutput();
    DataSinkPipelineProcessorFactory dataSinkPipelineProcessorFactory =
        new DataSinkPipelineProcessorFactory(fileSystemConnector, dataSinkInput);
    DataSinkPipelineProcessor dataSinkPipelineProcessor = dataSinkPipelineProcessorFactory.getProcessor();
    List<DataSinkConfig> filteredConfigs = dataSinkPipelineProcessor.filter(processedConfigs);
    if (CollectionUtils.isEmpty(filteredConfigs)) {
      upsertJobStatus(dataSinkInput, "No Files to be processed");
      throw new FilesNotFoundException("No Files to be processed");
    }
    logger.log(Level.INFO, "Files found to run job");
    upsertJobStatus(filteredConfigs, dataSinkInput);
    List<JobDetails> jobDetails = dataSinkPipelineProcessor.generateOutputAndUploadToS3(filteredConfigs);
    dataSinkOutput.setJobDetails(jobDetails);
    dataSinkOutput.setRetryEnabled(event.isRetryEnabled());
    dataSinkOutput.setFiles(event.getFiles());
    dataSinkOutput.setConfigId(event.getConfigId());
    return dataSinkOutput;
  }

  private void updateJarDetails(DataSinkOutput dataSinkOutput) {
    String jar = dataSinkOutput.getLivyCommand().getFile();
    dataSinkOutput.getLivyCommand()
        .setFile(jar.replace(CommonConstants.ACCOUNTID_PLACEHOLDER, LambdaVariables.AWS_ACCOUNTID)
            .replace(CommonConstants.ENVIRONMENT_PLACEHOLDER, LambdaVariables.AWS_ENVIRONMENT));
  }

  public List<DataSinkConfig> upsertJobStatus(List<DataSinkConfig> processedConfigs, DataSinkInput dataSinkJobInput)
      throws SQLException, DBQueryException {

    for (DataSinkConfig config : processedConfigs) {
      verticaUtil.metaDataInsert(config, dataSinkJobInput);
    }
    return processedConfigs;
  }

  public void upsertJobStatus(DataSinkInput dataSinkInput, String reason) throws SQLException {
    verticaUtil.metaDataInsert(dataSinkInput, removeExtraCharacters(reason));
  }

  public String removeExtraCharacters(String reason) {
    if (reason == null || reason.isEmpty()) {
      return reason;
    }
    String value = reason.replaceAll("\n|\r|\n\r|\'|\"", "");
    if (value.length() > CommonConstants.MAX_CHARACTER_LENGTH) {
      return value.substring(0, CommonConstants.MAX_CHARACTER_LENGTH);
    } else {
      return value;
    }
  }

}
