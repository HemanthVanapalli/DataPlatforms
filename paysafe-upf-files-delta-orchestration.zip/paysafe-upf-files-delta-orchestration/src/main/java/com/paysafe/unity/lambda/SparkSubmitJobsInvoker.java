// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2020. For more information see LICENSE

package com.paysafe.unity.lambda;

import com.paysafe.gdp.fp.common.config.etl.EtlPipelineConfig;
import com.paysafe.gdp.fp.common.config.etl.File;
import com.paysafe.gdp.fp.common.config.etl.StorageType;
import com.paysafe.gdp.fp.common.payload.CronEvent;
import com.paysafe.gdp.fp.common.payload.EmrDetails;
import com.paysafe.gdp.fp.common.util.S3Util;
import com.paysafe.gdp.fp.common.util.SnsUtils;

import com.paysafe.unity.constants.AlertConstants;
import com.paysafe.unity.etl.model.MapStepInput;
import com.paysafe.unity.etl.model.SparkJobExecutionDetails;
import com.paysafe.unity.lambda.helper.JobsInvokerHelper;
import com.paysafe.unity.etl.model.JobsInvokerInput;
import com.paysafe.unity.etl.model.JobsInvokerStepFunctionPayload;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.databind.ObjectMapper;


import com.paysafe.unity.model.LivyCommand;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SparkSubmitJobsInvoker {

  private static final String SHARED_BLUE_BUCKET = "SHARED_BLUE_BUCKET";
  private static final String SHARED_GREY_BUCKET = "SHARED_GREY_BUCKET";
  private static final String BLUE_MM_BUCKET = "BLUE_MM_BUCKET";
  private static final String GREY_MM_BUCKET = "GREY_MM_BUCKET";
  private static final String BLUE_BI_BUCKET = "BLUE_BI_BUCKET";
  private static final String GREY_BI_BUCKET = "GREY_BI_BUCKET";
  private static final String ENVIRONMENT = "ENVIRONMENT";
  private static final String CURRENT_ZONE = "CURRENT_ZONE";
  private static final String CLUSTER_TAG = "CLUSTER_TAG";
  private static final String ALERT_SUBJECT = "ALERT_SUBJECT";
  private static final String SNS_TOPIC_ARN = "SNS_TOPIC_ARN";

  private static final String JOBS_CRON_CONFIGS_S3_LOCATION = "JOBS_CRON_CONFIGS_S3_LOCATION";

  private static final String BLUE_MM_BUCKET_PLACEHOLDER = "@mmBucketBlue";
  private static final String GREY_MM_BUCKET_PLACEHOLDER = "@mmBucketGrey";
  private static final String BLUE_BI_BUCKET_PLACEHOLDER = "@biBucketBlue";
  private static final String GREY_BI_BUCKET_PLACEHOLDER = "@biBucketGrey";
  private static final String BLUE_SHARED_BUCKET_PLACEHOLDER = "@sharedBucketBlue";
  private static final String GREY_SHARED_BUCKET_PLACEHOLDER = "@sharedBucketGrey";

  private static final String ENV = "@environment";
  private static final String YEAR = "@year";
  private static final String MONTH = "@month";
  private static final String DAY = "@day";

  private S3Util s3Util = JobsInvokerHelper.s3Util;

  private Map<String, String> props = new HashMap<>();
  private Logger logger = Logger.getLogger(JobsInvokerHelper.class.getName());

  public JobsInvokerStepFunctionPayload handleRequest(CronEvent cronEvent, Context context)
          throws IOException {
    String sharedBlueBucket = System.getenv(SHARED_BLUE_BUCKET);
    String sharedGreyBucket = System.getenv(SHARED_GREY_BUCKET);
    String mmBlueBucket = System.getenv(BLUE_MM_BUCKET);
    String mmGreyBucket = System.getenv(GREY_MM_BUCKET);
    String biBlueBucket = System.getenv(BLUE_BI_BUCKET);
    String biGreyBucket = System.getenv(GREY_BI_BUCKET);
    String environment = System.getenv(ENVIRONMENT);
    String clusterTag = System.getenv(CLUSTER_TAG);
    String snsSubjectName = System.getenv(ALERT_SUBJECT);
    String currentZone = System.getenv(CURRENT_ZONE);
    String snsTopicArn = System.getenv(SNS_TOPIC_ARN);


    String cronLocation = System.getenv(JOBS_CRON_CONFIGS_S3_LOCATION);

    JobsInvokerStepFunctionPayload jobsInvokerStepFunctionPayload = new JobsInvokerStepFunctionPayload();

    EmrDetails emrDetails = cronEvent.getEmrDetails();
    String masterPublicDnsName = cronEvent.getEmrDetails().getMasterPublicDnsName();
    String emrClusterId = cronEvent.getEmrDetails().getEmrClusterId();

    logger.log(Level.INFO,
            "checking the available emr with the masterPublicDnsName: {0} and emrClusterId {1}",
            new Object[] { masterPublicDnsName, emrClusterId });

    List<MapStepInput> configs = new ArrayList<>();

    jobsInvokerStepFunctionPayload.setEmrDetails(emrDetails);
    jobsInvokerStepFunctionPayload.setEnvironment(environment);
    jobsInvokerStepFunctionPayload.setClusterTag(clusterTag);
    jobsInvokerStepFunctionPayload.setAlertSubject(snsSubjectName);
    jobsInvokerStepFunctionPayload.setCurrentZone(currentZone);
    jobsInvokerStepFunctionPayload.setAwsSnsTopicArn(snsTopicArn);

    try {
      JobsInvokerInput jobInput =
              new S3Util().getObject(cronLocation + cronEvent.getSource(), JobsInvokerInput.class);

      SparkJobExecutionDetails sparkJobData = jobInput.getData();
      String sparkJobDataStr = new ObjectMapper().writeValueAsString(sparkJobData);
      sparkJobDataStr = sparkJobDataStr.replaceAll(BLUE_SHARED_BUCKET_PLACEHOLDER, sharedBlueBucket)
              .replaceAll(ENV, environment);
      sparkJobData = new ObjectMapper().readValue(sparkJobDataStr, SparkJobExecutionDetails.class);
      jobsInvokerStepFunctionPayload.setData(sparkJobData);

      String jobInputStr = new ObjectMapper().writeValueAsString(jobInput);
      jobInputStr = jobInputStr.replaceAll(BLUE_SHARED_BUCKET_PLACEHOLDER, sharedBlueBucket)
              .replaceAll(ENV, environment);
      jobInput = new ObjectMapper().readValue(jobInputStr, JobsInvokerInput.class);

      String day = new SimpleDateFormat("dd").format(new Date());
      String month = new SimpleDateFormat("MM").format(new Date());
      String year = new SimpleDateFormat("yyyy").format(new Date());



      for (MapStepInput sparkJobSteps : jobInput.getConfigList()) {
        String baseConfigPath = null;
        String configId = null;
        EtlPipelineConfig etlPipelineConfig =
                new S3Util().getObject(sparkJobSteps.getBaseConfig(), EtlPipelineConfig.class);
        String etlPipelineConfigStr = new ObjectMapper().writeValueAsString(etlPipelineConfig);
        String finalConfig = etlPipelineConfigStr.replaceAll(GREY_SHARED_BUCKET_PLACEHOLDER, sharedGreyBucket)
                .replaceAll(BLUE_SHARED_BUCKET_PLACEHOLDER, sharedBlueBucket)
                .replaceAll(BLUE_MM_BUCKET_PLACEHOLDER, mmBlueBucket)
                .replaceAll(GREY_MM_BUCKET_PLACEHOLDER, mmGreyBucket)
                .replaceAll(BLUE_BI_BUCKET_PLACEHOLDER, biBlueBucket)
                .replaceAll(GREY_BI_BUCKET_PLACEHOLDER, biGreyBucket)
                .replaceAll(MONTH, month).replaceAll(YEAR, year).replaceAll(DAY, day);;

        finalConfig = JobsInvokerHelper.updateCachePaths(finalConfig);
        finalConfig = JobsInvokerHelper.updateAppflowPaths(finalConfig);

        EtlPipelineConfig etlPipelineConfigNew = new ObjectMapper().readValue(finalConfig,EtlPipelineConfig.class);
        String appName = etlPipelineConfigNew.getAppName();
        Map<String, StorageType> inputs = etlPipelineConfigNew.getInputs();

        logger.log(Level.INFO, "Job invocation etl config ::{0}", finalConfig);
        baseConfigPath = sparkJobSteps.getBaseConfig();
        configId = baseConfigPath.substring(baseConfigPath.lastIndexOf('/') + 1);
        JobsInvokerHelper.putConfigInS3(jobInput.getOutputConfigsPath() + configId, finalConfig);
        configId = configId.split("\\.")[0];
        MapStepInput stepInput = new MapStepInput();
        stepInput.setConfigId(configId);
        stepInput.setFailFast(sparkJobSteps.isFailFast());
        stepInput.setJobType(sparkJobSteps.getJobType());
        stepInput.setOutputConfigPath(jobInput.getOutputConfigsPath());
        configs.add(stepInput);
      }
      jobsInvokerStepFunctionPayload.setConfigs(configs);
      jobsInvokerStepFunctionPayload.setDeleteStaging(jobInput.getDeleteStaging());

    } catch (IOException | RuntimeException e) {
      logger.log(Level.SEVERE, "Spark sumbit job invocation failed", e);
      new SnsUtils(environment, currentZone, AlertConstants.JOBS_INVOKER, AlertConstants.ERROR)
              .sendEmail(ExceptionUtils.getStackTrace(e), props, snsTopicArn);
      throw e;
    }

    return jobsInvokerStepFunctionPayload;
  }

}
