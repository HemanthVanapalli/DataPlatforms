package com.paysafe.unity.service;

import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DynamoQuery;

public interface DynamoQueryBuilder {

  public void buildKeyConditionExpression();

  public void buildFilterExpression();

  public void buildValueMap(DataSinkConfig config);

  public void buildIndex();

  public void buildTable();

  public DynamoQuery build();

}
