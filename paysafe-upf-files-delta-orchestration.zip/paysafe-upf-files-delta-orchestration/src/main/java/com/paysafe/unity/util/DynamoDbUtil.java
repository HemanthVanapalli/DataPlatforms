package com.paysafe.unity.util;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.model.FpMetaData;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DynamoDbUtil {

  private static final Logger logger = Logger.getLogger(DynamoDbUtil.class.getName());

  private DynamoDB dynamoDB;

  ObjectMapper mapper = new ObjectMapper();

  public DynamoDbUtil(AwsConnection connection) {

    this.dynamoDB = connection.dynamoConnection();

  }

  public List<FpMetaData> queryTable(DynamoQuery dynamoQuery) throws IOException {

    logger.log(Level.INFO, "Querying dynamo db for {0}", dynamoQuery);

    Table table = dynamoDB.getTable(dynamoQuery.getTable());

    Index index = table.getIndex(dynamoQuery.getIndex());

    QuerySpec spec = new QuerySpec().withKeyConditionExpression(dynamoQuery.getKeyConditionExpression())
        .withFilterExpression(dynamoQuery.getFilterExpression()).withScanIndexForward(true)
        .withValueMap(dynamoQuery.getValueMap());

    ItemCollection<QueryOutcome> items = index.query(spec);
    Iterator<Item> iter = items.iterator();

    List<FpMetaData> dynamoItems = new ArrayList<>();

    while (iter.hasNext()) {
      String doc = iter.next().toJSONPretty();

      FpMetaData fpMetaData = mapper.readValue(doc, FpMetaData.class);

      dynamoItems.add(fpMetaData);
    }

    logger.log(Level.INFO, "Fetched {0} items ", dynamoItems.size());

    return dynamoItems;

  }

}
