package com.paysafe.unity.service.helper;

import com.paysafe.unity.service.FileSystemConnector;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public abstract class AbstractFileSystemConnector implements FileSystemConnector {
  

  protected final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
      .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  public <T> T deserialize(String content,Class<T> valueType) throws JsonParseException, JsonMappingException, IOException{
    return OBJECT_MAPPER.readValue(content, valueType);
  }

}
