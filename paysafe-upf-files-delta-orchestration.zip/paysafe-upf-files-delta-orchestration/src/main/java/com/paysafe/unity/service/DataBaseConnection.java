package com.paysafe.unity.service;

import com.paysafe.unity.exception.DBQueryException;

import java.sql.Connection;

public interface DataBaseConnection {

  Connection getConnection() throws DBQueryException;
}
