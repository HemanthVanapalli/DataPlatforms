package com.paysafe.unity.etl.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.paysafe.gdp.fp.common.payload.EmrDetails;
import com.paysafe.unity.model.LivyCommand;
import java.util.List;

public class SparkJobExecutionDetails {
    @JsonProperty
    private String emrName;
    @JsonProperty
    private String usecase;
    @JsonProperty
    private LivyCommand livyCommand;
    @JsonProperty
    private String jobName;
    @JsonProperty
    private String timeoutSeconds;
    @JsonProperty
    private Boolean publishEvents;



    public String getEmrName() {
        return emrName;
    }

    public void setEmrName(String emrName) {
        this.emrName = emrName;
    }

    public String getUsecase() {
        return usecase;
    }

    public void setUsecase(String usecase) {
        this.usecase = usecase;
    }

    public LivyCommand getLivyCommand() {
        return livyCommand;
    }

    public void setLivyCommand(LivyCommand livyCommand) {
        this.livyCommand = livyCommand;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getTimeoutSeconds() {
        return timeoutSeconds;
    }

    public void setTimeoutSeconds(String timeoutSeconds) {
        this.timeoutSeconds = timeoutSeconds;
    }

    public Boolean getPublishEvents() {
        return publishEvents;
    }

    public void setPublishEvents(Boolean publishEvents) {
        this.publishEvents = publishEvents;
    }


}
