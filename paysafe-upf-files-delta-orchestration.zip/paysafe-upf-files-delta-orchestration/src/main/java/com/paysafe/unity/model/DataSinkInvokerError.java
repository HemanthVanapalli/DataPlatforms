package com.paysafe.unity.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class DataSinkInvokerError extends DataSink {

    private String payloadPath;

    private DataSinkInvokerErrorDetails errorDetails;

    public String getPayloadPath() {
        return payloadPath;
    }

    public void setPayloadPath(String payloadPath) {
        this.payloadPath = payloadPath;
    }

    public DataSinkInvokerErrorDetails getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(DataSinkInvokerErrorDetails errorDetails) {
        this.errorDetails = errorDetails;
    }


    @Override
    public String toString() {

        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
