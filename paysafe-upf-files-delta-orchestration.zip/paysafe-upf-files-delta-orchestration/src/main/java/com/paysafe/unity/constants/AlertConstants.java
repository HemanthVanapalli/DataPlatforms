// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2020. For more information see LICENSE

package com.paysafe.unity.constants;

public class AlertConstants {
  public static final String STEP_FUNCTION_INVOKE = "StepFunctionInvocation";
  public static final String YELLOW_ZONE = "Yellow";
  public static final String BLUE_ZONE = "Blue";
  public static final String GREY_ZONE = "Grey";
  public static final String ERROR = "ERROR";

  public static final String JOBS_INVOKER = "JobsInvoker";
  public static final String CRON_CHECKER = "SparkSubmitJobsCronChecker";

  public static final String CALL_RAIL_DATA_INGESTION = "CallRailDataIngestion";
  private AlertConstants() {

  }
}
