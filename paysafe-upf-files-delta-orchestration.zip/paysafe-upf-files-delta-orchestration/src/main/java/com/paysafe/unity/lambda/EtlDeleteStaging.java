// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2018. For more information see LICENSE

package com.paysafe.unity.lambda;

import com.paysafe.gdp.fp.common.config.etl.CleanupConfig;
import com.paysafe.gdp.fp.common.config.etl.StagingDelete;
import com.paysafe.gdp.fp.common.util.S3Util;
import com.paysafe.unity.etl.model.JobsInvokerInput;

import com.paysafe.unity.etl.model.StagingUtils;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import java.util.logging.Level;
import java.util.logging.Logger;

public class EtlDeleteStaging
        implements RequestHandler<StagingDelete, StagingDelete> {
    private static Logger logger = Logger.getLogger(EtlDeleteStaging.class.getName());
    private static final String DOT_JSON = ".json";

    @Override
    public StagingDelete handleRequest(StagingDelete deleteStagingDetails, Context context) {
        String currentZone=null;
        try {
            StagingUtils stagingUtils = new StagingUtils();


            logger.log(Level.INFO, "delete config ::{0}", deleteStagingDetails);

            if (deleteStagingDetails != null) {
                if (deleteStagingDetails.getBlue() != null) {
                    currentZone = "BLUE";
                }
                else if (deleteStagingDetails.getGrey() != null) {
                    currentZone = "GREY";
                }
                else if (deleteStagingDetails.getYellow() != null) {
                    currentZone = "YELLOW";
                }
                stagingUtils.executeDeleteStaging(currentZone, deleteStagingDetails);
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Deletion from staging encountered error: ", e);
            throw new RuntimeException(e);
        }
        return deleteStagingDetails;
    }
}
