package com.paysafe.unity.util;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.exception.DBQueryException;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBUtil {

    static final Logger logger = Logger.getLogger(DBUtil.class.getName());

    protected Connection connection;

    public DBUtil(DBConnection dbConnection) throws DBQueryException {
        this.connection = dbConnection.getConnection();
    }

    /**
     * Convert Resultset into given class
     *
     * @param ResultSet
     * @param Class
     */
    public <T> T convert(ResultSet rs, Class<T> clazz) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int columns = md.getColumnCount();
        Map<String, Object> row = new HashMap<>(columns);
        for (int i = 1; i <= columns; ++i) {
            row.put(md.getColumnName(i), rs.getObject(i));
        }
        return CommonConstants.MAPPER.convertValue(row, clazz);
    }

    /**
     * Executes queries using connection
     *
     * @param query
     * @return boolean
     */
    public boolean executeQueries(List<String> queries) throws SQLException {
        connection.setAutoCommit(false);
        logger.log(Level.INFO, "Executing queries {0}", queries);
        try (Statement stmt = connection.createStatement()) {
            for (String query : queries) {
                stmt.addBatch(query);
            }
            int[] insertedRows = stmt.executeBatch();
            connection.commit();
            logger.log(Level.INFO, "Inserted {0} rows for query count {1}", new Object[]{insertedRows, queries.size()});
        } catch (Exception e) {
            connection.rollback();
            throw e;
        }
        connection.setAutoCommit(true);
        return true;
    }

    /**
     * Executes query using connection
     *
     * @param query
     * @return boolean
     */
    public boolean executeQuery(String query) throws SQLException {
        connection.setAutoCommit(false);
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            int insertedRows = stmt.executeUpdate();
            connection.commit();
            logger.log(Level.INFO, "Inserted {0} rows for query {1}", new Object[]{insertedRows, query});
        }
        connection.setAutoCommit(true);
        return true;
    }

    public List<Map<String, Object>> fetchRows(String query) throws Exception {
        logger.log(Level.INFO, "Executing query {0}", query);
        List<Map<String, Object>> rows = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet =
                stmt.executeQuery();) {
            ResultSetMetaData md = resultSet.getMetaData();
            int columns = md.getColumnCount();
            while (resultSet.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columns; ++i) {
                    if (resultSet.getObject(i) != null)
                        row.put(md.getColumnName(i).toUpperCase(), resultSet.getObject(i));
                }
                if (!row.isEmpty()) rows.add(row);
            }
        }
        logger.log(Level.INFO, "Executed query {0} obtained result {1}", new Object[]{query,
                rows.size()});
        if (rows.isEmpty()) return null;
        return rows;
    }


}
