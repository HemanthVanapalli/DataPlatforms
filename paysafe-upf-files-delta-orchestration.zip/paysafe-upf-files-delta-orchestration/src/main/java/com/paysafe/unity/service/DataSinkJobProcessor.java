package com.paysafe.unity.service;

import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;

import java.sql.SQLException;
import java.util.List;

public interface DataSinkJobProcessor {

  public List<DataSinkConfig> constructDataSinkConfig(List<String> configIds) throws DBQueryException, SQLException;

  public List<DataSinkConfig> fetchDeltaFiles(List<DataSinkConfig> configs) throws Exception;

}
