package com.paysafe.unity.service.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.VerticaMetaData;
import com.paysafe.unity.service.FileSystemConnector;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class VerticaDataSinkJobProcessor extends AbstractDataSinkJobProcessor {

  private static final Logger logger = Logger.getLogger(VerticaDataSinkJobProcessor.class.getName());

  public VerticaDataSinkJobProcessor(FileSystemConnector connector, DBConnection connection,
      DataSinkInput dataSinkJobInput, AwsConnection awsConnection) throws DBQueryException {
    super(connector, connection, dataSinkJobInput, awsConnection);
    logger.log(Level.INFO, "Initialization VerticaDataSinkJobProcessor");
  }

  @Override
  public List<DataSinkConfig> fetchDeltaFiles(List<DataSinkConfig> configs) throws Exception {

    String queries = configs.stream().map(config -> {
      return MessageFormat.format(DBConstants.FETCH_DELTA_FILES, config.getConfigId(), config.getLastRunDate(),
          dataSinkJobInput.getSrcType(), dataSinkJobInput.getJobType());
    }).collect(Collectors.joining(" UNION ALL ")) + "ORDER BY CONFIGID , LASTRUN; ";

    Map<String, List<VerticaMetaData>> deltaFiles = verticaUtil.fetchDeltaFiles(queries);
    if (MapUtils.isNotEmpty(deltaFiles)) {

      configs.stream().forEach(config -> {
        try {
          List<VerticaMetaData> metadataEntries = deltaFiles.get(config.getConfigId());
          if (CollectionUtils.isNotEmpty(metadataEntries)) {
            List<String> archivedFiles = new ArrayList<>();
            List<String> rollbackFiles = new ArrayList<>();
            metadataEntries.forEach(metadata -> {
              if (StringUtils.isNotBlank(metadata.getArchivedFiles())) {
                archivedFiles.addAll(
                    Stream.of(metadata.getArchivedFiles().split(",")).map(String::trim).collect(Collectors.toList()));
              }
              if (StringUtils.isNotBlank(metadata.getRollbackFiles())) {
                rollbackFiles.addAll(
                    Stream.of(metadata.getRollbackFiles().split(",")).map(String::trim).collect(Collectors.toList()));
              }
            });
            config.setArchivedFiles(archivedFiles.stream().distinct().collect(Collectors.toList()));
            config.setRollbackFiles(rollbackFiles.stream().distinct().collect(Collectors.toList()));
            config.setCurrentRunDate(metadataEntries.get(metadataEntries.size() - 1).getLastRun());
          }

          logger.log(Level.INFO, "List of delta files for processing :: {0} ", configs);
        } catch (Exception e) {
          throw new RuntimeException(e);
        }
      });

    }

    return configs;
  }

}
