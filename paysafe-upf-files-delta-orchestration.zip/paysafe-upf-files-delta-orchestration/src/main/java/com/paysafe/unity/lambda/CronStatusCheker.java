// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2020. For more information see LICENSE

package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.paysafe.gdp.fp.common.util.S3Util;
import com.paysafe.gdp.fp.common.util.SnsUtils;
import com.paysafe.unity.constants.AlertConstants;
import com.paysafe.unity.model.CronInput;
import com.paysafe.unity.model.Cron;

import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CronStatusCheker {
    private static final String CRON_STATUS_CONFIG_S3_LOCATION = "CRON_STATUS_CONFIG_S3_LOCATION";
    private static final String CRONEVENT = "Cron";
    private static final String SNS_TOPIC_ARN = "SNS_TOPIC_ARN";
    private static final String ENVIRONMENT = "ENVIRONMENT";
    private static final String CURRENT_ZONE = "CURRENT_ZONE";

    private Map<String, String> props = new HashMap<>();
    private Logger logger = Logger.getLogger(CronStatusCheker.class.getName());

    public Cron handleRequest(CronInput cronInput, Context context) throws IOException {
        String cronLocation = System.getenv(CRON_STATUS_CONFIG_S3_LOCATION);
        String environment = System.getenv(ENVIRONMENT);
        String snsTopicArn = System.getenv(SNS_TOPIC_ARN);
        String currentZone = System.getenv(CURRENT_ZONE);

        props.put(CRONEVENT, cronInput.toString());

        logger.log(Level.INFO, "cronLocation: {0}", new Object[] { cronLocation });

        Cron cron = null;

        try {
            cron = new S3Util().getObject(cronLocation + cronInput.getCronName(), Cron.class);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Couldn't get cron status", e);
            new SnsUtils(environment, currentZone, AlertConstants.CRON_CHECKER, AlertConstants.ERROR).sendEmail(ExceptionUtils.getStackTrace(e), props,
                    snsTopicArn);
            throw e;
        }
        return cron;
    }
}
