// All Rights Reserved, Copyright � Paysafe Holdings UK Limited 2018. For more information see LICENSE 

package com.paysafe.unity.util;

import com.paysafe.unity.AwsConnection;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AwsSecretsUtil {

  private final AWSSecretsManager client;
  private static final Logger logger = Logger.getLogger(AwsSecretsUtil.class.getName());

  public AwsSecretsUtil(AwsConnection awsConnection) {
    this.client = awsConnection.getSecretManager();
  }

  @SuppressWarnings("unchecked")
  public Map<String, String> getSecretsMap(String secretName) {

    Gson gson = new Gson();
    GetSecretValueRequest getSecretValueRequest = new GetSecretValueRequest().withSecretId(secretName);
    GetSecretValueResult getSecretValueResult = null;
    Map<String, String> secretsMap = new HashMap<String, String>();

    try {
      getSecretValueResult = client.getSecretValue(getSecretValueRequest);
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Error while getting secret", e);
      throw e;
    }

    if (getSecretValueResult == null) {
      logger.log(Level.SEVERE, "No secrets present in the Secret manager");
      return secretsMap;
      // return custom exception here todo
    }

    // Decrypts secret using the associated KMS CMK.
    // Depending on whether the secret is a string or binary, one of these
    // fields
    // will be populated.
    secretsMap = getSecretValueResult.getSecretString() == null
        ? (Map<String, String>) gson.fromJson(getSecretValueResult.getSecretBinary().toString(), secretsMap.getClass())
        : (Map<String, String>) gson.fromJson(getSecretValueResult.getSecretString(), secretsMap.getClass());
    return secretsMap;

  }
}