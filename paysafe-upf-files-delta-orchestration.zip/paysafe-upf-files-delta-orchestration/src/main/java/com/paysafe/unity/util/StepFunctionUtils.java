package com.paysafe.unity.util;

import com.amazonaws.services.stepfunctions.AWSStepFunctions;
import com.amazonaws.services.stepfunctions.AWSStepFunctionsClientBuilder;
import com.amazonaws.services.stepfunctions.model.StartExecutionRequest;
import com.amazonaws.services.stepfunctions.model.StartExecutionResult;

import java.util.logging.Logger;

public class StepFunctionUtils {

  private static final Logger logger = Logger.getLogger(StepFunctionUtils.class.getName());

  private static final AWSStepFunctions awsStepFunctions = AWSStepFunctionsClientBuilder.defaultClient();

  public static void startExecution(String stepFunctionArn, String input) {
    try {

      StartExecutionRequest startExecutionRequest = new StartExecutionRequest();
      startExecutionRequest.setInput(input);
      startExecutionRequest.setStateMachineArn(stepFunctionArn);

      logger.info("Starting stepfunction API for " + stepFunctionArn + " , " + input);

      StartExecutionResult startExecutionResult = awsStepFunctions.startExecution(startExecutionRequest);
      logger.info("Response obtained from startExecution API for " + startExecutionRequest + " :: "
          + startExecutionResult);

    } catch (Exception e) {
      logger.severe("Exception occured while starting step function for:: " + stepFunctionArn + " , " + input);
      throw new RuntimeException(e);
    }

  }

}

