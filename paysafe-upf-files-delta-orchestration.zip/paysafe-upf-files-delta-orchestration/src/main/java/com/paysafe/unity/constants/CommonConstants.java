package com.paysafe.unity.constants;

import com.paysafe.unity.util.NullAwareBeanUtilsBean;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public class CommonConstants {

  private CommonConstants() {

  }

  public static final String DOT = ".";
  public static final String EQUALS = "=";

  public static final String COMMA_SEPARATOR = ",";

  public static final String S3 = "s3://";

  public static final String NEWLINE = "\n";

  public static final String SPACE = " ";
  public static final String OPEN_BRACES = "(";
  public static final String SEMI_COLON = ";";
  public static final String CLOSE_BRACES = ")";
  public static final String QUESTION_MARK = "?";
  public static final String SINGLE_QUOTES = "'";

  public static final String PATH_DELIMITER = "/";
  public static final String DOT_JSON = ".json";
  public static final String INFRASTRUCTURE = "infrastructure";
  public static final String HYPHEN = "-";
  public static final String UNDERSCORE = "_";

  public static final String FAILED = "FAILED";
  public static final String SUCCESS = "SUCCESS";

  public final static String VERTICA_PIPELINE = "VERTICA-PIPELINE";
  public static final String FILENAME_PREFIX = "FILENAME=";

  public static final String UNITYFILENAME_PREFIX = "UNITYFILENAME=";

  public static final String AWS = "AWS";

  public static final ObjectMapper MAPPER = getObjectMapper();

  public static final NullAwareBeanUtilsBean BEAN_UTILS = new NullAwareBeanUtilsBean();

  public static final String ROLLBACKED_STATUS = "ROLLBACKED";

  public static final String FP_JOB_ARCHIEVED_STATUS = "ARCHIVED";

  public static final String FP_JOB_FOREXED_STATUS = "FOREXED";

  public static final String ERROR = "ERROR";

  public static final String ACCOUNTID_PLACEHOLDER = "{ACCOUNTID}";

  public static final String CONFIGID_PLACEHOLDER = "{CONFIGID}";

  public static final String ENVIRONMENT_PLACEHOLDER = "{ENVIRONMENT}";

  public static final String FILENAME = "FILENAME";

  public static final String UNITYFILENAME = "UNITYFILENAME";

  public static final String TRACINGID = "TRACINGID";

  public static final String PPBI_CONFIGS = "ppbi-unity/configs/usAcquiring";

  public static final String DATA_SINK_JOB_STATUS_SCHEMA = "ppbi";

  public static final String DATA_SINK_JOB_STATUS_TABLE = "DATA_SINK_JOB";

  public static final String DATA_SINK_AUDIT_SCHEMA = "ppbi";

  public static final String DATA_SINK_AUDIT_TABLE = "DATA_SINK_JOB_DETAILS";

  public static final String DATA_SINK_METADATA_SCHEMA = "ppbi";

  public static final String DATA_SINK_METADATA_LOG_SCHEMA = "ppbi";

  public static final String DATA_SINK_CONFIG_TABLE = "data_sink_config";

  public static final String VERTICA_DRIVER_CLASS = "com.vertica.jdbc.Driver";

  public static final String VERTICA_SPARK_CONNECTOR = "com.vertica.spark.datasource.DefaultSource";

  public static final String SCHEMA = "dbschema";

  public static final String DB_HOST = "host";

  public static final String DB_USER = "user";

  public static final String DB_PASSWORD = "password";

  public static final String DATABASE_NAME = "db";

  public static final String US_ACQUIRING = "USACQUIRING";

  public static final int MAX_CHARACTER_LENGTH = 64000;

  public static final String FP_UNITY = "FP-UNITY";

  public static final String FILENAMES_PATH = "pipeline-unity/input/filenames/";

  private static ObjectMapper getObjectMapper() {
    final ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    return objectMapper;
  }

  public static <T> T convertValue(String content, Class<T> configClass) throws IOException {
    return MAPPER.readValue(content, configClass);
  }

}
