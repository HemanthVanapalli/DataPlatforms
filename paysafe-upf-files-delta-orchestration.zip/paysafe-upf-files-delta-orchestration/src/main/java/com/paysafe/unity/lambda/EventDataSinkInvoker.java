package com.paysafe.unity.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.exception.FilesNotFoundException;
import com.paysafe.unity.model.DataSinkEvent;
import com.paysafe.unity.lambda.helper.EventDataSinkRequestHandler;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DataSinkOutput;
import com.paysafe.unity.service.DataSinkConfiguration;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.DataSinkConfigurationImpl;
import com.paysafe.unity.service.impl.S3Connector;

import com.amazonaws.services.lambda.runtime.Context;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class EventDataSinkInvoker {

  private static final Logger LOGGER = Logger.getLogger(EventDataSinkInvoker.class.getName());

  Map<String, String> buConfigMap;

  public EventDataSinkInvoker() {
    this.buConfigMap = new HashMap<>();
    buConfigMap.put("cardIssuing", "/verticapipeline/DATASINK_INVOKER_CARDISSUING.json");
    buConfigMap.put("canAcquiring", "/verticapipeline/DATASINK_INVOKER_CARDISSUING.json");
    buConfigMap.put("cardIssuing", "/verticapipeline/DATASINK_INVOKER_CARDISSUING_MARQUETA.json");
    buConfigMap.put("ukAcquiring", "/sparketlframework/DATASINK_INVOKER_RS2DATAMODELING.json");
    buConfigMap.put("usAcquiring", "/verticapipeline/DATASINK_INVOKER_PPBI.json");
    buConfigMap.put("MASS_FLAT_1", "/verticapipeline/DATASINK_INVOKER_MASS_FLAT_FILES_SET1.json");
    buConfigMap.put("MASS_FLAT_2", "/verticapipeline/DATASINK_INVOKER_MASS_FLAT_FILES_SET2.json");
    buConfigMap.put("MASS_FLAT_3", "/verticapipeline/DATASINK_INVOKER_MASS_FLAT_FILES_SET3.json");
    buConfigMap.put("MASS_FLAT_4", "/verticapipeline/DATASINK_INVOKER_MASS_FLAT_FILES_SET4.json");
  }

  public DataSinkOutput handleRequest(DataSinkEvent event, Context context) throws Exception {

    LOGGER.log(Level.INFO, "Event:  {0}", event);

    AwsConnection awsConnection = new AwsConnection();

    FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

    String srcBucket = System.getenv("SRC_BUCKET");
    String zone = System.getenv("AWS_ZONE");

    String payloadPathPrefix = "s3://" + srcBucket + "/pipeline-unity/cloudwatch/events/eventdriven/" + zone;
    String suffix = buConfigMap.get(event.getConfigId().split("_")[1]);
    if (suffix == null) {
      LOGGER.log(Level.SEVERE, "No mapping found for {0}", event.getConfigId());
      throw new RuntimeException("No mapping found for " + event.getConfigId());
    }
    event.setPayloadPath(payloadPathPrefix + suffix);
    DataSinkConfiguration configuration = new DataSinkConfigurationImpl(fileSystemConnector);
    DataSinkInput dataSinkInput = configuration.getPayload(event.getPayloadPath());
    if (dataSinkInput != null && dataSinkInput.getConfigIds() != null &&
        !dataSinkInput.getConfigIds().contains(event.getConfigId())) {
      LOGGER.log(Level.SEVERE, "config Id not found " + event.getConfigId() + " in the list from source " + event.getPayloadPath());
      throw new FilesNotFoundException("config Id not found " + event.getConfigId() + " in the list from source " + event
       .getPayloadPath());
    }
    String files = event.getFiles();
    if (files != null && !files.isEmpty()) {
      event.setFiles(files.replaceAll("FILENAME=", "").replaceAll("/", ""));
    }

    LOGGER.log(Level.INFO, "Event:  {0}", event);
    EventDataSinkRequestHandler dataSinkRequestHandler = new EventDataSinkRequestHandler(event);

    return dataSinkRequestHandler.handleRequest();

  }

}
