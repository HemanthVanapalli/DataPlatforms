package com.paysafe.unity.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.lambda.helper.DataSinkRequestHandler;
import com.paysafe.unity.model.DataSinkOutput;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;

import com.amazonaws.services.lambda.runtime.Context;

import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSinkInvoker {

  private static final Logger LOGGER = Logger.getLogger(DataSinkInvoker.class.getName());

  public DataSinkOutput handleRequest(String inputPayloadPath, Context context) throws Exception {

    LOGGER.log(Level.INFO, "inputPayloadPath:  {0}", inputPayloadPath);

    AwsConnection awsConnection = new AwsConnection();

    FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

    AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

    InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

    CommonUtil commonUtil = new CommonUtil();

    Map<String, String> connProperties =
        commonUtil.fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

    DBConnection connection = new DBConnection(connProperties);

    DataSinkRequestHandler dataSinkRequestHandler =
        new DataSinkRequestHandler(inputPayloadPath, fileSystemConnector, connection, awsConnection);

    return dataSinkRequestHandler.handleRequest();

  }

}
