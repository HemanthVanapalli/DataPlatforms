package com.paysafe.unity.service.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DataSinkJobProcessor;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.util.DateUtil;
import com.paysafe.unity.util.VerticaUtil;

import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class AbstractDataSinkJobProcessor implements DataSinkJobProcessor {
  protected FileSystemConnector connector;
  protected DataSinkInput dataSinkJobInput;
  protected VerticaUtil verticaUtil;

  private static final Logger logger = Logger.getLogger(AbstractDataSinkJobProcessor.class.getName());

  public AbstractDataSinkJobProcessor(FileSystemConnector connector, DBConnection connection,
      DataSinkInput dataSinkJobInput, AwsConnection awsConnection) throws DBQueryException {
    this.connector = connector;
    this.dataSinkJobInput = dataSinkJobInput;
    this.verticaUtil = new VerticaUtil(connection);
  }

  @Override
  public List<DataSinkConfig> constructDataSinkConfig(List<String> configIds) throws DBQueryException, SQLException {

    List<DataSinkConfig> sinkConfigList = verticaUtil.getConfigLastSuccessDate(configIds,
        dataSinkJobInput.getJobType().getVal(), dataSinkJobInput.getUsecase());

    List<String> missedConfigs = new ArrayList<>();
    missedConfigs.addAll(configIds);
    sinkConfigList.stream().forEach(dataSinkConfig -> missedConfigs.remove(dataSinkConfig.getConfigId()));
    String defaultTimeUtc =
        DateUtil.getUTCString(DateUtil.minusDuration(Duration.ofDays(dataSinkJobInput.getWindow())));

    for (String configId : missedConfigs) {
      DataSinkConfig dataSinkConfig = new DataSinkConfig(configId);
      dataSinkConfig.setLastRunDate(defaultTimeUtc);
      sinkConfigList.add(dataSinkConfig);
    }

    logger.log(Level.INFO, "List of config Ids for processing :: {0} ", sinkConfigList);
    return sinkConfigList;

  }

}
