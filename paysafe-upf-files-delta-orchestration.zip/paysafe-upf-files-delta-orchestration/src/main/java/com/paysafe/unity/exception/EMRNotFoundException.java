package com.paysafe.unity.exception;

public class EMRNotFoundException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -8938203219605534985L;

  public EMRNotFoundException(String message) {
    super(message);
  }

  public EMRNotFoundException(String message, Throwable cause) {
    super(message, cause);

  }

  public EMRNotFoundException(Throwable cause) {
    super(cause);

  }

}
