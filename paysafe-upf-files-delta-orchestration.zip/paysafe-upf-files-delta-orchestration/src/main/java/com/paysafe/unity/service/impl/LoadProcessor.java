package com.paysafe.unity.service.impl;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DynamoQueryBuilder;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.helper.FPDataSinkJobProcessor;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoadProcessor extends FPDataSinkJobProcessor {

  private static final Logger logger = Logger.getLogger(LoadProcessor.class.getName());

  public LoadProcessor(FileSystemConnector connector, DBConnection connection, DataSinkInput dataSinkJobInput,
      AwsConnection awsConnection) throws DBQueryException {
    super(connector, connection, dataSinkJobInput, awsConnection);
    logger.log(Level.INFO, "Initialization LoadProcesser");
  }

  @Override
  public DynamoQueryBuilder getDynamoQueryBuilder() {
    return new LoadDynamoQueryBuilder(dataSinkJobInput);
  }

}
