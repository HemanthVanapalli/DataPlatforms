package com.paysafe.unity.constants;

public interface DBConstants {

    public static final String CONFIGID_MAX_DATE =
            " SELECT STATUS.CONFIGID, MAX(STATUS.LASTRUN)  AS LASTRUNDATE FROM ppbi.DATA_SINK_JOB STATUS WHERE STATUS.STATUS = ''SUCCESS'' AND STATUS.CONFIGID in ( {0} ) AND STATUS.JOBTYPE=''{1}'' AND STATUS.USECASE = ''{2}'' GROUP BY STATUS.CONFIGID ";

    public static final String FETCH_DELTA_FILES =
            "select configId,archivedFiles,rollbackFiles,lastRun,jobType from ppbi.DATA_SINK_JOB where configId = ''{0}'' and lastRun > ''{1}'' and useCase = ''{2}'' and jobType = ''{3}'' and status = ''SUCCESS'' and lastRun <> ''null'' ";

    public static final String DATA_SINK_STATUS_INSERT_NO_FILES_FOUND =
            "INSERT INTO ppbi.DATA_SINK_JOB (CONFIGID,JOBTYPE,USECASE,REASON,LASTRUN,STATUS) VALUES (''{0}'',''{1}'' ,''{2}'',''{3}'',''{4}'',''SUCCESS'')";

    public static final String DATA_SINK_STATUS_INSERT =
            "INSERT INTO ppbi.DATA_SINK_JOB (CONFIGID,ARCHIVEDFILES,ROLLBACKFILES,STATUS,LASTRUN,JOBTYPE,USECASE) VALUES (''{0}'',''{1}'' ,''{2}'',''{3}'',''{4}'',''{5}'',''{6}'')";

    public static final String DATA_SINK_STATUS_UPDATE =
            "UPDATE ppbi.DATA_SINK_JOB SET STATUS = ''{1}'' , APPLICATIONID = ''{2}'' , CLUSTERID = ''{3}'', REASON = ''{4}'' WHERE ID in ( {0} )";

    public static final String APERIA_LOG_LAST_RUN_ID = " SELECT MAX(EVENTID) AS ID FROM ppbi.APERIA_LOG_AUDIT ;";

    public static final String FETCH_APERIA_LOGS =
            "SELECT TOP 1000 * FROM PAYSAFEBI.dbo.Paysafe_BI_FileActivityLog WHERE EventID  > {0} ORDER BY EventID;";

    public static final String FETCH_ALL_APERIA_LOGS =
            "SELECT TOP 1000 * FROM PAYSAFEBI.dbo.Paysafe_BI_FileActivityLog ORDER BY EventID;";

    public static final String INSERT_APERIA_LOGS_INTO_TEMPTABLE =
            "INSERT INTO PAYSAFE_BI_FILEACTIVITYLOG_TEMP ({0}) values({1})";

    public static final String INSERT_APERIA_LOG_AUDIT =
            "INSERT INTO ppbi.APERIA_LOG_AUDIT (EVENTID,UPDATEDON) values(''{0}'',TRANSACTION_TIMESTAMP())";

    public static final String CREATE_TEMPORARY_APERIA_LOG_TABLE =
            "CREATE LOCAL TEMP TABLE PAYSAFE_BI_FILEACTIVITYLOG_TEMP( EVENTID int NOT NULL, INSERTDATETIMEUTC timestamp, LOGLEVEL varchar(250), LOGENTRYTYPE varchar(250), FILENAME varchar(250), BUSINESSUNIT varchar(250), REPORTNAME varchar(250), USERNAME varchar(250), HOST varchar(250), ELAPSEDTIMESECONDS varchar(250), DESCRIPTION varchar(250), KILOBYTES varchar(250), ROWCOUNT varchar(250), VALIDRECORDCOUNT varchar(250), INVALIDRECORDCOUNT varchar(250),ORIGINALFILENAME varchar(250)) ; ";

    public static final String COPY_APERIA_LOGS_FROM_TEMP_TABLE =
            "INSERT into ppbi.PAYSAFE_BI_FILEACTIVITYLOG select * from PAYSAFE_BI_FILEACTIVITYLOG_TEMP ;";

    public static final String ORACLE_MIF_LOG_LAST_PROCESS_DATE = " SELECT MAX(PROCESS_DATE) AS ID FROM ppbi.ORACLE_MIF_LOG_AUDIT  ;";

    public static final String FETCH_ORACLE_MIF_LOGS = "SELECT i.interface_name, ie.process_date, ie.file_name, ie.creation_date, ied.task_code, ied.task_status, ied.start_date, ied.end_date, ied.total_rec_processed,  ied.total_rec_rejected, ied.error_msg, ied.log_msg FROM xxdcs.xxdcs_interface i, xxdcs.xxdcs_intf_entry ie, xxdcs.xxdcs_intf_entry_detail ied WHERE i.file_name_prefix LIKE ''Paysafe_SupplementalMIF%'' AND i.interface_id = ie.interface_id AND ie.intf_entry_id = ied.intf_entry_id AND ie.process_date > ''{0}''";

    public static final String FETCH_ALL_ORACLE_MIF_LOGS = "SELECT i.interface_name, ie.process_date, ie.file_name, ie.creation_date, ied.task_code, ied.task_status, ied.start_date, ied.end_date, ied.total_rec_processed, ied.total_rec_rejected, ied.error_msg, ied.log_msg FROM xxdcs.xxdcs_interface i, xxdcs.xxdcs_intf_entry ie, xxdcs.xxdcs_intf_entry_detail ied WHERE i.file_name_prefix LIKE 'Paysafe_SupplementalMIF%' AND i.interface_id = ie.interface_id AND ie.intf_entry_id = ied.intf_entry_id";

    public static final String INSERT_ORACLE_MIF_LOGS_INTO_TEMPTABLE =
            "INSERT INTO PAYSAFE_BI_MIF_FILEACTIVITYLOG_TEMP ({0}) values({1})";

    public static final String INSERT_ORACLE_MIF_LOG_AUDIT =
            "INSERT INTO ppbi.ORACLE_MIF_LOG_AUDIT (PROCESS_DATE) values(''{0}'')";

    public static final String CREATE_TEMPORARY_ORACLE_MIF_LOG_TABLE =
            "CREATE LOCAL TEMP TABLE PAYSAFE_BI_MIF_FILEACTIVITYLOG_TEMP (Interface_name varchar(250), Process_date date, File_name varchar(250), Creation_date timestamp, Task_code varchar(250), Task_status varchar(250), Start_date timestamp, End_date timestamp, Total_rec_processed int, Total_rec_rejected int, Error_msg varchar(250),  Log_msg varchar(250)) ; ";

    public static final String COPY_ORACLE_MIF_LOGS_FROM_TEMP_TABLE =
            "INSERT into ppbi.PAYSAFE_BI_MIF_FILEACTIVITYLOG select * from PAYSAFE_BI_MIF_FILEACTIVITYLOG_TEMP ;";

    public static final String EMR_CREATION_FAILED = " EMR CREATION FAILED :: {0} ";

    public static final String JOB_TAKING_TOO_LONG =
            "Submitted spark job . It is taking too long so step function timedout";

    public static final String GET_CORRECTEDFILES_FROM_PAYSAFE_BI_FILEACTIVITYLOG =
            "SELECT FileName,OriginalFileName from ppbi.PAYSAFE_BI_FILEACTIVITYLOG WHERE LOGENTRYTYPE = ''TransmitFileToPartner'' and FILENAME like ''%_corrected%'' and EventID > {0}";

    public static final String GET_DUPLICATEFILES_FROM_PAYSAFE_BI_FILEACTIVITYLOG =
            "SELECT FILENAME, ORIGINALFILENAME, Description FROM ppbi.PAYSAFE_BI_FILEACTIVITYLOG where Description like ''Duplicate%'' and EventID > {0}";

    public static final String GET_INVALIDRECORDCOUNT_FROM_PAYSAFE_BI_FILEACTIVITYLOG =
            "SELECT FileName, OriginalFileName, InvalidRecordCount from ppbi.PAYSAFE_BI_FILEACTIVITYLOG WHERE LOGENTRYTYPE = ''Parse'' and INVALIDRECORDCOUNT is not null and INVALIDRECORDCOUNT <> ''null'' and INVALIDRECORDCOUNT <> ''0'' and EventID > {0}";

    public static final String FETCH_FILES_AND_DUPLICATECOUNT =
            "SELECT FILENAME, duplicateCount, updatedTime  FROM ppbi.fp_metadata WHERE to_timestamp_tz(updatedTime, ''YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"'') > to_timestamp_tz((SELECT max(UPDATEDON) from ppbi.FPMETADATA_LOG_AUDIT WHERE NOTIFICATIONTYPE = ''NOTIFICATION FOR DUPLICATE RECORD FILES''), ''YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"'') and duplicateCount is not null  and duplicateCount <> ''0'' AND CONFIGID IN ({0}) ORDER BY updatedTime ASC";

    public static final String FETCH_DELAY_TIME =
            "SELECT * FROM (select aperiaFileName, FILEDATE, aperiaProcessedTime, verticaProcessedTime,FILESTATUS, cast(REGEXP_SUBSTR(APERIAFILENAME,''[0-9]{8}'') as date) as AperiaFileDate, TIMESTAMPDIFF(HOUR, aperiaProcessedTime, verticaProcessedTime) as LoadTime, TIMESTAMPDIFF(HOUR, aperiaProcessedTime, CURRENT_TIMESTAMP(1)) as DelayTime from ppbi.aperia_file_monitoring) as aperiaMonitoring where LoadTime is null and AperiaFileDate > CURRENT_DATE()-4 and DelayTime > ''{0}'' AND FILESTATUS != ''ARCHIVED'' ";

    public static final String NOTIFICATION_LOG_AUDIT =
            "INSERT INTO ppbi.FPMETADATA_LOG_AUDIT (UPDATEDON, UPDATEDTIME, NOTIFICATIONTYPE) values(''{0}'',TRANSACTION_TIMESTAMP(), ''{1}'' )";

    public static final String FETCH_COLUMN_ORDER =
            "SELECT column_name FROM v_catalog.columns WHERE table_schema=''{0}'' AND table_name=''{1}'' ORDER BY ordinal_position ;";

    public static final String CHECK_FILE_EXISTS = "SELECT FILENAME FROM {0}.{1} WHERE configId = ''{2}'' AND FILENAME IN ( {3} ) AND USECASE = ''{4}'';";

    public static final String DELETE_QUERY = "DELETE FROM {0}.{1} WHERE {2} IN ( {3} );";

    public static final String INSERT_METADATA_LOG_INACTIVE_QUERY =
            "INSERT INTO ppbi.{0} (FILENAME, CONFIGID, UPDATEDON,STATUS,ZONE,USECASE) VALUES ( ''{1}'',''{2}'', TRANSACTION_TIMESTAMP(),''INACTIVE'', ''{3}'', ''{4}'' );";

    public static final String VERTICA_DRIVER_CLASS = "com.vertica.jdbc.Driver";

    public static final String TABLE = "table";

    public static final String SCHEMA = "dbschema";

    public static final String DATABASE_NAME = "db";

    public static final String DB_USER = "user";

    public static final String DB_PASSWORD = "password";

    public static final String JDBC_URL = "url";

    public static final String DRIVER_CLASS = "driverClass";

    public static final String DB_HOST = "host";

    public static final String METADATA_STATUS = "INPROGRESS";

    public static final String STREAMING_BATCH_INSERT = "streamingBatchInsert";

    public static final String LAST_INSERT_RUN_QUERY = "SELECT LAST_INSERT_ID()";

    public static final String CONFIGID_IN_RUNNING_STATE =
            " SELECT STATUS.CONFIGID as CONFIGID,STATUS.ARCHIVEDFILES as ARCHIVEDFILES FROM ppbi.DATA_SINK_JOB STATUS WHERE STATUS.STATUS = ''INPROGRESS'' AND STATUS.CONFIGID in ( {0} ) AND STATUS.JOBTYPE=''{1}'' AND STATUS.USECASE = ''{2}'' AND STATUS.UPDATEDON >= ''{3}'' ";
}