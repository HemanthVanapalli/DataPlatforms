package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.paysafe.unity.constants.JobStatus;
import com.paysafe.unity.model.LivyResponse;

import java.util.List;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MapJobsStatusChecker {
    private Logger logger = Logger.getLogger(EtlDeleteStaging.class.getName());
    Boolean shootCleanup=true;
    public Boolean handleRequest(List<LivyResponse> livyResponses, Context context) throws IOException {
        try {
            for (LivyResponse livyResponse : livyResponses) {
                if (livyResponse.getJobStatus().equals(JobStatus.FAIL)) {
                    shootCleanup = false;
                    break;
                }
            }
        }
        catch (Exception e) {
            logger.log(Level.SEVERE, "Map Jobs status checker encountered error: ", e);
            throw new RuntimeException(e);
        }
        return shootCleanup;
    }
}
