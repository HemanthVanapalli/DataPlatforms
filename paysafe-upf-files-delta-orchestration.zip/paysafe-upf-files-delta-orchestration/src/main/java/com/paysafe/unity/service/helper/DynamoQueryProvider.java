package com.paysafe.unity.service.helper;

import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.service.DynamoQueryBuilder;

public class DynamoQueryProvider {

  private DynamoQueryBuilder builder;

  public DynamoQueryProvider(DynamoQueryBuilder builder) {

    this.builder = builder;
  }

  public DynamoQuery getDynamoQuery() {
    return this.builder.build();
  }

  public void createDynamoQuery(DataSinkConfig config) {
    this.builder.buildFilterExpression();
    this.builder.buildKeyConditionExpression();
    this.builder.buildIndex();
    this.builder.buildTable();
    this.builder.buildValueMap(config);
  }

}
