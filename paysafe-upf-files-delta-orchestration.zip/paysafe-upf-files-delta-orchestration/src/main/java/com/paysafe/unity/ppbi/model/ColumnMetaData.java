// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2017. For more information see LICENSE

package com.paysafe.unity.ppbi.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ColumnMetaData implements Serializable {

  private static final long serialVersionUID = 1899894039L;

  @JsonProperty("dataType")
  private String dataType;

  @JsonProperty("udf")
  private String udf;

  public ColumnMetaData() {

  }

  public ColumnMetaData(String dataType) {
    this.dataType = dataType;
  }

  public ColumnMetaData(String dataType, String udf) {
    super();
    
    if ("MONEY".equals(dataType)) {
      dataType = "MONEY(18,4)";
    } else if ("DECIMAL".equals(dataType)) {
      dataType = "DECIMAL(18,4)";
    }
    
    this.dataType = dataType;
    this.udf = udf;
  }

  public String getDataType() {
    return dataType;
  }

  public void setDataType(String dataType) {
    this.dataType = dataType;
  }

  public String getUdf() {
    return udf;
  }

  public void setUdf(String udf) {
    this.udf = udf;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
