package com.paysafe.unity.constants;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum DataTypeAutomation {
  INT("INTEGER"), NUMERIC("MONEY", "DECIMAL");
  private final List<String> compatibleTypes;

  DataTypeAutomation(String... values) {
    this.compatibleTypes = Arrays.asList(values);
  }

  public List<String> getCompatibleTypes() {
    return compatibleTypes;
  }

  public static ArrayList<String> find(String name) {

    ArrayList<String> arr = new ArrayList<String>();
    if (StringUtils.isBlank(name))
      return null;
    for (DataTypeAutomation dataType : DataTypeAutomation.values()) {
      for (String type : dataType.getCompatibleTypes()) {
        if (name.toUpperCase().startsWith(type)) {
          arr.add(type);
          arr.add(dataType.name());
          return arr;
        }
      }
    }
    return arr;

  }

}
