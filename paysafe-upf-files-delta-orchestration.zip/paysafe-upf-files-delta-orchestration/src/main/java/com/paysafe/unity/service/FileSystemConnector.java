package com.paysafe.unity.service;

import java.io.IOException;
import java.util.List;

public interface FileSystemConnector {

  public <T> T getObject(String path, Class<T> valueType) throws IOException;

  public List<String> listObjects(String configsPath) throws IOException;

  public <T> T deserialize(String content, Class<T> valueType) throws IOException;

  public boolean putObject(String fileLocation, Object value) throws IOException;

  public boolean putString(String fileLocation, String value) throws IOException;

  public String getObjectAsString(final String path) throws IOException;

}
