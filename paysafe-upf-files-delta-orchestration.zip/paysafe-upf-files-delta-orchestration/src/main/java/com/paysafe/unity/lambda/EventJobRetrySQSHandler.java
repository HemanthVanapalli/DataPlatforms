// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2018. For more information see LICENSE

package com.paysafe.unity.lambda;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paysafe.unity.model.DataSinkEvent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EventJobRetrySQSHandler {
  private static final String Event_RETRY_SQS_URL = System.getenv("EVENT_RETRY_SQS_URL");

  private final AmazonSQS sqs = AmazonSQSClientBuilder.defaultClient();
  static final Logger logger = Logger.getLogger(EventJobRetrySQSHandler.class.getName());
  private static final ObjectMapper OBJECT_MAPPER =
      new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);


  public DataSinkEvent sqsPublish(DataSinkEvent dataSinkEvent)
      throws JsonProcessingException {
    try {
      String message = OBJECT_MAPPER.writeValueAsString(dataSinkEvent);
      SendMessageRequest messageRequest = new SendMessageRequest();
      messageRequest.setMessageBody(message);
      messageRequest.setQueueUrl(Event_RETRY_SQS_URL);
      logger.log(Level.INFO, "sending message - {0}", message);
      SendMessageResult result = sqs.sendMessage(messageRequest);
      logger.log(Level.INFO, "sent message to SQS. message id = {0}", result.getMessageId());
    } catch (JsonProcessingException | RuntimeException e) {
      logger.log(Level.SEVERE,
          "Unable to Publish Message to Retry Queue" + dataSinkEvent, e);
      throw e;
    }
    return dataSinkEvent;
  }

  public List<DataSinkEvent> pollRetryQueue() {
    // Poll sqs for retry payloads
    ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest()
            .withQueueUrl(Event_RETRY_SQS_URL).withWaitTimeSeconds(20).withMaxNumberOfMessages(10);
    List<Message> polledBatch = sqs.receiveMessage(receiveMessageRequest).getMessages();
    List<Message> messages = new ArrayList<>();

    while (!polledBatch.isEmpty()) {
      messages.addAll(polledBatch);
      polledBatch = sqs.receiveMessage(receiveMessageRequest).getMessages();
    }
    logger.log(Level.INFO, "Messages polled count :: {0}", messages.size());
    logger.log(Level.INFO, "Polled Messages: " + messages);

    List<DataSinkEvent> eventList = new ArrayList<>();
    for (Message message : messages) {
      addToList(message, eventList);
    }

    return eventList;
  }


  private void addToList(Message message,
                         List<DataSinkEvent> eventList) {
    DataSinkEvent event = null;
    try {
      event = OBJECT_MAPPER.readValue(message.getBody(), DataSinkEvent.class);
      sqs.deleteMessage(Event_RETRY_SQS_URL, message.getReceiptHandle());
      logger.log(Level.INFO, "Deleting message from the queue: " + message.getMessageId());
    } catch (IOException | RuntimeException e) {
      logger.log(Level.INFO, "Unable to process SQS message body ::" + message.toString(), e);
      return;
    }
    eventList.add(event);
  }
}
