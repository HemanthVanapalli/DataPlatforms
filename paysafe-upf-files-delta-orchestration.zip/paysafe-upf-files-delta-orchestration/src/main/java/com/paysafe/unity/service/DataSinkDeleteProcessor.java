package com.paysafe.unity.service;

import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.DataDeleteHandlerException;
import com.paysafe.unity.model.DataSinkConfig;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public interface DataSinkDeleteProcessor {

  public List<DataSinkConfig> filter(List<DataSinkConfig> configs);

  public boolean execute(List<DataSinkConfig> configs)
      throws IOException, DBQueryException, SQLException, DataDeleteHandlerException;

  public List<String> createDeleteQuery(List<String> files, String configId, String schema, String table)
      throws SQLException;

  public boolean executeDeleteQueries(List<String> queries) throws SQLException;

}