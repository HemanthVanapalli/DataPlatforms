package com.paysafe.unity.service.impl;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DynamoQueryBuilder;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.helper.FPDataSinkJobProcessor;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class ReloadProcessor extends FPDataSinkJobProcessor {

  private static final Logger logger = Logger.getLogger(ReloadProcessor.class.getName());

  public ReloadProcessor(FileSystemConnector connector, DBConnection connection, DataSinkInput dataSinkJobInput,
      AwsConnection awsConnection) throws DBQueryException {
    super(connector, connection, dataSinkJobInput, awsConnection);
    logger.log(Level.INFO, "Initialization ReloadProcesser");
  }

  @Override
  public List<DataSinkConfig> constructDataSinkConfig(List<String> configIds) throws DBQueryException, SQLException {
    return configIds.stream().map(config -> new DataSinkConfig(config)).collect(Collectors.toList());
  }

  @Override
  public DynamoQueryBuilder getDynamoQueryBuilder() {
    return new ReloadDynamoQueryBuilder(dataSinkJobInput);
  }

}
