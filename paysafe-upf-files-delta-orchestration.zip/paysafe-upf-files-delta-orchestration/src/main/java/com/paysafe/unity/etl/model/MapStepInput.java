// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2020. For more information see LICENSE

package com.paysafe.unity.etl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MapStepInput {
  @JsonProperty
  private String configId;
  @JsonProperty
  private String jobType;
  @JsonProperty
  private boolean failFast;
  @JsonProperty
  private String outputConfigPath;
  @JsonProperty
  private String baseConfig;
  @JsonProperty
  private String verticaConfigPropsPath;

  public String getVerticaConfigPropsPath() {
    return verticaConfigPropsPath;
  }

  public void setVerticaConfigPropsPath(String verticaConfigPropsPath) {
    this.verticaConfigPropsPath = verticaConfigPropsPath;
  }

  public String getBaseConfig() {
    return baseConfig;
  }

  public void setBaseConfig(String baseConfig) {
    this.baseConfig = baseConfig;
  }

  public String getOutputConfigPath() {
    return outputConfigPath;
  }

  public void setOutputConfigPath(String outputConfigPath) {
    this.outputConfigPath = outputConfigPath;
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public String getJobType() {
    return jobType;
  }

  public void setJobType(String jobType) {
    this.jobType = jobType;
  }

  public boolean isFailFast() {
    return failFast;
  }

  public void setFailFast(boolean failFast) {
    this.failFast = failFast;
  }


}
