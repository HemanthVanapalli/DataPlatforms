package com.paysafe.unity.constants;

public enum JobStatus {

  SUCCESS("success", "Session is successfully stopped LivySessionState.SUCCESS "),
  /**
   * ERROR("error","Session errored out"), DEAD("dead","Session has exited"),
   * KILLED("killed","Session has been killed")
   */
  FAIL("failed", "Session is ERROR or DEAD or KILLED"),
  /**
   * NOT_STARTED("not_started","Session has not been started"),
   * STARTING("starting","Session is starting"), IDLE("idle",
   * "Session is waiting for input"), BUSY("busy",
   * "Session is executing a statement"), SHUTTING_DOWN("shutting_down",
   * "Session is shutting down"),
   */
  INCOMPLETE("incomplete", "any status other than above from LivySessionState after max time wait"),
  NOJOBS("nojobs","no livy jobs"),
  
  INPROGRESS("inprogress","monitoring of livy job is inprogress"),
  COMPLETED("completed","livy job monitoring is completed");

  private String name;
  private String description;

  private JobStatus(String name, String description) {
    this.name = name;
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  
  

}
