package com.paysafe.unity.lambda;

import com.paysafe.unity.util.StepFunctionUtils;
import com.paysafe.unity.util.SnsUtils;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import org.apache.commons.lang3.exception.ExceptionUtils;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SNSEvent;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VerticaMmLoadTrigger implements RequestHandler<SNSEvent, Void> {
    private Logger logger = Logger.getLogger(VerticaMmLoadTrigger.class.getName());


    @Override
    public Void handleRequest(SNSEvent request, Context context) {

        String stepFunctionArn = System.getenv("MM_STATE_MACHINE_ARN");
        String accountId = System.getenv("AWS_ACCOUNT_ID");
        String stepFunctionPayload = "";
        try {
            logger.log(Level.INFO, "Getting step function input from Sns message");
            List<SNSEvent.SNSRecord> snsRecordList = request.getRecords();
            if (snsRecordList != null) {
                SNSEvent.SNS recordSNS = null;
                for (SNSEvent.SNSRecord snsRecord : snsRecordList) {
                    recordSNS = snsRecord.getSNS();
                    stepFunctionPayload = recordSNS.getMessage();
                    logger.log(Level.INFO, "Subject:[ {0} ] Arn:[ {1} ] attribs:[ {2} ] message:[ {3} ] messagetostr:[ {4} ] ", new Object[]{recordSNS.getSubject(), recordSNS.getTopicArn(), recordSNS.getMessageAttributes(), recordSNS.getMessage(), stepFunctionPayload});
                }
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in SNSread", ExceptionUtils.getStackTrace(ex));
        }

        try {
            logger.log(Level.INFO, "invoking step function for mm vetica load", stepFunctionPayload);
            StepFunctionUtils.startExecution(stepFunctionArn, stepFunctionPayload);

        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in VerticaMmLoadTrigger", ExceptionUtils.getStackTrace(ex));
            SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
                    this.getClass().getName(), CommonConstants.ERROR);
            snsUtils.sendEmail(ExceptionUtils.getStackTrace(ex), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
            throw ex;
        }
        return null;
    }

}
