// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2017. For more information see LICENSE

package com.paysafe.unity.exception;

public class ClusterException extends Exception {

  private static final long serialVersionUID = 1L;
  private static final String regionZoneEnvironment =
      "No active clusters found with region: %s, name/zone: %s, environment: %s";

  public ClusterException(final String region, final String zone, final String environment) {
    super(String.format(regionZoneEnvironment, zone, region, environment));
  }

}
