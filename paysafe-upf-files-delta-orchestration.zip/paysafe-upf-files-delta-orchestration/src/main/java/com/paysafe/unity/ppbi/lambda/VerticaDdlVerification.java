package com.paysafe.unity.ppbi.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.DataTypeAutomation;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.lambda.DataSinkInvoker;
import com.paysafe.unity.ppbi.model.MetaData;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;
import com.paysafe.unity.util.S3Util;
import com.paysafe.unity.util.SnsUtils;
import com.paysafe.unity.util.VerticaUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

public class VerticaDdlVerification {
  private static final Logger LOGGER = Logger.getLogger(VerticaUtil.class.getName());

  private Connection conn;
  DataSinkInvoker ds;
  S3Util s3Util;
  AwsSecretsUtil awsSecretsUtil;

  DBConnection connection;
  Connection con;
  Statement stmt;
  InfrastructureUtil infrastructureUtil;

  public void connectToVertica() throws Exception {
    AwsConnection awsConnection = new AwsConnection();

    FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

    AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

    infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

    DataSinkInvoker ds = new DataSinkInvoker();
    CommonUtil util = new CommonUtil();
    Map<String, String> connProps =
        util.fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

    DBConnection connection = new DBConnection(connProps);
    con = connection.getConnection();

  }

  public ResultSet getVerticaDdl(String query) throws SQLException {

    Statement stmt = con.createStatement();

    ResultSet rs = stmt.executeQuery(query);

    return rs;
  }

  public MetaData readConfig(String absoluteConfigPath) throws IOException {
    s3Util = new S3Util();
    return s3Util.getObjectFromJson(absoluteConfigPath, MetaData.class);

  }

  public void handleRequest(String relativePath) {
    String s3BucketName = LambdaVariables.SRC_BUCKET;
    String inputS3Path = "s3://" + s3BucketName + "/" + relativePath;
    LOGGER.info("inputS3Path: " + inputS3Path);
    String configId = "";
    try {

      connectToVertica();
      MetaData meta = readConfig(inputS3Path);
      String query = "SELECT  column_name, data_type FROM columns WHERE table_schema = '" + meta.getSchema()
          + "' AND table_name='" + meta.getTable() + "'";
      LOGGER.info("query: " + query);
      configId = meta.getConfigId();

      ResultSet rs = getVerticaDdl(query);

      LinkedHashMap<String, String> verticaResult = new LinkedHashMap<String, String>();

      while (rs.next()) {

        String colName = rs.getString("column_name");
        String colDataType = rs.getString("data_type");
        verticaResult.put(colName, colDataType);

      }

      validation(verticaResult, meta);

    } catch (Exception e) {
      Map<String, String> props = new HashMap<String, String>();
      props.put("Relative Path", relativePath);

      sendNotification(props, e.toString());
    }

  }

  public void sendNotification(Map<String, String> propsPayload, String exception) {
    SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
        this.getClass().getName(), CommonConstants.ERROR);

    snsUtils.sendEmail(exception, propsPayload, LambdaVariables.ALERT_SNS_TOPIC_ARN);
  }

  public String validation(LinkedHashMap<String, String> verticaResult, MetaData meta) throws IOException {

    String orderInCorrectAt = "";

    String missCols = "";

    String dataTypeNotMatchingCols = "";

    ArrayList<String> verticaColumns = new ArrayList<String>();
    Set<String> verticaCols = verticaResult.keySet();
    for (String verticaColName : verticaCols) {
      verticaColumns.add(verticaColName);

    }

    int counter = 0;
    String dataTypeMissingInConfig = "";

    for (String metaDataCol : meta.getColumnMetadata().keySet()) {
      if (!verticaCols.contains(metaDataCol)) {
        missCols = missCols + metaDataCol + " , ";
      } else {

        String metaDataType = meta.getColumnMetadata().get(metaDataCol).getDataType();
        String verticaDataType = verticaResult.get(metaDataCol);

        // Verify if dataType is matching
        ArrayList<String> refVerticaDataType = DataTypeAutomation.find(metaDataType);

        if (refVerticaDataType != null && refVerticaDataType.size() > 0) {
          metaDataType =
              metaDataType.toUpperCase(Locale.ENGLISH).replace(refVerticaDataType.get(0), refVerticaDataType.get(1));
        }

        if (metaDataType == null) {
          dataTypeMissingInConfig += metaDataCol + ",";

        } else if (!metaDataType.equalsIgnoreCase(verticaDataType)) {

          dataTypeNotMatchingCols = dataTypeNotMatchingCols + metaDataCol + ",";
        }

        // Verify if order is correct
        String verticaCol = verticaColumns.get(counter);

        if (!verticaCol.equalsIgnoreCase(metaDataCol) && orderInCorrectAt.isEmpty()) {
          LOGGER.info("metaCol:" + metaDataCol);
          LOGGER.info("verticaColName:" + verticaCol);
          LOGGER.info("counter=" + counter);
          orderInCorrectAt = metaDataCol;

        }
        counter++;
      }

    }

    String msg = "";

    if (!orderInCorrectAt.isEmpty() || !missCols.isEmpty() || !dataTypeNotMatchingCols.isEmpty()
        || !dataTypeMissingInConfig.isEmpty()) {
      msg = "\n Order incorrect at :" + orderInCorrectAt + "\n MissingCols: " + missCols
          + "Data type is not matching for :" + dataTypeNotMatchingCols + "DataType is missing in config for :"
          + dataTypeMissingInConfig;

      Map<String, String> props = new HashMap<String, String>();
      props.put("DDL Validation", msg);

      sendNotification(props, msg);
    }
    LOGGER.info(msg);
    return msg;

  }

}
