package com.paysafe.unity.exception;

public class DataDeleteHandlerException extends Exception {

  /**
   *
   */
  private static final long serialVersionUID = 8169105801913680613L;

  public DataDeleteHandlerException(String message) {
    super(message);
  }

  public DataDeleteHandlerException(String message, Throwable cause) {
    super(message, cause);

  }

  public DataDeleteHandlerException(Throwable cause) {
    super(cause);

  }

}
