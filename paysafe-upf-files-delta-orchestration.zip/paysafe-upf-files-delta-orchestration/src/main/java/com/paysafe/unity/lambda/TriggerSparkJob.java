package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.JobStatus;
import com.paysafe.unity.exception.PPBISparkJobLaunchException;
import com.paysafe.unity.lambda.helper.LivySubmit;
import com.paysafe.unity.model.LivyInput;
import com.paysafe.unity.model.LivyResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.time.LocalDateTime;

public class TriggerSparkJob {

    private LambdaLogger lambdaLogger;

    public LivyResponse handleRequest(LivyInput livyInput, Context context)
            throws JsonProcessingException, PPBISparkJobLaunchException {

        lambdaLogger = context.getLogger();

        lambdaLogger.log("TriggerSparkJob:: Input " + livyInput);

        String masterPublicDnsName = livyInput.getEmrDetails().getMasterPublicDnsName();

        if (StringUtils.isEmpty(masterPublicDnsName) || StringUtils.isEmpty(livyInput.getEmrDetails().getEmrClusterId())) {

            throw new PPBISparkJobLaunchException("Mandatory fields masterPublicDnsName or ClusterId is missing ");
        }

        if (StringUtils.isNotEmpty(livyInput.getJobName())) {

            livyInput.getLivyCommand().getConf().put("spark.app.name",
                    livyInput.getJobName() + CommonConstants.UNDERSCORE + LocalDateTime.now());
        }

        // actual livyCommand
        String livyJob = CommonConstants.MAPPER.writeValueAsString(livyInput.getLivyCommand());

        String livyEndpoint =
                new StringBuilder("http://").append(masterPublicDnsName).append(":8998/").append("batches").toString();

        try {

            lambdaLogger.log("Trigger livy with payload " + livyJob);
            LivyResponse livyResponse = LivySubmit.callLivyJob(livyEndpoint, livyJob);

            lambdaLogger.log("after BeanUtils copy " + livyResponse);

            livyResponse.setLivyMoitoringStatus(JobStatus.INPROGRESS);
            livyResponse.setLivyEndPoint(livyEndpoint);
            livyResponse.setMaxCounter((livyInput.getTimeoutSeconds() / 180L) - 5);
            return livyResponse;

        } catch (Exception e) {
            lambdaLogger.log(ExceptionUtils.getStackTrace(e));
            throw new PPBISparkJobLaunchException(e.getMessage());
        }
    }

    /*
     * private void addEmrProps(LivyInput livyInput, String masterPublicDnsName) { String payLoadPath =
     * livyInput.getJobDetails().getPath();
     *
     * String id = payLoadPath.substring(payLoadPath.lastIndexOf("/") + 1);
     *
     * livyInput.getLivyCommand().getArgs().add(payLoadPath);
     *
     * // EMR console it will be shown String jobName = id + CommonConstants.UNDERSCORE + LocalDate.now();
     * livyInput.getLivyCommand().getConf().put("spark.app.name", jobName);
     *
     * // to avoid duplicate Livy jobs for same config livyInput.getLivyCommand().setName(jobName); }
     */

}
