package com.paysafe.unity.lambda.helper;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class DataAccessAlertModel implements Serializable {

    @JsonProperty("SenderEmail")
    private String SenderEmail;

    @JsonProperty("NonBusinessReceiver")
    private String NonBusinessReceiver;

    @JsonProperty("EmailSubject")
    private String EmailSubject;

    @JsonProperty("bodyText")
    private String bodyText;

    @JsonProperty("ErrorMsg")
    private String ErrorMsg;

    @JsonProperty("regexForColumnName")
    private String regexForColumnName;

    @JsonProperty("regexForTableName")
    private String regexForTableName;

    @JsonProperty("PII_NOTIFICATION_LOG_AUDIT")
    private String PII_NOTIFICATION_LOG_AUDIT;

    @JsonProperty("DataAccessAlertQuery")
    private String DataAccessAlertQuery;

    @JsonProperty("userRole")
    private String userRole;

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public String getZeroRecordsFromQuery() {
        return zeroRecordsFromQuery;
    }

    public void setZeroRecordsFromQuery(String zeroRecordsFromQuery) {
        this.zeroRecordsFromQuery = zeroRecordsFromQuery;
    }

    @JsonProperty("zeroRecordsFromQuery")
    private String zeroRecordsFromQuery;


    public String getSenderEmail() {
        return SenderEmail;
    }

    public void setSenderEmail(String senderEmail) {
        SenderEmail = senderEmail;
    }

    public String getNonBusinessReceiver() {
        return NonBusinessReceiver;
    }

    public void setNonBusinessReceiver(String nonBusinessReceiver) {
        NonBusinessReceiver = nonBusinessReceiver;
    }

    public String getEmailSubject() {
        return EmailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        EmailSubject = emailSubject;
    }

    public String getBodyText() {
        return bodyText;
    }

    public void setBodyText(String bodyText) {
        this.bodyText = bodyText;
    }

    public String getErrorMsg() {
        return ErrorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        ErrorMsg = errorMsg;
    }

    public String getRegexForColumnName() {
        return regexForColumnName;
    }

    public void setRegexForColumnName(String regexForColumnName) {
        this.regexForColumnName = regexForColumnName;
    }

    public String getRegexForTableName() {
        return regexForTableName;
    }

    public void setRegexForTableName(String regexForTableName) {
        this.regexForTableName = regexForTableName;
    }

    public String getPII_NOTIFICATION_LOG_AUDIT() {
        return PII_NOTIFICATION_LOG_AUDIT;
    }

    public void setPII_NOTIFICATION_LOG_AUDIT(String PII_NOTIFICATION_LOG_AUDIT) {
        this.PII_NOTIFICATION_LOG_AUDIT = PII_NOTIFICATION_LOG_AUDIT;
    }

    public String getDataAccessAlertQuery() {
        return DataAccessAlertQuery;
    }

    public void setDataAccessAlertQuery(String dataAccessAlertQuery) {
        DataAccessAlertQuery = dataAccessAlertQuery;
    }


}
