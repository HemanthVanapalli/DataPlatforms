package com.paysafe.unity.service.helper;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DataSinkDeleteProcessor;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.VerticaUtil;

import org.apache.commons.collections.CollectionUtils;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class AbstractDataSinkDeleteProcessor implements DataSinkDeleteProcessor {

  final Logger logger = Logger.getLogger(AbstractDataSinkDeleteProcessor.class.getName());

  protected DataSinkInput dataSinkInput;
  protected VerticaUtil verticaUtil;
  protected CommonUtil commonUtil;

  public AbstractDataSinkDeleteProcessor(DataSinkInput dataSinkInput, DBConnection dbConnection)
      throws DBQueryException {
    this.dataSinkInput = dataSinkInput;
    this.verticaUtil = new VerticaUtil(dbConnection);
    this.commonUtil = new CommonUtil();
  }

  @Override
  public List<DataSinkConfig> filter(List<DataSinkConfig> configs) {
    List<DataSinkConfig> filteredConfigs =
        configs.stream().parallel().filter(config -> (CollectionUtils.isNotEmpty(config.getArchivedFiles())
            || (CollectionUtils.isNotEmpty(config.getRollbackFiles())))).collect(Collectors.toList());
    return filteredConfigs;
  }

  @Override
  public List<String> createDeleteQuery(List<String> files, String configId, String schema, String table) {
    List<String> queries = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(files)) {
      String existingFileNames = files.stream().collect(Collectors.joining("','", "'", "'"));
      logger.log(Level.INFO, "Deleting entries in " + schema + "." + table + " for :: " + existingFileNames);
      queries.add(MessageFormat.format(DBConstants.DELETE_QUERY, schema, table, dataSinkInput.getTracingColumn(),
          existingFileNames));
      for (String file : files) {
        queries.add(MessageFormat.format(DBConstants.INSERT_METADATA_LOG_INACTIVE_QUERY,dataSinkInput.getMetaDataLogTable(),file, configId, LambdaVariables.AWS_ZONE.toUpperCase(), dataSinkInput.getUsecase()));
      }
    } else {
      logger.log(Level.INFO, "Given files were not loaded previously for :: " + files + " in " + schema + "." + table);
    }
    return queries;
  }

  public List<String> checkFileExists(List<DataSinkConfig> configs) throws SQLException {
    ArrayList<String> existingFiles = new ArrayList<>();
    for (DataSinkConfig config : configs) {
      ArrayList<String> fetchedExistingFiles = new ArrayList<>();
      fetchedExistingFiles
          .addAll(Stream.of(config.getArchivedFiles(), config.getRollbackFiles()).flatMap(Collection::stream)
              .collect(Collectors.toList()));
      String fileNames = fetchedExistingFiles.stream().collect(Collectors.joining("','", "'", "'"));
      
      String configIdforQuery = this.dataSinkInput.getConformedConfigId()!=null ? this.dataSinkInput.getConformedConfigId() : config.getConfigId().trim();
      String selectQuery =
          MessageFormat.format(DBConstants.CHECK_FILE_EXISTS, CommonConstants.DATA_SINK_METADATA_SCHEMA,
              this.dataSinkInput.getMetaDataTable() , configIdforQuery, fileNames, dataSinkInput.getUsecase());
      existingFiles.addAll(verticaUtil.getExistingFileNames(selectQuery));
    }
    return existingFiles;
  }

  @Override
  public boolean executeDeleteQueries(List<String> queries) throws SQLException {
    return verticaUtil.executeQueries(queries);
  }
}