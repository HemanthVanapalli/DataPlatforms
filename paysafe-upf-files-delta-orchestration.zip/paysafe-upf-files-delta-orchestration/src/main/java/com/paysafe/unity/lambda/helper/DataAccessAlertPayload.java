package com.paysafe.unity.lambda.helper;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class DataAccessAlertPayload implements Serializable {

    @JsonProperty("payloadPath")
    private String payloadPath;

    public String getPayloadPath() {
        return payloadPath;
    }

    public void setPayloadPath(String payloadPath) {
        this.payloadPath = payloadPath;
    }

}
