package com.paysafe.unity.constants;

import org.apache.commons.lang3.StringUtils;

public enum MultiConnectors {

  VERTICA("VERTICA"), S3("S3"), KAFKA("KAFKA");

  private final String val;

  private MultiConnectors(String val) {
    this.val = val;
  }

  public String getVal() {
    return val;
  }

  public static MultiConnectors find(String name) {
    if (StringUtils.isBlank(name))
      return null;
    for (MultiConnectors multiConnectors : MultiConnectors.values()) {
      if (name.equalsIgnoreCase(multiConnectors.name())) {
        return multiConnectors;
      }
    }
    return null;
  }

}
