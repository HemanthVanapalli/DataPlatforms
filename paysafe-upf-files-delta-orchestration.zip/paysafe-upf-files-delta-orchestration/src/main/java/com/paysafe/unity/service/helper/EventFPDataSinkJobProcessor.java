package com.paysafe.unity.service.helper;

import com.paysafe.unity.model.DataSinkEvent;
import com.paysafe.unity.model.DataSinkConfig;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EventFPDataSinkJobProcessor {

  public List<DataSinkConfig> fetchDeltaFiles(DataSinkEvent event) {
    List<DataSinkConfig> configs = new ArrayList<DataSinkConfig>();
    DataSinkConfig config = new DataSinkConfig(event.getConfigId());
    config.setArchivedFiles(Arrays.stream(event.getFiles().split(",")).collect(Collectors.toList()));
    config.setLastRunDate(event.getEventTime());
    config.setCurrentRunDate(event.getEventTime());
    configs.add(config);

    return configs;
  }
}
