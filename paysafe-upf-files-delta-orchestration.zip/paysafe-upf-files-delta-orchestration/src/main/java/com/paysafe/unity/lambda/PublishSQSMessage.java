package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paysafe.unity.model.DataSinkEvent;
import com.paysafe.unity.model.DataSinkOutput;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PublishSQSMessage {
    private static final Logger LOGGER = Logger.getLogger(PublishSQSMessage.class.getName());

    public boolean handleRequest(DataSinkOutput dataSinkOutput, Context context) throws JsonProcessingException {

        EventJobRetrySQSHandler eventJobRetrySQSHandler = new EventJobRetrySQSHandler();

        DataSinkEvent dataSinkEvent = new DataSinkEvent();
        dataSinkEvent.setConfigId(dataSinkOutput.getConfigId());
        dataSinkEvent.setFiles(dataSinkOutput.getFiles());

        LOGGER.log(Level.INFO, "DataSink Event ::" + dataSinkEvent);
        eventJobRetrySQSHandler.sqsPublish(dataSinkEvent);
        return false;
    }
}
