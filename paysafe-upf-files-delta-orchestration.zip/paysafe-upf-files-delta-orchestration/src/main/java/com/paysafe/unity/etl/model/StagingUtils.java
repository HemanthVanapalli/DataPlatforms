// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2018. For more information see LICENSE

package com.paysafe.unity.etl.model;

import com.paysafe.gdp.fp.common.config.CopyConfig;
import com.paysafe.gdp.fp.common.config.etl.DeleteConfig;
import com.paysafe.gdp.fp.common.config.etl.StagingDelete;
import com.paysafe.gdp.fp.common.config.etl.StagingToDest;
import com.paysafe.gdp.fp.common.payload.LivySubmitPayload;
import com.paysafe.gdp.fp.common.util.S3Util;
import com.paysafe.unity.lambda.EtlDeleteStaging;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StagingUtils {
  private static final String YELLOW_ZONE = "YELLOW";
  private static final String BLUE_ZONE = "BLUE";
  private static final String GREY_ZONE = "GREY";
  private static final S3Util s3Util = new S3Util();
  private static Logger logger = Logger.getLogger(StagingUtils.class.getName());

  public void executeDeleteStaging(String currentZone, StagingDelete deleteStaging) {
    switch (currentZone) {
      case YELLOW_ZONE:
        deletePath(deleteStaging.getYellow());
        break;
      case BLUE_ZONE:
        deletePath(deleteStaging.getBlue());
        break;
      case GREY_ZONE:
        deletePath(deleteStaging.getGrey());
        break;
      default:
        throw new RuntimeException("no matching zone found");
    }
  }

  public void executeStagingToDest(String currentZone, StagingToDest stagingToDest) {
    switch (currentZone) {
      case YELLOW_ZONE:
        copyPath(stagingToDest.getYellow());
        break;
      case BLUE_ZONE:
        copyPath(stagingToDest.getBlue());
        break;
      case GREY_ZONE:
        copyPath(stagingToDest.getGrey());
        break;
      default:
        throw new RuntimeException("no matching zone found");
    }
  }

  private void copyPath(List<CopyConfig> copyConfigList) {
    for (CopyConfig copyPaths : copyConfigList) {
      List<String> directories =
          s3Util.getSubDirList(copyPaths.getSrcBucket(), copyPaths.getSrcPath());
      s3Util.replaceDirectories(directories, copyPaths.getSrcBucket(), copyPaths.getSrcPath(),
          copyPaths.getDestBucket(), copyPaths.getDestPath());
    }
  }

  private void deletePath(DeleteConfig deleteConfig) {
    for (String dir : deleteConfig.getPath()) {
      String bucketName = deleteConfig.getBucket();
      List<String> srcKeys = s3Util.listObjects(bucketName, dir);
      logger.log(Level.INFO, "Total keys to be deleted :: {0}", srcKeys.size());
      logger.log(Level.INFO, "Keys to be deleted :: {0}", srcKeys);
      srcKeys.stream().forEach(key -> s3Util.delete(bucketName, key));
    }
  }

}
