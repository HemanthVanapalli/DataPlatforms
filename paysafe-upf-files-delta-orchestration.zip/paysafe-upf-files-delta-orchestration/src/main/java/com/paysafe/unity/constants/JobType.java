package com.paysafe.unity.constants;

import org.apache.commons.lang3.StringUtils;

public enum JobType {

  LOAD("LOAD"), RELOAD("RELOAD");

  private final String val;

  private JobType(String val) {
    this.val = val;
  }

  public String getVal() {
    return val;
  }

  public static JobType find(String name) {
    if (StringUtils.isBlank(name))
      return null;
    for (JobType jobType : JobType.values()) {
      if (name.equalsIgnoreCase(jobType.name())) {
        return jobType;
      }
    }
    return null;
  }

}
