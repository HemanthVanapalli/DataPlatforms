package com.paysafe.unity.util;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.ppbi.model.ColumnMetaData;
import com.paysafe.unity.ppbi.model.MetaData;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CreatePPBIConfig {
  public static final ObjectMapper MAPPER = CommonConstants.MAPPER;
  public static Map<String, String> map;

  /*
   *
   * 1.ExcelFilename 2.dataType Column Index 3.new DataTypeColumnIndex 4.Unity UDF 5. fieldNameIndex 6.Schema Nama
   * 7.srcPrefix
   *
   */
  public static void main(String[] args) throws Exception {

    System.out.println(args.length);
    MetaData config;
    DataFormatter dataFormatter = new DataFormatter();
    Iterator<Row> rowIterator;
    Row row;

    File dirPath = new File("src/main/resources/");

    if (args.length != 7) {
      throw new Exception(
          "Required number of argumnets no provided 1.Excel sheet name 2.dataType Column Index 3.new DataTypeColumnIndex 4.Unity UDF 5. fieldNameIndex 6.Schema Nama 7.filepath");

    }

    String templatePath = args[0];
    int dataTypeIndex = Integer.valueOf(args[1]);
    int dataTypeChangeIndex = Integer.valueOf(args[2]);
    int udfNameIndex = Integer.valueOf(args[3]);
    int fieldNameIndex = Integer.valueOf(args[4]);
    String schemaName = args[5];
    String srcPrefix = args[6];

    System.out
        .println("Following is the input excel file name from which we want to create PPBI config: " + templatePath);
    // Creating a Workbook from an Excel file (.xls or .xlsx)
    Workbook workbook =
        WorkbookFactory.create(new File(dirPath.getAbsolutePath() + "/automation/input/" + templatePath));

    map = MAPPER.readValue(new File(dirPath.getAbsolutePath() + "/automation/input/PPBI_UDF.json"),
        new TypeReference<Map<String, String>>() {
        });

    // Retrieving the number of sheets in the Workbook
    for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
      Sheet sheet = workbook.getSheetAt(i);
      System.out.println("Preparing config for : " + sheet.getSheetName().trim());
      config = new MetaData("paymentProcessing_usAcquiring_" + sheet.getSheetName().trim());
      config.setColumnMetadata(CreatePPBIConfig.setColMetadata());
      config.setDropColumns(CreatePPBIConfig.setDropCols());
      config.setBusinessUnit("usAcquiring");
      config.setTable("**Please modify accordingly**");
      config.setAvoidSchemaUpdates(true);
      config.setSchema(schemaName);
      config.setSrcPrefix("fp-unity/output/" + config.getConfigId() + "/");
      // 1. You can obtain a rowIterator and columnIterator and iterate over
      // them
      rowIterator = sheet.rowIterator();
      if (rowIterator.hasNext()) {
        rowIterator.next(); // skipping the first row as its column header.
      }
      // iterate over each row in sheet
      while (rowIterator.hasNext()) {
        row = rowIterator.next();
        if (dataFormatter.formatCellValue(row.getCell(0)).isEmpty()) {
          break;
        }
        Cell cell = row.getCell(fieldNameIndex);
        // having actual columns
        String colName = dataFormatter.formatCellValue(cell).toUpperCase();

        String dataType = dataFormatter.formatCellValue(row.getCell(dataTypeIndex));
        String dataTypeChange = dataFormatter.formatCellValue(row.getCell(dataTypeChangeIndex));
        String paysafeUdf = dataFormatter.formatCellValue(row.getCell(udfNameIndex));

        if (StringUtils.isNotBlank(colName)) {
          // Added Paysafe Udf as one of the column in excel sheet to simplify
          // the creation of PPBI config from Excel. Before running this tool
          // one should add Paysafe UDF as last column in each sheet. Mapping
          // has been maintained in following path
          // src\main\resources\automation\PPBI_UDF.json
          if (StringUtils.isNotBlank(paysafeUdf)) {
            if (StringUtils.isEmpty(dataType) && StringUtils.isEmpty(dataTypeChange)) {
              config.getColumnMetadata().put(colName, new ColumnMetaData("VARCHAR(512)", udf(paysafeUdf)));
            } else if (StringUtils.isNotBlank(dataTypeChange)) {
              config.getColumnMetadata().put(colName, new ColumnMetaData(dataTypeChange, udf(paysafeUdf)));
            } else {
              config.getColumnMetadata().put(colName, new ColumnMetaData(dataType, udf(paysafeUdf)));
            }
          } else if (StringUtils.isNotBlank(dataTypeChange)) {
            config.getColumnMetadata().put(colName, new ColumnMetaData(dataTypeChange));
          } else {
            config.getColumnMetadata().put(colName, new ColumnMetaData(dataType));
          }

        } else {
          System.out.println("Column name is empty");
        }
      }
      ObjectWriter writer = MAPPER.writer(new DefaultPrettyPrinter());
      writer.writeValue(
          new File(dirPath.getAbsolutePath() + "/automation/output/" + config.getConfigId().trim() + ".json"), config);
    }
  }

  public static String udf(String cellValue) {
    String[] strList = cellValue.split("#");
    String functionName = strList[0];
    String[] args = Arrays.copyOfRange(strList, 1, strList.length);
    String udfFunction = map.get(functionName);
    for (String param : args) {
      udfFunction = udfFunction.replaceFirst("\\$col", param.toUpperCase());
    }
    return udfFunction;
  }

  public static Map<String, ColumnMetaData> setColMetadata() {
    Map<String, ColumnMetaData> columnMetadata = new LinkedHashMap<String, ColumnMetaData>();
    columnMetadata.put("UNITYFILENAME", new ColumnMetaData("varchar(100)", "O_FILEDATE"));
    columnMetadata.put("UNITYFILEDATE", new ColumnMetaData("TIMESTAMP",
        "to_timestamp(parseRegex(O_FILEDATE,\"Paysafe_.*_([0-9]{14}).*\"),'yyyyMMddHHmmss')"));
    columnMetadata.put("ENVELOPECREATIONTIME", new ColumnMetaData("TIMESTAMP"));
    columnMetadata.put("ENVELOPEFILENAME", new ColumnMetaData("varchar(100)"));
    columnMetadata.put("ENVELOPEFILEDATE", new ColumnMetaData("DATE", "to_date(ENVELOPEFILEDATE,'yyyyMMdd')"));
    columnMetadata.put("ENVELOPEJOBNAME", new ColumnMetaData("varchar(100)"));
    columnMetadata.put("ENVELOPEREPORTNAME", new ColumnMetaData("varchar(100)"));
    columnMetadata.put("ENVELOPEPROCESSORNAME", new ColumnMetaData("varchar(100)"));
    columnMetadata.put("ENVELOPEPROCESSORPLATFORM", new ColumnMetaData("varchar(100)"));
    columnMetadata.put("ENVELOPEBUSINESSLOCATION", new ColumnMetaData("varchar(100)"));
    columnMetadata.put("ENVELOPEBUSINESSUNIT", new ColumnMetaData("varchar(100)"));
    return columnMetadata;
  }

  public static List<String> setDropCols() {
    List<String> dropColumns = new ArrayList<>();
    String dropCols =
        "CONFIGID,MD5,ROWKEY,ROWTYPE,FILELOCATION,FILEDATE,INDEX,O_FILEDATE,FILENAME,BIN,CARDLASTFOURDIGIT,ISTRANSACTIONACTIVE,UPDATEDON";
    dropColumns.addAll(Arrays.asList(dropCols.split(",")));
    return dropColumns;
  }
}