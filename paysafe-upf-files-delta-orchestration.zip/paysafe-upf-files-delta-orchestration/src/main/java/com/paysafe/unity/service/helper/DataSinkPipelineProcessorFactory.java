package com.paysafe.unity.service.helper;

import com.paysafe.unity.constants.Pipeline;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DataSinkPipelineProcessor;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.SparkETLPipelineProcessor;
import com.paysafe.unity.service.impl.VerticaPipelineProcessor;

import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSinkPipelineProcessorFactory {

  private static final Logger logger = Logger.getLogger(DataSinkPipelineProcessorFactory.class.getName());

  private FileSystemConnector fileSystemConnector;
  private DataSinkInput dataSinkJobInput;

  public DataSinkPipelineProcessorFactory(FileSystemConnector fileSystemConnector, DataSinkInput dataSinkJobInput) {
    this.fileSystemConnector = fileSystemConnector;
    this.dataSinkJobInput = dataSinkJobInput;
  }

  public DataSinkPipelineProcessor getProcessor() throws DataSinkException, DBQueryException {

    Pipeline type = dataSinkJobInput.getPipeline();
    logger.log(Level.INFO, "Fetching DataSinkPipelineProcessor for pipeline " + type);

    switch (type) {
    case VERTICA_PIPELINE:
      return new VerticaPipelineProcessor(fileSystemConnector, dataSinkJobInput);
    case SPARK_ETL_FRAMEWORK:
      return new SparkETLPipelineProcessor(fileSystemConnector, dataSinkJobInput);
    default:
      throw new DataSinkException("No relevant pipeline found");
    }

  }
}
