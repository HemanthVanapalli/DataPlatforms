package com.paysafe.unity.service.impl;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.etl.model.EtlConfig;
import com.paysafe.unity.etl.model.OutputProperties;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.DataDeleteHandlerException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.ppbi.model.Config;
import com.paysafe.unity.service.helper.AbstractDataSinkDeleteProcessor;
import com.paysafe.unity.util.S3Util;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SparkEtlPipeLineDeleteProcessor extends AbstractDataSinkDeleteProcessor {

  final Logger logger = Logger.getLogger(SparkEtlPipeLineDeleteProcessor.class.getName());

  public SparkEtlPipeLineDeleteProcessor(DataSinkInput dataSinkInput, DBConnection dbConnection)
      throws DBQueryException {
    super(dataSinkInput, dbConnection);
  }

  @Override
  public boolean execute(List<DataSinkConfig> configs) throws DataDeleteHandlerException, SQLException {
    if (StringUtils.isNotBlank(dataSinkInput.getTracingColumn())) {
      try {
        List<DataSinkConfig> filteredConfigs = filter(configs);
        Map<String, Config> inputConfigs = readConfigs(filteredConfigs);
        logger.log(Level.INFO, "Triggering delete for :: " + filteredConfigs);
        deleteFromVertica(filteredConfigs, inputConfigs);
      } catch (Exception ex) {
        logger.log(Level.INFO, " Exception occurred while calling Delete handler :: " + ex.getMessage());
        throw new DataDeleteHandlerException(" Execution Failed For Delete " + ex.getMessage());
      }
    }
    return true;
  }

  private void deleteFromVertica(List<DataSinkConfig> configs, Map<String, Config> inputConfigs) throws SQLException {
    List<String> queries = prepareDeleteQueries(configs, inputConfigs);
    executeDeleteQueries(queries);
  }

  public List<String> checkTableExists(String schema, String table) throws SQLException {
    return verticaUtil.getColumnNamesInorder(schema, table);
  }

  public List<String> prepareDeleteQueries(List<DataSinkConfig> configs, Map<String, Config> inputConfigs)
      throws SQLException {
    List<String> queries = new ArrayList<>();
    List<String> existingFileNames = checkFileExists(configs);
    if (CollectionUtils.isEmpty(existingFileNames)) {
      return queries;
    }
    for (DataSinkConfig config : configs) {
      List<String> files = Stream.of(config.getArchivedFiles(), config.getRollbackFiles()).flatMap(Collection::stream)
          .collect(Collectors.toList());
      EtlConfig etlConfig = (EtlConfig) inputConfigs.get(config.getConfigId());
      List<String> existingFiles = (List<String>) CollectionUtils.intersection(files, existingFileNames);
      if (CollectionUtils.isNotEmpty(existingFiles)) {
        for (String rowtype : etlConfig.getOutputs().keySet()) {
          OutputProperties verticaProperties = etlConfig.getOutputs().get(rowtype).getVertica();
          if(verticaProperties != null) {
            String table = verticaProperties.getTable();
            String schema = verticaProperties.getSchema();
            List<String> tableColumns = checkTableExists(schema, table);
            if (!table.equalsIgnoreCase(dataSinkInput.getMetaDataLogTable()) &&
                CollectionUtils.isNotEmpty(tableColumns)) {
              String configIdforQuery = StringUtils.isNotBlank(this.dataSinkInput.getConformedConfigId())
                  ? this.dataSinkInput.getConformedConfigId()
                  : config.getConfigId();
              List<String> query = createDeleteQuery(existingFiles, configIdforQuery, schema, table);
              queries.addAll(query);
            }
          }
          else {
            logger.log(Level.INFO,
                "ignoring files in S3 for :: " + files + " for " + config.getConfigId());
          }
        }
      } else {
        logger.log(Level.INFO,
            "Given files were not loaded previously for :: " + files + " for " + config.getConfigId());
      }
    }
    return queries;
  }

  public Map<String, Config> readConfigs(List<DataSinkConfig> configs) throws IOException, DataSinkException {
    Map<String, Config> inputConfigs = new HashMap<>();
    EtlConfig etlConfig = null;
    for (DataSinkConfig config : configs) {
      if (dataSinkInput.isOneJobPerConfigId() || etlConfig == null) {
        String templateJson = commonUtil.constructTemplatePath(dataSinkInput.isOneJobPerConfigId(),
            config.getConfigId(), dataSinkInput.getTemplatePath());
        etlConfig = readConfig(templateJson);
      }
      inputConfigs.put(config.getConfigId(), etlConfig);
    }
    return inputConfigs;
  }

  private EtlConfig readConfig(String absoluteConfigPath) throws IOException {
    S3Util s3Util = new S3Util();
    logger.log(Level.INFO, "Reading config from location :: " + absoluteConfigPath);
    return s3Util.getObjectFromJson(absoluteConfigPath, EtlConfig.class);
  }
}