package com.paysafe.unity.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.EMRNotFoundException;
import com.paysafe.unity.model.DataSinkOutput;
import com.paysafe.unity.model.EmrDetails;
import com.paysafe.unity.model.JobDetails;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;
import com.paysafe.unity.util.S3Util;
import com.paysafe.unity.util.VerticaUtil;

import com.amazonaws.services.lambda.runtime.Context;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSinkJobStatusUpdate {

  private static final Logger LOGGER = Logger.getLogger(DataSinkJobStatusUpdate.class.getName());

  public boolean handleRequest(DataSinkOutput dataSinkOutput, Context context) throws Exception {

    LOGGER.info("dataSinkOutput " + dataSinkOutput);

    try {

      boolean atleastOneJobFailed = false;

      AwsConnection awsConnection = new AwsConnection();

      FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

      AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

      InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

      CommonUtil commonUtil = new CommonUtil();

      Map<String, String> connProperties =
              commonUtil.fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

      DBConnection connection = new DBConnection(connProperties);

      VerticaUtil verticaUtil = new VerticaUtil(connection);

      String clusterId =
          dataSinkOutput.getEmrDetails() != null ? dataSinkOutput.getEmrDetails().getEmrClusterId() : StringUtils.EMPTY;

      List<String> queries = new ArrayList<>();

      for (JobDetails jobDetails : dataSinkOutput.getJobDetails()) {

        String status =
            StringUtils.isEmpty(jobDetails.getJobStatus()) ? CommonConstants.FAILED : jobDetails.getJobStatus();

        if (atleastOneJobFailed || CommonConstants.FAILED.equalsIgnoreCase(status)) {
          atleastOneJobFailed = true;
        }

        String reason = constructReason(jobDetails, dataSinkOutput.getEmrDetails());

        LOGGER.info(
            "Updated jobDetails for id :: " + jobDetails.getJobId() + " ,status :: " + status + " ,applicationId :: "
                + jobDetails.getApplicationId() + " ,clusterId :: " + clusterId + " ,reason :: " + reason);

        Map<String,String> dataSinkJobStatus =new HashMap();

        dataSinkJobStatus.put("JobName",jobDetails.getJobName());
        dataSinkJobStatus.put("JobId",jobDetails.getJobId());
        dataSinkJobStatus.put("status",status);
        dataSinkJobStatus.put("applicationId",jobDetails.getApplicationId());
        dataSinkJobStatus.put("clusterId",clusterId);
        dataSinkJobStatus.put("reason",reason);

        LOGGER.info(dataSinkJobStatus.toString());


        String updateQuery = MessageFormat.format(DBConstants.DATA_SINK_STATUS_UPDATE, jobDetails.getJobId(), status,
            jobDetails.getApplicationId(), clusterId, reason);

        queries.add(updateQuery);

        // Delete the payload.
        deletePayload(jobDetails.getJobInput().get(0));
      }

      // Update the job status in Vertica DATA_SINK_JOB table.
      verticaUtil.executeQueries(queries);

      // If emrFailed after updatejob status , Next step is to pushExceptionToSNS
      if (dataSinkOutput.getEmrDetails() == null
          || CommonConstants.FAILED.equalsIgnoreCase(dataSinkOutput.getEmrDetails().getStatus())) {
        throw new EMRNotFoundException(constructReason(null, dataSinkOutput.getEmrDetails()));
      }

      return atleastOneJobFailed;

    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, "Error occured in DataSinkJobStatusUpdate :: {0}", ExceptionUtils.getStackTrace(ex));
      throw ex;
    }
  }

  private void deletePayload(String payLoadPath) {
    LOGGER.info("Deleting the payload from the path " + payLoadPath);
    if (StringUtils.isNotEmpty(payLoadPath)) {
      S3Util s3Util = new S3Util();
      s3Util.deleteObject(payLoadPath);
    }
  }

  private String constructReason(JobDetails jobDetails, EmrDetails emrDetails) {

    if (emrDetails == null) {
      return MessageFormat.format(DBConstants.EMR_CREATION_FAILED, "ephemeral step function is taking too long");

    } else if (CommonConstants.FAILED.equalsIgnoreCase(emrDetails.getStatus())) {
      return MessageFormat.format(DBConstants.EMR_CREATION_FAILED, emrDetails.getErrorMessage());

    } else if (CollectionUtils.isNotEmpty(jobDetails.getReason())) {
      String reason = jobDetails.getReason().toString().replaceAll("\n|\r|\n\r|\'|\"", "");
      reason = reason.length() > CommonConstants.MAX_CHARACTER_LENGTH
          ? reason.substring(0, CommonConstants.MAX_CHARACTER_LENGTH)
          : reason;
      return reason;
    } else {
      return CommonConstants.SUCCESS.equalsIgnoreCase(jobDetails.getJobStatus()) ? CommonConstants.SUCCESS
          : DBConstants.JOB_TAKING_TOO_LONG;
    }

  }

}
