package com.paysafe.unity.ppbi.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.ppbi.model.OracleMifLog;
import com.paysafe.unity.ppbi.model.EmailSenderReceiver;
import com.paysafe.unity.ppbi.model.SesPayload;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.OracleMifUtil;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;
import com.paysafe.unity.util.S3Util;
import com.paysafe.unity.util.SesUtils;
import com.paysafe.unity.util.SnsUtils;
import com.paysafe.unity.util.VerticaUtil;

import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class OracleMifLogTableSyncJob {

    private static final Logger logger = Logger.getLogger(OracleMifLogTableSyncJob.class.getName());

    public boolean handleRequest() throws Exception {

        try {

            AwsConnection awsConnection = new AwsConnection();

            FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

            InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

            AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

            CommonUtil commonUtil = new CommonUtil();

            return syncData(commonUtil, infrastructureUtil, awsSecretsUtil);

        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in OracleMifLogTableSyncJob :: {0}", ExceptionUtils.getStackTrace(ex));
            SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
                    this.getClass().getName(), CommonConstants.ERROR);
            snsUtils.sendEmail(ExceptionUtils.getStackTrace(ex), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
            throw ex;
        }

    }

    public boolean syncData(CommonUtil commonUtil, InfrastructureUtil infrastructureUtil, AwsSecretsUtil awsSecretsUtil)
            throws SQLException, DBQueryException, IllegalAccessException, ClusterException, IOException {

        logger.log(Level.INFO, "Fetching vertica connection");
        DBConnection verticaDBConnection =
                commonUtil.fetchConnection(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

        logger.log(Level.INFO, "Fetching Oracle Mif connection");
        DBConnection oracleMifDBConnection =
                commonUtil.fetchConnection(infrastructureUtil, awsSecretsUtil, LambdaVariables.ORACLE_MIF_CLUSTER_NAME);

        VerticaUtil verticaUtil = new VerticaUtil(verticaDBConnection);

        OracleMifUtil oracleMifUtil = new OracleMifUtil(oracleMifDBConnection);

        String lastProcessDate = verticaUtil.fetchLastProcessDate();
        List<OracleMifLog> oracleMifLogs = oracleMifUtil.fetchLogs(lastProcessDate);
        boolean insertedLogs = verticaUtil.insertOracleMifLogsIntoVertica(oracleMifLogs);
        return insertedLogs;
    }
}