package com.paysafe.unity.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.Count;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.model.FpMetaData;
import com.paysafe.unity.model.HistoricalValidationConfig;
import com.paysafe.unity.ppbi.lambda.VerticaDdlVerification;
import com.paysafe.unity.service.helper.DynamoQueryProvider;
import com.paysafe.unity.service.impl.LoadDynamoQueryBuilder;
import com.paysafe.unity.util.DynamoDbUtil;
import com.paysafe.unity.util.S3Util;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class HistoricalMassCountValidation {

  private DynamoQuery dynamoQuery;
  private static final Logger LOGGER = Logger.getLogger(HistoricalMassCountValidation.class.getName());
  VerticaDdlVerification vertica;
  S3Util s3Util;
  Map<String, ArrayList<String>> missingColsInAllFiles = new HashMap<String, ArrayList<String>>();

  public void handleRequest(HistoricalValidationConfig configInput, Context context) {
    Map<String, String> propsPayload = new HashMap<String, String>();

    try {
      // Validate count is correct

      Map<String, Count> mismatchCountForFile = new HashMap<>();
      vertica = new VerticaDdlVerification();
      vertica.connectToVertica();
      Map<String, String> missingTables = new HashMap<String, String>();
      String query =
          "select table_name as tableName from tables where table_schema= " + "'" + configInput.getSchemaName() + "';";
      // LOGGER.info("Query: " + query);
      for (String config : configInput.getConfigIds()) {

        LOGGER.info("Executing for " + config);
        List<FpMetaData> result = queryDynamo(config, configInput.getWindow());
        ArrayList<String> tables = getVerticaResult(query, "tableName");

        for (FpMetaData fpMetaData : result) {

          String fileName = fpMetaData.getId();
          Map<String, String> jobMetaData = fpMetaData.getJobMetaData();
          String parseCount = convertStringToJson(jobMetaData.get("FPJOB"), "txnCount");

          if (!parseCount.equals("0") && fileName.startsWith(configInput.getPrefix())) {
            String verticaTable = getVerticaTableName(fileName);

            String colQuery = "select * from columns where table_name='" + verticaTable + "' and table_schema='"
                + configInput.getSchemaName() + "'";
            LOGGER.info("colQuery: " + colQuery);
            // Verify table exists
            if (verticaTableExists(verticaTable, tables)) {

              String verticaCount = getVerticaCount(fileName, verticaTable, configInput.getSchemaName());

              // Verify the number of columns are correct.
              missingVerticaCols(getcolumnNamesFromFile(fileName, config), getVerticaResult(colQuery, "column_name"),
                  fileName, verticaTable);

              if (!parseCount.equals(verticaCount))
                mismatchCountForFile.put(fileName, new Count(parseCount, verticaCount));

            } else {
              missingTables.put(fileName, verticaTable);

            }

          }

        }
      }

      if (!mismatchCountForFile.isEmpty() || !missingTables.isEmpty() || !missingColsInAllFiles.isEmpty()) {

        String msg = "Count mistmatch for Below files \n FileName ParseCount VerticaCount \n"
            + CommonConstants.MAPPER.writeValueAsString(mismatchCountForFile) + "\n "
            + "Table not found for below files \n" + CommonConstants.MAPPER.writeValueAsString(missingTables);
        LOGGER.info(msg);

        propsPayload.put("Count mistmatch for below files: ",
            CommonConstants.MAPPER.writeValueAsString(mismatchCountForFile));
        propsPayload.put("Table not found for below files: ", CommonConstants.MAPPER.writeValueAsString(missingTables));

        propsPayload.put("Columns missing in files: ",
            CommonConstants.MAPPER.writeValueAsString(missingColsInAllFiles));

        vertica.sendNotification(propsPayload, "");

      }

    } catch (Exception e) {
      LOGGER.info(e.toString());
      vertica.sendNotification(propsPayload, e.toString());
    }

  }

  public List<FpMetaData> queryDynamo(String configId, String window)
      throws JsonParseException, JsonMappingException, IOException {

    DataSinkInput dataSinkJobInput = new DataSinkInput();

    dataSinkJobInput.setWindow(7);

    dataSinkJobInput.setJobId("DATA_LOAD");

    Date dNow = new Date();
    SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    DynamoQueryProvider dynamoQueryProvider = new DynamoQueryProvider(new LoadDynamoQueryBuilder(dataSinkJobInput));

    DataSinkConfig config = new DataSinkConfig();
    config.setConfigId(configId);
    config.setLastRunDate(
        ft.format(new Date(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(Integer.parseInt(window)))));

    dynamoQueryProvider.createDynamoQuery(config);

    DynamoQuery dynamoQuery = dynamoQueryProvider.getDynamoQuery();

    AwsConnection awsConnection = new AwsConnection();

    DynamoDbUtil util = new DynamoDbUtil(awsConnection);
    List<FpMetaData> result = util.queryTable(dynamoQuery);
    return result;

  }

  public String getVerticaTableName(String fileName) {
    Map<String, String> mm = new HashMap<String, String>();
    mm.put("KASX257A", "Omaha");
    mm.put("KASY741C", "Omaha");
    mm.put("KASY741D", "Omaha");
    mm.put("KASY561A", "Omaha");
    mm.put("KASY561B", "Omaha");
    mm.put("KASY741A", "Omaha");
    mm.put("KASY741B", "North");
    mm.put("SASX670A", "");
    mm.put("KASY339A", "North");
    mm.put("KASY339B", "North");
    mm.put("KASY339C", "Omaha");
    mm.put("KASY339D", "Omaha");
    mm.put("KASY339E", "Omaha");
    mm.put("KASY339F", "Omaha");
    mm.put("KASY339G", "Omaha");
    mm.put("KASY339H", "Omaha");
    mm.put("KASY615A", "Omaha");
    mm.put("KASY638A", "");
    String[] fileArr = fileName.split("_");
    String tableNameString = "";

    for (int counter = 2; counter < fileArr.length; counter++) {

      tableNameString = tableNameString.concat(fileArr[counter]);
    }

    String tableName = tableNameString.replaceAll("[\\s_-]", "").replace(" ", "").replace(".csv", "");
    String schemaName = fileArr[1].substring(3);
    String platform = "MASS" + mm.get(fileArr[0].split("\\.")[0]) + "Access";
    String completeTableName = platform + "_" + tableName + "_" + schemaName;
    // LOGGER.info("TableName: " + completeTableName);
    return completeTableName;

  }

  public String getVerticaCount(String fileName, String verticaTable, String schemaName) throws Exception {
    String envelopeFileName = fileName.substring(0, fileName.indexOf("_"));
    String absoluteTableName = schemaName + "." + verticaTable;
    String query = "select count(*) as verticaCount from  " + absoluteTableName + " where envelopeFileName = '"
        + envelopeFileName + "'";
    LOGGER.info("Vertica query: " + query);
    ResultSet rs = vertica.getVerticaDdl(query);
    rs.next();
    return rs.getString("verticaCount");

  }

  public boolean verticaTableExists(String tableName, ArrayList<String> tables) {
    if (tables.contains(tableName)) {
      return true;
    } else {

      return false;
    }

  }

  public ArrayList<String> getVerticaResult(String query, String col) throws SQLException {

    ResultSet rs = vertica.getVerticaDdl(query);
    ArrayList<String> tableNames = new ArrayList<String>();
    while (rs.next()) {
      tableNames.add(rs.getString(col));
    }
    return tableNames;

  }

  public void missingVerticaCols(String[] fileCols, ArrayList<String> verticaCols, String fileName,
      String verticaTable) {
    ArrayList<String> missingCols = new ArrayList<String>();
    for (String fileCol : fileCols) {
      if (!verticaCols.contains(fileCol)) {
        missingCols.add(fileCol);

      }
    }
    if (!missingCols.isEmpty()) {
      String key = "Columns missing in " + fileName + " in " + verticaTable;
      LOGGER.info(key);
      missingColsInAllFiles.put(key, missingCols);

    }

  }

  public String[] getcolumnNamesFromFile(String fileName, String configId) throws IOException {

    s3Util = new S3Util();

    List<String> absolutePath = s3Util.listObjects(LambdaVariables.SRC_BUCKET,
        "fp-unity/historical/" + configId + "/scrubbing/staging/FILENAME=" + fileName);
    String s3Path = "s3://" + LambdaVariables.SRC_BUCKET + "/" + absolutePath.get(0);

    String[] lines = s3Util.getString(s3Path).split("\n");
    LOGGER.info(Integer.toString(lines.length));
    String[] columns = lines[0].split("|");
    LOGGER.info(Integer.toString(columns.length));
    return columns;
  }

  public String convertStringToJson(String jsonString, String key) {
    try {
      JSONObject jsonObject = new JSONObject(jsonString);
      return jsonObject.get(key).toString();
    } catch (JSONException err) {
      return null;

    }

  }

}
