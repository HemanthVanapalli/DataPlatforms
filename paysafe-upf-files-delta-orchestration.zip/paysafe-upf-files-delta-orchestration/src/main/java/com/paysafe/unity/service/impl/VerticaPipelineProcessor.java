package com.paysafe.unity.service.impl;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.JobDetails;
import com.paysafe.unity.ppbi.model.ClusterProperties;
import com.paysafe.unity.ppbi.model.ConfigProperties;
import com.paysafe.unity.ppbi.model.SparkJobConfiguration;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.helper.AbstractDataSinkPipelineProcessor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class VerticaPipelineProcessor extends AbstractDataSinkPipelineProcessor {

  public VerticaPipelineProcessor(FileSystemConnector connector, DataSinkInput dataSinkJobInput) {
    super(connector, dataSinkJobInput);
  }

  @Override
  public List<JobDetails> generateOutputAndUploadToS3(List<DataSinkConfig> configs) throws Exception {

    List<JobDetails> livyInputs = new ArrayList<>();
    String outputLocation = LambdaVariables.LIVY_PAYLOAD_PATH + CommonConstants.PATH_DELIMITER + UUID.randomUUID();
    ClusterProperties clusterProps = clusterProps();
    for (DataSinkConfig config : configs) {

      SparkJobConfiguration configuration = new SparkJobConfiguration();
      configuration.setClusterProps(clusterProps);
      configuration.setConfigProps(configProps(config));
      configuration.getConfigProps().setId(config.getJobId());

      String livyInputPath = outputLocation + CommonConstants.PATH_DELIMITER + dataSinkInput.getUsecase()
          + CommonConstants.UNDERSCORE + config.getConfigId();

      connector.putObject(livyInputPath, configuration);

      String fileNamesLocation =
          "s3://" + LambdaVariables.SRC_BUCKET + CommonConstants.PATH_DELIMITER + CommonConstants.FILENAMES_PATH + dataSinkInput.getUsecase() + CommonConstants.PATH_DELIMITER + config.getConfigId() + CommonConstants.PATH_DELIMITER +
              UUID.randomUUID();
      List<String> fileNames = config.getArchivedFiles().stream().collect(Collectors.toList());
      connector.putObject(fileNamesLocation, fileNames);
      JobDetails livyInput = new JobDetails();
      livyInput.setJobInput(Arrays.asList(livyInputPath));
      livyInput.setJobId(String.valueOf(config.getJobId()));
      livyInput.setFileNamesLocation(fileNamesLocation);
      livyInput.setJobName(dataSinkInput.getUsecase() + CommonConstants.UNDERSCORE + config.getConfigId());
      livyInput.setConfigId(config.getConfigId());
      livyInputs.add(livyInput);

    }
    return livyInputs;
  }

  private ClusterProperties clusterProps() {
    ClusterProperties clusterProps = new ClusterProperties();
    clusterProps.setName(LambdaVariables.CLUSTER_NAME);
    clusterProps.setEnvironment(LambdaVariables.CLUSTER_ENVIRONMENT);
    clusterProps.setInfrastructurePath(LambdaVariables.INFRASTRUCTURE_PATH);
    clusterProps.setZone(LambdaVariables.CLUSTER_AVAILABILITY_ZONE);
    clusterProps.setRegion(LambdaVariables.CLUSTER_REGION);
    return clusterProps;
  }

  private ConfigProperties configProps(DataSinkConfig config) {
    ConfigProperties configProps = new ConfigProperties();
    List<String> srcFiles = buildSrcPath(config);
    configProps.setSrcFiles(srcFiles);
    configProps.setMetadataPrefix(CommonConstants.S3 + LambdaVariables.SRC_BUCKET + CommonConstants.PATH_DELIMITER
        + dataSinkInput.getTemplatePath());
    configProps.setSrcBucket(LambdaVariables.SRC_BUCKET);
    configProps.setConfigId(config.getConfigId());
    configProps.setZone(LambdaVariables.AWS_ZONE.toUpperCase());
    configProps.setUseCase(dataSinkInput.getUsecase());
    configProps.setHiveEnabled(dataSinkInput.isHiveEnabled());
    return configProps;
  }

}
