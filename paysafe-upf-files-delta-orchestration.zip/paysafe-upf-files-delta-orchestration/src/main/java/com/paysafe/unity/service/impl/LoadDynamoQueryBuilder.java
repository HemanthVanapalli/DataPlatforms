package com.paysafe.unity.service.impl;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.service.DynamoQueryBuilder;
import com.paysafe.unity.util.DateUtil;

import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

import java.time.Duration;

public class LoadDynamoQueryBuilder implements DynamoQueryBuilder {

  private DynamoQuery dynamoQuery;
  private DataSinkInput dataSinkJobInput;

  public LoadDynamoQueryBuilder(DataSinkInput dataSinkJobInput) {

    this.dynamoQuery = new DynamoQuery();
    this.dataSinkJobInput = dataSinkJobInput;
  }

  @Override
  public void buildKeyConditionExpression() {
    dynamoQuery.setKeyConditionExpression("CONFIGID =:configID and updatedTime >:lastRuntime");

  }

  @Override
  public void buildFilterExpression() {
    dynamoQuery.setFilterExpression("FILESTATUS=:filestatus or FILESTATUS=:deletestatus or FILESTATUS=:forexstatus");

  }

  @Override
  public void buildValueMap(DataSinkConfig config) {

    String timeUtc = config.getLastRunDate() == null
        ? DateUtil.getUTCString(DateUtil.minusDuration(Duration.ofDays(dataSinkJobInput.getWindow())))
        : config.getLastRunDate();

    dynamoQuery.setValueMap(new ValueMap().withString(":configID", config.getConfigId())
        .withString(":lastRuntime", timeUtc)
        .withString(":filestatus", CommonConstants.FP_JOB_ARCHIEVED_STATUS)
        .withString(":deletestatus", CommonConstants.ROLLBACKED_STATUS)
        .withString(":forexstatus", CommonConstants.FP_JOB_FOREXED_STATUS));

  }

  @Override
  public void buildIndex() {
    dynamoQuery.setIndex(LambdaVariables.DYNAMO_INDEX_TIME);
  }

  @Override
  public void buildTable() {

    dynamoQuery.setTable(LambdaVariables.FP_METABATA_TABLE);
  }

  @Override
  public DynamoQuery build() {
    return this.dynamoQuery;
  }

}
