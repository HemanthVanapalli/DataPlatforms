package com.paysafe.unity.service.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.model.FpMetaData;
import com.paysafe.unity.service.DynamoQueryBuilder;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.util.DynamoDbUtil;

import org.apache.commons.collections.CollectionUtils;

import java.util.List;

public abstract class FPDataSinkJobProcessor extends AbstractDataSinkJobProcessor {

  private DynamoDbUtil dbUtil;

  public FPDataSinkJobProcessor(FileSystemConnector connector, DBConnection connection, DataSinkInput dataSinkJobInput,
      AwsConnection awsConnection) throws DBQueryException {
    super(connector, connection, dataSinkJobInput, awsConnection);
    this.dbUtil = new DynamoDbUtil(awsConnection);
  }

  public abstract DynamoQueryBuilder getDynamoQueryBuilder();

  @Override
  public List<DataSinkConfig> fetchDeltaFiles(List<DataSinkConfig> configs) throws Exception {
    DynamoQueryProvider dynamoQueryProvider = new DynamoQueryProvider(getDynamoQueryBuilder());

    configs.stream().forEach(config -> {
      try {

        dynamoQueryProvider.createDynamoQuery(config);

        DynamoQuery dynamoQuery = dynamoQueryProvider.getDynamoQuery();

        List<FpMetaData> metadataEntries = dbUtil.queryTable(dynamoQuery);

        if (CollectionUtils.isNotEmpty(metadataEntries)) {

          metadataEntries.forEach(metadata -> {
            if (CommonConstants.ROLLBACKED_STATUS.equalsIgnoreCase(metadata.getFilestatus())) {
              config.getRollbackFiles().add(metadata.getId());
            } else {
              config.getArchivedFiles().add(metadata.getId());
            }
          });

          config.setCurrentRunDate(metadataEntries.get(metadataEntries.size() - 1).getUpdatedTime());
        }
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    });

    return configs;
  }

}
