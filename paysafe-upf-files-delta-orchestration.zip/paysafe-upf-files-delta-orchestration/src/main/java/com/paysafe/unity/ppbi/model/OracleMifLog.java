package com.paysafe.unity.ppbi.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OracleMifLog implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 187677479839L;

    @JsonProperty("INTERFACE_NAME")
    private String interface_name;

    @JsonProperty("PROCESS_DATE")
    private Date process_date;

    @JsonProperty("FILE_NAME")
    private String file_name;

    @JsonProperty("CREATION_DATE")
    private Date creation_date;

    @JsonProperty("TASK_CODE")
    private String task_code;

    @JsonProperty("TASK_STATUS")
    private String task_status;

    @JsonProperty("START_DATE")
    private Date start_date;

    @JsonProperty("END_DATE")
    private Date end_date;

    @JsonProperty("TOTAL_REC_PROCESSED")
    private String total_rec_processed;

    @JsonProperty("TOTAL_REC_REJECTED")
    private String total_rec_rejected;

    @JsonProperty("ERROR_MSG")
    private String error_msg;

    @JsonProperty("LOG_MSG")
    private String log_msg;

    public String getINTERFACE_NAME() {
        return interface_name;
    }

    public void setINTERFACE_NAME(String interface_name) {
        this.interface_name = interface_name;
    }

    public Date getPROCESS_DATE() {
        return process_date;
    }

    public void setPROCESS_DATE(Date process_date) {
        this.process_date = process_date;
    }

    public String getFILE_NAME() {
        return file_name;
    }

    public void setFILE_NAME(String file_name) {
        this.file_name = file_name;
    }

    public Date getCREATION_DATE() {
        return creation_date;
    }

    public void setCREATION_DATE(Date creation_date) {
        this.creation_date = creation_date;
    }

    public String getTASK_CODE() {
        return task_code;
    }

    public void setTASK_CODE(String task_code) {
        this.task_code = task_code;
    }

    public String getTASK_STATUS() {
        return task_status;
    }

    public void setTASK_STATUS(String task_status) {
        this.task_status = task_status;
    }

    public Date getSTART_DATE() {
        return start_date;
    }

    public void setSTART_DATE(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEND_DATE() {
        return end_date;
    }

    public void setEND_DATE(Date end_date) {
        this.end_date = end_date;
    }

    public String getTOTAL_REC_PROCESSED() {
        return total_rec_processed;
    }

    public void setTOTAL_REC_PROCESSED(String total_rec_processed) {
        this.total_rec_processed = total_rec_processed;
    }

    public String getTOTAL_REC_REJECTED() {
        return total_rec_rejected;
    }

    public void setTOTAL_REC_REJECTED(String total_rec_rejected) {
        this.total_rec_rejected = total_rec_rejected;
    }

    public String getERROR_MSG() {
        return error_msg;
    }

    public void setERROR_MSG(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getLOG_MSG() {
        return log_msg;
    }

    public void setLOG_MSG(String log_msg) {
        this.log_msg = log_msg;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }

}
