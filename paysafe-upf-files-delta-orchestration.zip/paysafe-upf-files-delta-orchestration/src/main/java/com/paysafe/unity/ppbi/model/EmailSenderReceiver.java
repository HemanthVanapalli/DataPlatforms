// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2017. For more information see LICENSE

package com.paysafe.unity.ppbi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class EmailSenderReceiver {

  @JsonProperty("SENDER")
  private String sender;

  @JsonProperty("BUSINESSRECEIVER")
  private String businessReceiver;

  @JsonProperty("NONBUSINESSRECEIVER")
  private String nonBusinessReceiver;

  @JsonProperty("CC")
  private String cc;

  @JsonProperty("BCC")
  private String bcc;

  public String getSender() {
    return sender;
  }

  public void setSender(String sender) {
    this.sender = sender;
  }

  public String getBusinessReceiver() {
    return businessReceiver;
  }

  public void setBusinessReceiver(String businessReceiver) {
    this.businessReceiver = businessReceiver;
  }

  public String getNonBusinessReceiver() {
    return nonBusinessReceiver;
  }

  public void setNonBusinessReceiver(String nonBusinessReceiver) {
    this.nonBusinessReceiver = nonBusinessReceiver;
  }

  public String getCc() {
    return cc;
  }

  public void setCc(String cc) {
    this.cc = cc;
  }

  public String getBcc() {
    return bcc;
  }

  public void setBcc(String bcc) {
    this.bcc = bcc;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
