// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2017. For more information see LICENSE

package com.paysafe.unity.ppbi.model;

import com.paysafe.unity.constants.MultiConnectors;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MetaData extends Config {

  @JsonProperty("id")
  private String configId;

  @JsonProperty("businessUnit")
  private String businessUnit;

  @JsonProperty("schema")
  private String schema;

  @JsonProperty("table")
  private String table;

  @JsonProperty("columnMetaData")
  private Map<String, ColumnMetaData> columnMetadata;

  @JsonProperty("dropColumns")
  private List<String> dropColumns;

  @JsonProperty("srcPrefix")
  private String srcPrefix;

  @JsonProperty("dupPrefix")
  private String dupPrefix;

  @JsonProperty("destPrefix")
  private String destPrefix;

  @JsonProperty("filter")
  private String filter;

  @JsonProperty("avoidSchemaUpdates")
  private boolean avoidSchemaUpdates;

  @JsonProperty("outputs")
  private Map<String, List<MultiConnectors>> outputs;

  public MetaData() {

  }

  public MetaData(String id) {
    this.configId = id;
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public String getSchema() {
    return schema;
  }

  public void setSchema(String schema) {
    this.schema = schema;
  }

  public String getTable() {
    return table;
  }

  public void setTable(String table) {
    this.table = table;
  }

  public Map<String, ColumnMetaData> getColumnMetadata() {
    return columnMetadata;
  }

  public void setColumnMetadata(Map<String, ColumnMetaData> columnMetadata) {
    this.columnMetadata = columnMetadata;
  }

  public List<String> getDropColumns() {
    return dropColumns;
  }

  public void setDropColumns(List<String> dropColumns) {
    this.dropColumns = dropColumns;
  }

  public String getSrcPrefix() {
    return srcPrefix;
  }

  public void setSrcPrefix(String srcPrefix) {
    this.srcPrefix = srcPrefix;
  }

  public String getBusinessUnit() {
    return businessUnit;
  }

  public void setBusinessUnit(String businessUnit) {
    this.businessUnit = businessUnit;
  }

  public String getFilter() {
    return filter;
  }

  public void setFilter(String filter) {
    this.filter = filter;
  }

  public String getDupPrefix() {
    return dupPrefix;
  }

  public void setDupPrefix(String dupPrefix) {
    this.dupPrefix = dupPrefix;
  }

  public String getDestPrefix() {
    return destPrefix;
  }

  public void setDestPrefix(String destPrefix) {
    this.destPrefix = destPrefix;
  }

  public boolean isAvoidSchemaUpdates() {
    return avoidSchemaUpdates;
  }

  public void setAvoidSchemaUpdates(boolean avoidSchemaUpdates) {
    this.avoidSchemaUpdates = avoidSchemaUpdates;
  }

  public Map<String, List<MultiConnectors>> getOutputs() {
    return outputs;
  }

  public void setOutputs(Map<String, List<MultiConnectors>> outputs) {
    this.outputs = outputs;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
