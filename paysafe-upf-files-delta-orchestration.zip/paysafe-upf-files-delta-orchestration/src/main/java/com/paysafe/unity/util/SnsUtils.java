// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2018. For more information see LICENSE

package com.paysafe.unity.util;

import com.paysafe.unity.constants.CommonConstants;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.AmazonSNSException;
import com.amazonaws.services.sns.model.PublishRequest;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SnsUtils {

  private AmazonSNS amazonSnsClient = AmazonSNSClientBuilder.defaultClient();
  private final Logger logger = Logger.getLogger(SnsUtils.class.getName());
  private String environment;
  private String zone;
  private String invokingLambda;
  private String alertType;

  public SnsUtils(String env, String zone, String invokingLambda, String alertType) {
    this.environment = env;
    this.zone = zone;
    this.invokingLambda = invokingLambda;
    this.alertType = alertType;
  }

  public void sendEmail(String exceptionStackTrace, Map<String, String> input, String snsTopicArn) {
    try {
      PublishRequest publishRequest = new PublishRequest().withMessage(buildEmailBody(exceptionStackTrace, input))
          .withSubject(buildSubject()).withTopicArn(snsTopicArn);
      amazonSnsClient.publish(publishRequest);
    } catch (AmazonSNSException e) {
      logger.log(Level.SEVERE, "SNS message publish failed", e);
    }

  }

  private String buildSubject() {
    StringBuilder sb = new StringBuilder();
    sb.append(CommonConstants.AWS);
    sb.append(CommonConstants.HYPHEN);
    sb.append(CommonConstants.VERTICA_PIPELINE);
    sb.append(CommonConstants.HYPHEN);
    sb.append(StringUtils.upperCase(environment));
    sb.append(CommonConstants.HYPHEN);
    sb.append(StringUtils.upperCase(zone));
    sb.append(CommonConstants.HYPHEN);
    sb.append(StringUtils.upperCase(invokingLambda));
    sb.append(CommonConstants.HYPHEN);
    sb.append(alertType);
    return sb.toString();
  }

  private String buildEmailBody(String exceptionStackTrace, Map<String, String> input) {
    StringBuilder sb = new StringBuilder();
    sb.append(CommonConstants.NEWLINE);
    if (MapUtils.isNotEmpty(input)) {
      sb.append(buildPayload(input));
      sb.append(CommonConstants.NEWLINE);
    }
    sb.append("StackTrace ::\n").append(exceptionStackTrace);
    return sb.toString();
  }

  private String buildPayload(Map<String, String> input) {
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, String> e : input.entrySet()) {
      sb.append(e.getKey());
      sb.append(CommonConstants.SEMI_COLON);
      sb.append(e.getValue());
      sb.append(CommonConstants.NEWLINE);
    }
    return sb.toString();
  }
}
