package com.paysafe.unity.lambda;


import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.lambda.helper.DataAccessAlertModel;
import com.paysafe.unity.lambda.helper.DataAccessAlertPayload;
import com.paysafe.unity.ppbi.model.SesPayload;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTime;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PIIDataAccessAlert {

    protected Connection connection;
    private static final Logger logger = Logger.getLogger(PIIDataAccessAlert.class.getName());

    public void handleRequest(DataAccessAlertPayload dataAccessAlertPayload, Context context) throws Exception {

        DataAccessAlertModel dataAccessAlertConfig =readConfig(dataAccessAlertPayload.getPayloadPath());

        try {
            AwsConnection awsConnection = new AwsConnection();
            SesUtils sesUtils = new SesUtils();
            AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);
            FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

            InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

            CommonUtil commonUtil = new CommonUtil();

            Map<String, String> connProperties = commonUtil.fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

            DBConnection dbConnection = new DBConnection(connProperties);
            List<Map<String, Object>> queryData = queryVerticaForAccessAlert(dbConnection, dataAccessAlertConfig);


            if (queryData != null) {
                String content = createHtmlTable(queryData, dataAccessAlertConfig);
                ByteArrayOutputStream file = createAttachment(queryData);
                SesPayload payload = new SesPayload();
                payload.setSender(dataAccessAlertConfig.getSenderEmail());
                payload.setRecipients(dataAccessAlertConfig.getNonBusinessReceiver());
                payload.setSubject(dataAccessAlertConfig.getEmailSubject() + LocalDate.now());
                payload.setBodyHtml(content);
                payload.setBodyText(dataAccessAlertConfig.getBodyText());

                sesUtils.sendMailWithAttachment(payload, true, file);
            }
            else{
                logger.log(Level.INFO, dataAccessAlertConfig.getZeroRecordsFromQuery());
            }
            updateMetaDataTable(dbConnection, dataAccessAlertConfig);
        } catch (Exception e) {

            logger.log(Level.INFO, dataAccessAlertConfig.getErrorMsg() + ExceptionUtils.getStackTrace(e));
            SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE, this.getClass().getName(), CommonConstants.ERROR);
            snsUtils.sendEmail(ExceptionUtils.getStackTrace(e), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
            throw e;
        }
    }

    private List<Map<String, Object>> queryVerticaForAccessAlert(DBConnection dbconnection, DataAccessAlertModel dataAccessAlertConfig) throws Exception {
        String query = dataAccessAlertConfig.getDataAccessAlertQuery();
        logger.log(Level.INFO, "Executing Query: " + query);
        List<Map<String, Object>> rows = new ArrayList<>();
        this.connection = dbconnection.getConnection();
        Statement connectionStatement = connection.createStatement();
        logger.log(Level.INFO, "Executing set role query.");
        connectionStatement.execute(dataAccessAlertConfig.getUserRole());
        ResultSet resultSet = connectionStatement.executeQuery(dataAccessAlertConfig.getDataAccessAlertQuery());
        ResultSetMetaData md = resultSet.getMetaData();
        int columns = md.getColumnCount();
        while (resultSet.next()) {
            Map<String, Object> row = new HashMap<>();
            for (int i = 1; i <= columns; ++i) {
                if (resultSet.getObject(i) != null)
                    row.put(md.getColumnName(i).toUpperCase(), resultSet.getObject(i));
            }
            if (!row.isEmpty()) rows.add(row);
        }
        logger.log(Level.INFO, "Executed query {0} obtained result {1}", new Object[]{query,
                rows.size()});
        if (rows.isEmpty()) return null;
        return rows;
    }

    private String createHtmlTable(List<Map<String, Object>> queryRows, DataAccessAlertModel dataAccessAlertConfig) {

        if (queryRows != null && queryRows.size() > 0) {
            String heading = "<h3 style='color:#FF0000;'>PII Data Access Alert </h3> " + "<table rules='all'" + " " + "bordercolor='#4d4c4d' border='1' bgcolor='#FFFFFF'  align='center'" + "style='width:100%' " + " cellspacing='0'>";
            StringBuilder stringBuilder = new StringBuilder(heading);
            stringBuilder.append("<tr>");
            stringBuilder.append("<th>User Name</th>");
            stringBuilder.append("<th>Schema and TableName</th>");
            stringBuilder.append("<th>Columns Accessed</th>");
            stringBuilder.append("<th>Query Execution Timestamp</th>");
            stringBuilder.append("<th>Number of Rows Accessed</th>");
            stringBuilder.append("</tr>");

            for (Map<String, Object> row : queryRows) {
                String user_name = row.get("USER_NAME").toString();
                String request = row.get("QUERY").toString();
                String[] queryData = extractQueryData(request, dataAccessAlertConfig);
                String start_time = row.get("QUERY_START").toString();
                String rowsAccessed = row.get("INPUT_ROWS_PROCESSED").toString();
                stringBuilder.append("<tr>");
                stringBuilder.append("<td>").append(user_name).append("</td>");
                stringBuilder.append("<td>").append(queryData[1]).append("</td>");
                stringBuilder.append("<td>").append(queryData[0]).append("</td>");
                stringBuilder.append("<td>").append(start_time).append("</td>");
                stringBuilder.append("<td>").append(rowsAccessed).append("</td>");
                stringBuilder.append("</tr>");
            }
            stringBuilder.append("</table>");

            return stringBuilder.toString();
        }
        return "";
    }


    public void updateMetaDataTable(DBConnection dbConnection, DataAccessAlertModel dataAccessAlertConfig) throws Exception {
        VerticaUtil verticaUtil = new VerticaUtil(dbConnection);
        DateTime dateTime = DateTime.now();
        String updateQuery = MessageFormat.format(dataAccessAlertConfig.getPII_NOTIFICATION_LOG_AUDIT(), dateTime, "PII Data Access Alert");
        verticaUtil.executeQuery(updateQuery);
    }

    private String[] extractQueryData(String returnedQuery, DataAccessAlertModel dataAccessAlertConfig){
        Pattern getColumnName = Pattern.compile(dataAccessAlertConfig.getRegexForColumnName(), Pattern.CASE_INSENSITIVE);
        Matcher matchColumnName = getColumnName.matcher(returnedQuery);
        Pattern getTableName = Pattern.compile(dataAccessAlertConfig.getRegexForTableName() , Pattern.CASE_INSENSITIVE);
        Matcher matchTableName = getTableName.matcher(returnedQuery);
        String[] queryData = new String[2];
        if (matchColumnName.find()) {
            queryData[0] = matchColumnName.group();
        } else {
            queryData[0] = null;
        }
        if (matchTableName.find()) {
            queryData[1] = matchTableName.group();
        } else {
            queryData[1] = null;
        }
        return queryData;
    }

    private ByteArrayOutputStream createAttachment(List<Map<String, Object>> queryData) throws IOException {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Queries");

        Row rowHead = sheet.createRow((short) 0);
        rowHead.createCell(0).setCellValue("UserName");
        rowHead.createCell(1).setCellValue("Query Execution Timestamp");
        rowHead.createCell(2).setCellValue("Query Executed");
        int rowNum = 1;
        for (Map<String, Object> row : queryData) {
            String user_name = row.get("USER_NAME").toString();
            String start_time = row.get("QUERY_START").toString();
            String request = row.get("QUERY").toString();
            Row ExcelRow = sheet.createRow(rowNum);
            ExcelRow.createCell(0).setCellValue(user_name);
            ExcelRow.createCell(1).setCellValue(start_time);
            ExcelRow.createCell(2).setCellValue(request);
            rowNum++;
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        workbook.write(bos); // write excel data to a byte array
        bos.close();
        logger.log(Level.INFO, "Excel sheet has been created successfully");
        workbook.close();

        return bos;
    }

    public DataAccessAlertModel readConfig(String absoluteConfigPath) throws IOException {
        logger.log(Level.INFO, "Reading config from location :: " + absoluteConfigPath);
        DataAccessAlertModel dataAccessAlertConfig = new S3Util().getObject(absoluteConfigPath, DataAccessAlertModel.class);
        String facebookVerticaLoadStr = new ObjectMapper().writeValueAsString(dataAccessAlertConfig);
        dataAccessAlertConfig = new ObjectMapper().readValue(facebookVerticaLoadStr, DataAccessAlertModel.class);
        return dataAccessAlertConfig;
    }

}