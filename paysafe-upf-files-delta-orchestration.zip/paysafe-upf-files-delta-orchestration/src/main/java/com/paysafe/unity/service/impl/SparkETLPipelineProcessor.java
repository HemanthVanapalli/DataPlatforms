package com.paysafe.unity.service.impl;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataCenter;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.InfraProperties;
import com.paysafe.unity.model.JobDetails;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.helper.AbstractDataSinkPipelineProcessor;
import com.paysafe.unity.util.CommonUtil;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class SparkETLPipelineProcessor extends AbstractDataSinkPipelineProcessor {

  protected CommonUtil commonUtil;

  public SparkETLPipelineProcessor(FileSystemConnector connector, DataSinkInput dataSinkInput) {
    super(connector, dataSinkInput);
    commonUtil = new CommonUtil();
  }

  @Override
  public List<JobDetails> generateOutputAndUploadToS3(List<DataSinkConfig> configs) throws Exception {
    if (dataSinkInput.isOneJobPerConfigId()) {
      return generateLivyInputPerConfig(configs);
    } else {
      return generateLivyInput(configs);
    }
  }

  private Map<String, String> buildVariables() throws ClusterException, IOException {
    Map<String, String> sinkVariables = new HashMap<>();
    sinkVariables.put("SRC_BUCKET", LambdaVariables.SRC_BUCKET);
    sinkVariables.put("ACCOUNTID", LambdaVariables.AWS_ACCOUNTID);
    sinkVariables.put("EDL1ACCOUNTID", LambdaVariables.AWS_EDL1ACCOUNTID);
    sinkVariables.put("EDL2ACCOUNTID", LambdaVariables.AWS_EDL2ACCOUNTID);
    sinkVariables.put("AWS_ENVIRONMENT", LambdaVariables.AWS_ENVIRONMENT);
    sinkVariables.put("AWS_ZONE", LambdaVariables.AWS_ZONE);
    if (CollectionUtils.isNotEmpty(dataSinkInput.getInfraProps())) {
      String infrastructurePath = LambdaVariables.INFRASTRUCTURE_PATH;
      String environment = LambdaVariables.CLUSTER_ENVIRONMENT;
      for (InfraProperties sink : dataSinkInput.getInfraProps()) {
        DataCenter dataCenter = StringUtils.isNotBlank(sink.getZone())
            ? infrastructureUtil.getDataCenter(infrastructurePath, sink.getRegion(), sink.getZone(), environment)
            : infrastructureUtil.getActiveDataCenter(infrastructurePath, sink.getRegion(), environment);
        Map<String, String> connectionProperties =
            infrastructureUtil.getClusterConfiguration(infrastructurePath, sink.getName(), dataCenter);
        if (MapUtils.isNotEmpty(connectionProperties)) {
          sinkVariables.putAll(commonUtil.prefix(connectionProperties, sink.getName()));
        }
      }
    }
    return sinkVariables;
  }

  private List<JobDetails> generateLivyInputPerConfig(List<DataSinkConfig> configs)
      throws ClusterException, IOException, DataSinkException {
    List<JobDetails> livyInputs = new ArrayList<>();
    String outputLocation = LambdaVariables.LIVY_PAYLOAD_PATH + CommonConstants.PATH_DELIMITER + UUID.randomUUID()
        + CommonConstants.PATH_DELIMITER + dataSinkInput.getUsecase();
    Map<String, String> outputVariables = new HashMap<>();
    outputVariables.putAll(buildVariables());
    for (DataSinkConfig config : configs) {
      String inputPath = buildSrcPath(config).stream().collect(Collectors.joining(CommonConstants.COMMA_SEPARATOR));
      outputVariables.put(config.getConfigId().toUpperCase(), inputPath);
      String templateStr =
          connector.getObjectAsString(commonUtil.constructTemplatePath(dataSinkInput.isOneJobPerConfigId(),
              config.getConfigId(), dataSinkInput.getTemplatePath()));
      String inputStr = StringSubstitutor.replace(templateStr, outputVariables);
      String livyInputPath = outputLocation + CommonConstants.UNDERSCORE + config.getConfigId();
      connector.putString(livyInputPath, inputStr);
      String fileNamesLocation =
          "s3://" + LambdaVariables.SRC_BUCKET + CommonConstants.PATH_DELIMITER + CommonConstants.FILENAMES_PATH + dataSinkInput.getUsecase() + CommonConstants.PATH_DELIMITER + config.getConfigId() + CommonConstants.PATH_DELIMITER +
              UUID.randomUUID();
      List<String> fileNames = config.getArchivedFiles().stream().collect(Collectors.toList());
      connector.putObject(fileNamesLocation, fileNames);
      JobDetails livyInput = new JobDetails();
      livyInput.setJobInput(Arrays.asList(livyInputPath));
      livyInput.setJobId(String.valueOf(config.getJobId()));
      livyInput.setFileNamesLocation(fileNamesLocation);
      livyInput.setJobName(dataSinkInput.getUsecase() + CommonConstants.UNDERSCORE + config.getConfigId());
      livyInput.setConfigId(config.getConfigId());
      outputVariables.remove(config.getConfigId().toUpperCase());
      livyInputs.add(livyInput);

    }

    return livyInputs;
  }

  private List<JobDetails> generateLivyInput(List<DataSinkConfig> configs)
      throws ClusterException, IOException, DataSinkException {
    List<JobDetails> livyInputs = new ArrayList<>();
    String livyInputPath = LambdaVariables.LIVY_PAYLOAD_PATH + CommonConstants.PATH_DELIMITER + UUID.randomUUID()
        + CommonConstants.PATH_DELIMITER + dataSinkInput.getUsecase();
    Map<String, String> outputVariables = new HashMap<>();
    outputVariables.putAll(buildVariables());
    List<Long> ids = new ArrayList<>();
    for (DataSinkConfig config : configs) {
      String inputPath = buildSrcPath(config).stream().collect(Collectors.joining(CommonConstants.COMMA_SEPARATOR));
      outputVariables.put(config.getConfigId().toUpperCase(), inputPath);
      ids.add(config.getJobId());
    }

    dataSinkInput.getConfigIds().stream().filter(configId -> !outputVariables.containsKey(configId.toUpperCase()))
        .forEach(configId -> outputVariables.put(configId.toUpperCase(), StringUtils.EMPTY));

    String templateStr = connector.getObjectAsString(
        commonUtil.constructTemplatePath(dataSinkInput.isOneJobPerConfigId(), null, dataSinkInput.getTemplatePath()));

    String inputStr = StringSubstitutor.replace(templateStr, outputVariables);
    connector.putString(livyInputPath, inputStr);
    String idstr = ids.stream().map(String::valueOf).collect(Collectors.joining(CommonConstants.COMMA_SEPARATOR));
    String fileNamesLocation =
        "s3://" + LambdaVariables.SRC_BUCKET + CommonConstants.PATH_DELIMITER + CommonConstants.FILENAMES_PATH + dataSinkInput.getUsecase() + CommonConstants.PATH_DELIMITER  +dataSinkInput.getConformedConfigId() + CommonConstants.PATH_DELIMITER +
            UUID.randomUUID();
    List<String> fileNames =
        configs.stream().map(config -> config.getArchivedFiles().stream().collect(Collectors.joining(",")))
            .collect(Collectors.toList());
    connector.putObject(fileNamesLocation, fileNames);
    JobDetails livyInput = new JobDetails();
    livyInput.setJobInput(Arrays.asList(livyInputPath));
    livyInput.setJobId(idstr);
    livyInput.setJobName(dataSinkInput.getUsecase());
    livyInput.setConfigId(dataSinkInput.getConformedConfigId());
    livyInput.setFileNamesLocation(fileNamesLocation);
    livyInputs.add(livyInput);
    return livyInputs;
  }

}
