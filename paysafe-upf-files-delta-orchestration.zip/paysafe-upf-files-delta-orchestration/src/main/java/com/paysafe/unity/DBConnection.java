package com.paysafe.unity;

import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.service.DataBaseConnection;

import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection implements DataBaseConnection, AutoCloseable {

  private Connection conn = null;

  private static final Logger LOGGER = Logger.getLogger(DBConnection.class.getName());

  private Map<String, String> connProperties;

  public DBConnection(Map<String, String> connProperties) {

    this.connProperties = connProperties;
  }

  public Connection getConnection() throws DBQueryException {

    if (conn == null) {
      try {

        Class.forName(connProperties.get(DBConstants.DRIVER_CLASS));
        String jdbcUrl = connProperties.get(DBConstants.JDBC_URL);

        LOGGER.log(Level.INFO, "Establising connection to jdbc Url");

        Properties properties = new Properties();
        properties.putAll(connProperties);
        properties.put(DBConstants.STREAMING_BATCH_INSERT, true);

        this.conn = DriverManager.getConnection(jdbcUrl, properties);

      } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Exception when creating connection to vertica DB " + e.getMessage());
        throw new DBQueryException(e);
      } catch (ClassNotFoundException e) {
        LOGGER.log(Level.SEVERE, "Exception when creating connection to vertica DB " + e.getMessage());
        throw new DBQueryException(e);
      }

    }
    return conn;
  }

  @Override
  public void close() throws IOException {
    if (conn != null)
      try {
        conn.close();
      } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Unable to close connection " + ExceptionUtils.getStackTrace(e));
        throw new RuntimeException("Unable to close db connection");
      }
  }

}
