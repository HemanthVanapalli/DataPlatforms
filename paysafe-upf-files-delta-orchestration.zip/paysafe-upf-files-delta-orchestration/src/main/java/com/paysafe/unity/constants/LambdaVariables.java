package com.paysafe.unity.constants;

import org.apache.commons.lang3.StringUtils;

public interface LambdaVariables {

  public static final String FP_METABATA_TABLE =
      StringUtils.defaultString(System.getenv("FP_METADATA_TABLE"), "fp-unity-metadata-prod");

  public static final Long WINDOW = Long.parseLong(StringUtils.defaultString(System.getenv("WINDOW"), "1"));

  public static final String VERTICA_SECRET_KEY =
      StringUtils.defaultString(System.getenv("VERTICA_SECRET_KEY"), "vertica-ppbi-cred-private");

  public static final String DYNAMO_INDEX_TIME =
      StringUtils.defaultString(System.getenv("DYNAMO_INDEX_TIME"), "CONFIGID-updatedTime-index");

  public static final String DYNAMO_RELOAD_INDEX =
      StringUtils.defaultString(System.getenv("DYNAMO_RELOAD_INDEX"), "CONFIGID-FILEDATE-index");

  public static final String EMR_TAG_KEY = StringUtils.defaultString(System.getenv("EMR_TAG_KEY"), "ppbi-tag");

  public static final String EMR_TAG_VALUE = StringUtils.defaultString(System.getenv("EMR_TAG_VALUE"), "ppbi-vertica");

  public static final String SRC_BUCKET = StringUtils.defaultString(System.getenv("SRC_BUCKET"), "SRC_BUCKET");

  public static final String AWS_ACCOUNTID = StringUtils.defaultString(System.getenv("AWS_ACCOUNTID"), "preprod");

  public static final String AWS_ENVIRONMENT = StringUtils.defaultString(System.getenv("AWS_ENVIRONMENT"), "preprod");

  public static final String AWS_ZONE = StringUtils.defaultString(System.getenv("AWS_ZONE"), "grey");

  public static final String CLUSTER_AVAILABILITY_ZONE =

      StringUtils.defaultString(System.getenv("CLUSTER_AVAILABILITY_ZONE"), "mtl");

  public static final String CLUSTER_ENVIRONMENT =
      StringUtils.defaultString(System.getenv("CLUSTER_ENVIRONMENT"), "preprod");

  public static final String CLUSTER_REGION = StringUtils.defaultString(System.getenv("CLUSTER_REGION"), "canada");

  public static final String JAR_PATH = StringUtils.defaultString(System.getenv("JAR_PATH"), "JAR_PATH");

  public static final String INFRASTRUCTURE_PATH =
      StringUtils.defaultString(System.getenv("INFRASTRUCTURE_PATH"), "src/test/resources/infrastructure");

  public static final String LIVY_PAYLOAD_PATH =
      StringUtils.defaultString(System.getenv("LIVY_PAYLOAD_PATH"), "LIVY_PAYLOAD_PATH");

  public static final String FP_OUTPUT_PREFIX =
      StringUtils.defaultString(System.getenv("FP_OUTPUT_PREFIX"), "fp-unity/output/");

  public static final String STATE_MACHINE_ARN =
      StringUtils.defaultString(System.getenv("STATE_MACHINE_ARN"), "STEP_FUNCTION_ARN");

  public static final String DYNAMO_STS_ROLE = StringUtils.defaultString(System.getenv("DYNAMODB_ROLE_ARN"),
      "arn:aws:iam::550629512586:role/ppbi-unity-xacc-dynamodb-full-access-prep");

  public static final String APERIA_CLUSTER_NAME =
      StringUtils.defaultString(System.getenv("APERIA_CLUSTER_NAME"), "aperia_mssql");

  public static final String ORACLE_MIF_CLUSTER_NAME =
      StringUtils.defaultString(System.getenv("ORACLE_MIF_CLUSTER_NAME"), "oracle_mif_sql");

  public static final String CLUSTER_NAME = StringUtils.defaultString(System.getenv("CLUSTER_NAME"), "ppbi_vertica");

  public static final String METADATA_CONFIG_PREFIX = StringUtils
      .defaultString(System.getenv("METADATA_CONFIGS_S3_LOCATION"), "src/test/resources/workflow-scripts/configs/");

  public static final String ALERT_SNS_TOPIC_ARN = StringUtils.defaultString(System.getenv("ALERT_SNS_TOPIC_ARN"), "");

  public static final String NOTIFICATION_SES_PATH =  StringUtils
      .defaultString(System.getenv("NOTIFICATION_SES_PATH"), "ppbi-unity/configs/usAcquiring/SesNotification.json");

  public static final String NOCSESPath =
      StringUtils.defaultString(System.getenv("NOCSESPath"),
          "ppbi-unity/configs/usAcquiring/SesNotificationFormat.json");

  public static final String AWS_EDL1ACCOUNTID =  StringUtils
          .defaultString(System.getenv("AWS_EDL1ACCOUNTID"), "550629512586");

  public static final String AWS_EDL2ACCOUNTID =  StringUtils
          .defaultString(System.getenv("AWS_EDL2ACCOUNTID"), "332318758586");


}
