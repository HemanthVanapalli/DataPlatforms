// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2017. For more information see LICENSE

package com.paysafe.unity.etl.model;

import com.paysafe.unity.ppbi.model.Config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EtlConfig extends Config {

  @JsonProperty("appName")
  private String appName;

  @JsonProperty("inputs")
  private Map<String, InputPath> inputs;

  @JsonProperty("connectionProperties")
  private Map<String, ConnectionProperties> connectionProperties;

  @JsonProperty("stages")
  private List<SqlQueries> stages;

  @JsonProperty("outputs")
  private Map<String,VerticaSync> outputs;

  @JsonProperty("explain")
  private String explain;

  @JsonProperty("showPreviewLines")
  private String showPreviewLines;

  @JsonProperty("showQuery")
  private String showQuery;

  @JsonProperty("cacheOnPreview")
  private String cacheOnPreview;

  @JsonProperty("logLevel")
  private String logLevel;

  @JsonProperty("cacheCountOnOutput")
  private String cacheCountOnOutput;

  @JsonProperty("continueOnFailedStep")
  private String continueOnFailedStep;

  @JsonProperty("enableHiveSupport")
  private boolean enableHiveSupport;

  public EtlConfig() {

  }

  public String getAppName() {
    return appName;
  }

  public void setAppName(String appName) {
    this.appName = appName;
  }

  public Map<String, InputPath> getInputs() {
    return inputs;
  }

  public void setInputs(Map<String, InputPath> inputs) {
    this.inputs = inputs;
  }

  public Map<String, ConnectionProperties> getConnectionProperties() {
    return connectionProperties;
  }

  public void setConnectionProperties(
      Map<String, ConnectionProperties> connectionProperties) {
    this.connectionProperties = connectionProperties;
  }

  public List<SqlQueries> getStages() {
    return stages;
  }

  public void setStages(List<SqlQueries> stages) {
    this.stages = stages;
  }

  public  Map<String,VerticaSync>  getOutputs() {
    return outputs;
  }

  public void setOutputs( Map<String,VerticaSync>  outputs) {
    this.outputs = outputs;
  }

  public String getExplain() {
    return explain;
  }

  public void setExplain(String explain) {
    this.explain = explain;
  }

  public String getShowPreviewLines() {
    return showPreviewLines;
  }

  public void setShowPreviewLines(String showPreviewLines) {
    this.showPreviewLines = showPreviewLines;
  }

  public String getShowQuery() {
    return showQuery;
  }

  public void setShowQuery(String showQuery) {
    this.showQuery = showQuery;
  }

  public String getCacheOnPreview() {
    return cacheOnPreview;
  }

  public void setCacheOnPreview(String cacheOnPreview) {
    this.cacheOnPreview = cacheOnPreview;
  }

  public String getLogLevel() {
    return logLevel;
  }

  public void setLogLevel(String logLevel) {
    this.logLevel = logLevel;
  }

  public String getCacheCountOnOutput() {
    return cacheCountOnOutput;
  }

  public void setCacheCountOnOutput(String cacheCountOnOutput) {
    this.cacheCountOnOutput = cacheCountOnOutput;
  }

  public String getContinueOnFailedStep() {
    return continueOnFailedStep;
  }

  public void setContinueOnFailedStep(String continueOnFailedStep) {
    this.continueOnFailedStep = continueOnFailedStep;
  }

  public boolean isEnableHiveSupport() {
    return enableHiveSupport;
  }

  public void setEnableHiveSupport(boolean enableHiveSupport) {
    this.enableHiveSupport = enableHiveSupport;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
