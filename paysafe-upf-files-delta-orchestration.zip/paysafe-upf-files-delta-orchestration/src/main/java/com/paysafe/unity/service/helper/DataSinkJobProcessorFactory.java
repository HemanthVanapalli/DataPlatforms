package com.paysafe.unity.service.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.JobType;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DataSinkJobProcessor;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.LoadProcessor;
import com.paysafe.unity.service.impl.ReloadProcessor;

import org.apache.commons.lang3.StringUtils;

import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSinkJobProcessorFactory {

  private static final Logger logger = Logger.getLogger(DataSinkJobProcessorFactory.class.getName());

  private FileSystemConnector fileSystemConnector;
  private DataSinkInput dataSinkJobInput;
  private DBConnection connection;
  private AwsConnection awsConnection;

  public DataSinkJobProcessorFactory(FileSystemConnector fileSystemConnector, DataSinkInput dataSinkJobInput,
      DBConnection connection, AwsConnection awsConnection) {
    this.fileSystemConnector = fileSystemConnector;
    this.dataSinkJobInput = dataSinkJobInput;
    this.connection = connection;
    this.awsConnection = awsConnection;
  }

  public DataSinkJobProcessor getProcessor() throws DataSinkException, DBQueryException {

    JobType type = dataSinkJobInput.getJobType();
    String sourceType =
        StringUtils.isEmpty(dataSinkJobInput.getSrcType()) ? CommonConstants.FP_UNITY : dataSinkJobInput.getSrcType();

    logger.log(Level.INFO, "Fetching DataSinkJonProcessor for jobtype " + type + " sourceType " + sourceType);
    switch (type) {
    case LOAD: {
      switch (sourceType) {
      case CommonConstants.FP_UNITY:
        return new LoadProcessor(fileSystemConnector, connection, dataSinkJobInput, awsConnection);
      default:
        return new VerticaDataSinkJobProcessor(fileSystemConnector, connection, dataSinkJobInput, awsConnection);
      }
    }
    case RELOAD:
      return new ReloadProcessor(fileSystemConnector, connection, dataSinkJobInput, awsConnection);
    default:
      throw new DataSinkException("No relevant job type found");
    }

  }
}
