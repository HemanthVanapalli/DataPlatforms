package com.paysafe.unity.service.impl;

import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.service.DataSinkConfiguration;
import com.paysafe.unity.service.FileSystemConnector;

import java.io.IOException;
import java.util.UUID;

public class DataSinkConfigurationImpl implements DataSinkConfiguration {

  private FileSystemConnector fileSystemConnector;

  public DataSinkConfigurationImpl(FileSystemConnector fileSystemConnector) {
    this.fileSystemConnector = fileSystemConnector;
  }

  @Override
  public DataSinkInput getPayload(String inputPath) throws IOException {
    return fileSystemConnector.getObject(inputPath, DataSinkInput.class);
  }

  @Override
  public String getLivyPayloadLocation() {
    return LambdaVariables.LIVY_PAYLOAD_PATH + UUID.randomUUID();
  }

}
