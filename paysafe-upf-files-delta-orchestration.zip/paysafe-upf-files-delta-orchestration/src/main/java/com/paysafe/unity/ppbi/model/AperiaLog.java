package com.paysafe.unity.ppbi.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AperiaLog implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 187677479839L;

  @JsonProperty("EventID")
  private Long eventID;

  @JsonProperty("InsertDateTimeUTC")
  private Date insertDateTimeUTC;

  @JsonProperty("LogLevel")
  private String logLevel;

  @JsonProperty("LogEntryType")
  private String logEntryType;

  @JsonProperty("FileName")
  private String fileName;

  @JsonProperty("OriginalFileName")
  private String originalFileName;

  @JsonProperty("BusinessUnit")
  private String businessUnit;

  @JsonProperty("ReportName")
  private String reportName;

  @JsonProperty("UserName")
  private String userName;

  @JsonProperty("Host")
  private String host;

  @JsonProperty("ElapsedTimeSeconds")
  private String elapsedTimeSeconds;

  @JsonProperty("Description")
  private String description;

  @JsonProperty("Kilobytes")
  private String kilobytes;

  @JsonProperty("RowCount")
  private String rowCount;

  @JsonProperty("ValidRecordCount")
  private String validRecordCount;

  @JsonProperty("InvalidRecordCount")
  private String invalidRecordCount;

  public Long getEventID() {
    return eventID;
  }

  public void setEventID(Long eventID) {
    this.eventID = eventID;
  }

  public Date getInsertDateTimeUTC() {
    return insertDateTimeUTC;
  }

  public void setInsertDateTimeUTC(Date insertDateTimeUTC) {
    this.insertDateTimeUTC = insertDateTimeUTC;
  }

  public String getLogLevel() {
    return logLevel;
  }

  public void setLogLevel(String logLevel) {
    this.logLevel = logLevel;
  }

  public String getLogEntryType() {
    return logEntryType;
  }

  public void setLogEntryType(String logEntryType) {
    this.logEntryType = logEntryType;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getOriginalFileName() {
    return originalFileName;
  }

  public void setOriginalFileName(String originalFileName) {
    this.originalFileName = originalFileName;
  }

  public String getBusinessUnit() {
    return businessUnit;
  }

  public void setBusinessUnit(String businessUnit) {
    this.businessUnit = businessUnit;
  }

  public String getReportName() {
    return reportName;
  }

  public void setReportName(String reportName) {
    this.reportName = reportName;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getHost() {
    return host;
  }

  public void setHost(String host) {
    this.host = host;
  }

  public String getElapsedTimeSeconds() {
    return elapsedTimeSeconds;
  }

  public void setElapsedTimeSeconds(String elapsedTimeSeconds) {
    this.elapsedTimeSeconds = elapsedTimeSeconds;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getKilobytes() {
    return kilobytes;
  }

  public void setKilobytes(String kilobytes) {
    this.kilobytes = kilobytes;
  }

  public String getRowCount() {
    return rowCount;
  }

  public void setRowCount(String rowCount) {
    this.rowCount = rowCount;
  }

  public String getValidRecordCount() {
    return validRecordCount;
  }

  public void setValidRecordCount(String validRecordCount) {
    this.validRecordCount = validRecordCount;
  }

  public String getInvalidRecordCount() {
    return invalidRecordCount;
  }

  public void setInvalidRecordCount(String invalidRecordCount) {
    this.invalidRecordCount = invalidRecordCount;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
