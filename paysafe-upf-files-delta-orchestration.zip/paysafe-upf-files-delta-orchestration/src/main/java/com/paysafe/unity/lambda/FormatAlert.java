package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.events.SNSEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkInvokerError;
import com.paysafe.unity.model.JobAlertDetails;
import com.paysafe.unity.util.SesUtils;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FormatAlert {

    private static final Logger LOGGER = Logger.getLogger ( FormatAlert.class.getName ( ) );
    private StringBuilder msg = new StringBuilder ( );
    private String subject = "";
    private String jobName = "null";
    private ObjectMapper mapper = new ObjectMapper ( );
    SesUtils sesUtils = new SesUtils ( );

    public void handleRequest(SNSEvent event, Context context) throws JsonProcessingException {

        List<String> inputEvents = new ArrayList<>();
        try {
            LOGGER.log(Level.INFO, "Getting input from Sns message");
            List<SNSEvent.SNSRecord> snsRecordList = event.getRecords();
            if (snsRecordList != null) {
                SNSEvent.SNS recordSNS = null;
                for (SNSEvent.SNSRecord snsRecord : snsRecordList) {
                    recordSNS = snsRecord.getSNS();
                    inputEvents.add(recordSNS.getMessage());
                    LOGGER.log(Level.INFO, recordSNS.getMessage());
                }
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error occured in SNSread", ExceptionUtils.getStackTrace(ex));
        }
        try {
            for (String inputEvent : inputEvents) {
                JSONObject jsonObject = new JSONObject(inputEvent);
                LOGGER.log(Level.INFO, jsonObject.toString());
                if (jsonObject.has ( "payloadPath" ))
                    dataSinkInvokerAlert ( mapper.readValue ( jsonObject.toString ( ), DataSinkInvokerError.class ) );
                else if (jsonObject.has ( "context" ))
                    deltaPipelineAlert ( mapper.readValue ( jsonObject.toString ( ), JobAlertDetails.class ) );
                
            }
        } catch (JSONException | IOException e) {
            e.printStackTrace();
        }
    }

    public void deltaPipelineAlert(JobAlertDetails configInput) {

        LOGGER.info(configInput.toString());
        subject = "ERROR::PPBI::" + LambdaVariables.AWS_ENVIRONMENT.toUpperCase ( ) + "::"
                + LambdaVariables.AWS_ZONE.toUpperCase ( ) + "::" + configInput.getData ( ).getUsecase ( ).toUpperCase ( );

        try {
            if (configInput.getData ( ) != null) {
                msg.append ( "<br>Please refer "
                        + "<a href=\"https://confluence.neterra.paysafe.com/display/ARCHITECT/" +
                        "paysafe-upf-files-delta-orchestration+Runbook\">paysafe-upf-files-delta-orchestration Runbook</a>" + " for Remediations section<br><br>" );
                if (configInput.getData ( ).getJobId ( ) != null)
                    msg.append ( "<br>" + "JobId : " + configInput.getData ( ).getJobId ( ) + "<br>" );
                if(configInput.getData ( ).getUsecase ( )!=null)
                msg.append ( "Usecase: " + configInput.getData ( ).getUsecase ( ) + "<br>" );
                msg.append ( "JobName: " + configInput.getData ( ).getJobName ( ) + "<br>" );
                msg.append ( "EMR ClusterId: " + configInput.getData ( ).getEmrDetails ( ).getEmrClusterId ( ) + "<br>" );
                msg.append ( "Application ID: " + configInput.getData ( ).getLivyResponse ( ).getAppId ( ) + "<br>" );
                msg.append ( "State: " + configInput.getData ( ).getLivyResponse ( ).getState ( ) + "<br><br>" );
                msg.append ( "Detailed Message : " + "<br>" + mapper.writerWithDefaultPrettyPrinter ( ).writeValueAsString ( configInput ) );
            }
        } catch (JsonProcessingException e) {
            LOGGER.log( Level.SEVERE, e.getMessage () );
        }
        sesUtils.sendSesMail ( subject, msg.toString ( ), LambdaVariables.NOCSESPath, false );
    }


    public void dataSinkInvokerAlert(DataSinkInvokerError configInput) {

        String payloadPath = configInput.getPayloadPath ( );
        String pattern = "(.*)/(.*?).json";
        Matcher m = Pattern.compile ( pattern ).matcher ( payloadPath );
        String config;
        if (m.find ( ))
            config = m.group ( 2 );
        else
            config = "";
        subject = "ERROR::DATASINKINVOKER::"
                + LambdaVariables.AWS_ENVIRONMENT.toUpperCase ( )
                + "::" + LambdaVariables.AWS_ZONE.toUpperCase ( ) + "::" + config;

        try {
            String cause = configInput.getErrorDetails ( ).getCause ( );
            JSONObject jsonObject = new JSONObject ( cause );
            msg.append ( "<br>Please refer "
                    + "<a href=\"https://confluence.neterra.paysafe.com/display/ARCHITECT/" +
                    "paysafe-upf-files-delta-orchestration+Runbook\">paysafe-upf-files-delta-orchestration Runbook</a>"
                    + " for Remediations section<br><br>" );
            msg.append("<br>PayloadPath : ").append(payloadPath).append("<br>");
            msg.append("Error : ").append(configInput.getErrorDetails().getError()).append("<br>");
            msg.append("Error Detail : ").append(jsonObject.get("errorMessage")).append("<br>");
            msg.append("<br><br>" + "Detailed Message : " + "<br>").append(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(configInput));
        } catch (JsonProcessingException | JSONException e) {
            LOGGER.log( Level.SEVERE, e.getMessage () );
        }
        sesUtils.sendSesMail ( subject, msg.toString ( ), LambdaVariables.NOCSESPath, false );
    }

}