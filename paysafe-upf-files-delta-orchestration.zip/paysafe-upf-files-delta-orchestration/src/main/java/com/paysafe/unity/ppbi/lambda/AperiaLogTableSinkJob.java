package com.paysafe.unity.ppbi.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.ppbi.model.AperiaLog;
import com.paysafe.unity.ppbi.model.EmailSenderReceiver;
import com.paysafe.unity.ppbi.model.SesPayload;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.AperiaUtil;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;
import com.paysafe.unity.util.S3Util;
import com.paysafe.unity.util.SesUtils;
import com.paysafe.unity.util.SnsUtils;
import com.paysafe.unity.util.VerticaUtil;

import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class AperiaLogTableSinkJob {

    private static final Logger logger = Logger.getLogger(AperiaLogTableSinkJob.class.getName());
    SesUtils sesUtils = new SesUtils();

    public boolean handleRequest() throws Exception {

        try {

            AwsConnection awsConnection = new AwsConnection();

            FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

            InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

            AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

            CommonUtil commonUtil = new CommonUtil();

            return syncData(commonUtil, infrastructureUtil, awsSecretsUtil);

        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in AperiaLogTableSinkJob :: {0}", ex);
            SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
                    this.getClass().getName(), CommonConstants.ERROR);
            snsUtils.sendEmail(ExceptionUtils.getStackTrace(ex), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
            throw ex;
        }

    }

    public boolean syncData(CommonUtil commonUtil, InfrastructureUtil infrastructureUtil, AwsSecretsUtil awsSecretsUtil)
            throws SQLException, DBQueryException, IllegalAccessException, ClusterException, IOException {

        logger.log(Level.INFO, "Fetching vertica connection");
        DBConnection verticaDBConnection =
                commonUtil.fetchConnection(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

        logger.log(Level.INFO, "Fetching aperia connection");
        DBConnection aperiaDBConnection =
                commonUtil.fetchConnection(infrastructureUtil, awsSecretsUtil, LambdaVariables.APERIA_CLUSTER_NAME);

        VerticaUtil verticaUtil = new VerticaUtil(verticaDBConnection);

        AperiaUtil aperiaUtil = new AperiaUtil(aperiaDBConnection);

        Long lastRunId = verticaUtil.fetchLastRunEventID();
        List<AperiaLog> aperiaLogs = aperiaUtil.fetchLogs(lastRunId);
        boolean insertedLogs = verticaUtil.insertLogsIntoVertica(aperiaLogs);
        boolean sendNotification = invalidRecordCountAndCorrectedFiles(lastRunId, verticaUtil);
        return insertedLogs;
    }

    public boolean invalidRecordCountAndCorrectedFiles(long lastRunId, VerticaUtil verticaUtil) throws SQLException {
        List<String> correctedFiles = verticaUtil.fetchCorrectedFiles(lastRunId);
        List<AperiaLog> invalidFiles = verticaUtil.fetchInvalidRecordCountFiles(lastRunId);
        List<String> duplicateFiles = verticaUtil.fetchDuplicateFiles(lastRunId);

        try {
            if (duplicateFiles.size() > 0) {
                String subject = "Aperia identified duplicate files | " + LambdaVariables.AWS_ENVIRONMENT;
                String body =
                        duplicateFiles.toString().replaceAll(",", " <br>").replaceAll("[{}]", " ")
                                .replaceAll("\\[", "").replaceAll("\\]", "");
                logger.log(Level.INFO, "Sending email with subject :: " + subject + " ,Body :: " + body);
                sesUtils.sendSesMail(subject, body, LambdaVariables.NOTIFICATION_SES_PATH,true);
            }
            if (correctedFiles.size() > 0) {
                String subject = "Corrected Files reloaded | " + LambdaVariables.AWS_ENVIRONMENT;
                String body =
                        correctedFiles.toString().replaceAll(",", " is Reloaded, ").replaceAll(",", " <br>").replaceAll("[{}]", " ")
                                .replaceAll("\\[", "").replaceAll("\\]", "");
                logger.log(Level.INFO, "Sending email with subject :: " + subject + " ,Body :: " + body);
                sesUtils.sendSesMail(subject, body, LambdaVariables.NOTIFICATION_SES_PATH, true);
            }
            if (invalidFiles != null && invalidFiles.size() > 0) {
                String subject = "Files with Invalid Record Counts From Aperia | " + LambdaVariables.AWS_ENVIRONMENT;
                String staticContent = " has Invalid Record Count = ";
                String content =
                        invalidFiles
                                .stream().map(aperiaLog -> aperiaLog.getFileName() + "( originalfilename = "
                                + aperiaLog.getOriginalFileName() + ")"
                                + staticContent + aperiaLog.getInvalidRecordCount()).collect(Collectors.joining("<br>"));
                logger.log(Level.INFO, "Sending email with subject :: " + subject + " ,Body :: " + content);
                sesUtils.sendSesMail(subject, content, LambdaVariables.NOTIFICATION_SES_PATH,true);
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in fetching Corrected files and Invalid Record Count Files");
        }
        return true;
    }
}