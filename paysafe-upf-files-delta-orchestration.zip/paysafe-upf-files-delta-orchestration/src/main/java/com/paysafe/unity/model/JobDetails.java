package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobDetails {

  private List<String> jobInput;
  private String jobId;
  private String jobName;
  private String jobStatus;
  private String applicationId = "";
  private List<String> reason;
  private String configId;

  public String getFileNamesLocation() {
    return fileNamesLocation;
  }

  public void setFileNamesLocation(String fileNamesLocation) {
    this.fileNamesLocation = fileNamesLocation;
  }

  private String fileNamesLocation;

  public List<String> getJobInput() {
    return jobInput;
  }

  public void setJobInput(List<String> jobInput) {
    this.jobInput = jobInput;
  }

  public String getJobName() {
    return jobName;
  }

  public void setJobName(String jobName) {
    this.jobName = jobName;
  }

  public String getJobId() {
    return jobId;
  }

  public void setJobId(String jobId) {
    this.jobId = jobId;
  }

  public String getJobStatus() {
    return jobStatus;
  }

  public void setJobStatus(String jobStatus) {
    this.jobStatus = jobStatus;
  }

  public String getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
  }

  public List<String> getReason() {
    return reason;
  }

  public void setReason(List<String> reason) {
    this.reason = reason;
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
