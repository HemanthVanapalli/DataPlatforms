package com.paysafe.unity.ppbi.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConfigProperties implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 186479839L;

  private String configId;
  private List<String> srcFiles;
  private String srcBucket;
  private String metadataPrefix;
  private Long id;
  private String zone;
  private String useCase;
  private boolean hiveEnabled;

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public List<String> getSrcFiles() {
    return srcFiles;
  }

  public void setSrcFiles(List<String> srcFiles) {
    this.srcFiles = srcFiles;
  }

  public String getSrcBucket() {
    return srcBucket;
  }

  public void setSrcBucket(String srcBucket) {
    this.srcBucket = srcBucket;
  }

  public String getMetadataPrefix() {
    return metadataPrefix;
  }

  public void setMetadataPrefix(String metadataPrefix) {
    this.metadataPrefix = metadataPrefix;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getZone() {
    return zone;
  }

  public void setZone(String zone) {
    this.zone = zone;
  }

  public String getUseCase() {
    return useCase;
  }

  public void setUseCase(String useCase) {
    this.useCase = useCase;
  }

  public boolean isHiveEnabled() {
    return hiveEnabled;
  }

  public void setHiveEnabled(boolean hiveEnabled) {
    this.hiveEnabled = hiveEnabled;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
