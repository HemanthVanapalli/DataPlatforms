package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.util.S3Util;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.logging.Level;
import java.util.logging.Logger;



public class S3InputPathReader {

    static final Logger logger = Logger.getLogger(S3InputPathReader.class.getName());

    public JSONObject handleRequest(String fileLocation, Context context) throws Exception {
        try {
            S3Util s3Util = new S3Util();
            String jsonString = s3Util.getString(fileLocation);
            jsonString = jsonString.replaceAll("\\{EDL2ACCOUNTID\\}", LambdaVariables.AWS_EDL2ACCOUNTID).replaceAll("\\{EDL1ACCOUNTID\\}", LambdaVariables.AWS_EDL1ACCOUNTID);
            logger.log(Level.INFO, "The input json is ::" + jsonString);
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(jsonString);
            return json;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Exception occured while running job ::" + ex.getMessage());
            throw ex;
        }
    }




}
