package com.paysafe.unity.model;

import com.paysafe.unity.constants.JobType;
import com.paysafe.unity.constants.Pipeline;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataSink {

    private String businessUnit;
    private LivyCommand livyCommand; // required for spark submit
    private String jobId; // used for constructing application id in livy submit
    private String emrName; // used for epheremal emr
    private Pipeline pipeline;
    private String usecase;
    private JobType jobType;
    private EmrDetails emrDetails;
    private Long timeoutSeconds = 10800L;

    public LivyCommand getLivyCommand() {
        return livyCommand;
    }

    public void setLivyCommand(LivyCommand command) {
        this.livyCommand = command;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getEmrName() {
        return emrName;
    }

    public void setEmrName(String emrName) {
        this.emrName = emrName;
    }

    public String getUsecase() {
        return usecase;
    }

    public void setUsecase(String usecase) {
        this.usecase = usecase;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public EmrDetails getEmrDetails() {
        return emrDetails;
    }

    public void setEmrDetails(EmrDetails emrDetails) {
        this.emrDetails = emrDetails;
    }

    public Pipeline getPipeline() {
        return pipeline;
    }

    public void setPipeline(Pipeline pipeline) {
        this.pipeline = pipeline;
    }

    public JobType getJobType() {
        return jobType;
    }

    public void setJobType(JobType jobType) {
        this.jobType = jobType;
    }

    public Long getTimeoutSeconds() {
        return timeoutSeconds;
    }

    public void setTimeoutSeconds(Long timeoutSeconds) {
        this.timeoutSeconds = timeoutSeconds;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }

}
