package com.paysafe.unity.lambda.helper;

import com.paysafe.gdp.fp.common.config.etl.EtlPipelineConfig;
import com.paysafe.gdp.fp.common.util.S3Util;

import com.amazonaws.services.s3.AmazonS3URI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JobsInvokerHelper {
  public static S3Util s3Util = new S3Util();
  private static Logger logger = Logger.getLogger(JobsInvokerHelper.class.getName());
  private static final String CACHE_WINDOW = "#WINDOWSIZE_DAYS:";
  private static final String APPFLOW_WINDOW = "#APPFLOW_WINDOWSIZE_DAYS:";
  private static final String APPFLOW_DATA = "appflowdata";
  private static final String CACHE = "cache";

  public static boolean containsData(String s3Path) {
    AmazonS3URI amazonS3Uri = new AmazonS3URI(s3Path);
    String bucket = amazonS3Uri.getBucket();
    String prefix = amazonS3Uri.getKey();
    return !s3Util.getS3Client().listObjects(bucket, prefix).getObjectSummaries().isEmpty();
  }

  public static List<String> getSubDirPaths(String path) {
    AmazonS3URI amazonS3URI = new AmazonS3URI(path);
    List<String> subDirs = s3Util.getSubDirList(amazonS3URI.getBucket(), amazonS3URI.getKey());
    Set<String> subDirSet = new HashSet<>(subDirs);
    logger.log(Level.INFO, "for path {0}", path);
    logger.log(Level.INFO, "sub directories {0}", subDirSet);
    if(subDirSet.isEmpty()){
      logger.log(Level.INFO, "no subdirectory found for path {0}, considering it as source path", path);
      return Collections.singletonList(path);
    }
    return subDirSet.stream().map(dir -> path + dir).collect(Collectors.toList());
  }

  /**
   * Start and end dates are inclusive
   *
   * @param start .
   * @param end .
   * @param df
   * @param prefix .
   * @return list of s3 paths containg data in the given date range.
   */
  public static List<String> getComputedPaths(LocalDateTime start, LocalDateTime end,
      DateTimeFormatter df, String prefix) {
    List<String> fullPaths = new ArrayList<>();
    List<String> paths = Stream.iterate(start, date -> date.plusHours(1))
        .limit(ChronoUnit.HOURS.between(start, end) + 1).map(d -> prefix + d.format(df) + "/")
        .filter(JobsInvokerHelper::containsData).collect(Collectors.toList());
    for (String path : paths) {
      fullPaths.addAll(getSubDirPaths(path));
    }
    return fullPaths;
  }

  public static List<String> getComputedPaths(LocalDate start, LocalDate end, DateTimeFormatter df,
      String prefix, String suffix) {
    return Stream.iterate(start, date -> date.plusDays(1))
        .limit(ChronoUnit.DAYS.between(start, end) + 1).map(d -> prefix + d.format(df))
        .filter(JobsInvokerHelper::containsData).map(d -> d + suffix).collect(Collectors.toList());
  }

  public static void putConfigInS3(String s3Path, String finalConfig) {
    AmazonS3URI amazonS3Uri = new AmazonS3URI(s3Path);
    s3Util.getS3Client().putObject(amazonS3Uri.getBucket(), amazonS3Uri.getKey(), finalConfig);
  }

  public static String updateAppflowPaths(String etlConfig) throws JsonProcessingException, IOException {
    logger.log(Level.INFO, "populate dirs:: {0}", etlConfig);
    EtlPipelineConfig etlPipelineConfig =
        new ObjectMapper().readValue(etlConfig, EtlPipelineConfig.class);
    if (etlPipelineConfig.getInputs().get(APPFLOW_DATA) == null) {
      return etlConfig;
    }
    String appflowPath = etlPipelineConfig.getInputs().get(APPFLOW_DATA).getFileCustom().getPath();
    String prefix = appflowPath.split(APPFLOW_WINDOW)[0];
    String days = appflowPath.split(APPFLOW_WINDOW)[1];

    DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy/MM/dd/HH");
    LocalDateTime end = LocalDateTime.now();
    LocalDateTime start = end.plusHours(-24L * Integer.parseInt(days));
    List<String> s3Paths = getComputedPaths(start, end, df, prefix);
    etlPipelineConfig.getInputs().get(APPFLOW_DATA).getFileCustom()
        .setPath(String.join(",", s3Paths));
    return new ObjectMapper().writeValueAsString(etlPipelineConfig);
  }

  public static String updateCachePaths(String etlConfig) throws JsonProcessingException,IOException {
    logger.log(Level.INFO, "populate dirs:: {0}", etlConfig);
    EtlPipelineConfig etlPipelineConfig =
        new ObjectMapper().readValue(etlConfig, EtlPipelineConfig.class);
    if (etlPipelineConfig.getInputs().get(CACHE) == null) {
      return etlConfig;
    }
    String cachePath = etlPipelineConfig.getInputs().get(CACHE).getFileCustom().getPath();

    String prefix = cachePath.split(CACHE_WINDOW)[0];
    String days = cachePath.split(CACHE_WINDOW)[1];

    DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    LocalDate end = LocalDate.now();
    LocalDate start = end.plusDays(-Integer.parseInt(days));
    List<String> s3Paths = getComputedPaths(start, end, df, prefix, "/");
    etlPipelineConfig.getInputs().get(CACHE).getFileCustom().setPath(String.join(",", s3Paths));
    return new ObjectMapper().writeValueAsString(etlPipelineConfig);
  }
}
