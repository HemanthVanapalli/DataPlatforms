package com.paysafe.unity.ppbi.lambda;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.ppbi.model.EmailSenderReceiver;
import com.paysafe.unity.ppbi.model.SesPayload;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.AwsSecretsUtil;
import com.paysafe.unity.util.CommonUtil;
import com.paysafe.unity.util.InfrastructureUtil;
import com.paysafe.unity.util.S3Util;
import com.paysafe.unity.util.SesUtils;
import com.paysafe.unity.util.SnsUtils;
import com.paysafe.unity.util.VerticaUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VerticaFileNotification {

  private static final Logger logger = Logger.getLogger(VerticaFileNotification.class.getName());
  SesUtils sesUtils = new SesUtils();

  public boolean handleRequest() {
    try {
      AwsConnection awsConnection = new AwsConnection();
      FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);
      InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);
      AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);
      CommonUtil commonUtil = new CommonUtil();
      return fetchDelay(commonUtil, infrastructureUtil, awsSecretsUtil);
    } catch (Exception ex) {
      logger.log(Level.SEVERE, "Error occured in VerticaFileNotification Job :: {0}", ex);
      SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
          this.getClass().getName(), CommonConstants.ERROR);
      snsUtils.sendEmail(ExceptionUtils.getStackTrace(ex), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
      return false;
    }
  }

  public boolean fetchDelay(CommonUtil commonUtil, InfrastructureUtil infrastructureUtil,
      AwsSecretsUtil awsSecretsUtil)
      throws SQLException, DBQueryException, ClusterException, IOException {
    logger.log(Level.INFO, "Fetching vertica connection");
    try {
      DBConnection verticaDBConnection =
          commonUtil.fetchConnection(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);
      VerticaUtil verticaUtil = new VerticaUtil(verticaDBConnection);
      logger.log(Level.INFO, "queries started");
      String thresholdTime = "10";
      Map<String, String> delayFiles = new HashMap<>();
      verticaUtil.fetchDelayTime(delayFiles,thresholdTime);
      logger.log(Level.INFO, "delayFiles " + delayFiles);
      if (!delayFiles.isEmpty()) {
        String subject = "Files with delay in load time | " + LambdaVariables.AWS_ENVIRONMENT;
        String staticContent = " has delay time of <b>";
        String content =
                delayFiles.toString().replaceAll("=", staticContent).replaceAll(",", "</b> hrs <br>")
                .replaceAll("[{}]", " ")
                .replaceAll("\\[", "").replaceAll("\\]", "");
        content = content + "</b> hrs";
        sesUtils.sendSesMail(subject, content, LambdaVariables.NOTIFICATION_SES_PATH, false);
      }
    } catch (Exception ex) {
      logger.log(Level.INFO, "Error occured in fetching delay in Files");
      SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
          this.getClass().getName(), CommonConstants.ERROR);
      snsUtils.sendEmail(ExceptionUtils.getStackTrace(ex), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
      throw ex;
    }
    return true;
  }
}
