package com.paysafe.unity.util;


import com.paysafe.unity.exception.EMRNotFoundException;

import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduce;
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduceClientBuilder;
import com.amazonaws.services.elasticmapreduce.model.Cluster;
import com.amazonaws.services.elasticmapreduce.model.ClusterState;
import com.amazonaws.services.elasticmapreduce.model.ClusterSummary;
import com.amazonaws.services.elasticmapreduce.model.DescribeClusterRequest;
import com.amazonaws.services.elasticmapreduce.model.Instance;
import com.amazonaws.services.elasticmapreduce.model.InstanceGroupType;
import com.amazonaws.services.elasticmapreduce.model.ListClustersRequest;
import com.amazonaws.services.elasticmapreduce.model.ListClustersResult;
import com.amazonaws.services.elasticmapreduce.model.ListInstancesRequest;
import com.amazonaws.services.elasticmapreduce.model.Tag;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class EmrUtils {

  private static AmazonElasticMapReduce emr = AmazonElasticMapReduceClientBuilder.defaultClient();;
  private static Logger logger = Logger.getLogger(EmrUtils.class.getName());

  /**
   * gets EMR clusters that has the given tag
   * 
   * @param emrTagKey
   * @param emrTagValue
   * @return
   */
  public static Cluster getExistingValidCluster(String emrTagKey, String emrTagValue) {
    String nextMarker = null;
    while (true) {
      ListClustersResult resp = emr.listClusters(new ListClustersRequest()
          .withClusterStates(ClusterState.RUNNING, ClusterState.WAITING).withMarker(nextMarker));

      nextMarker = resp.getMarker();
      for (ClusterSummary clusterSummary : resp.getClusters()) {
        Cluster cluster = emr
            .describeCluster(new DescribeClusterRequest().withClusterId(clusterSummary.getId()))
            .getCluster();
        if (cluster.getTags() != null) {
          for (Tag tag : cluster.getTags()) {
            if (tag.getKey().equalsIgnoreCase(emrTagKey) && 
                tag.getValue().equalsIgnoreCase(emrTagValue)) {
              return cluster;
            }
          }
        }
      }
      if (nextMarker == null || nextMarker.isEmpty()) {
        break;
      }
    }

    return null;
  }

  public static List<Instance> getMasterNodes(Cluster cluster) {
    return emr.listInstances(new ListInstancesRequest().withClusterId(cluster.getId())
        .withInstanceGroupTypes(InstanceGroupType.MASTER)).getInstances();
  }

  public static Cluster getClusterWithTag(String emrTagKey, String emrTagValue) throws EMRNotFoundException {
    logger.log(Level.INFO, "checking the available emr with the tag key {0} and value {1}",
        new Object[] {emrTagKey, emrTagValue});

    Cluster validClusterToUse = getExistingValidCluster(emrTagKey, emrTagValue);

    logger.log(Level.INFO, "EMR cluster found with the tag {0}={1} is  {2}",
        new Object[] {emrTagKey, emrTagValue, validClusterToUse});

    if (validClusterToUse == null) { // no running cluster with that name, so create one, will wait until state is
      throw new EMRNotFoundException(
          String.format("No EMR cluster found in WAITING and RUNNING state for tag %s=%s", emrTagKey, emrTagValue));
    }

    return validClusterToUse;

  }

  public static Instance getMasterNode(Cluster validClusterToUse) throws EMRNotFoundException {
    List<Instance> masterNodes = getMasterNodes(validClusterToUse);
    if (masterNodes.isEmpty()) {
      throw new EMRNotFoundException(String.format("master nodes not found for %s", validClusterToUse.getId()));
    }
    return masterNodes.get(0);
  }
}