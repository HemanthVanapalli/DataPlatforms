package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class VerticaMetaData {

  private String id;
  private String configId;
  private String archivedFiles;
  private String rollbackFiles;
  private String lastRun;
  private String status;
  private String updatedOn;
  private String reason;
  private String jobType;
  private String usecase;
  private String clusterId;
  private String applicationId;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public String getArchivedFiles() {
    return archivedFiles;
  }

  public void setArchivedFiles(String archivedFiles) {
    this.archivedFiles = archivedFiles;
  }

  public String getRollbackFiles() {
    return rollbackFiles;
  }

  public void setRollbackFiles(String rollbackFiles) {
    this.rollbackFiles = rollbackFiles;
  }

  public String getLastRun() {
    return lastRun;
  }

  public void setLastRun(String lastRun) {
    this.lastRun = lastRun;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getUpdatedOn() {
    return updatedOn;
  }

  public void setUpdatedOn(String updatedOn) {
    this.updatedOn = updatedOn;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public String getJobType() {
    return jobType;
  }

  public void setJobType(String jobType) {
    this.jobType = jobType;
  }

  public String getUsecase() {
    return usecase;
  }

  public void setUsecase(String usecase) {
    this.usecase = usecase;
  }

  public String getClusterId() {
    return clusterId;
  }

  public void setClusterId(String clusterId) {
    this.clusterId = clusterId;
  }

  public String getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
