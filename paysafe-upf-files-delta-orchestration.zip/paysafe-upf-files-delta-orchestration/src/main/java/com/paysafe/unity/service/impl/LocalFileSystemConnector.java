package com.paysafe.unity.service.impl;

import com.paysafe.unity.service.helper.AbstractFileSystemConnector;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LocalFileSystemConnector extends AbstractFileSystemConnector {

  private static final Logger LOGGER = Logger.getLogger(LocalFileSystemConnector.class.getName());

  @Override
  public <T> T getObject(String path, Class<T> valueType) throws IOException {
    String content = new String(Files.readAllBytes(Paths.get(path)));
    return deserialize(content, valueType);
  }

  @Override
  public List<String> listObjects(String configsPath) throws IOException {

    LOGGER.info("configs path = " + configsPath);

    List<String> files = new ArrayList<String>();

    try (Stream<Path> walk = Files.walk(Paths.get(configsPath))) {

      files = walk.filter(Files::isRegularFile).map(x -> x.toString()).collect(Collectors.toList());

    }
    return files;

  }

  @Override
  public boolean putObject(String fileLocation, Object value) throws IOException {

    String content = OBJECT_MAPPER.writeValueAsString(value);

    Files.write(Paths.get(fileLocation), content.getBytes());

    return true;
  }

  @Override
  public String getObjectAsString(String path) throws IOException {
    return new String(Files.readAllBytes(Paths.get(path)));
  }

  @Override
  public boolean putString(String fileLocation, String value) throws IOException {
    Files.write(Paths.get(fileLocation), value.getBytes());
    return true;
  }

}
