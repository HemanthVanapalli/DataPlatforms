package com.paysafe.unity.exception;

public class PPBIJobMonitoringException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -8938203219605534985L;

  public PPBIJobMonitoringException(String message) {
    super(message);
  }

  public PPBIJobMonitoringException(String message, Throwable cause) {
    super(message, cause);

  }

  public PPBIJobMonitoringException(Throwable cause) {
    super(cause);

  }

}
