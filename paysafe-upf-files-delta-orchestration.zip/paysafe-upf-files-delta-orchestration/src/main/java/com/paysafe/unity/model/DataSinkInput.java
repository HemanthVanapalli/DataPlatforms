package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataSinkInput extends DataSink {

  private String templatePath;
  private List<String> configIds;
  private int window;
  private String startDate;
  private String endDate;
  private List<InfraProperties> infraProps;
  private boolean oneJobPerConfigId = true;
  private String tracingColumn;
  private String srcType;
  private List<Path> srcPaths;
  private String conformedConfigId;
  private String metaDataLogTable;
  private String metaDataTable;
  private boolean hiveEnabled;

  public String getTemplatePath() {
    return templatePath;
  }

  public void setTemplatePath(String templatePath) {
    this.templatePath = templatePath;
  }

  public List<String> getConfigIds() {
    return configIds;
  }

  public void setConfigIds(List<String> configIds) {
    this.configIds = configIds;
  }

  public int getWindow() {
    return window;
  }

  public void setWindow(int window) {
    this.window = window;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public List<InfraProperties> getInfraProps() {
    return infraProps;
  }

  public void setInfraProps(List<InfraProperties> infraProps) {
    this.infraProps = infraProps;
  }

  public String getTracingColumn() {
    return tracingColumn;
  }

  public void setTracingColumn(String tracingColumn) {
    this.tracingColumn = tracingColumn;
  }

  public boolean isOneJobPerConfigId() {
    return oneJobPerConfigId;
  }

  public void setOneJobPerConfigId(boolean oneJobPerConfigId) {
    this.oneJobPerConfigId = oneJobPerConfigId;
  }

  public List<Path> getSrcPaths() {
    return srcPaths;
  }

  public void setSrcPaths(List<Path> srcPaths) {
    this.srcPaths = srcPaths;
  }

  public String getSrcType() {
    return srcType;
  }

  public void setSrcType(String srcType) {
    this.srcType = srcType;
  }


  public String getConformedConfigId() {
    return conformedConfigId;
  }

  public void setConformedConfigId(String conformedConfigId) {
    this.conformedConfigId = conformedConfigId;
  }

  public String getMetaDataLogTable() {
    return metaDataLogTable;
  }

  public void setMetaDataLogTable(String metaDataLogTable) {
    this.metaDataLogTable = metaDataLogTable;
  }


  public String getMetaDataTable() {
    return metaDataTable;
  }

  public void setMetaDataTable(String metaDataTable) {
    this.metaDataTable = metaDataTable;
  }

  public boolean isHiveEnabled() {
    return hiveEnabled;
  }

  public void setHiveEnabled(boolean hiveEnabled) {
    this.hiveEnabled = hiveEnabled;
  }
  
  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }


}
