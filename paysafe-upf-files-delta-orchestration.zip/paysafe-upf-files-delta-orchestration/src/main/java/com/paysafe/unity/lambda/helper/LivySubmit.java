package com.paysafe.unity.lambda.helper;

import com.paysafe.unity.model.LivyResponse;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class LivySubmit {

  private static Logger logger = Logger.getLogger(LivySubmit.class.getName());

  public static LivyResponse callLivyJob(String endpoint, String livyCommand) throws IOException {
    
    logger.log(Level.INFO, "callLivyJob with endpoint {0} ",endpoint);

    Gson gson = new Gson();

    try (CloseableHttpClient client = HttpClients.createDefault()) {
      StringEntity requestEntity = new StringEntity(livyCommand, "UTF-8");

      HttpPost postMethod = new HttpPost(endpoint);
      postMethod.setHeader("Content-Type", "application/json");
      postMethod.setEntity(requestEntity);

      CloseableHttpResponse resp = client.execute(postMethod);
      return gson.fromJson(IOUtils.toString(resp.getEntity().getContent(), "UTF-8"), LivyResponse.class);
    }
  }

}
