package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataSinkAlert extends DataSink {
  private JobDetails jobDetails;

  private String jobName;

  private LivyResponse livyResponse;

  public JobDetails getJobDetails() {
    return jobDetails;
  }

  public void setJobDetails(JobDetails configs) {
    this.jobDetails = configs;
  }


  public LivyResponse getLivyResponse() {
    return livyResponse;
  }

  public void setLivyResponse(LivyResponse livyResponse) {
    this.livyResponse = livyResponse;
  }

  public String getJobName() {
    return jobName;
  }

  public void setJobName(String jobName) {
    this.jobName = jobName;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
