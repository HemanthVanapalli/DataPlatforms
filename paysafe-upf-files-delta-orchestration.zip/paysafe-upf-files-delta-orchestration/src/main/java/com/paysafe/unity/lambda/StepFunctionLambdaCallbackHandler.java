package com.paysafe.unity.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.stepfunctions.AWSStepFunctionsClientBuilder;
import com.amazonaws.services.stepfunctions.model.SendTaskSuccessRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paysafe.unity.ppbi.model.CallbackInput;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StepFunctionLambdaCallbackHandler {

  Logger logger = Logger.getLogger(StepFunctionLambdaCallbackHandler.class.getName());

  private static ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  public String handleRequest(CallbackInput callbackDto, Context context) throws IOException {
    logger.log(Level.INFO, "Input: {0}", callbackDto);
    logger.log(Level.INFO, "Context: {0}", context);
    sendSuccessCallback(callbackDto);
    return "true";
  }

  private void sendSuccessCallback(final CallbackInput callbackDto) throws IOException {
    String output = OBJECT_MAPPER.writeValueAsString(callbackDto.getOutput());
    logger.log(Level.INFO, "Sending success callback request for task {0} :: {1}",
        new Object[] {callbackDto.getToken(), output});
    final SendTaskSuccessRequest sendTaskSuccessRequest = new SendTaskSuccessRequest();
    sendTaskSuccessRequest.setTaskToken(callbackDto.getToken());
    sendTaskSuccessRequest.setOutput(output);
    AWSStepFunctionsClientBuilder.defaultClient().sendTaskSuccess(sendTaskSuccessRequest);
  }

}
