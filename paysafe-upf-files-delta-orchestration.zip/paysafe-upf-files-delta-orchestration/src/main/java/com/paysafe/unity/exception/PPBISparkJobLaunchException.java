package com.paysafe.unity.exception;

public class PPBISparkJobLaunchException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -8938203219605534985L;

  public PPBISparkJobLaunchException(String message) {
    super(message);
  }

  public PPBISparkJobLaunchException(String message, Throwable cause) {
    super(message, cause);

  }

  public PPBISparkJobLaunchException(Throwable cause) {
    super(cause);

  }

}
