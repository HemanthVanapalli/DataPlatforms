package com.paysafe.unity.lambda;

import com.paysafe.unity.model.DataSinkEvent;
import com.paysafe.unity.util.StepFunctionUtils;

import java.time.Instant;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EventDataSinkInvokerRetry {
    private static final Logger logger = Logger.getLogger(EventDataSinkInvokerRetry.class.getName());

    public void handleRequest() throws Exception{

        EventJobRetrySQSHandler eventJobRetrySQSHandler = new EventJobRetrySQSHandler();

        logger.log(Level.INFO, "Polling queue for messages.");
        List<DataSinkEvent> eventList = null;
        try {
            eventList = eventJobRetrySQSHandler.pollRetryQueue();
            logger.log(Level.INFO, "Total Messages fetched from the queue. " + eventList.size());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Unable to fetch messages from the queue. Error: " + e);
            throw e;
        }

        String eventTime = String.valueOf(Instant.now());

        if (!eventList.isEmpty()) {
            String stepFunctionArn = System.getenv("STATE_MACHINE_ARN");
            for (DataSinkEvent dataSinkEvent : eventList) {
                logger.log(Level.INFO, "datasink Event value:: " + dataSinkEvent.toString().replaceAll("DataSinkEvent", ""));

                //Create payload for each message polled from the queue.
                String payload = "{\"payloadPath\":" + "\"" + dataSinkEvent.getPayloadPath() + "\"" + ",\"files\":" + "\"" + dataSinkEvent.getFiles() + "\"" + ",\"configId\":" + "\"" + dataSinkEvent.getConfigId() + "\"" + ",\"eventTime\" :" + "\"" + eventTime +"\"}";
                logger.log(Level.INFO, "payload value:: " + payload);
                StepFunctionUtils.startExecution(stepFunctionArn, payload);
            }
        }
    }
}