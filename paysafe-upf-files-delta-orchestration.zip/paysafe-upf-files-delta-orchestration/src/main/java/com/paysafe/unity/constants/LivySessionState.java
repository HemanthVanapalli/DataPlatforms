package com.paysafe.unity.constants;

public enum LivySessionState {

  NOT_STARTED("not_started","Session has not been started"),
  STARTING("starting","Session is starting"),
  IDLE("idle","Session is waiting for input"),
  BUSY("busy","Session is executing a statement"),
  SHUTTING_DOWN("shutting_down","Session is shutting down"),
  ERROR("error","Session errored out"),
  DEAD("dead","Session has exited"),
  KILLED("killed","Session has been killed"),
  SUCCESS("success","Session is successfully stopped");
  
  private final String state;
  private final String description;

  private LivySessionState(String state, String description) {
      this.state = state;
      this.description = description;
  }

  
  /**
   * .
   */
  public String getState() {
      return state;
  }

  /**
   * Descriptive readable name for this state .
   */
  public String getDescription() {
      return description;
  }

}
