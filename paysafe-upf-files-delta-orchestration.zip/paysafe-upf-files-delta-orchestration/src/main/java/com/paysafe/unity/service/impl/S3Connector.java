package com.paysafe.unity.service.impl;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.service.helper.AbstractFileSystemConnector;

import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.s3.model.ObjectListing;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class S3Connector extends AbstractFileSystemConnector {

  AmazonS3 s3 = null;

  public S3Connector(AwsConnection awsConnection) {

    this.s3 = awsConnection.s3Connection();
  }

  @Override
  public <T> T getObject(String path, Class<T> valueType) throws IOException {

    AmazonS3URI amazonS3URI = new AmazonS3URI(path);

    String content = s3.getObjectAsString(amazonS3URI.getBucket(), amazonS3URI.getKey());

    return deserialize(content, valueType);
  }

  @Override
  public List<String> listObjects(String configsPath) {

    AmazonS3URI amazonS3URI = new AmazonS3URI(configsPath);

    ObjectListing objectListing = s3.listObjects(amazonS3URI.getBucket(), amazonS3URI.getKey());

    List<String> s3ObjectKeys = new ArrayList<String>();

    do {
      s3ObjectKeys.addAll(objectListing.getObjectSummaries().stream().filter(summary -> summary.getSize() > 0)
          .map(summary -> summary.getKey()).collect(Collectors.toList()));
      objectListing = s3.listNextBatchOfObjects(objectListing);
    } while (objectListing.isTruncated());

    s3ObjectKeys.addAll(objectListing.getObjectSummaries().stream().filter(summary -> summary.getSize() > 0)
        .map(summary -> summary.getKey()).collect(Collectors.toList()));

    return s3ObjectKeys;

  }

  @Override
  public boolean putObject(String fileLocation, Object value) {
    AmazonS3URI amazonS3URI = new AmazonS3URI(fileLocation);
    try {
      s3.putObject(amazonS3URI.getBucket(), amazonS3URI.getKey(), OBJECT_MAPPER.writeValueAsString(value));
    } catch (SdkClientException | JsonProcessingException e) {
      return false;
    }
    return true;

  }

  @Override
  public boolean putString(String fileLocation, String value) {
    AmazonS3URI amazonS3URI = new AmazonS3URI(fileLocation);
    try {
      s3.putObject(amazonS3URI.getBucket(), amazonS3URI.getKey(), value);
    } catch (SdkClientException e) {
      return false;
    }
    return true;

  }

  @Override
  public String getObjectAsString(final String path) throws IOException {
    AmazonS3URI amazonS3URI = new AmazonS3URI(path);
    return s3.getObjectAsString(amazonS3URI.getBucket(), amazonS3URI.getKey());
  }

}
