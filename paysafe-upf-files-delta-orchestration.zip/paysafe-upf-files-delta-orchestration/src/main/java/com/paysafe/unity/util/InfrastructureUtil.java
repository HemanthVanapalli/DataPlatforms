package com.paysafe.unity.util;

import static java.lang.String.join;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.model.DataCenter;
import com.paysafe.unity.model.Infrastructure;
import com.paysafe.unity.service.FileSystemConnector;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InfrastructureUtil {

  private static final Logger logger = Logger.getLogger(InfrastructureUtil.class.getName());
  private FileSystemConnector connector;

  public InfrastructureUtil(FileSystemConnector connector) {
    this.connector = connector;
  }

  /**
   * Method for fetching infrastructure e
   * 
   * @throws IOException
   */
  private Infrastructure getInfrastructure(final String infrastructurePath) throws IOException {
    String file =
        infrastructurePath + CommonConstants.PATH_DELIMITER + CommonConstants.INFRASTRUCTURE + CommonConstants.DOT_JSON;
    logger.info("Reading infrastructure configuration from " + file);
    return connector.getObject(file, Infrastructure.class);
  }

  /**
   * Method for getting data centers for given region,zone and environment
   *
   * @throws ClusterException
   * @throws IOException
   */
  public DataCenter getDataCenter(final String infrastructurePath, final String region, final String zone,
      final String environment) throws ClusterException, IOException {
    logger.log(Level.INFO, "Fetching datacenter from path {0} , environment {1}, region {2},zone {3}",
        new Object[] {infrastructurePath, environment, region, zone});

    List<DataCenter> dataCenters = getInfrastructure(infrastructurePath).getDataCenters(environment);
    final Predicate<? super DataCenter> withRegion = x -> x.getRegion().equalsIgnoreCase(region);
    final Predicate<? super DataCenter> withZone = x -> x.getName().equalsIgnoreCase(zone);

    final Supplier<? extends ClusterException> exception = () -> new ClusterException(region, zone, environment);

    return dataCenters.stream().filter(withRegion).filter(withZone).findFirst().orElseThrow(exception);
  }

  /**
   * Method for getting only active data centers for given region,and environment
   *
   * @throws ClusterException
   * @throws IOException
   */
  public DataCenter getActiveDataCenter(final String infrastructurePath, final String region, final String environment)
      throws ClusterException, IOException {
    logger.log(Level.INFO, "Fetching active datacenter from path {0} , environment {1}, region {2}",
        new Object[] {infrastructurePath, environment, region});

    List<DataCenter> dataCenters = getInfrastructure(infrastructurePath).getDataCenters(environment);
    final Predicate<? super DataCenter> withRegion = x -> x.getRegion().equalsIgnoreCase(region);
    final Predicate<? super DataCenter> withActive = x -> x.getActive();
    final Supplier<? extends ClusterException> exception = () -> new ClusterException(region, "", environment);

    return dataCenters.stream().filter(withRegion).filter(withActive).findFirst().orElseThrow(exception);
  }

  /**
   * Method for getting use case specific cluster details for given region and environment
   *
   * @throws ClusterException
   * @throws IOException
   */
  public Map<String, String> getActiveClusterConfiguration(final String infrastructurePath, final String cluster,
      final String region, final String environment) throws ClusterException, IOException {
    logger.log(Level.INFO, "Fetching active {0} cluster configuration from path {1} , environment {2}, region {3}",
        new Object[] {cluster, infrastructurePath, environment, region});
    final DataCenter activeDataCenter = getActiveDataCenter(infrastructurePath, region, environment);
    return getClusterConfiguration(infrastructurePath, cluster, activeDataCenter);
  }

  /**
   * Method for getting use case specific cluster details for given dataCenter
   *
   * @throws IOException
   */
  @SuppressWarnings("unchecked")
  public Map<String, String> getClusterConfiguration(final String infrastructurePath, final String cluster,
      final DataCenter dataCenter) throws IOException {
    final String file = join(CommonConstants.PATH_DELIMITER, infrastructurePath, dataCenter.getSuffix(),
        cluster + CommonConstants.DOT_JSON);
    logger.info("Reading cluster configuration from " + file);
    return connector.getObject(file, Map.class);
  }

}
