// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2017. For more information see LICENSE

package com.paysafe.unity.ppbi.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MultiConnectors implements Serializable {

  private static final long serialVersionUID = 1899894039L;

  @JsonProperty("VERTICA")
  private Boolean vertica = false;

  @JsonProperty("S3")
  private String s3;

  @JsonProperty("KAFKA")
  private Boolean kafka = false;

  public MultiConnectors() {

  }

  public Boolean getVertica() {
    return vertica;
  }

  public void setVertica(Boolean vertica) {
    this.vertica = vertica;
  }

  public String getS3() {
    return s3;
  }

  public void setS3(String s3) {
    this.s3 = s3;
  }

  public Boolean getKafka() {
    return kafka;
  }

  public void setKafka(Boolean kafka) {
    this.kafka = kafka;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
