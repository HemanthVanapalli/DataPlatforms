package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmrDetails {

  private String status;
  private String emrClusterId = "";
  private String masterPublicDnsName;
  private String errorMessage;

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getEmrClusterId() {
    return emrClusterId;
  }

  public void setEmrClusterId(String emrClusterId) {
    this.emrClusterId = emrClusterId;
  }

  public String getMasterPublicDnsName() {
    return masterPublicDnsName;
  }

  public void setMasterPublicDnsName(String masterPublicDnsName) {
    this.masterPublicDnsName = masterPublicDnsName;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
