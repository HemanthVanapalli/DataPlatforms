package com.paysafe.unity.util;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.VerticaMetaData;
import com.paysafe.unity.ppbi.model.AperiaLog;
import com.paysafe.unity.ppbi.model.OracleMifLog;
import org.apache.commons.lang3.exception.ExceptionUtils;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class VerticaUtil extends DBUtil {

    private static final Logger LOGGER = Logger.getLogger(VerticaUtil.class.getName());

    public VerticaUtil(DBConnection dbConnection) throws DBQueryException {
        super(dbConnection);

    }

    /***
     *
     * @param businessUnit
     * @return
     * @throws DBQueryException
     * @throws SQLException
     */

    public List<DataSinkConfig> getConfigLastSuccessDate(List<String> configIds, String jobType, String usecase)
            throws SQLException {

        List<DataSinkConfig> configList = new ArrayList<>();

        String configStr = "'" + StringUtils.join(configIds, "','") + "'";

        String queryForConfig = MessageFormat.format(DBConstants.CONFIGID_MAX_DATE, configStr, jobType, usecase);

        LOGGER.log(Level.INFO, "Query for getConfigLastSuccessDate :: {0} ", queryForConfig);

        try (Statement preparedStatement = connection.createStatement();
             ResultSet resultSet = preparedStatement.executeQuery(queryForConfig);) {

            while (resultSet.next()) {

                DataSinkConfig config = new DataSinkConfig();
                config.setConfigId(resultSet.getString("CONFIGID"));
                config.setLastRunDate(resultSet.getString("LASTRUNDATE"));
                configList.add(config);

            }

        }

        LOGGER.log(Level.INFO, "List of config Ids for processing fetched from DB :: {0} ", configList);

        return configList;

    }

    /***
     * Add entries in DATA_SINK_STATUS table with file processing updatedOn Time.
     *
     * @param dataSinkJobInput
     *
     * @param sparkJobConfig
     * @return
     * @throws SQLException
     * @throws DBQueryException
     */

    public void metaDataInsert(DataSinkConfig dataSinkConfig, DataSinkInput dataSinkJobInput) throws SQLException {

        connection.setAutoCommit(false);

        String configId = dataSinkConfig.getConfigId();

        String archievedFiles = StringUtils.join(dataSinkConfig.getArchivedFiles(), ",");
        String rollbackedFiles = StringUtils.join(dataSinkConfig.getRollbackFiles(), ",");

        String insertQuery = MessageFormat.format(DBConstants.DATA_SINK_STATUS_INSERT, configId, archievedFiles,
                rollbackedFiles, DBConstants.METADATA_STATUS, dataSinkConfig.getCurrentRunDate(), dataSinkJobInput.getJobType(),
                dataSinkJobInput.getUsecase());

        LOGGER.log(Level.INFO, "metaDataInsert query :: {0} ", insertQuery);

        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(insertQuery);
        }

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(DBConstants.LAST_INSERT_RUN_QUERY);) {

            if (resultSet.next()) {
                Long jobId = resultSet.getLong("last_insert_id");
                dataSinkConfig.setJobId(jobId);

            }

        }
        connection.commit();
        connection.setAutoCommit(true);

    }

    /***
     * Add entries in DATA_SINK_STATUS table with failure Reason
     *
     * @param dataSinkJobInput
     *
     * @param reason
     * @return
     * @throws SQLException
     * @throws DBQueryException
     */

    public void metaDataInsert(DataSinkInput dataSinkJobInput, String reason) throws SQLException {

        String insertQuery =
                MessageFormat.format(DBConstants.DATA_SINK_STATUS_INSERT_NO_FILES_FOUND, dataSinkJobInput.getUsecase(),
                        dataSinkJobInput.getJobType(), dataSinkJobInput.getUsecase(), reason, Instant.now().toString());

        LOGGER.log(Level.INFO, "metaDataInsert query :: {0} ", insertQuery);

        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(insertQuery);
        }

    }

    /**
     * Fetches Corrected Files From Last Run EventID i.e, last Id which has been synced from Aperia log table into vertica
     *
     * @return CorrectedFiles
     */
    public List<String> fetchCorrectedFiles(Long lastRunId) throws SQLException {
        List<String> fileNames = new ArrayList<>();
        String query =
                MessageFormat.format(DBConstants.GET_CORRECTEDFILES_FROM_PAYSAFE_BI_FILEACTIVITYLOG, lastRunId.toString());
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.GET_CORRECTEDFILES_FROM_PAYSAFE_BI_FILEACTIVITYLOG, resultSet});
            while (resultSet.next()) {
                fileNames.add(resultSet.getString(CommonConstants.FILENAME));
            }
        }
        return fileNames.stream().distinct().collect(Collectors.toList());
    }

    /**
     * Fetches Duplicate Files From Last Run EventID i.e, last Id which has been synced from Aperia log table into vertica
     *
     * @return DuplicateFiles
     */
    public List<String> fetchDuplicateFiles(Long lastRunId) throws SQLException {
        List<String> duplicateDescriptions = new ArrayList<>();
        String query =
                MessageFormat.format(DBConstants.GET_DUPLICATEFILES_FROM_PAYSAFE_BI_FILEACTIVITYLOG, lastRunId.toString());
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.GET_DUPLICATEFILES_FROM_PAYSAFE_BI_FILEACTIVITYLOG, resultSet});
            while (resultSet.next()) {
                duplicateDescriptions.add(resultSet.getString("Description"));
            }
        }
        return duplicateDescriptions.stream().distinct().collect(Collectors.toList());
    }

    /**
     * Fetches invalidRecordCounts Files From Last Run EventID(which has been synced from Aperia log table into vertica)
     *
     * @return invalidRecordCountFiles
     */
    public List<AperiaLog> fetchInvalidRecordCountFiles(Long lastRunId) throws SQLException {
        List<AperiaLog> aperiaLogs = new ArrayList<>();
        String query =
                MessageFormat.format(DBConstants.GET_INVALIDRECORDCOUNT_FROM_PAYSAFE_BI_FILEACTIVITYLOG, lastRunId.toString());
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.GET_INVALIDRECORDCOUNT_FROM_PAYSAFE_BI_FILEACTIVITYLOG, resultSet});
            while (resultSet.next()) {
                AperiaLog aperiaLog = convert(resultSet, AperiaLog.class);
                aperiaLogs.add(aperiaLog);
            }
        }
        return aperiaLogs;
    }

    /**
     * Fetches duplicateRecordCounts Files From Last Run LastupdatedOn(which has been synced from metadata table into
     * metadata audit table)
     *
     * @return DuplicateRecordFiles
     */
    public String fetchDuplicateRecordCountFiles(Map<String, String> duplicateRecordFiles, String configsList)
            throws SQLException {
        String updatedtime = "";
        logger.log(Level.INFO, configsList);
        LOGGER.log(Level.INFO, "Executing query {0}", DBConstants.FETCH_FILES_AND_DUPLICATECOUNT);
        String query = MessageFormat.format(DBConstants.FETCH_FILES_AND_DUPLICATECOUNT, configsList);
        logger.log(Level.INFO, query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.FETCH_FILES_AND_DUPLICATECOUNT, resultSet});
            while (resultSet.next()) {
                String filename = resultSet.getString(resultSet.findColumn("FILENAME"));
                String duplicateCount = resultSet.getString(resultSet.findColumn("DUPLICATECOUNT"));
                updatedtime = resultSet.getString(resultSet.findColumn("UPDATEDTIME"));
                duplicateRecordFiles.put(filename, duplicateCount);
            }
        }
        return updatedtime;
    }

    public void fetchDelayTime(Map<String, String> delayFiles, String thresholdTime)
            throws SQLException {
        logger.log(Level.INFO, thresholdTime);
        LOGGER.log(Level.INFO, "Executing query {0}", DBConstants.FETCH_DELAY_TIME);
        String query = MessageFormat.format(DBConstants.FETCH_DELAY_TIME, thresholdTime);
        logger.log(Level.INFO, query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.FETCH_DELAY_TIME, resultSet});
            while (resultSet.next()) {
                String filename = resultSet.getString(resultSet.findColumn("aperiaFileName"));
                String delayTime = resultSet.getString(resultSet.findColumn("DelayTime"));
                delayFiles.put(filename, delayTime);
            }
        }
    }

    public void insertIntoNotificationLogAudit(String updatedtime) throws SQLException {
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(MessageFormat.format(DBConstants.NOTIFICATION_LOG_AUDIT, updatedtime,
                    "NOTIFICATION FOR DUPLICATE RECORD FILES"));
        }
    }


    /**
     * Fetches Last Run EventID i.e, last Id which has been synced from Aperia log table into vertica
     *
     * @return EventID
     */
    public Long fetchLastRunEventID() throws SQLException {
        LOGGER.log(Level.INFO, "Executing query {0}", DBConstants.APERIA_LOG_LAST_RUN_ID);
        try (PreparedStatement stmt = connection.prepareStatement(DBConstants.APERIA_LOG_LAST_RUN_ID);
             ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.APERIA_LOG_LAST_RUN_ID, resultSet});
            if (resultSet.next()) {
                return resultSet.getLong("ID");
            }
        }
        return null;
    }

    /**
     * Fetches Last Run Process_date i.e, last date which has been synced from oracle mif log table into vertica
     *
     * @return Process_date
     */
    public String fetchLastProcessDate() throws SQLException {
        LOGGER.log(Level.INFO, "Executing query {0}", DBConstants.ORACLE_MIF_LOG_LAST_PROCESS_DATE);
        try (PreparedStatement stmt = connection.prepareStatement(DBConstants.ORACLE_MIF_LOG_LAST_PROCESS_DATE);
             ResultSet resultSet = stmt.executeQuery();) {
            LOGGER.log(Level.INFO, "Executed query {0} obtained result {1}",
                    new Object[]{DBConstants.ORACLE_MIF_LOG_LAST_PROCESS_DATE, resultSet});
            if (resultSet.next()) {
                return resultSet.getString("ID");
            }
        }
        return null;
    }

    /**
     * Prepare query for inserting aperia log into vertica
     *
     * @param AperiaLog
     * @param Fields.
     * @return query
     */
    private String prepareInsertQuery(AperiaLog aperiaLog, Field[] fields) throws IllegalAccessException {
        String columnSeparator = CommonConstants.SPACE;
        StringBuilder insertColumns = new StringBuilder();
        StringBuilder insertValues = new StringBuilder();

        for (int i = 1; i < fields.length; i++) {
            Field field = fields[i];
            field.setAccessible(true);
            if (field.get(aperiaLog) != null) {
                insertColumns.append(columnSeparator).append(field.getName());
                insertValues.append(columnSeparator).append(CommonConstants.SINGLE_QUOTES).append(field.get(aperiaLog))
                        .append(CommonConstants.SINGLE_QUOTES);
                columnSeparator = CommonConstants.COMMA_SEPARATOR;
            }
        }

        return MessageFormat.format(DBConstants.INSERT_APERIA_LOGS_INTO_TEMPTABLE, insertColumns.toString(),
                insertValues.toString());
    }

    /**
     * Prepare query for inserting oracle mif log into vertica
     *
     * @param OracleMifLog
     * @param Fields.
     * @return query
     */
    private String prepareInsertOracleQuery(OracleMifLog oracleMifLog, Field[] fields) throws IllegalAccessException {
        String columnSeparator = CommonConstants.SPACE;
        StringBuilder insertColumns = new StringBuilder();
        StringBuilder insertValues = new StringBuilder();

        for (int i = 1; i < fields.length; i++) {
            Field field = fields[i];
            field.setAccessible(true);
            if (field.get(oracleMifLog) != null) {
                insertColumns.append(columnSeparator).append(field.getName());
                insertValues.append(columnSeparator).append(CommonConstants.SINGLE_QUOTES).append(field.get(oracleMifLog))
                        .append(CommonConstants.SINGLE_QUOTES);
                columnSeparator = CommonConstants.COMMA_SEPARATOR;
            }
        }

        return MessageFormat.format(DBConstants.INSERT_ORACLE_MIF_LOGS_INTO_TEMPTABLE, insertColumns.toString(),
                insertValues.toString());
    }

    /**
     * Inserts aperia logs into vertica
     *
     * @param List of AperiaLog
     * @return Boolean
     * @throws DBQueryException
     * @throws SQLException
     */
    public boolean insertLogsIntoVertica(List<AperiaLog> aperiaLogs) throws IllegalAccessException, SQLException {
        if (CollectionUtils.isEmpty(aperiaLogs)) {
            return true;
        }
        Field[] fields = AperiaLog.class.getDeclaredFields();
        List<String> queries = new ArrayList<>();
        queries.add(DBConstants.CREATE_TEMPORARY_APERIA_LOG_TABLE);

        Long lastRunId = 0L;
        for (AperiaLog aperiaLog : aperiaLogs) {
            queries.add(prepareInsertQuery(aperiaLog, fields));
            lastRunId = Math.max(lastRunId, aperiaLog.getEventID());
        }
        queries.add(DBConstants.COPY_APERIA_LOGS_FROM_TEMP_TABLE);

        queries.add(MessageFormat.format(DBConstants.INSERT_APERIA_LOG_AUDIT, lastRunId.toString()));
        return executeQueries(queries);
    }

    /**
     * Inserts oracle mif logs into vertica
     *
     * @param List of OracleMifLog
     * @return Boolean
     * @throws DBQueryException
     * @throws SQLException
     */
    public boolean insertOracleMifLogsIntoVertica(List<OracleMifLog> oracleMifLogs) throws IllegalAccessException, SQLException {

        if (CollectionUtils.isEmpty(oracleMifLogs)) {
            return true;
        }
        logger.log(Level.INFO, "oracleMifLogs values format {0} ", oracleMifLogs);
        Field[] fields = OracleMifLog.class.getDeclaredFields();
        List<String> queries = new ArrayList<>();
        queries.add(DBConstants.CREATE_TEMPORARY_ORACLE_MIF_LOG_TABLE);
        try {
            Date lastProcessDate = new Date();
            for (OracleMifLog oracleMifLog : oracleMifLogs) {
                queries.add(prepareInsertOracleQuery(oracleMifLog, fields));
                lastProcessDate = oracleMifLog.getPROCESS_DATE();
            }
            queries.add(DBConstants.COPY_ORACLE_MIF_LOGS_FROM_TEMP_TABLE);

            queries.add(MessageFormat.format(DBConstants.INSERT_ORACLE_MIF_LOG_AUDIT, lastProcessDate.toString()));
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in VerticaUtil :: {0}", ExceptionUtils.getStackTrace(ex));
        }
        return executeQueries(queries);
    }

    public List<String> getExistingFileNames(String query) throws SQLException {
        List<String> fileNames = new ArrayList<>();
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            logger.log(Level.INFO, "Executed query {0} obtained result {1}", new Object[]{query, resultSet});
            while (resultSet.next()) {
                fileNames.add(resultSet.getString(CommonConstants.FILENAME));
            }
        }
        return fileNames;
    }

    public List<String> getColumnNamesInorder(String schema, String table) throws SQLException {
        List<String> fileNames = new ArrayList<>();
        String query = MessageFormat.format(DBConstants.FETCH_COLUMN_ORDER, schema, table);

        logger.log(Level.INFO, "Executing query {0}", query);

        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            logger.log(Level.INFO, "Executed query {0} obtained result {1}", new Object[]{query, resultSet});
            while (resultSet.next()) {
                fileNames.add(resultSet.getString("column_name"));
            }
        }
        return fileNames;
    }

    /***
     *
     * @param Query
     * @return
     * @throws DBQueryException
     * @throws SQLException
     */

    public Map<String, List<VerticaMetaData>> fetchDeltaFiles(String query) throws SQLException {
        Map<String, List<VerticaMetaData>> deltaFiles = new HashMap<>();
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                VerticaMetaData verticaMetaData = convert(resultSet, VerticaMetaData.class);
                if (!deltaFiles.containsKey(verticaMetaData.getConfigId())) {
                    deltaFiles.put(verticaMetaData.getConfigId(), new ArrayList<>());
                }
                deltaFiles.get(verticaMetaData.getConfigId()).add(verticaMetaData);
            }
        }
        logger.log(Level.INFO, "Executed query obtained result :: ", deltaFiles);
        return deltaFiles;
    }


    public List<String> getConfigsInRunningState(List<String> configIds, String jobType, String usecase)
            throws SQLException {

        List<String> configList = new ArrayList<>();
        String configStr = "'" + StringUtils.join(configIds, "','") + "'";
        String queryForConfig = MessageFormat.format(DBConstants.CONFIGID_IN_RUNNING_STATE, configStr, jobType, usecase, LocalDate.now());
        LOGGER.log(Level.INFO, "Query for configsInRunningState :: {0} ", queryForConfig);

        try (Statement preparedStatement = connection.createStatement();
             ResultSet resultSet = preparedStatement.executeQuery(queryForConfig);) {
            while (resultSet.next()) {
                String configId = resultSet.getString("CONFIGID");
                String archivedFiles = resultSet.getString("ARCHIVEDFILES");
                LOGGER.log(Level.INFO, configId+" is in running state with files "+ archivedFiles);
                configList.add(resultSet.getString("configId"));
            }

        }
        LOGGER.log(Level.INFO, "List of config Ids in running state fetched from DB :: {0} ", configList);
        return configList;

    }

}
