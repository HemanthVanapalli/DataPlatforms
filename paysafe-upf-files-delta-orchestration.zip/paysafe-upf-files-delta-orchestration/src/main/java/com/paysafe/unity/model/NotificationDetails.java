package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paysafe.unity.ppbi.model.EmailSenderReceiver;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationDetails {

    private List<String> configIds;

    private int window;

    private String usecase;

    private String onboardedDate;

    private EmailSenderReceiver emailDetails;

    public List<String> getConfigIds() {
        return configIds;
    }

    public void setConfigIds(List<String> configIds) {
        this.configIds = configIds;
    }

    public int getWindow() {
        return window;
    }

    public void setWindow(int window) {
        this.window = window;
    }

    public String getUsecase() {
        return usecase;
    }

    public void setUsecase(String usecase) {
        this.usecase = usecase;
    }

    public String getOnboardedDate() {
        return onboardedDate;
    }

    public void setOnboardedDate(String onboardedDate) {
        this.onboardedDate = onboardedDate;
    }

    public EmailSenderReceiver getEmailDetails() {
        return emailDetails;
    }

    public void setEmailDetails(EmailSenderReceiver emailDetails) {
        this.emailDetails = emailDetails;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
