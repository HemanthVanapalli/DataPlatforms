package com.paysafe.unity.util;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.ppbi.model.OracleMifLog;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.exception.ExceptionUtils;

public class OracleMifUtil extends DBUtil {

    public OracleMifUtil(DBConnection dbConnection) throws DBQueryException {
        super(dbConnection);
    }

    /**
     * Fetches Oracle Mif logs from ProcessDate
     *
     * @param LastProcessDate
     * @return List of OracleMifLog
     * @throws DBQueryException
     */
    public List<OracleMifLog> fetchLogs(String lastProcessDate) throws SQLException, DBQueryException {
        List<OracleMifLog> oracleMifLogs = new ArrayList<>();
        
        String query = DBConstants.FETCH_ALL_ORACLE_MIF_LOGS;
        if(lastProcessDate != null){
            try{
            SimpleDateFormat prevDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat newDateFormat = new SimpleDateFormat("dd-MMM-yy");
            query = MessageFormat.format(DBConstants.FETCH_ORACLE_MIF_LOGS, newDateFormat.format(prevDateFormat.parse(lastProcessDate)).toString());
            }
            catch (Exception ex) {
                logger.log(Level.SEVERE, "Error occured in parsing date  :: {0}", ExceptionUtils.getStackTrace(ex));
            }
        }
        logger.log(Level.INFO, "Executing query {0}", query);
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet resultSet = stmt.executeQuery();) {
            logger.log(Level.INFO, "Executed query {0} obtained result {1}", new Object[]{query, resultSet});
            while (resultSet.next()) {
                OracleMifLog oracleMifLog = convert(resultSet, OracleMifLog.class);
                oracleMifLogs.add(oracleMifLog);
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error occured in OracleMifUtil :: {0}", ExceptionUtils.getStackTrace(ex));
        } finally {
            if (connection != null) connection.close();
        }
        return oracleMifLogs;
    }

}
