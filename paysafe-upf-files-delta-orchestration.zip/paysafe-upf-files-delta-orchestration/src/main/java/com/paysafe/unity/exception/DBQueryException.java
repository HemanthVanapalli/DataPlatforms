package com.paysafe.unity.exception;

public class DBQueryException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -8938203219605534985L;

  public DBQueryException(String message) {
    super(message);
  }

  public DBQueryException(String message, Throwable cause) {
    super(message, cause);

  }

  public DBQueryException(Throwable cause) {
    super(cause);

  }

}
