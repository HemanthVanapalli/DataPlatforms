package com.paysafe.unity.service.impl;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.service.DynamoQueryBuilder;

import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

public class ReloadDynamoQueryBuilder implements DynamoQueryBuilder {

  private DynamoQuery dynamoQuery;
  private DataSinkInput dataSinkJobInput;

  public ReloadDynamoQueryBuilder(DataSinkInput dataSinkJobInput) {

    this.dynamoQuery = new DynamoQuery();
    this.dataSinkJobInput = dataSinkJobInput;
  }

  @Override
  public void buildKeyConditionExpression() {
    dynamoQuery.setKeyConditionExpression("CONFIGID =:configID and FILEDATE Between :startDate and :endDate");

  }

  @Override
  public void buildFilterExpression() {
    dynamoQuery.setFilterExpression("FILESTATUS=:filestatus");
  }

  @Override
  public void buildValueMap(DataSinkConfig config) {
    dynamoQuery.setValueMap(new ValueMap().withString(":configID", config.getConfigId())
        .withString(":startDate", dataSinkJobInput.getStartDate()).withString(":endDate", dataSinkJobInput.getEndDate())
        .withString(":filestatus", CommonConstants.FP_JOB_ARCHIEVED_STATUS));

  }

  @Override
  public void buildIndex() {
    dynamoQuery.setIndex(LambdaVariables.DYNAMO_RELOAD_INDEX);
  }

  @Override
  public void buildTable() {

    dynamoQuery.setTable(LambdaVariables.FP_METABATA_TABLE);
  }

  @Override
  public DynamoQuery build() {
    return this.dynamoQuery;
  }

}
