package com.paysafe.unity.util;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public interface DateUtil {

  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
      .withZone(ZoneId.systemDefault());

  public static String getUTCString(Instant dateVal) {

    return formatter.format(dateVal);
  }

  public static Instant getUTCTime(String dateVal) {

    return Instant.parse(dateVal);
  }
  

  public static Instant minusDuration(Duration duration) {
    return Instant.now().minus(duration);
  }

}
