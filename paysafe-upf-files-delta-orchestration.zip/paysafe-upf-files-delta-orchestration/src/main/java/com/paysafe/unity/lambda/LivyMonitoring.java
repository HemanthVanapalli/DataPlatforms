package com.paysafe.unity.lambda;

import com.paysafe.unity.constants.JobStatus;
import com.paysafe.unity.constants.LivySessionState;
import com.paysafe.unity.exception.PPBIJobMonitoringException;
import com.paysafe.unity.model.LivyResponse;
import com.paysafe.unity.util.S3Util;

import com.amazonaws.services.lambda.runtime.Context;
import com.google.gson.Gson;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LivyMonitoring {

  private static Logger logger = Logger.getLogger(LivyMonitoring.class.getName());

  public LivyResponse handleRequest(LivyResponse livyResponse, Context context) throws PPBIJobMonitoringException {

    Gson gson = new Gson();

    livyResponse.incrementCounter();

    try (CloseableHttpClient client = HttpClients.createDefault()) {

      HttpGet method = new HttpGet(new URIBuilder(livyResponse.getLivyEndPoint() + "/" + livyResponse.getId()).build());

      logger.log(Level.INFO, "GET livy Sessions API call :: {0} ", method.getURI().toString());

      CloseableHttpResponse resp = client.execute(method);
      LivyResponse session =
          gson.fromJson(IOUtils.toString(resp.getEntity().getContent(), "UTF-8"), LivyResponse.class);

      if (session != null) {

        if (session.getAppId() != null) {
          livyResponse.setAppId(session.getAppId());
          livyResponse.setLog(session.getLog());
        }

        logger.log(Level.INFO, "Status of the application {0} is {1}",
            new Object[] {session.getAppId(), session.getState()});

        if (LivySessionState.ERROR.getState().equalsIgnoreCase(session.getState())
            || LivySessionState.DEAD.getState().equalsIgnoreCase(session.getState())
            || LivySessionState.KILLED.getState().equalsIgnoreCase(session.getState())) {

          livyResponse.setLivyMoitoringStatus(JobStatus.COMPLETED);
          livyResponse.setJobStatus(JobStatus.FAIL);

        } else if (LivySessionState.SUCCESS.getState().equalsIgnoreCase(session.getState())) {
          livyResponse.setLivyMoitoringStatus(JobStatus.COMPLETED);
          livyResponse.setJobStatus(JobStatus.SUCCESS);

        } else {
          livyResponse.setJobStatus(JobStatus.INCOMPLETE);
        }

        livyResponse.setState(session.getState());
      }

    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception occured while processing {0} is {1}",
          new Object[] {livyResponse, ExceptionUtils.getStackTrace(e)});
      // deletePayload(livyResponse.getPayloadpath());
      throw new PPBIJobMonitoringException(ExceptionUtils.getStackTrace(e));
    }

    logger.log(Level.SEVERE, "Result of LivyMonitoring::handleRequest is {0}", livyResponse);

    return livyResponse;

  }

  @Deprecated
  private void deletePayload(String payLoadPath) {
    if (!StringUtils.isEmpty(payLoadPath)) {
      S3Util s3Util = new S3Util();
      s3Util.deleteObject(payLoadPath);
    }
  }
}
