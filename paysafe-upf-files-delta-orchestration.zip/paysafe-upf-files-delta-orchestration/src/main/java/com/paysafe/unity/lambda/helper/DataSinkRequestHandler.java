package com.paysafe.unity.lambda.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.JobType;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.FilesNotFoundException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.DataSinkOutput;
import com.paysafe.unity.model.JobDetails;
import com.paysafe.unity.service.*;
import com.paysafe.unity.service.helper.DataSinkDeleteProcessorFactory;
import com.paysafe.unity.service.helper.DataSinkJobProcessorFactory;
import com.paysafe.unity.service.helper.DataSinkPipelineProcessorFactory;
import com.paysafe.unity.service.impl.DataSinkConfigurationImpl;
import com.paysafe.unity.util.VerticaUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;

import javax.xml.crypto.Data;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class DataSinkRequestHandler {

    static final Logger logger = Logger.getLogger(DataSinkRequestHandler.class.getName());

    private String jobInput;
    private DBConnection connection;
    private FileSystemConnector fileSystemConnector;
    private AwsConnection awsConnection;
    private VerticaUtil verticaUtil;

    public DataSinkRequestHandler(String jobInput, FileSystemConnector fileSystemConnector, DBConnection connection,
                                  AwsConnection awsConnection) throws DBQueryException {

        this.jobInput = jobInput;
        this.fileSystemConnector = fileSystemConnector;
        this.connection = connection;
        this.awsConnection = awsConnection;
        this.verticaUtil = new VerticaUtil(connection);

    }

    public DataSinkOutput handleRequest() throws Exception {
        DataSinkConfiguration configuration = new DataSinkConfigurationImpl(fileSystemConnector);
        DataSinkInput dataSinkInput = configuration.getPayload(jobInput);
        logger.log(Level.INFO, "Processing dataSinkInput :: {0}", dataSinkInput);
        try {
            List<DataSinkConfig> processedConfigs = fetchFiles(dataSinkInput);
            List<DataSinkConfig> finalConfigs=filterRunningConfigs(processedConfigs,dataSinkInput);
            deleteFiles(dataSinkInput, finalConfigs);
            DataSinkOutput dataSinkOutput = processFiles(dataSinkInput, finalConfigs);
            BeanUtils.copyProperties(dataSinkOutput, dataSinkInput);
            updateJarDetails(dataSinkOutput);
            return dataSinkOutput;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Exception occured while running job ::" + ex.getMessage());
            upsertJobStatus(dataSinkInput, ex.getMessage());
            throw ex;
        }
    }

    private List<DataSinkConfig> fetchFiles(DataSinkInput dataSinkInput) throws Exception {
        DataSinkJobProcessorFactory dataSinkJobProcessorFactory =
                new DataSinkJobProcessorFactory(fileSystemConnector, dataSinkInput, connection, awsConnection);
        DataSinkJobProcessor dataSinkJobProcessor = dataSinkJobProcessorFactory.getProcessor();
        List<DataSinkConfig> dataSinkConfigs = dataSinkJobProcessor.constructDataSinkConfig(dataSinkInput.getConfigIds());
        List<DataSinkConfig> processedConfigs = dataSinkJobProcessor.fetchDeltaFiles(dataSinkConfigs);
        return processedConfigs;
    }

    private boolean deleteFiles(DataSinkInput dataSinkInput, List<DataSinkConfig> processedConfigs) throws Exception {
        DataSinkDeleteProcessorFactory dataSinkDeleteProcessorFactory =
                new DataSinkDeleteProcessorFactory(dataSinkInput, connection);
        DataSinkDeleteProcessor dataSinkDeleteProcessor = dataSinkDeleteProcessorFactory.getProcessor();
        return dataSinkDeleteProcessor.execute(processedConfigs);
    }

    private DataSinkOutput processFiles(DataSinkInput dataSinkInput, List<DataSinkConfig> processedConfigs)
            throws Exception {
        DataSinkOutput dataSinkOutput = new DataSinkOutput();
        DataSinkPipelineProcessorFactory dataSinkPipelineProcessorFactory =
                new DataSinkPipelineProcessorFactory(fileSystemConnector, dataSinkInput);
        DataSinkPipelineProcessor dataSinkPipelineProcessor = dataSinkPipelineProcessorFactory.getProcessor();
        List<DataSinkConfig> filteredConfigs = dataSinkPipelineProcessor.filter(processedConfigs);
        if (CollectionUtils.isEmpty(filteredConfigs)) {
            upsertJobStatus(dataSinkInput, "No Files to be processed");
            throw new FilesNotFoundException("No Files to be processed");
        }
        logger.log(Level.INFO, "Files found to run job");
        upsertJobStatus(filteredConfigs, dataSinkInput);
        List<JobDetails> jobDetails = dataSinkPipelineProcessor.generateOutputAndUploadToS3(filteredConfigs);
        dataSinkOutput.setJobDetails(jobDetails);
        return dataSinkOutput;
    }

    private void updateJarDetails(DataSinkOutput dataSinkOutput) {
        String jar = dataSinkOutput.getLivyCommand().getFile();
        dataSinkOutput.getLivyCommand()
                .setFile(jar.replace(CommonConstants.ACCOUNTID_PLACEHOLDER, LambdaVariables.AWS_ACCOUNTID)
                        .replace(CommonConstants.ENVIRONMENT_PLACEHOLDER, LambdaVariables.AWS_ENVIRONMENT));
    }

    public List<DataSinkConfig> filterRunningConfigs(List<DataSinkConfig> configs,DataSinkInput dataSinkInput) throws SQLException {
        if (configs != null && !configs.isEmpty() && JobType.LOAD.equals(dataSinkInput.getJobType())) {
            Map<String, DataSinkConfig> configsMap = configs.stream()
                    .collect(Collectors.toMap(DataSinkConfig::getConfigId, Function.identity()));

            List<String> runningConfigList = verticaUtil.getConfigsInRunningState(dataSinkInput.getConfigIds(),
                    dataSinkInput.getJobType().getVal(), dataSinkInput.getUsecase());

            if (runningConfigList != null && !runningConfigList.isEmpty()) {
                configs = configsMap.entrySet().stream().filter(x -> !runningConfigList.contains(x.getKey())).map(x -> x.getValue())
                        .collect(Collectors.toList());
            }
        }
        return configs;
    }

    public List<DataSinkConfig> upsertJobStatus(List<DataSinkConfig> processedConfigs, DataSinkInput dataSinkJobInput)
            throws SQLException, DBQueryException {

        for (DataSinkConfig config : processedConfigs) {
            verticaUtil.metaDataInsert(config, dataSinkJobInput);
        }
        return processedConfigs;
    }

    public void upsertJobStatus(DataSinkInput dataSinkInput, String reason) throws SQLException {
        verticaUtil.metaDataInsert(dataSinkInput, removeExtraCharacters(reason));
    }

    public String removeExtraCharacters(String reason) {
        if (reason == null || reason.isEmpty()) {
            return reason;
        }
        String value = reason.replaceAll("\n|\r|\n\r|\'|\"", "");
        if (value.length() > CommonConstants.MAX_CHARACTER_LENGTH) {
            return value.substring(0, CommonConstants.MAX_CHARACTER_LENGTH);
        } else {
            return value;
        }
    }

}
