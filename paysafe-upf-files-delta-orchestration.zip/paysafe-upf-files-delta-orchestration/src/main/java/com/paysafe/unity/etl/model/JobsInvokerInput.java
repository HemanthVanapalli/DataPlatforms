// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2020. For more information see LICENSE

package com.paysafe.unity.etl.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.paysafe.gdp.fp.common.payload.StepFunctionPayload;
import com.paysafe.gdp.fp.common.config.etl.StagingDelete;

import java.util.List;

public class JobsInvokerInput extends StepFunctionPayload{

  @JsonProperty
  private String outputConfigsPath;
  @JsonProperty
  private List<MapStepInput> configList;
  @JsonProperty
  private SparkJobExecutionDetails data;
  private StagingDelete deleteStaging ;

  public StagingDelete getDeleteStaging() {
    return deleteStaging;
  }

  public void setDeleteStaging(StagingDelete deleteStaging) {
    this.deleteStaging = deleteStaging;
  }

  public SparkJobExecutionDetails getData() {
    return data;
  }

  public void setData(SparkJobExecutionDetails data) {
    this.data = data;
  }

  public String getOutputConfigsPath() {
    return outputConfigsPath;
  }

  public void setOutputConfigsPath(String outputConfigsPath) {
    this.outputConfigsPath = outputConfigsPath;
  }
    
  public List<MapStepInput> getConfigList() {
    return configList;
  }

  public void setConfigList(List<MapStepInput> configList) {
    this.configList = configList;
  }
}
