package com.paysafe.unity.service.helper;

import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;

public class FileSystemProvider {

  public FileSystemConnector getFileSystem(String path,AwsConnection awsConnection) {
    return new S3Connector(awsConnection);
  }

}
