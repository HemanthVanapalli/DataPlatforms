package com.paysafe.unity.constants;

public enum DataBaseType {
  VERTICA_AWS
}
