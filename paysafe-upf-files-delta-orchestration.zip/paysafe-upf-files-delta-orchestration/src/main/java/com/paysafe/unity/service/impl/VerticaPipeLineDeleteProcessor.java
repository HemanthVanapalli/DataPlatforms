package com.paysafe.unity.service.impl;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.constants.MultiConnectors;
import com.paysafe.unity.exception.DBQueryException;
import com.paysafe.unity.exception.DataDeleteHandlerException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.ppbi.model.Config;
import com.paysafe.unity.ppbi.model.MetaData;
import com.paysafe.unity.service.helper.AbstractDataSinkDeleteProcessor;
import com.paysafe.unity.util.S3Util;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class VerticaPipeLineDeleteProcessor extends AbstractDataSinkDeleteProcessor {

    final Logger logger = Logger.getLogger(VerticaPipeLineDeleteProcessor.class.getName());

    public VerticaPipeLineDeleteProcessor(DataSinkInput dataSinkInput, DBConnection dbConnection)
            throws DBQueryException {
        super(dataSinkInput, dbConnection);
    }

    public boolean execute(List<DataSinkConfig> configs) throws DataDeleteHandlerException {
        if (StringUtils.isNotBlank(dataSinkInput.getTracingColumn())) {
            try {
                List<DataSinkConfig> filteredConfigs = filter(configs);
                Map<String, Config> inputConfigs = readConfigs(filteredConfigs);
                logger.log(Level.INFO, "Triggering delete for :: " + filteredConfigs);
                List<String> existingFileNames = checkFileExists(filteredConfigs);
                deleteFromS3(filteredConfigs, inputConfigs, existingFileNames);
                deleteFromVertica(filteredConfigs, inputConfigs, existingFileNames);
            } catch (Exception ex) {
                logger.log(Level.INFO, " Exception occurred while calling Delete handler :: " + ex.getMessage());
                throw new DataDeleteHandlerException(" Execution Failed For Delete " + ex.getMessage());
            }
        }
        return true;
    }

    private void deleteFromVertica(List<DataSinkConfig> configs, Map<String, Config> inputConfigs,
                                   List<String> existingFileNames) throws SQLException {
        List<String> queries = prepareDeleteQueries(configs, inputConfigs, existingFileNames);
        executeDeleteQueries(queries);
    }

    public List<String> prepareDeleteQueries(List<DataSinkConfig> configs, Map<String, Config> inputConfigs,
                                             List<String> existingFileNames) throws SQLException {
        List<String> queries = new ArrayList<>();
        if (CollectionUtils.isEmpty(existingFileNames)) {
            logger.log(Level.INFO, "Given files were not loaded previously for all configs ");
            return queries;
        }
        for (DataSinkConfig config : configs) {
            List<String> files = Stream.of(config.getArchivedFiles(), config.getRollbackFiles()).flatMap(Collection::stream)
                    .collect(Collectors.toList());
            MetaData metadata = (MetaData) inputConfigs.get(config.getConfigId());
            if (metadata.getOutputs().containsKey(LambdaVariables.AWS_ZONE.toUpperCase()) && metadata.getOutputs().get(LambdaVariables.AWS_ZONE.toUpperCase()).contains(MultiConnectors.VERTICA)) {
                List<String> existingFiles = (List<String>) CollectionUtils.intersection(files, existingFileNames);
                List<String> tableColumns = verticaUtil.getColumnNamesInorder(metadata.getSchema(), metadata.getTable());
                if (CollectionUtils.isNotEmpty(existingFiles) && CollectionUtils.isNotEmpty(tableColumns)) {
                    List<String> query =
                            createDeleteQuery(existingFiles, config.getConfigId(), metadata.getSchema(), metadata.getTable());
                    queries.addAll(query);
                } else {
                    logger.log(Level.INFO,
                            "Given files were not loaded previously for :: " + files + " for " + config.getConfigId());
                }
            } else {
                logger.log(Level.INFO,
                        "Given files were not loaded previously for :: " + files + " for " + config.getConfigId() + " in the " +
                                LambdaVariables.AWS_ZONE + " zone ");
            }
        }
        return queries;
    }

    private void deleteFromS3(List<DataSinkConfig> configs, Map<String, Config> inputConfigs,
                              List<String> existingFileNames) throws SQLException {
        S3Util s3Util = new S3Util();
        configs.stream().forEach(config -> {
            String configId = config.getConfigId();
            MetaData metaData = (MetaData) inputConfigs.get(configId);
            if (metaData.getOutputs().containsKey(LambdaVariables.AWS_ZONE.toUpperCase()) && metaData.getOutputs().get(LambdaVariables.AWS_ZONE.toUpperCase()).contains(MultiConnectors.S3) &&
                    !StringUtils.isAllEmpty(metaData.getDestPrefix())) {
                List<String> files = Stream.of(config.getArchivedFiles(), config.getRollbackFiles()).flatMap(Collection::stream)
                        .collect(Collectors.toList());
                List<String> existingFiles = (List<String>) CollectionUtils.intersection(files, existingFileNames);
                String destPrefix = metaData.getDestPrefix();
                for (String file : existingFiles) {
                    String s3Path = destPrefix + dataSinkInput.getTracingColumn() + CommonConstants.EQUALS + file
                            + CommonConstants.PATH_DELIMITER;
                    logger.log(Level.INFO, "Deleting data from s3 Bucket :: " + LambdaVariables.SRC_BUCKET + " path :: " + s3Path);
                    s3Util.deleteDirectory(LambdaVariables.SRC_BUCKET, s3Path);
                }
            } else {
                logger.log(Level.INFO, "No data loaded into s3 for :: " + metaData.getConfigId() + " in the zone " + LambdaVariables.AWS_ZONE);
                return;
            }
        });
    }


    public Map<String, Config> readConfigs(List<DataSinkConfig> configs) throws IOException, DataSinkException {
        Map<String, Config> inputConfigs = new HashMap<>();
        for (DataSinkConfig config : configs) {
            String templateJson = commonUtil.constructTemplatePath(dataSinkInput.isOneJobPerConfigId(), config.getConfigId(),
                    dataSinkInput.getTemplatePath());
            MetaData metaData = readConfig(templateJson);
            inputConfigs.put(config.getConfigId(), metaData);
        }
        return inputConfigs;
    }

    private MetaData readConfig(String absoluteConfigPath) throws IOException {
        S3Util s3Util = new S3Util();
        logger.log(Level.INFO, "Reading config from location :: " + absoluteConfigPath);
        return s3Util.getObjectFromJson(absoluteConfigPath, MetaData.class);
    }
}
