package com.paysafe.unity.service;

import com.paysafe.unity.exception.FilesNotFoundException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.JobDetails;

import java.util.List;

public interface DataSinkPipelineProcessor {

  public List<DataSinkConfig> filter(List<DataSinkConfig> configs) throws FilesNotFoundException;

  public List<JobDetails> generateOutputAndUploadToS3(List<DataSinkConfig> configs) throws Exception;

}
