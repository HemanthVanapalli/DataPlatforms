package com.paysafe.unity.model;

import com.paysafe.unity.constants.JobStatus;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.ArrayList;

public class LivyResponse {

    private int id;
    private String appId;
    private String state;
    private String status;
    private ArrayList<String> log;
    private String livyEndPoint;
    private JobStatus livyMoitoringStatus;
    private JobStatus jobStatus;
    private long counter;
    private long maxCounter;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<String> getLog() {
        return log;
    }

    public void setLog(ArrayList<String> log) {
        this.log = log;
    }

    public String getLivyEndPoint() {
        return livyEndPoint;
    }

    public void setLivyEndPoint(String livyEndPoint) {
        this.livyEndPoint = livyEndPoint;
    }

    public JobStatus getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(JobStatus jobStatus) {
        this.jobStatus = jobStatus;
    }

    public JobStatus getLivyMoitoringStatus() {
        return livyMoitoringStatus;
    }

    public void setLivyMoitoringStatus(JobStatus livyMoitoringStatus) {
        this.livyMoitoringStatus = livyMoitoringStatus;
    }

    public long getCounter() {
        return counter;
    }

    public void setCounter(long counter) {
        this.counter = counter;
    }

    public void incrementCounter() {
        this.counter = this.counter + 1;
    }


    public long getMaxCounter() {
        return maxCounter;
    }

    public void setMaxCounter(long maxCounter) {
        this.maxCounter = maxCounter;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

}
