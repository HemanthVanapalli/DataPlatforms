// All Rights Reserved, Copyright © Paysafe Holdings UK Limited 2020. For more information see LICENSE

package com.paysafe.unity.etl.model;

import com.paysafe.gdp.fp.common.config.etl.StagingDelete;
import com.paysafe.gdp.fp.common.payload.EmrDetails;
import com.paysafe.gdp.fp.common.payload.StepFunctionPayload;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

public class JobsInvokerStepFunctionPayload extends StepFunctionPayload {

    private SparkJobExecutionDetails data;
    private String token;
    private EmrDetails emrDetails;
    private List<MapStepInput> configs;
    private StagingDelete deleteStaging;

    public StagingDelete getDeleteStaging() {
        return deleteStaging;
    }

    public void setDeleteStaging(StagingDelete deleteStaging) {
        this.deleteStaging = deleteStaging;
    }

    public List<MapStepInput> getConfigs() {
        return configs;
    }

    public void setConfigs(List<MapStepInput> configs) {
        this.configs = configs;
    }

    public EmrDetails getEmrDetails() {
        return emrDetails;
    }

    public void setEmrDetails(EmrDetails emrDetails) {
        this.emrDetails = emrDetails;
    }

    public SparkJobExecutionDetails getData() {
        return data;
    }

    public void setData(SparkJobExecutionDetails data) {
        this.data = data;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }


}
