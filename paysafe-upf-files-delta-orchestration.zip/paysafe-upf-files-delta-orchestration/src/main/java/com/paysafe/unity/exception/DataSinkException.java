package com.paysafe.unity.exception;

public class DataSinkException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 8169105801913680613L;

  public DataSinkException(String message) {
    super(message);
  }

  public DataSinkException(String message, Throwable cause) {
    super(message, cause);

  }

  public DataSinkException(Throwable cause) {
    super(cause);

  }

}
