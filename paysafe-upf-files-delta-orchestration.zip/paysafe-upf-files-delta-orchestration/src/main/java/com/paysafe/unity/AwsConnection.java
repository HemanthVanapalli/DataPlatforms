package com.paysafe.unity;

import com.paysafe.unity.constants.LambdaVariables;

import com.amazonaws.auth.profile.internal.securitytoken.RoleInfo;
import com.amazonaws.auth.profile.internal.securitytoken.STSProfileCredentialsServiceProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;

public class AwsConnection {

  private AmazonDynamoDB client;

  private AmazonS3 s3;

  private String ROLE_SESSION_NAME = "ppbi-unity-cross-account-session";

  private AWSSecretsManager secretManagerClient;

  public DynamoDB dynamoConnection() {

    if (client == null) {
      this.client = AmazonDynamoDBClientBuilder.standard()
          .withCredentials(new STSProfileCredentialsServiceProvider(
              new RoleInfo().withRoleArn(LambdaVariables.DYNAMO_STS_ROLE).withRoleSessionName(ROLE_SESSION_NAME)))
          .build();
    }

    return new DynamoDB(client);

  }

  public AmazonS3 s3Connection() {
    if (s3 == null) {
      this.s3 = AmazonS3ClientBuilder.standard().withForceGlobalBucketAccessEnabled(true).build();
    }

    return s3;
  }

  public AWSSecretsManager getSecretManager() {

    if (secretManagerClient == null) {

      this.secretManagerClient = AWSSecretsManagerClientBuilder.standard().build();

    }
    return secretManagerClient;

  }

}
