package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataSinkEvent {

  @JsonProperty("payloadPath")
  private String payloadPath;

  @JsonProperty("files")
  private String files;

  @JsonProperty("configId")
  private String configId;

  @JsonProperty("retryEnabled")
  private boolean retryEnabled;

  @JsonProperty("eventTime")
  private String eventTime;

  public String getPayloadPath() {
    return payloadPath;
  }

  public void setPayloadPath(String payloadPath) {
    this.payloadPath = payloadPath;
  }

  public String getFiles() {
    return files;
  }

  public void setFiles(String files) {
    this.files = files;
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public boolean isRetryEnabled() {
    return retryEnabled;
  }

  public void setRetryEnabled(boolean retryEnabled) {
    this.retryEnabled = retryEnabled;
  }

  public String getEventTime() {
    return eventTime;
  }

  public void setEventTime(String eventTime) {
    this.eventTime = eventTime;
  }

  @Override
  public String toString() {
    final StringBuffer sb = new StringBuffer("DataSinkEvent{");
    sb.append("payloadPath='").append(payloadPath).append('\'');
    sb.append(", files='").append(files).append('\'');
    sb.append(", configId='").append(configId).append('\'');
    sb.append(", retryEnabled=").append(retryEnabled);
    sb.append(", eventTime='").append(eventTime).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
