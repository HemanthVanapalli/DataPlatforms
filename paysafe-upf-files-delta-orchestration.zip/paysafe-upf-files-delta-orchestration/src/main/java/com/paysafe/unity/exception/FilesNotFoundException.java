package com.paysafe.unity.exception;

public class FilesNotFoundException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 8169105801913680613L;

  public FilesNotFoundException(String message) {
    super(message);
  }

  public FilesNotFoundException(String message, Throwable cause) {
    super(message, cause);

  }

  public FilesNotFoundException(Throwable cause) {
    super(cause);

  }

}
