package com.paysafe.unity.service;

import com.paysafe.unity.model.DataSinkInput;

import java.io.IOException;

public interface DataSinkConfiguration {

  public DataSinkInput getPayload(String s3Path) throws IOException;

  public String getLivyPayloadLocation();

}
