package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FpMetaData {

  @JsonProperty("updatedTime")
  private String updatedTime;

  @JsonProperty("createdTime")
  private String createdTime;
  @JsonProperty("id")
  private String id;
  @JsonProperty("CONFIGID")
  private String configId;

  @JsonProperty("FILESTATUS")
  private String filestatus;

  @JsonProperty("JOBMETADATA")
  private Map<String, String> jobMetadata;

  @JsonProperty("updatedTime")
  public String getUpdatedTime() {
    return updatedTime;
  }

  @JsonProperty("updatedTime")
  public void setUpdatedTime(String updatedTime) {
    this.updatedTime = updatedTime;
  }

  @JsonProperty("createdTime")
  public String getCreatedTime() {
    return createdTime;
  }

  @JsonProperty("createdTime")
  public void setCreatedTime(String createdTime) {
    this.createdTime = createdTime;
  }

  @JsonProperty("id")
  public String getId() {
    return id;
  }

  @JsonProperty("id")
  public void setId(String id) {
    this.id = id;
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public String getFilestatus() {
    return filestatus;
  }

  public void setFilestatus(String filestatus) {
    this.filestatus = filestatus;
  }
  
  
  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

  public Map<String, String> getJobMetaData() {
    return jobMetadata;
  }

}