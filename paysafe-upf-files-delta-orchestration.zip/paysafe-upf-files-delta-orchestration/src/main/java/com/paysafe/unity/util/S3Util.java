package com.paysafe.unity.util;

import com.paysafe.unity.constants.CommonConstants;

import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class S3Util {

  private final AmazonS3 S3_CLIENT = AmazonS3ClientBuilder.standard().withForceGlobalBucketAccessEnabled(true).build();
  private static final String KEY_DELIMITER = "/";

  private Logger logger = Logger.getLogger(S3Util.class.getName());

  public <T> T getObject(String bucket, String key, Class<T> valueType) throws IOException {
    S3Object s3Object = S3_CLIENT.getObject(bucket, key);
    return CommonConstants.MAPPER.readValue(s3Object.getObjectContent(), valueType);
  }

  public boolean putObject(String fileLocation, Object value) {
    AmazonS3URI amazonS3URI = new AmazonS3URI(fileLocation);
    try {
      logger.log(Level.INFO, String.format("Adding object %s",fileLocation));
      S3_CLIENT.putObject(amazonS3URI.getBucket(), amazonS3URI.getKey(),
          CommonConstants.MAPPER.writeValueAsString(value));
    } catch (SdkClientException | JsonProcessingException e) {
      logger.log(Level.SEVERE, String.format("Failed to add object in %s. Exception:%s", fileLocation, e));
      return false;
    }
    return true;

  }

  public List<String> getCommonObjects(String bucket, String prefix) {

    ListObjectsRequest listObjectsRequest =
        new ListObjectsRequest().withBucketName(bucket).withPrefix(prefix).withDelimiter("/");

    ObjectListing objectListing = S3_CLIENT.listObjects(listObjectsRequest);

    return objectListing.getCommonPrefixes();

  }

  /**
   * Method to get list of file names with extensions only in given path. This will return all files even from sub
   * directories.
   */
  public List<String> getFilesList(String bucket, String path) {
    List<String> files = new ArrayList<>();
    List<String> keys = listObjects(bucket, path);
    Predicate<String> endsWithSlash = str -> !str.endsWith(KEY_DELIMITER);
    logger.log(Level.INFO, endsWithSlash.toString());
    keys.stream().filter(endsWithSlash).collect(Collectors.<String>toList())
        .forEach(fileName -> files.add(fileName.substring(fileName.lastIndexOf(KEY_DELIMITER) + 1)));
    return files;
  }

  /**
   * Method to get list of file names without extension only in given path. This will return all files even from sub
   * directories.
   */
  public List<String> getFilesListWithoutExtension(String bucket, String path) {
    List<String> files = new ArrayList<>();
    List<String> keys = listObjects(bucket, path);
    Predicate<String> endsWithSlash = str -> !str.endsWith(KEY_DELIMITER);
    logger.log(Level.INFO, endsWithSlash.toString());
    keys.stream().filter(endsWithSlash).collect(Collectors.<String>toList()).forEach(
        fileName -> files.add(fileName.substring(fileName.lastIndexOf(KEY_DELIMITER) + 1, fileName.lastIndexOf("."))));
    return files;
  }

  public List<String> listObjects(String bucket, String prefix) {
    ObjectListing objectListing = S3_CLIENT.listObjects(bucket, prefix);

    List<String> s3ObjectKeys = new ArrayList<String>();

    do {
      s3ObjectKeys.addAll(objectListing.getObjectSummaries().stream().filter(summary -> summary.getSize() > 0)
          .map(summary -> summary.getKey()).collect(Collectors.toList()));
      objectListing = S3_CLIENT.listNextBatchOfObjects(objectListing);
    } while (objectListing.isTruncated());

    s3ObjectKeys.addAll(objectListing.getObjectSummaries().stream().filter(summary -> summary.getSize() > 0)
        .map(summary -> summary.getKey()).collect(Collectors.toList()));

    return s3ObjectKeys;
  }

  public List<String> listAperiaConfigs(String bucket, String prefix, String filterKey) {
    ObjectListing objectListing = S3_CLIENT.listObjects(bucket, prefix);

    List<String> s3ObjectKeys = new ArrayList<String>();

    do {
      s3ObjectKeys.addAll(objectListing.getObjectSummaries().stream()
          .filter(summary -> (summary.getSize() > 0 && summary.getKey().contains(filterKey)))
          .map(summary -> summary.getKey()).collect(Collectors.toList()));
      objectListing = S3_CLIENT.listNextBatchOfObjects(objectListing);
    } while (objectListing.isTruncated());

    s3ObjectKeys.addAll(objectListing.getObjectSummaries().stream()
        .filter(summary -> summary.getSize() > 0 && summary.getKey().contains(filterKey))
        .map(summary -> summary.getKey()).collect(Collectors.toList()));

    return s3ObjectKeys;
  }

  public <T> T getObject(String fileLocation, Class<T> valueType) throws IOException {
    S3Object s3Object = getS3Object(fileLocation);
    return CommonConstants.MAPPER.readValue(s3Object.getObjectContent(), valueType);
  }

  public String getString(String fileLocation) throws IOException {
    S3Object s3Object = getS3Object(fileLocation);
    return IOUtils.toString(s3Object.getObjectContent());
  }

  public S3Object getS3Object(String fileLocation) {
    AmazonS3URI amazonS3URI = new AmazonS3URI(fileLocation);
    return S3_CLIENT.getObject(amazonS3URI.getBucket(), amazonS3URI.getKey());
  }

  public void deleteDirectory(String rootBucket, String prefix) {
    List<String> list = listObjects(rootBucket, prefix);
    if (list.size() > 0) {
      DeleteObjectsRequest deleteObjectsRequest =
          new DeleteObjectsRequest(rootBucket).withKeys(list.stream().toArray(String[]::new));
      S3_CLIENT.deleteObjects(deleteObjectsRequest);
    }
  }

  public void deleteObject(String rootBucket, String key) {
    S3_CLIENT.deleteObject(rootBucket, key);
  }

  public void deleteObject(String s3Path) {

    AmazonS3URI amazonS3URI = new AmazonS3URI(s3Path);

    deleteObject(amazonS3URI.getBucket(), amazonS3URI.getKey());

  }

  public void copyObject(String s3Bucket, String srcKey, String destBucket, String destKey) {

    S3_CLIENT.copyObject(s3Bucket, srcKey, destBucket, destKey);
  }

  /**
   * Get object from S3 path with given class type.
   *
   * @param fileLocation .
   * @param clazz class type.
   */
  public <T> T getObjectFromJson(final String fileLocation, final Class<T> clazz) throws IOException {
    final AmazonS3URI s3URI = new AmazonS3URI(fileLocation);
    final S3Object s3Object = S3_CLIENT.getObject(s3URI.getBucket(), s3URI.getKey());
    return CommonConstants.MAPPER.readValue(s3Object.getObjectContent(), clazz);
  }

}