package com.paysafe.unity.service.helper;

import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.exception.FilesNotFoundException;
import com.paysafe.unity.model.DataSinkConfig;
import com.paysafe.unity.model.DataSinkInput;
import com.paysafe.unity.model.Path;
import com.paysafe.unity.service.DataSinkPipelineProcessor;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.util.InfrastructureUtil;

import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public abstract class AbstractDataSinkPipelineProcessor implements DataSinkPipelineProcessor {

    protected FileSystemConnector connector;
    protected DataSinkInput dataSinkInput;
    protected InfrastructureUtil infrastructureUtil;

    public AbstractDataSinkPipelineProcessor(FileSystemConnector connector, DataSinkInput dataSinkInput) {
        this.connector = connector;
        this.dataSinkInput = dataSinkInput;
        this.infrastructureUtil = new InfrastructureUtil(connector);
    }

    @Override
    public List<DataSinkConfig> filter(List<DataSinkConfig> configs) throws FilesNotFoundException {
        List<DataSinkConfig> filteredConfigs = configs.stream().parallel()
                .filter(config -> (CollectionUtils.isNotEmpty(config.getArchivedFiles()))).collect(Collectors.toList());
        return filteredConfigs;
    }

    public List<String> buildSrcPath(DataSinkConfig config) {
        List<String> srcFiles = new ArrayList<>();
        List<Path> srcPaths = dataSinkInput.getSrcPaths();
        for (Path srcPath : srcPaths) {
            String prefixPath = srcPath.getPrefix().replace(CommonConstants.CONFIGID_PLACEHOLDER, config.getConfigId());
            String srcPrefix = prefixPath.endsWith(CommonConstants.PATH_DELIMITER) ? prefixPath
                    : prefixPath + CommonConstants.PATH_DELIMITER;
            String paritionColumn = srcPath.getPartitionColumn();
            srcFiles.addAll(config.getArchivedFiles().stream().map(fileName -> {
                return CommonConstants.S3 + LambdaVariables.SRC_BUCKET + CommonConstants.PATH_DELIMITER + srcPrefix +
                        paritionColumn + CommonConstants.EQUALS +
                        fileName
                        + CommonConstants.PATH_DELIMITER;
            }).collect(Collectors.toList()));
        }
        return srcFiles;
    }

}
