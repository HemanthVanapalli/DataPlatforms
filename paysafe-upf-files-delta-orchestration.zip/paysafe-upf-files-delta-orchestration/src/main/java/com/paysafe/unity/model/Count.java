package com.paysafe.unity.model;

public class Count {
  private String parseCount;

  public String getParseCount() {
    return parseCount;
  }

  public void setParseCount(String parseCount) {
    this.parseCount = parseCount;
  }

  private String verticaCount;

  public String getVerticaCount() {
    return verticaCount;
  }

  public void setVerticaCount(String verticaCount) {
    this.verticaCount = verticaCount;
  }

  public Count(String parseCount, String verticaCount) {
    this.parseCount = parseCount;
    this.verticaCount = verticaCount;
  }

}
