package com.paysafe.unity.lambda;

import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.lambda.runtime.Context;
import com.paysafe.unity.AwsConnection;
import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.model.DataSinkMetaDataLog;
import com.paysafe.unity.model.DynamoQuery;
import com.paysafe.unity.model.FpMetaData;
import com.paysafe.unity.model.NotificationDetails;
import com.paysafe.unity.service.FileSystemConnector;
import com.paysafe.unity.service.impl.S3Connector;
import com.paysafe.unity.util.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class DailyProccessedFilesNotification {

    private static final Logger logger =
            Logger.getLogger(DailyProccessedFilesNotification.class.getName());

    public void handleRequest(String inputPath, Context context) throws Exception {

        logger.log(Level.INFO, "inputPayloadPath:  {0}", inputPath);

        try {
            AwsConnection awsConnection = new AwsConnection();
            SesUtils sesUtils = new SesUtils();

            FileSystemConnector fileSystemConnector = new S3Connector(awsConnection);

            AwsSecretsUtil awsSecretsUtil = new AwsSecretsUtil(awsConnection);

            InfrastructureUtil infrastructureUtil = new InfrastructureUtil(fileSystemConnector);

            CommonUtil commonUtil = new CommonUtil();

            Map<String, String> connProperties =
                    commonUtil.fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, LambdaVariables.CLUSTER_NAME);

            DBConnection connection = new DBConnection(connProperties);

            NotificationDetails notificationDetails = fileSystemConnector.getObject(inputPath,
                    NotificationDetails.class);

            String content = prepareContentForDailyFilesNotification(awsConnection, connection,
                    notificationDetails);

            String historicalContent = prepareContentForHistoricalFilesNotification(awsConnection
                    , connection,
                    notificationDetails);

            String notes = "<h3 style='color:#006400;'>Success - Data Loaded to Vertica</h3><ul> " +
                    "<li>FileStatus is ARCHIVED and Record Count in vertica is matching with Record count in s3</li></ul> <h3 style='color:#9B2335;'>Failure - Data Not loaded to Vertica</h3><ul><li>No rows in the table</li><li>FileStatus is not ARCHIVED </li><li>FileStatus is ARCHIVED and Record Count in vertica is null </li><li>File vs Vertica Count column should have the value Matching for all the rows</li></ul>";

            String body = content + historicalContent + notes;
            String subject =
                    "[" + notificationDetails.getUsecase() + "] File Summary on " + LocalDate.now().toString();

            sesUtils.sendSesMail(subject, body, true, notificationDetails.getEmailDetails());

        } catch (Exception ex) {
            logger.log(Level.INFO, "Error occured in DailyProccessedFilesNotification " + ExceptionUtils.getStackTrace(ex));
            SnsUtils snsUtils = new SnsUtils(LambdaVariables.AWS_ENVIRONMENT, LambdaVariables.AWS_ZONE,
                    this.getClass().getName(), CommonConstants.ERROR);
            snsUtils.sendEmail(ExceptionUtils.getStackTrace(ex), null, LambdaVariables.ALERT_SNS_TOPIC_ARN);
            throw ex;
        }
    }

    private String prepareContentForDailyFilesNotification(AwsConnection awsConnection, DBConnection connection, NotificationDetails notificationDetails) throws Exception {
        Map<String, FpMetaData> filesProcessedAtFP =
                queryDynamoForProcessedFiles(notificationDetails.getConfigIds(),
                        notificationDetails.getWindow(), awsConnection);

        Map<String, DataSinkMetaDataLog> filesProcessedAtVertica =
                queryVerticaForProcessedFiles(notificationDetails.getConfigIds(),
                        notificationDetails.getWindow(), connection);


        String heading = "<h3>File Summary on " + LocalDate.now().toString() + "</h3><table " +
                "rules='all' bordercolor='#4d4c4d' border='1' bgcolor='#FFFFFF'  align='center'" +
                "style='width:100%' " +
                " cellspacing='0'>" +
                "<tr><th>FileName</th><th>File status</th><th>Record Count in " +
                "S3</th><th>Record Count in Vertica</th><th>File vs Vertica Count</th></tr>";
        StringBuilder stringBuilder = new StringBuilder(heading);

        for (String file : filesProcessedAtFP.keySet()) {
            FpMetaData fpMetaData = filesProcessedAtFP.get(file);
            DataSinkMetaDataLog verticaMetaData = filesProcessedAtVertica.get(file);

            stringBuilder.append("<tr>");
            stringBuilder.append("<td>" + file + "</td>");

            stringBuilder.append("<td>" + fpMetaData.getFilestatus() + "</td>");
            Map<String, String> jobMetaData = fpMetaData.getJobMetaData();
            String parseCount = convertStringToJson(jobMetaData.get("FPJOB"), "txnCount");
            String fpCountColumn = parseCount != null ? parseCount : "";
            logger.log(Level.INFO, "FPCount obtained for  " + file + " is " + fpCountColumn);
            stringBuilder.append("<td>" + fpCountColumn + "</td>");

            String verticaCountColumn =
                    verticaMetaData != null && verticaMetaData.getRawCount() != null ?
                            verticaMetaData.getRawCount().toString() : "";
            logger.log(Level.INFO, "VerticaCount obtained for  " + file + " is " + verticaCountColumn);
            stringBuilder.append("<td>" + verticaCountColumn + "</td>");

            String countMismatchColumn = fpCountColumn.isEmpty() ||
                    !fpCountColumn.equalsIgnoreCase(verticaCountColumn) ? "Not Matching" : "Matching";
            stringBuilder.append("<td>" + countMismatchColumn + "</td>");
            stringBuilder.append("</tr>");

        }
        stringBuilder.append("</table>");
        return stringBuilder.toString();
    }

    private String prepareContentForHistoricalFilesNotification(AwsConnection awsConnection,
                                                                DBConnection connection, NotificationDetails notificationDetails) throws Exception {

        int window = notificationDetails.getWindow();
        List<String> configIds = notificationDetails.getConfigIds();
        LocalDate lastUpdatedOn = LocalDate.now().minusDays(window);

        if (notificationDetails.getOnboardedDate() != null) {

            String historicalQuery = "select filename, fileDate, fileStatus, recordCountInS3, " +
                    "recordCountInVertica, fpUpdatedTime, verticaUpdatedTime from " +
                    "( select a.CONFIGID as configId, a.FILENAME as filename, a.FILEDATE as fileDate, a.FILESTATUS as fileStatus, a.parsingCount as recordCountInS3, " +
                    "b.RAWCOUNT as recordCountInVertica, a.updatedTime as fpUpdatedTime, b.UPDATEDON as verticaUpdatedTime from " +
                    "( select * from ppbi.fp_metadata where filename not like '%.zip%' and " +
                    "updatedtime < " + "'" + lastUpdatedOn.toString() + "' " + "and filedate >= '" + notificationDetails.getOnboardedDate() + "'" +
                    " ) a left join ( select * from ppbi.DATA_SINK_META_DATA where SOURCE = " + "'VERTICA' and ZONE = 'GREY' and ISCONFORMEDENTRY = false) b " +
                    "on a.FILENAME = b.FILENAME where a.CONFIGID in( '" + String.join("','", configIds) + "') ) temp " +
                    "where (temp.fileStatus not in ('ARCHIVED', 'ROLLBACKED') or (temp.recordCountInVertica is null) or (temp.recordCountInS3 <> temp.recordCountInVertica) ) " +
                    "order by configId,fileDate  asc";

            VerticaUtil verticaUtil = new VerticaUtil(connection);
            List<Map<String, Object>> rows = verticaUtil.fetchRows(historicalQuery);
            logger.log(Level.INFO, "Fetched vertica metadata rows for " + historicalQuery + " : " + rows);


            if (rows != null && rows.size() > 0) {
                String heading = "<h3 style='color:#FF0000;'>Historical files - Need Attention </h3> <table rules='all'" +
                        " " + "bordercolor='#4d4c4d' border='1' bgcolor='#FFFFFF'  align='center'" +
                        "style='width:100%' " +
                        " cellspacing='0'>" +
                        "<tr><th>FileName</th><th>File status</th><th>Record Count in " +
                        "S3</th><th>Record Count in Vertica</th><th>File vs Vertica Count</th></tr>";
                StringBuilder stringBuilder = new StringBuilder(heading);
                for (Map<String, Object> row : rows) {
                    stringBuilder.append("<tr>");
                    String file = row.get("FILENAME").toString();
                    stringBuilder.append("<td>" + file + "</td>");

                    stringBuilder.append("<td>" + row.get("FILESTATUS").toString() + "</td>");

                    String fpCountColumn = row.get("RECORDCOUNTINS3") != null ? row.get(
                            "RECORDCOUNTINS3").toString() : "";
                    logger.log(Level.INFO, "FPCount obtained for  " + file + " is " + fpCountColumn);
                    stringBuilder.append("<td>" + fpCountColumn + "</td>");

                    String verticaCountColumn = row.get("RECORDCOUNTINVERTICA") != null ? row.get(
                            "RECORDCOUNTINVERTICA").toString() : "";
                    logger.log(Level.INFO, "VerticaCount obtained for  " + file + " is " + verticaCountColumn);
                    stringBuilder.append("<td>" + verticaCountColumn + "</td>");

                    String countMismatchColumn = fpCountColumn.isEmpty() ||
                            !fpCountColumn.equalsIgnoreCase(verticaCountColumn) ? "Not Matching" : "Matching";
                    stringBuilder.append("<td>" + countMismatchColumn + "</td>");
                    stringBuilder.append("</tr>");

                }
                stringBuilder.append("</table>");
                return stringBuilder.toString();
            }
        }
        return "";
    }

    private Map<String, FpMetaData> queryDynamoForProcessedFiles(List<String> configIds,
                                                                 int window, AwsConnection awsConnection) throws IOException {
        DynamoDbUtil util = new DynamoDbUtil(awsConnection);

        List<FpMetaData> filesProcessed = new ArrayList<>();
        for (String configId : configIds) {
            DynamoQuery dynamoQuery = buildDynamoQuery(configId, window);
            logger.log(Level.INFO, "DynamoDBQuery for " + configId + " : " + dynamoQuery);
            List<FpMetaData> result = util.queryTable(dynamoQuery);
            logger.log(Level.INFO, "Fetched fp metadata rows for " + configId + " : " + result);
            if (result != null && result.size() > 0)
                filesProcessed.addAll(result);
        }
        Map<String, FpMetaData> filesProcessedAtFP =
                filesProcessed.stream().collect(Collectors.toMap(FpMetaData::getId,
                        Function.identity()));
        logger.log(Level.INFO, "Total files processed at fp end " + filesProcessedAtFP);
        return filesProcessedAtFP;
    }

    private Map<String, DataSinkMetaDataLog> queryVerticaForProcessedFiles(List<String> configIds
            , int window, DBConnection connection) throws Exception {
        LocalDate lastUpdatedOn = LocalDate.now().minusDays(window);
        String query =
                "SELECT CONFIGID, FILENAME, RAWCOUNT, PROCESSEDCOUNT, UPDATEDON, BUSINESSUNIT, FILEDATE, USECASE, SOURCE, ZONE from ppbi.DATA_SINK_META_DATA where " +
                        "configID in ('" + String.join("','", configIds) + "') " +
                        "and SOURCE='VERTICA' and ZONE='GREY' and ISCONFORMEDENTRY = false and  updatedOn >= '" + lastUpdatedOn.toString() + "'";
        VerticaUtil verticaUtil = new VerticaUtil(connection);
        List<Map<String, Object>> rows = verticaUtil.fetchRows(query);
        logger.log(Level.INFO, "Fetched vertica metadata rows for " + query + " : " + rows);
        Map<String, DataSinkMetaDataLog> filesProcessedAtVertica = new HashMap<>();
        if (rows != null && rows.size() > 0)
            rows.forEach(x -> {
                filesProcessedAtVertica.put(x.get("FILENAME").toString(),
                        CommonConstants.MAPPER.convertValue(x, DataSinkMetaDataLog.class));
            });
        logger.log(Level.INFO, "Total files processed at fp end " + filesProcessedAtVertica);
        return filesProcessedAtVertica;
    }


    public DynamoQuery buildDynamoQuery(String configId, int window) {
        LocalDate lastUpdatedOn = LocalDate.now().minusDays(window);
        DynamoQuery dynamoQuery = new DynamoQuery();
        dynamoQuery.setKeyConditionExpression("CONFIGID =:configID and updatedTime >= " +
                ":lastRuntime");
        dynamoQuery.setFilterExpression("FILESTATUS<>:filestatus");

        dynamoQuery.setValueMap(new ValueMap().withString(":configID", configId)
                .withString(":lastRuntime", lastUpdatedOn.toString())
                .withString(":filestatus", CommonConstants.ROLLBACKED_STATUS));
        dynamoQuery.setIndex(LambdaVariables.DYNAMO_INDEX_TIME);
        dynamoQuery.setTable(LambdaVariables.FP_METABATA_TABLE);
        return dynamoQuery;
    }

    public String convertStringToJson(String jsonString, String key) {
        try {
            if (jsonString != null && !jsonString.isEmpty()) {
                JSONObject jsonObject = new JSONObject(jsonString);
                Object o = jsonObject.get(key);
                if (o != null) {
                    return o.toString();
                }
            }
            return null;
        } catch (JSONException err) {
            return null;
        }

    }


}
