package com.paysafe.unity.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.ArrayList;
import java.util.List;

public class DataSinkConfig {

  private String configId;
  private String lastRunDate;
  private String currentRunDate;
  private List<String> rollbackFiles = new ArrayList<>();
  private List<String> archivedFiles = new ArrayList<>();
  private Long jobId;

  public DataSinkConfig(String configId) {

    this.configId = configId;
  }

  public DataSinkConfig() {
  }

  public String getConfigId() {
    return configId;
  }

  public void setConfigId(String configId) {
    this.configId = configId;
  }

  public String getLastRunDate() {
    return lastRunDate;
  }

  public void setLastRunDate(String lastRunDate) {
    this.lastRunDate = lastRunDate;
  }

  public List<String> getRollbackFiles() {
    return rollbackFiles;
  }

  public void setRollbackFiles(List<String> rollbackFiles) {
    this.rollbackFiles = rollbackFiles;
  }

  public List<String> getArchivedFiles() {
    return archivedFiles;
  }

  public void setArchivedFiles(List<String> archivedFiles) {
    this.archivedFiles = archivedFiles;
  }

  public Long getJobId() {
    return jobId;
  }

  public String getCurrentRunDate() {
    return currentRunDate;
  }

  public void setCurrentRunDate(String currentRunDate) {
    this.currentRunDate = currentRunDate;
  }

  public void setJobId(Long jobId) {
    this.jobId = jobId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((configId == null) ? 0 : configId.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    DataSinkConfig other = (DataSinkConfig) obj;
    if (configId == null) {
      if (other.configId != null)
        return false;
    } else if (!configId.equals(other.configId))
      return false;
    return true;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
