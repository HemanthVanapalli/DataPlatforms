package com.paysafe.unity.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Infrastructure implements Serializable {

  private static final long serialVersionUID = 17584595898L;

  private Map<String, List<DataCenter>> environments;

  public List<DataCenter> getDataCenters(final String environment) {
    return environments.get(environment);
  }

  public Map<String, List<DataCenter>> getEnvironments() {
    return environments;
  }

  public void setEnvironments(Map<String, List<DataCenter>> environments) {
    this.environments = environments;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
