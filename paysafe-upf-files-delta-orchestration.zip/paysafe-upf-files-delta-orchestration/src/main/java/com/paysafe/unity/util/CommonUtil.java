package com.paysafe.unity.util;

import com.paysafe.unity.DBConnection;
import com.paysafe.unity.constants.CommonConstants;
import com.paysafe.unity.constants.DBConstants;
import com.paysafe.unity.constants.LambdaVariables;
import com.paysafe.unity.constants.SecretConstants;
import com.paysafe.unity.exception.ClusterException;
import com.paysafe.unity.exception.DataSinkException;
import com.paysafe.unity.model.DataCenter;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

public class CommonUtil {

    private final Logger logger = Logger.getLogger(CommonUtil.class.getName());

    public CommonUtil() {
        super();
    }

    /**
     * Fetches ConnectionProperties for given cluster
     *
     * @param InfrastructureUtil
     * @param AwsSecretsUtil
     * @param clusterName
     * @return map of key,value paris used for connection
     */
    public Map<String, String> fetchConnectionProperties(InfrastructureUtil infrastructureUtil,
                                                         AwsSecretsUtil awsSecretsUtil, String clusterName) throws ClusterException, IOException {

        DataCenter dataCenter = infrastructureUtil.getDataCenter(LambdaVariables.INFRASTRUCTURE_PATH,
                LambdaVariables.CLUSTER_REGION, LambdaVariables.CLUSTER_AVAILABILITY_ZONE, LambdaVariables.CLUSTER_ENVIRONMENT);

        Map<String, String> connectionProperties =
                infrastructureUtil.getClusterConfiguration(LambdaVariables.INFRASTRUCTURE_PATH, clusterName, dataCenter);
        String secretKey = connectionProperties.get(SecretConstants.SECRET_KEY);
        Map<String, String> secretVault = awsSecretsUtil.getSecretsMap(secretKey);
        String userName = secretVault.get(SecretConstants.DB_USER_KEY);
        String passWord = secretVault.get(SecretConstants.DB_PASSWORD_KEY);

        connectionProperties.put(DBConstants.DB_USER, userName);
        connectionProperties.put(DBConstants.DB_PASSWORD, passWord);

        return connectionProperties;
    }

    /**
     * Fetches DBConnection for given cluster
     *
     * @param InfrastructureUtil
     * @param AwsSecretsUtil
     * @param clusterName
     * @return connection
     */
    public DBConnection fetchConnection(InfrastructureUtil infrastructureUtil, AwsSecretsUtil awsSecretsUtil,
                                        String clusterName) throws ClusterException, IOException {
        Map<String, String> connectionProperties =
                fetchConnectionProperties(infrastructureUtil, awsSecretsUtil, clusterName);
        return new DBConnection(connectionProperties);
    }

    /**
     * Convert Resultset into given class
     *
     * @param ResultSet
     * @param Class
     */
    public <T> T convert(ResultSet rs, Class<T> clazz) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int columns = md.getColumnCount();
        Map<String, Object> row = new HashMap<>(columns);
        for (int i = 1; i <= columns; ++i) {
            row.put(md.getColumnName(i), rs.getObject(i));
        }
        return CommonConstants.MAPPER.convertValue(row, clazz);
    }

    /*
     * Clones a map and prefixes the keys in the clone, e.g. for mapping "x" to "env.x" to simulate the behaviour of Ant.
     *
     * @param source the source map
     *
     * @param prefix the prefix used for all names
     *
     * @param <K> the map key type
     *
     * @param <V> the map value type
     *
     * @return the clone of the source map
     */
    public <K, V> Map<String, V> prefix(final Map<K, V> source, final String prefix) {

        if (source == null) {
            return null;
        }

        final Map<String, V> result = new HashMap<String, V>();

        for (final Map.Entry<K, V> entry : source.entrySet()) {
            final K key = entry.getKey();
            final V value = entry.getValue();
            result.put(prefix.toUpperCase() + CommonConstants.UNDERSCORE + key.toString().toUpperCase(), value);
        }

        return result;
    }

    public String constructTemplatePath(boolean oneJobPerConfigId, String configId, String templatePath)
            throws DataSinkException {
        Optional.ofNullable(templatePath)
                .orElseThrow(() -> new DataSinkException("Cannot fetch config json with empty src prefix"));
        String path = CommonConstants.S3 + LambdaVariables.SRC_BUCKET + CommonConstants.PATH_DELIMITER;
        if (oneJobPerConfigId) {
            path += templatePath.endsWith(CommonConstants.PATH_DELIMITER) ? templatePath
                    : templatePath + CommonConstants.PATH_DELIMITER;
            return path + configId + CommonConstants.DOT_JSON;

        } else {
            return path + templatePath;
        }
    }

}
